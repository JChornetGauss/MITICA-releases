@echo off
setlocal EnableDelayedExpansion

:: ============================================================================
:: package.cmd -- Packages MITICA Next for distribution
::
:: Usage: scripts\package.cmd v0.1.0
::
:: What it does:
::   1. Compiles Python code to .pyc (unreadable bytecode)
::   2. Copies only the necessary files to a staging folder
::   3. Generates a ZIP
::   4. Publishes the ZIP to the public MITICA-releases repo on GitHub
::
:: First-time setup on a new machine:
::   Clone MITICA-releases next to MITICA-2.0:
::   git clone https://github.com/JChornetGauss/MITICA-releases.git %USERPROFILE%\Desktop\MITICA-releases
::   Or set MITICA_RELEASES_PATH environment variable to your clone location.
:: ============================================================================

:: Read version from first argument
set VERSION=%1
if "%VERSION%"=="" (
    echo Usage: scripts\package.cmd ^<version^>
    echo Example: scripts\package.cmd v0.1.0
    exit /b 1
)

:: Main paths -- resolve to absolute to avoid PowerShell issues
set ROOT=%~dp0..
for %%i in ("%ROOT%") do set ROOT=%%~fi
set DIST=%ROOT%\dist
set STAGING=%DIST%\staging
set ZIPNAME=mitica_%VERSION%.zip

:: Path to the public releases repo
:: Priority: 1) MITICA_RELEASES_PATH env var, 2) sibling folder on Desktop
if "%MITICA_RELEASES_PATH%"=="" (
    set RELEASES_REPO=%USERPROFILE%\Desktop\MITICA-releases
) else (
    set RELEASES_REPO=%MITICA_RELEASES_PATH%
)

echo.
echo ============================================================
echo   MITICA Next -- Packaging version %VERSION%
echo   Root:          %ROOT%
echo   Output:        %DIST%\%ZIPNAME%
echo   Releases repo: %RELEASES_REPO%
echo ============================================================
echo.

:: ── STEP 1: Compile Python to bytecode ───────────────────────────────────────
:: -b puts .pyc files next to the .py files (not in __pycache__)
:: -q suppresses per-file output
echo [1/5] Compiling Python to bytecode (.pyc)...
"%ROOT%\.venv\Scripts\python.exe" -m compileall "%ROOT%\packages" -b -q
if errorlevel 1 (
    echo ERROR: Python compilation failed.
    exit /b 1
)
echo       OK.

:: ── STEP 2: Clean previous staging folder ────────────────────────────────────
echo [2/5] Preparing staging folder...
if exist "%STAGING%" rmdir /s /q "%STAGING%"
mkdir "%STAGING%"
echo       OK.

:: ── STEP 3: Copy only what is needed ─────────────────────────────────────────
echo [3/5] Copying files...

:: Python packages -- .pyc only, no .py source files
robocopy "%ROOT%\packages" "%STAGING%\packages" /E /XF *.py /NFL /NDL /NJH /NJS

:: Frontend -- exclude node_modules and .next (installed on tester's machine)
robocopy "%ROOT%\apps" "%STAGING%\apps" /E /XD node_modules .next /NFL /NDL /NJH /NJS

:: Launch scripts
robocopy "%ROOT%\scripts" "%STAGING%\scripts" /E /NFL /NDL /NJH /NJS

:: Sample data
robocopy "%ROOT%\sample_data" "%STAGING%\sample_data" /E /NFL /NDL /NJH /NJS

:: Loose config files
copy "%ROOT%\package.json"        "%STAGING%\" >nul
copy "%ROOT%\pyproject.toml"      "%STAGING%\" >nul
copy "%ROOT%\pnpm-workspace.yaml" "%STAGING%\" >nul

echo       OK.

:: ── STEP 4: Create the ZIP ───────────────────────────────────────────────────
echo [4/5] Generating ZIP...
if exist "%DIST%\%ZIPNAME%" del "%DIST%\%ZIPNAME%"

powershell -NoProfile -Command "Compress-Archive -Path '%STAGING%\*' -DestinationPath '%DIST%\%ZIPNAME%' -Force"
if errorlevel 1 (
    echo ERROR: Could not create ZIP.
    exit /b 1
)
if not exist "%DIST%\%ZIPNAME%" (
    echo ERROR: ZIP file was not created.
    exit /b 1
)

:: Clean up staging folder
rmdir /s /q "%STAGING%"
echo       OK.

:: ── STEP 5: Publish ZIP to public releases repo ──────────────────────────────
echo [5/5] Publishing to public releases repo...

:: Verify releases repo exists
if not exist "%RELEASES_REPO%" (
    echo ERROR: Releases repo not found at %RELEASES_REPO%
    echo.
    echo To fix this, run one of:
    echo   git clone https://github.com/JChornetGauss/MITICA-releases.git %USERPROFILE%\Desktop\MITICA-releases
    echo   set MITICA_RELEASES_PATH=^<path to your MITICA-releases clone^>
    exit /b 1
)

:: Copy ZIP to the public repo
copy "%DIST%\%ZIPNAME%" "%RELEASES_REPO%\%ZIPNAME%" >nul
if errorlevel 1 (
    echo ERROR: Could not copy ZIP to releases repo.
    exit /b 1
)

:: Commit and push from the public repo
pushd "%RELEASES_REPO%"
git add "%ZIPNAME%"
git commit -m "Release %VERSION%"
if errorlevel 1 (
    echo WARNING: Nothing to commit - ZIP may already be published.
) else (
    git push origin main
    if errorlevel 1 (
        echo ERROR: Could not push to GitHub.
        popd
        exit /b 1
    )
)
popd

echo.
echo ============================================================
echo   Done!
echo   ZIP: dist\%ZIPNAME%
echo   URL: https://github.com/JChornetGauss/MITICA-releases/raw/main/%ZIPNAME%
echo.
echo   Next steps:
echo   1. Update VERSION and RELEASE_URL in mitica-installer\nsis\mitica_setup.nsi
echo   2. Recompile: cd mitica-installer ^&^& makensis nsis\mitica_setup.nsi
echo   3. Distribute: mitica-installer\dist\MITICA_Next_Setup.exe
echo ============================================================
echo.

endlocal
