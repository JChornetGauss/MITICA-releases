"use client";

import { use } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { ProjectHeader } from "@/components/mitica/ProjectHeader";
import { Stepper } from "@/components/mitica/Stepper";
import { Skeleton } from "@/components/ui/skeleton";

export default function ProjectLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const { data: project, isLoading, error } = useQuery({
    queryKey: ["project", id],
    queryFn: () => api.getProject(id),
    refetchInterval: 5_000, // Reflect job completion / PAM creation promptly
  });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8">
        <Skeleton className="mb-4 h-8 w-1/3" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }
  if (error || !project) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8">
        <p className="text-destructive">Project not found.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <ProjectHeader project={project} />
      <Stepper
        projectId={project.id}
        status={{
          hasInventory: project.has_inventory,
          hasForecast: project.has_forecast,
          pamCount: project.pam_count,
          validatedCount: project.validated_count,
          categoryCount: project.category_count,
        }}
      />
      {children}
    </div>
  );
}
