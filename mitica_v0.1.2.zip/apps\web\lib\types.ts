// TypeScript mirrors of the Pydantic contracts in mitica_core.contracts.
// Keep in sync as the API evolves.

export type Gas =
  | "CO2eq"
  | "CO2"
  | "CH4"
  | "N2O"
  | "SF6"
  | "NF3"
  | "HFCs"
  | "PFCs"
  | "F_gases";

export const NON_AGGREGATE_GASES: Gas[] = ["CO2", "CH4", "N2O", "HFCs", "PFCs", "SF6", "NF3"];

export type ForecastMethod =
  | "ANNALIST"
  | "SARIMAX"
  | "LINREG"
  | "AG"
  | "ThymeBoost";

export type ModifierKind =
  | "AVOID_INCREASE"
  | "AVOID_DECREASE"
  | "AVOID_NEGATIVE"
  | "AVOID_OUTCOMES"
  | "SMOOTH"
  | "ANNUAL_GROWTH"
  | "LINEAL_FIX"
  | "ADJUST_VALUE";

export type ScenarioKind = "WOM" | "WEM" | "WAM";
export type PAMTimeDistribution = "CONSTANT" | "VARIABLE";

export interface Project {
  id: string;
  name: string;
  country_code: string;
  description: string;
  horizon_year: number | null;
  reference_year: number | null;
  created_at: string;
  updated_at: string;
  has_inventory: boolean;
  has_forecast: boolean;
  pam_count: number;
  validated_count: number;
  category_count: number;
  // SI-008 module activation
  use_macro_module: boolean;
  use_energy_module: boolean;
  has_macro_result: boolean;
  has_energy_result: boolean;
}

export interface InventoryRow {
  ipcc_code: string;
  year: number;
  value: number;
  gas: Gas;
}

export interface Inventory {
  country_code: string;
  unit: string;
  start_year: number;
  end_year: number;
  rows: InventoryRow[];
}

export interface ProxyDataset {
  name: string;
  sector: "Energy" | "IPPU" | "LULUCF" | "Agri" | "Waste" | null;
  mandatory: boolean;
  unit: string | null;
  years: number[];
  values: number[];
}

export interface CategoryForecast {
  ipcc_code: string;
  gas: Gas;
  years: number[];
  historical: (number | null)[];
  forecast: (number | null)[];
  reference?: (number | null)[] | null;
  reference_forecast?: (number | null)[] | null;
  proxies_used: string[];
  method: ForecastMethod;
  validated: boolean;
  historical_by_gas: Record<string, (number | null)[]>;
  by_gas: Record<string, (number | null)[]>;
  metadata: Record<string, unknown>;
}

export interface PAMCatalogVariable {
  alias: string;
  name: string;
  unit: string | null;
  default: number | null;
}

export interface PAMCatalogEntry {
  catalog_id: string;
  name: string;
  categories: string[];
  formula: string;
  variables: PAMCatalogVariable[];
}

export type PAMCatalog = Record<string, Record<string, PAMCatalogEntry[]>>;

export interface ProxyCatalogEntry {
  name: string;
  label: string;
  unit: string;
}

export type ProxyCatalog = Record<string, ProxyCatalogEntry[]>;

export interface Forecast {
  config: {
    horizon_year: number;
    reference_year: number | null;
    method: ForecastMethod;
    seed: number | null;
    apply_auto_modifications: boolean;
  };
  last_inventory_year: number;
  categories: CategoryForecast[];
  created_at: string;
  input_hash: string | null;
}

export interface PAMVariable {
  alias: string;
  name: string;
  unit: string | null;
  value: number;
}

export interface PAM {
  id: string;
  name: string;
  category: string;
  scenario: ScenarioKind;
  formula: string;
  variables: PAMVariable[];
  cost_usd_per_ton: number | null;
  time_distribution: PAMTimeDistribution;
  t0: number;
  t1: number | null;
  t2: number | null;
  annual_mitigation_kt: number | null;
  dynamic: boolean;
  notes: string | null;
}

export interface MACCPoint {
  pam_id: string;
  pam_name: string;
  mitigation_kt: number;
  cost_usd: number;
  cost_per_ton: number | null;
}

export interface MACCData {
  sector: string;
  initial_year: number;
  final_year: number;
  points: MACCPoint[];
}

export interface JobStatus {
  id: string;
  project_id: string;
  kind: string;
  status: "pending" | "running" | "done" | "error";
  progress: number;
  message: string;
  result_ref: string | null;
  created_at: string;
  updated_at: string;
}

export interface ScenarioOverview {
  project_id: string;
  years: number[];
  totals: Record<ScenarioKind, number[]>;
  by_sector: Record<string, Record<ScenarioKind, number[]>>;
  by_category: Record<ScenarioKind, Record<string, number[]>>;
}

export interface InventoryUploadResponse {
  project_id: string;
  inventory: Inventory;
  rows: number;
  categories: string[];
}

export interface ProjectCreate {
  name: string;
  country_code?: string;
  description?: string;
  horizon_year?: number | null;
  reference_year?: number | null;
}

export interface ProjectUpdate {
  name?: string;
  country_code?: string;
  description?: string;
  horizon_year?: number | null;
  reference_year?: number | null;
  use_macro_module?: boolean;
  use_energy_module?: boolean;
}

// ---- Targets (BI-003) ---------------------------------------------------

export type TargetType = "PCT_FROM_WOM" | "PCT_FROM_BASE_YEAR" | "ABSOLUTE";
export type TargetScope = "all" | "sector" | "category";

export interface Target {
  id: string;
  name: string;
  type: TargetType;
  target_year: number;
  base_year: number | null;
  pct: number | null;
  absolute_value: number | null;
  scope: TargetScope;
  scope_filter: string | null;
  notes: string | null;
  created_at: string;
}

export interface TargetScenarioEntry {
  value_kt: number | null;
  achieved: boolean | null;
  gap_kt: number | null;
  gap_pct: number | null;
}

export interface TargetEvaluation {
  target_id: string;
  threshold_kt: number;
  scenarios: Record<"WOM" | "WEM" | "WAM", TargetScenarioEntry>;
}

export interface TargetEvaluationEntry {
  target: Target;
  evaluation: TargetEvaluation | null;
  error?: string;
}

export interface TargetEvaluationResponse {
  project_id: string;
  targets: TargetEvaluationEntry[];
}
