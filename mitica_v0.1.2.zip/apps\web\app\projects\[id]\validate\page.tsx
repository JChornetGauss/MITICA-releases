"use client";

import { use, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Wand2, CheckCircle2, Circle, Minus, Plus, TrendingDown, Sigma,
  Target, Settings2, ArrowRight, CheckCheck,
} from "lucide-react";

import { api } from "@/lib/api";
import type { CategoryForecast, ModifierKind } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { GasBreakdown } from "@/components/mitica/GasBreakdown";
import { cn } from "@/lib/utils";

const MODIFIERS: {
  kind: ModifierKind;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}[] = [
  { kind: "AVOID_NEGATIVE", label: "Avoid negative", icon: Plus, description: "Shift negative forecast values up to zero (sectors 1/2/3/5)" },
  { kind: "AVOID_DECREASE", label: "Avoid decrease", icon: TrendingDown, description: "Enforce non-decreasing slope on the forecast" },
  { kind: "AVOID_INCREASE", label: "Avoid increase", icon: Minus, description: "Cap runaway increase at the historical slope" },
  { kind: "AVOID_OUTCOMES", label: "Remove outliers", icon: Sigma, description: "Interpolate values > 1.5σ outside historical mean" },
  { kind: "SMOOTH", label: "Smooth", icon: Wand2, description: "Savitzky-Golay smoothing, preserving historical" },
  { kind: "LINEAL_FIX", label: "Polynomial fit", icon: Settings2, description: "Re-extrapolate historical with a polynomial" },
];

export default function ValidatePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();

  const { data: forecast, isLoading } = useQuery({
    queryKey: ["forecast", id],
    queryFn: () => api.getForecast(id),
    retry: false,
  });

  const [selectedCode, setSelectedCode] = useState<string | null>(null);
  useEffect(() => {
    if (forecast && !selectedCode && forecast.categories.length > 0) {
      setSelectedCode(forecast.categories[0].ipcc_code);
    }
  }, [forecast, selectedCode]);

  const apply = useMutation({
    mutationFn: (kind: ModifierKind) =>
      api.applyModifier(id, { category: selectedCode!, modifier: kind }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const validateOne = useMutation({
    mutationFn: ({ code, validated }: { code: string; validated: boolean }) =>
      api.validateCategory(id, code, validated),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const validateAll = useMutation({
    mutationFn: () => api.validateAll(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const selectedCat: CategoryForecast | undefined = useMemo(() => {
    return forecast?.categories.find((c) => c.ipcc_code === selectedCode);
  }, [forecast, selectedCode]);

  const total = forecast?.categories.length ?? 0;
  const validatedCount = forecast?.categories.filter((c) => c.validated).length ?? 0;
  const allValidated = total > 0 && validatedCount === total;

  if (isLoading)
    return (
      <div className="grid gap-4 md:grid-cols-[260px_1fr]">
        <Skeleton className="h-96" />
        <Skeleton className="h-96" />
      </div>
    );
  if (!forecast)
    return (
      <Card>
        <CardContent className="py-8 text-sm text-muted-foreground">
          No forecast available. Run a forecast first.
        </CardContent>
      </Card>
    );

  // Jump to next unvalidated category after saving
  function goNextUnvalidated() {
    if (!forecast) return;
    const idx = forecast.categories.findIndex((c) => c.ipcc_code === selectedCode);
    const after = forecast.categories.slice(idx + 1);
    const before = forecast.categories.slice(0, idx);
    const next = [...after, ...before].find((c) => !c.validated);
    if (next) setSelectedCode(next.ipcc_code);
  }

  return (
    <div className="space-y-4">
      {/* ---- Progress banner ---- */}
      <Card className={cn(allValidated && "border-emerald-500/40 bg-emerald-500/5")}>
        <CardContent className="flex items-center gap-4 py-4">
          <div className="flex-1">
            <div className="mb-1 flex items-center gap-2 text-sm font-medium">
              <span>Validation progress</span>
              <Badge variant={allValidated ? "success" : "outline"}>
                {validatedCount} / {total}
              </Badge>
            </div>
            <Progress value={total > 0 ? (validatedCount / total) * 100 : 0} />
            <p className="mt-1 text-xs text-muted-foreground">
              Each category must be explicitly validated before moving to PAMs.
              Applying a modifier resets the flag for that category.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => validateAll.mutate()}
            disabled={validateAll.isPending || allValidated}
          >
            <CheckCheck className="mr-2 h-4 w-4" />
            {allValidated ? "All validated" : "Accept all (no changes)"}
          </Button>
          <Button asChild disabled={!allValidated}>
            <Link href={`/projects/${id}/pams`}>
              Next: PAMs <ArrowRight className="ml-2 h-3 w-3" />
            </Link>
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-[260px_1fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle className="text-base">Categories</CardTitle>
            <CardDescription>
              {validatedCount}/{total} validated
            </CardDescription>
          </CardHeader>
          <CardContent className="max-h-[70vh] overflow-y-auto px-2">
            <ul className="space-y-0.5">
              {forecast.categories.map((c) => (
                <li key={c.ipcc_code}>
                  <button
                    className={cn(
                      "flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors",
                      c.ipcc_code === selectedCode
                        ? "bg-primary/10 text-foreground"
                        : "hover:bg-muted"
                    )}
                    onClick={() => setSelectedCode(c.ipcc_code)}
                  >
                    {c.validated ? (
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                    ) : (
                      <Circle className="h-3.5 w-3.5 shrink-0 text-muted-foreground/40" />
                    )}
                    <span className="font-mono text-xs">{c.ipcc_code}</span>
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {selectedCat && (
            <>
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <CardTitle className="font-mono text-base">{selectedCat.ipcc_code}</CardTitle>
                      <CardDescription>
                        Method: {selectedCat.method} · Years {selectedCat.years[0]} –{" "}
                        {selectedCat.years.at(-1)}
                      </CardDescription>
                    </div>
                    {selectedCat.validated ? (
                      <Badge variant="success">Validated ✓</Badge>
                    ) : (
                      <Badge variant="outline">Unvalidated</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <PlotlyChart
                    data={[
                      {
                        x: selectedCat.years,
                        y: selectedCat.historical,
                        type: "scatter",
                        mode: "lines+markers",
                        name: "Historical",
                        line: { color: "#0ea5e9", width: 2 },
                      },
                      {
                        x: selectedCat.years,
                        y: selectedCat.forecast,
                        type: "scatter",
                        mode: "lines+markers",
                        name: "Forecast (WOM)",
                        line: { color: "#0f766e", width: 2, dash: "dot" },
                      },
                    ]}
                    layout={{
                      yaxis: { title: { text: "kt CO₂ eq" } },
                      xaxis: { title: { text: "Year" } },
                    }}
                  />
                  <div className="mt-3 flex items-center justify-end gap-2">
                    {selectedCat.validated ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          validateOne.mutate({
                            code: selectedCat.ipcc_code,
                            validated: false,
                          })
                        }
                      >
                        Un-validate
                      </Button>
                    ) : (
                      <>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() =>
                            validateOne
                              .mutateAsync({
                                code: selectedCat.ipcc_code,
                                validated: true,
                              })
                              .then(() => goNextUnvalidated())
                          }
                          disabled={validateOne.isPending}
                        >
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          Validate + next
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Per-gas breakdown (BI-001) — only when the inventory has multi-gas data */}
              <GasBreakdown category={selectedCat} />

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Modifiers</CardTitle>
                  <CardDescription>
                    Each modifier rewrites this category's forecast and clears the validation flag —
                    re-check the chart before validating.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                    {MODIFIERS.map((m) => {
                      const Icon = m.icon;
                      return (
                        <Button
                          key={m.kind}
                          variant="outline"
                          className="h-auto flex-col items-start gap-1 p-3 text-left"
                          onClick={() => apply.mutate(m.kind)}
                          disabled={apply.isPending}
                        >
                          <div className="flex w-full items-center gap-2">
                            <Icon className="h-4 w-4 text-primary" />
                            <span className="font-medium">{m.label}</span>
                          </div>
                          <p className="text-xs font-normal text-muted-foreground">
                            {m.description}
                          </p>
                        </Button>
                      );
                    })}
                  </div>
                  {apply.error && (
                    <p className="mt-3 text-xs text-destructive">{(apply.error as Error).message}</p>
                  )}

                  <AdjustValuePanel
                    projectId={id}
                    category={selectedCat.ipcc_code}
                    years={selectedCat.years}
                  />
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function AdjustValuePanel({
  projectId,
  category,
  years,
}: {
  projectId: string;
  category: string;
  years: number[];
}) {
  const qc = useQueryClient();
  const [year, setYear] = useState<number>(years.at(-1) ?? 2030);
  const [target, setTarget] = useState<string>("");
  const apply = useMutation({
    mutationFn: () =>
      api.applyModifier(projectId, {
        category,
        modifier: "ADJUST_VALUE",
        params: { year, target_value: Number(target) },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", projectId] });
      qc.invalidateQueries({ queryKey: ["project", projectId] });
    },
  });

  return (
    <div className="mt-4 rounded-md border bg-muted/30 p-3">
      <div className="mb-2 flex items-center gap-2 text-sm font-medium">
        <Target className="h-4 w-4 text-primary" /> Anchor forecast to a target value
      </div>
      <div className="flex flex-wrap items-end gap-2">
        <div>
          <label className="text-xs text-muted-foreground">Year</label>
          <select
            className="block h-9 rounded-md border border-input bg-background px-2 text-sm"
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
          >
            {years.slice(-10).map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Target (kt CO2eq)</label>
          <input
            className="block h-9 w-32 rounded-md border border-input bg-background px-2 text-sm"
            type="number"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder="5000"
          />
        </div>
        <Button size="sm" disabled={!target || apply.isPending} onClick={() => apply.mutate()}>
          Anchor
        </Button>
      </div>
    </div>
  );
}
