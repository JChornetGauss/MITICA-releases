@echo off
rem Helper invoked by start.cmd — runs the API in PRODUCTION mode (no --reload).
rem
rem Differences from _run_api.cmd (dev mode):
rem   - No --reload (no file watching)
rem   - Multiple workers (uses 1 by default; override with MITICA_WORKERS env)
rem   - Proxy headers honoured (so a reverse proxy can sit in front later)

set ROOT=%~dp0..
cd /d "%ROOT%"
title MITICA API (production)

if "%MITICA_WORKERS%"=="" set MITICA_WORKERS=1

echo.
echo [MITICA API] starting uvicorn on http://127.0.0.1:8000  (workers=%MITICA_WORKERS%)
echo.

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -m uvicorn mitica_api.main:app ^
        --host 127.0.0.1 --port 8000 ^
        --workers %MITICA_WORKERS% ^
        --proxy-headers
) else (
    python -m uvicorn mitica_api.main:app ^
        --host 127.0.0.1 --port 8000 ^
        --workers %MITICA_WORKERS% ^
        --proxy-headers
)

echo.
echo [MITICA API] server exited. Press any key to close this window.
pause >nul
