"use client";

import { use } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowRight,
  Upload,
  Zap,
  CheckSquare,
  Lightbulb,
  LineChart,
  Download,
  Activity,
  Power,
  AlertCircle,
} from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Project } from "@/lib/types";

const STEP_CARDS = [
  {
    slug: "upload",
    title: "1. Upload data",
    description:
      "Upload your IPCC inventory (Excel or CRT JSON) and proxy CSVs (GDP, Population, sectoral drivers).",
    icon: Upload,
  },
  {
    slug: "macro",
    title: "· Macroeconomic module",
    description:
      "Optional SI-002 — generates consistent GDP / Population / SGDP / energy-demand proxies for ANNALIST.",
    icon: Activity,
    optional: true,
  },
  {
    slug: "energy",
    title: "· Energy industries module",
    description:
      "Optional SI-003 (IPCC 1A1 only) — merit-order dispatch of public electricity + heat generation. WoM + WM + WAM.",
    icon: Zap,
    optional: true,
  },
  {
    slug: "forecast",
    title: "2. Run the baseline forecast",
    description:
      "Pick a horizon year + method (ANNALIST, AG, LINREG). The backend runs per-category in a background job.",
    icon: Zap,
  },
  {
    slug: "validate",
    title: "3. Validate per category",
    description:
      "Review each IPCC category's historical + forecast, apply modifiers (avoid-negative, smooth, anchor target, …).",
    icon: CheckSquare,
  },
  {
    slug: "pams",
    title: "4. Define Policies & Measures",
    description:
      "Write a formula with variables, pick a time distribution, attach a cost. Safe AST evaluator — no eval().",
    icon: Lightbulb,
  },
  {
    slug: "scenarios",
    title: "5. Compare scenarios",
    description: "Auto-aggregated WOM / WEM / WAM by sector and by category.",
    icon: LineChart,
  },
  {
    slug: "dashboard",
    title: "6. Dashboard & CRT export",
    description:
      "MACC curve + downloadable CRT-shaped Excel for BTR/BUR submission.",
    icon: Download,
  },
];

export default function ProjectOverviewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const { data: project } = useQuery({
    queryKey: ["project", id],
    queryFn: () => api.getProject(id),
  });

  return (
    <div className="space-y-6">
      {project && <ModuleActivationPanel project={project} />}

      <div className="grid gap-4 md:grid-cols-2">
        {STEP_CARDS.map((s) => {
          const Icon = s.icon;
          const isOptional = "optional" in s && s.optional;
          const moduleActive =
            (s.slug === "macro" && project?.use_macro_module) ||
            (s.slug === "energy" && project?.use_energy_module);
          return (
            <Card
              key={s.slug}
              className={`flex flex-col ${isOptional ? "border-dashed bg-muted/20" : ""} ${
                moduleActive ? "ring-1 ring-primary/40" : ""
              }`}
            >
              <CardHeader className="flex-1">
                <div className="mb-2 flex items-start justify-between gap-2">
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-md ${
                      isOptional
                        ? s.slug === "macro"
                          ? "bg-indigo-600/10 text-indigo-600"
                          : "bg-amber-700/10 text-amber-700"
                        : "bg-primary/10 text-primary"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  {moduleActive && (
                    <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary">
                      Active · feeds forecast
                    </span>
                  )}
                </div>
                <CardTitle className="text-base">{s.title}</CardTitle>
                <CardDescription>{s.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="outline" size="sm">
                  <Link href={`/projects/${id}/${s.slug}`}>
                    Open <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {project && (
        <div className="rounded-lg border bg-card p-4 text-sm text-muted-foreground">
          Project <code className="rounded bg-muted px-1">{project.id}</code> — the
          underlying artifacts (inventory, forecast, PAMs) are stored under{" "}
          <code className="rounded bg-muted px-1">data/</code> and indexed in SQLite.
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// SI-008 hand-off: module activation panel
// ----------------------------------------------------------------------------

function ModuleActivationPanel({ project }: { project: Project }) {
  const qc = useQueryClient();

  const patch = useMutation({
    mutationFn: (data: { use_macro_module?: boolean; use_energy_module?: boolean }) =>
      api.patchProject(project.id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["project", project.id] }),
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Power className="h-4 w-4 text-primary" />
          <CardTitle className="text-sm">Modular ecosystem · SI-008 hand-off</CardTitle>
        </div>
        <CardDescription>
          When a module is active the Integration forecast uses its outputs instead of
          ANNALIST for the categories it covers. Per-project — toggle off to fall back.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-3 md:grid-cols-2">
        <ModuleToggle
          projectId={project.id}
          label="Macroeconomic module"
          sublabel="Replaces user proxies with SI-002's coherent set"
          color="indigo"
          icon={<Activity className="h-4 w-4" />}
          enabled={project.use_macro_module}
          resultAvailable={project.has_macro_result}
          missingHref={`/projects/${project.id}/macro`}
          onToggle={(v) => patch.mutate({ use_macro_module: v })}
          isPending={patch.isPending}
        />
        <ModuleToggle
          projectId={project.id}
          label="Energy industries module"
          sublabel="Overrides 1A1a WoM forecast with merit-order dispatch"
          color="amber"
          icon={<Zap className="h-4 w-4" />}
          enabled={project.use_energy_module}
          resultAvailable={project.has_energy_result}
          missingHref={`/projects/${project.id}/energy`}
          onToggle={(v) => patch.mutate({ use_energy_module: v })}
          isPending={patch.isPending}
        />
        {patch.error && (
          <p className="md:col-span-2 text-xs text-destructive">
            {(patch.error as Error).message}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function ModuleToggle({
  label,
  sublabel,
  color,
  icon,
  enabled,
  resultAvailable,
  missingHref,
  onToggle,
  isPending,
}: {
  projectId: string;
  label: string;
  sublabel: string;
  color: "indigo" | "amber";
  icon: React.ReactNode;
  enabled: boolean;
  resultAvailable: boolean;
  missingHref: string;
  onToggle: (v: boolean) => void;
  isPending: boolean;
}) {
  const disabled = !resultAvailable;
  const accentBg =
    color === "indigo" ? "bg-indigo-600/10 text-indigo-700" : "bg-amber-700/10 text-amber-800";
  return (
    <div
      className={`flex items-start gap-3 rounded-md border p-3 transition-colors ${
        enabled ? "border-primary/40 bg-primary/5" : "border-border"
      } ${disabled ? "opacity-70" : ""}`}
    >
      <div className={`mt-0.5 flex h-8 w-8 items-center justify-center rounded ${accentBg}`}>
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm font-medium">{label}</div>
            <div className="truncate text-xs text-muted-foreground">{sublabel}</div>
          </div>
          <button
            type="button"
            aria-label={`${enabled ? "Disable" : "Enable"} ${label}`}
            disabled={disabled || isPending}
            onClick={() => onToggle(!enabled)}
            className={`relative inline-flex h-5 w-9 shrink-0 rounded-full transition-colors ${
              enabled ? "bg-primary" : "bg-muted"
            } ${disabled ? "cursor-not-allowed" : ""}`}
          >
            <span
              className={`absolute top-0.5 h-4 w-4 rounded-full bg-background shadow transition-transform ${
                enabled ? "translate-x-4" : "translate-x-0.5"
              }`}
            />
          </button>
        </div>
        {disabled && (
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-700">
            <AlertCircle className="h-3 w-3" />
            <Link href={missingHref} className="underline underline-offset-2">
              Run this module first
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
