"use client";

import { use, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadBox } from "@/components/mitica/UploadBox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function UploadPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();
  const [uploadedInv, setUploadedInv] = useState(false);
  const { data: project } = useQuery({ queryKey: ["project", id], queryFn: () => api.getProject(id) });
  const { data: proxies } = useQuery({
    queryKey: ["proxies", id],
    // Backend doesn't have a GET /proxies that returns metadata only; we derive from project counts.
    queryFn: () => Promise.resolve(null as null),
    enabled: false,
  });

  async function invalidate() {
    await qc.invalidateQueries({ queryKey: ["project", id] });
    await qc.invalidateQueries({ queryKey: ["projects"] });
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Inventory</CardTitle>
          <CardDescription>
            Three ways to feed MITICA the historical inventory. Pick one — the
            per-gas option is <strong>recommended</strong> because it unlocks
            gas-level projections (BI-001).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <UploadBox
            label="Single file — CO₂-eq aggregate"
            description="One .xlsx with a single sheet: either MITICA template (row 2 = Key Category | Country Code | … | years) or simple shape (ipcc_code | years). Fast to set up; no gas decomposition."
            accept=".xlsx,.xls,.xlsm"
            uploaded={project?.has_inventory || uploadedInv}
            onUpload={async (f) => {
              await api.uploadInventoryExcel(id, f);
              setUploadedInv(true);
              await invalidate();
            }}
          />
          <UploadBox
            label="Single file — multi-gas (MITICA template)"
            description="One .xlsx with one sheet per gas (CO2, CH4, N2O, SF6, NF3, HFC, PFC). Values in kt CO2-eq. Enables per-gas projections with the Σ(gas) = CO2-eq constraint."
            accept=".xlsx,.xls,.xlsm"
            onUpload={async (f) => {
              await api.uploadInventoryExcel(id, f);
              setUploadedInv(true);
              await invalidate();
            }}
          />
          <PerGasUpload projectId={id} onDone={invalidate} />
          <UploadBox
            label="IPCC CRT JSON"
            description="IPCC Inventory Software export (IPCC-CRT-v1.0 schema)."
            accept=".json"
            onUpload={async (f) => {
              await api.uploadInventoryCRT(id, f);
              setUploadedInv(true);
              await invalidate();
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Proxies</CardTitle>
          <CardDescription>
            Two-column file with <code>Year | value</code> (Excel <code>.xlsx</code> or{" "}
            <code>.csv</code>). <strong>GDP</strong> and <strong>population</strong> are mandatory;
            sectoral proxies (VAB, electricity demand, fleet, …) are optional and are matched
            automatically to the sector of each IPCC category.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <UploadBox
            label="GDP (mandatory)"
            description="Year | GDP  (.xlsx or .csv)"
            accept=".xlsx,.xls,.xlsm,.csv"
            onUpload={async (f) => {
              await api.uploadProxy(id, f, { name: "gdp", mandatory: true, unit: "USD" });
              await invalidate();
            }}
          />
          <UploadBox
            label="Population (mandatory)"
            description="Year | Population  (.xlsx or .csv)"
            accept=".xlsx,.xls,.xlsm,.csv"
            onUpload={async (f) => {
              await api.uploadProxy(id, f, { name: "pop", mandatory: true, unit: "people" });
              await invalidate();
            }}
          />
          <SectoralProxyUpload projectId={id} onDone={invalidate} />
        </CardContent>
      </Card>

      <div className="md:col-span-2 flex items-center justify-between rounded-lg border bg-card p-4">
        <div className="flex items-center gap-3 text-sm">
          <Badge variant={project?.has_inventory ? "success" : "outline"}>
            {project?.has_inventory ? "Inventory ✓" : "Inventory missing"}
          </Badge>
          <span className="text-muted-foreground">
            Proxies are persisted separately; at least GDP + Pop are required before forecasting.
          </span>
        </div>
        <Button asChild disabled={!project?.has_inventory}>
          <Link href={`/projects/${id}/forecast`}>
            Next: Forecast <ArrowRight className="ml-2 h-3 w-3" />
          </Link>
        </Button>
      </div>
    </div>
  );
}

const GAS_CHOICES: { value: string; label: string }[] = [
  { value: "CO2", label: "CO₂ — Carbon dioxide" },
  { value: "CH4", label: "CH₄ — Methane" },
  { value: "N2O", label: "N₂O — Nitrous oxide" },
  { value: "HFCs", label: "HFCs — Hydrofluorocarbons (agg.)" },
  { value: "PFCs", label: "PFCs — Perfluorocarbons (agg.)" },
  { value: "SF6", label: "SF₆ — Sulfur hexafluoride" },
  { value: "NF3", label: "NF₃ — Nitrogen trifluoride" },
];

function PerGasUpload({ projectId, onDone }: { projectId: string; onDone: () => void }) {
  const [selectedGas, setSelectedGas] = useState<string>("CO2");
  return (
    <div className="rounded-md border p-3">
      <p className="mb-1 text-sm font-medium">Per-gas files (recommended for BI-001)</p>
      <p className="mb-2 text-xs text-muted-foreground">
        Upload one Excel per gas, tagging it below. Values in <strong>kt CO₂-eq</strong> (mass ×
        GWP). Each new gas is merged into the inventory; re-uploading the same gas overwrites it.
      </p>
      <div className="mb-2">
        <select
          className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          value={selectedGas}
          onChange={(e) => setSelectedGas(e.target.value)}
        >
          {GAS_CHOICES.map((g) => (
            <option key={g.value} value={g.value}>
              {g.label}
            </option>
          ))}
        </select>
      </div>
      <UploadBox
        label={`Upload ${selectedGas} sheet`}
        description="Same v1.1s template layout — col B = IPCC code, cols G+ = years in kt CO2-eq"
        accept=".xlsx,.xls,.xlsm"
        onUpload={async (f) => {
          await api.uploadInventoryGasSheet(projectId, selectedGas, f);
          onDone();
        }}
      />
    </div>
  );
}

function SectoralProxyUpload({ projectId, onDone }: { projectId: string; onDone: () => void }) {
  const { data: proxyCatalog } = useQuery({
    queryKey: ["proxy-catalog"],
    queryFn: () => api.proxyCatalog(),
    staleTime: Infinity,
  });

  const [sector, setSector] = useState<string>("Energy");
  const [preset, setPreset] = useState<string>(""); // selected preset slot name, or "" for custom
  const [customName, setCustomName] = useState<string>("");

  const presets = proxyCatalog?.[sector] ?? [];
  const activeName = preset === "__custom__" ? customName.trim() : preset;
  const activePreset = presets.find((p) => p.name === preset);
  const activeUnit = activePreset?.unit ?? null;

  // Reset preset when sector changes
  useEffect(() => {
    const first = proxyCatalog?.[sector]?.[0]?.name ?? "__custom__";
    setPreset(first);
  }, [sector, proxyCatalog]);

  return (
    <div className="rounded-md border p-3">
      <p className="mb-2 text-sm font-medium">Sectoral proxy (optional)</p>
      <div className="mb-2 grid grid-cols-2 gap-2">
        <select
          className="h-10 rounded-md border border-input bg-background px-3 text-sm"
          value={sector}
          onChange={(e) => setSector(e.target.value)}
        >
          <option value="Energy">Energy</option>
          <option value="IPPU">IPPU</option>
          <option value="LULUCF">LULUCF</option>
          <option value="Agri">Agriculture</option>
          <option value="Waste">Waste</option>
        </select>
        <select
          className="h-10 rounded-md border border-input bg-background px-3 text-sm"
          value={preset}
          onChange={(e) => setPreset(e.target.value)}
        >
          {presets.map((p) => (
            <option key={p.name} value={p.name}>
              {p.label} ({p.unit})
            </option>
          ))}
          <option value="__custom__">— Other (free-form name) —</option>
        </select>
      </div>
      {preset === "__custom__" && (
        <input
          className="mb-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          value={customName}
          onChange={(e) => setCustomName(e.target.value)}
          placeholder="custom proxy name, e.g. 'production_index'"
        />
      )}
      <UploadBox
        label={activeName ? `Upload "${activeName}"` : "Sectoral proxy"}
        description={
          activeName
            ? `Year | ${activeName}${activeUnit ? ` (${activeUnit})` : ""}  —  .xlsx or .csv`
            : "Pick a preset or type a name first"
        }
        accept=".xlsx,.xls,.xlsm,.csv"
        onUpload={async (f) => {
          if (!activeName) throw new Error("Proxy name required — pick a preset or type a custom name");
          await api.uploadProxy(projectId, f, {
            name: activeName,
            sector,
            mandatory: false,
            unit: activeUnit,
          });
          onDone();
        }}
      />
    </div>
  );
}
