"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface Step {
  slug: string;
  title: string;
  subtitle: string;
}

const STEPS: Step[] = [
  { slug: "upload", title: "1 · Upload", subtitle: "Inventory + proxies" },
  { slug: "forecast", title: "2 · Forecast", subtitle: "WOM baseline" },
  { slug: "validate", title: "3 · Validate", subtitle: "Per-category review" },
  { slug: "pams", title: "4 · PAMs", subtitle: "Policies & measures" },
  { slug: "scenarios", title: "5 · Scenarios", subtitle: "WEM / WAM" },
  { slug: "dashboard", title: "6 · Dashboard", subtitle: "Charts + CRT export" },
];

interface StepperProps {
  projectId: string;
  status: {
    hasInventory: boolean;
    hasForecast: boolean;
    pamCount: number;
    validatedCount: number;
    categoryCount: number;
  };
}

function stepDone(slug: string, status: StepperProps["status"]): boolean {
  const allValidated =
    status.categoryCount > 0 && status.validatedCount === status.categoryCount;
  switch (slug) {
    case "upload":
      return status.hasInventory;
    case "forecast":
      return status.hasForecast;
    case "validate":
      return allValidated;
    case "pams":
      return status.pamCount > 0;
    case "scenarios":
    case "dashboard":
      return allValidated && status.pamCount > 0;
    default:
      return false;
  }
}

export function Stepper({ projectId, status }: StepperProps) {
  const pathname = usePathname();

  return (
    <nav aria-label="Workflow steps" className="mb-6 overflow-x-auto">
      <ol className="flex min-w-max items-center gap-1">
        {STEPS.map((s, i) => {
          const active = pathname?.endsWith(`/${s.slug}`);
          const done = stepDone(s.slug, status);
          return (
            <li key={s.slug} className="flex items-center">
              <Link
                href={`/projects/${projectId}/${s.slug}`}
                className={cn(
                  "flex items-center gap-3 rounded-md border px-3 py-2 text-sm transition-colors",
                  active
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border bg-background text-muted-foreground hover:text-foreground"
                )}
              >
                <span
                  className={cn(
                    "flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
                    done
                      ? "bg-primary text-primary-foreground"
                      : active
                      ? "bg-primary/20 text-primary"
                      : "bg-muted text-muted-foreground"
                  )}
                >
                  {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
                </span>
                <div className="hidden text-left sm:block">
                  <p className="font-medium leading-tight">{s.title}</p>
                  <p className="text-[10px] leading-tight text-muted-foreground">{s.subtitle}</p>
                </div>
              </Link>
              {i < STEPS.length - 1 && (
                <span aria-hidden className="mx-1 h-px w-4 bg-border sm:w-6" />
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
