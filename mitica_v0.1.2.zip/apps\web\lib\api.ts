// Typed fetch wrapper. Base URL is relative; next.config.mjs rewrites /api/* to :8000.

import type {
  Forecast,
  InventoryUploadResponse,
  JobStatus,
  MACCData,
  PAM,
  PAMCatalog,
  Project,
  ProjectCreate,
  ProjectUpdate,
  ProxyCatalog,
  ScenarioOverview,
  Target,
  TargetEvaluationResponse,
} from "./types";

const API_PREFIX = "/api/v1";

class ApiError extends Error {
  constructor(public status: number, message: string, public body?: unknown) {
    super(message);
    this.name = "ApiError";
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_PREFIX}${path}`, {
      ...init,
      headers: {
        ...(init?.body && !(init.body instanceof FormData)
          ? { "Content-Type": "application/json" }
          : {}),
        ...init?.headers,
      },
    });
  } catch (e) {
    // Network-level failure — fetch itself threw (DNS, refused, CORS, offline).
    throw new ApiError(
      0,
      `Network error reaching the API. Is http://127.0.0.1:8000 running? (${(e as Error).message})`
    );
  }

  // Read the body exactly once, then decide how to interpret it.
  const rawText = await res.text();

  if (!res.ok) {
    let parsed: unknown = rawText;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      /* keep rawText */
    }
    const detail =
      typeof parsed === "object" && parsed && "detail" in parsed
        ? String((parsed as { detail: unknown }).detail)
        : typeof parsed === "string" && parsed.trim().length > 0
        ? parsed.trim().slice(0, 300)
        : `HTTP ${res.status} ${res.statusText}`.trim();
    throw new ApiError(res.status, detail, parsed);
  }

  // 2xx — may be empty (204-like), text, or JSON.
  const ct = res.headers.get("content-type") ?? "";
  if (rawText.length === 0) return undefined as unknown as T;
  if (ct.includes("application/json")) {
    try {
      return JSON.parse(rawText) as T;
    } catch (e) {
      throw new ApiError(res.status, `Malformed JSON from API: ${(e as Error).message}`);
    }
  }
  return rawText as unknown as T;
}

export const api = {
  // ---- Health
  health: () => request<{ status: string; api_version: string }>("/health"),

  // ---- Projects
  listProjects: () => request<Project[]>("/projects"),
  createProject: (data: ProjectCreate) =>
    request<Project>("/projects", { method: "POST", body: JSON.stringify(data) }),
  getProject: (id: string) => request<Project>(`/projects/${id}`),
  patchProject: (id: string, data: ProjectUpdate) =>
    request<Project>(`/projects/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  deleteProject: (id: string) =>
    request<{ deleted: string }>(`/projects/${id}`, { method: "DELETE" }),

  // ---- Inventory
  uploadInventoryExcel: (projectId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<InventoryUploadResponse>(
      `/projects/${projectId}/inventory/excel`,
      { method: "POST", body: fd }
    );
  },
  uploadInventoryCRT: (projectId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<InventoryUploadResponse>(
      `/projects/${projectId}/inventory/crt-json`,
      { method: "POST", body: fd }
    );
  },
  uploadInventoryGasSheet: (projectId: string, gas: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<InventoryUploadResponse>(
      `/projects/${projectId}/inventory/gas-sheet?gas=${encodeURIComponent(gas)}`,
      { method: "POST", body: fd }
    );
  },

  // ---- Proxies
  uploadProxy: (
    projectId: string,
    file: File,
    opts: {
      name: string;
      sector?: string | null;
      mandatory?: boolean;
      unit?: string | null;
    }
  ) => {
    const fd = new FormData();
    fd.append("file", file);
    const qs = new URLSearchParams();
    qs.set("name", opts.name);
    if (opts.sector) qs.set("sector", opts.sector);
    if (opts.mandatory !== undefined) qs.set("mandatory", String(opts.mandatory));
    if (opts.unit) qs.set("unit", opts.unit);
    return request<{ project_id: string; proxy: unknown }>(
      `/projects/${projectId}/proxies?${qs.toString()}`,
      { method: "POST", body: fd }
    );
  },

  // ---- Forecast
  runForecast: (
    projectId: string,
    data: {
      horizon_year: number;
      reference_year?: number | null;
      method: string;
      apply_auto_modifications?: boolean;
      seed?: number | null;
    }
  ) =>
    request<JobStatus>(`/projects/${projectId}/forecasts/run`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  jobStatus: (projectId: string, jobId: string) =>
    request<JobStatus>(`/projects/${projectId}/forecasts/jobs/${jobId}`),

  getForecast: (projectId: string) =>
    request<Forecast>(`/projects/${projectId}/forecast`),

  // ---- Modifiers
  applyModifier: (
    projectId: string,
    body: { category: string; modifier: string; params?: Record<string, unknown> }
  ) =>
    request<{
      category: string;
      modifier: string;
      years: number[];
      forecast: (number | null)[];
      validated: boolean;
    }>(`/projects/${projectId}/validate/apply-modifier`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  // ---- Validation flags
  validateCategory: (projectId: string, category: string, validated = true) =>
    request<{
      category: string;
      validated: boolean;
      total_categories: number;
      validated_count: number;
    }>(`/projects/${projectId}/validate/category`, {
      method: "POST",
      body: JSON.stringify({ category, validated }),
    }),
  validateAll: (projectId: string) =>
    request<{ total_categories: number; validated_count: number }>(
      `/projects/${projectId}/validate/all`,
      { method: "POST", body: "{}" }
    ),

  // ---- Catalogs
  pamCatalog: () => request<PAMCatalog>("/catalog/pams"),
  proxyCatalog: () => request<ProxyCatalog>("/catalog/proxies"),

  // ---- PAMs
  listPAMs: (projectId: string) => request<PAM[]>(`/projects/${projectId}/pams`),
  createPAM: (projectId: string, pam: PAM) =>
    request<PAM>(`/projects/${projectId}/pams`, {
      method: "POST",
      body: JSON.stringify(pam),
    }),
  deletePAM: (projectId: string, pamId: string) =>
    request<{ deleted: number }>(`/projects/${projectId}/pams/${pamId}`, {
      method: "DELETE",
    }),
  pamSeries: (projectId: string, pamId: string) =>
    request<{ years: number[]; forecast: (number | null)[]; mitigation: (number | null)[] }>(
      `/projects/${projectId}/pams/${pamId}/mitigation-series`
    ),

  // ---- Scenarios + MACC
  scenarios: (projectId: string) =>
    request<ScenarioOverview>(`/projects/${projectId}/scenarios`),
  macc: (projectId: string, sector = "All Sectors") =>
    request<MACCData>(
      `/projects/${projectId}/macc?sector=${encodeURIComponent(sector)}`
    ),

  // ---- Targets (BI-003)
  listTargets: (projectId: string) => request<Target[]>(`/projects/${projectId}/targets`),
  createTarget: (projectId: string, target: Target) =>
    request<Target>(`/projects/${projectId}/targets`, {
      method: "POST",
      body: JSON.stringify(target),
    }),
  deleteTarget: (projectId: string, targetId: string) =>
    request<{ deleted: number }>(`/projects/${projectId}/targets/${targetId}`, {
      method: "DELETE",
    }),
  evaluateTargets: (projectId: string) =>
    request<TargetEvaluationResponse>(`/projects/${projectId}/targets/evaluation`),

  // ---- Macro module (SI-002)
  runMacro: (projectId: string, body: unknown) =>
    request<MacroResult>(`/projects/${projectId}/macro/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getMacroResult: (projectId: string) =>
    request<MacroResult>(`/projects/${projectId}/macro/result`),

  // ---- Energy industries module (SI-003, IPCC 1A1)
  uploadEnergyTemplate: (projectId: string, file: File, countryCode = "UNK") => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("country_code", countryCode);
    return request<EnergyUploadResponse>(
      `/projects/${projectId}/energy/upload`,
      { method: "POST", body: fd }
    );
  },
  runEnergy: (
    projectId: string,
    body: { horizon_year?: number | null; losses_pct?: number; scenarios?: string[] }
  ) =>
    request<EnergyResult>(`/projects/${projectId}/energy/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getEnergySystem: (projectId: string) =>
    request<EnergySystem>(`/projects/${projectId}/energy/system`),
  getEnergyResult: (projectId: string) =>
    request<EnergyResult>(`/projects/${projectId}/energy/result`),

  // PAM CRUD (edit without re-uploading the Excel)
  listEnergyPAMs: (projectId: string) =>
    request<EnergyPAM[]>(`/projects/${projectId}/energy/pams`),
  createEnergyPAM: (projectId: string, body: EnergyPAMInput) =>
    request<EnergyPAM>(`/projects/${projectId}/energy/pams`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  updateEnergyPAM: (projectId: string, pamId: string, body: Partial<EnergyPAMInput>) =>
    request<EnergyPAM>(`/projects/${projectId}/energy/pams/${pamId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),
  deleteEnergyPAM: (projectId: string, pamId: string) =>
    request<{ deleted: number }>(`/projects/${projectId}/energy/pams/${pamId}`, {
      method: "DELETE",
    }),

  // Download URLs — hit them from a regular <a href> so the browser handles the file.
  energyExportJsonUrl: (projectId: string) =>
    `${API_PREFIX}/projects/${projectId}/energy/export.json`,
  energyExportCsvUrl: (projectId: string) =>
    `${API_PREFIX}/projects/${projectId}/energy/export.csv`,

  // ---- Export
  exportCRTUrl: (projectId: string) =>
    `${API_PREFIX}/projects/${projectId}/exports/crt.xlsx`,
};

// ----- Module types -----

export interface MacroResult {
  flow_detected: string;
  horizon_year: number;
  region: string;
  shrinkage: number;
  gdp_tot: Record<string, number>[];
  population: Record<string, number>[];
  sgdp: Record<string, number>[];
  sed: Record<string, number>[];
  sed_hh: Record<string, number>[];
  sgdp_primary_split: Record<string, number>[];
  heads: Record<string, number>[];
  derived: Record<string, number>[];
  parameter_log: { name: string; value: number; origin: string }[];
  validation_report: {
    test_id: string;
    severity: "red" | "amber" | "info";
    variable: string;
    message: string;
    has_proposed_fix: boolean;
  }[];
  annalist_proxies: Record<string, Record<string, number>[]>;
  annalist_proxies_index: string[];
  economic_sectors?: string[];
  energy_sectors?: string[];
  ref?: string;
}

export interface EnergyUploadResponse {
  ref: string;
  country_code: string;
  technologies: string[];
  n_pams: number;
  last_historical_year: number;
  horizon_year: number;
  demand_history_years: number[];
  demand_projection_years: number[];
}

export interface EnergyTechRow {
  name: string;
  capacity_mw: Record<string, number>;
  generation_gwh: Record<string, number>;
  emissions_kt: Record<string, number>;
  input_energy_tj: Record<string, number>;
}

export interface EnergyPAM {
  id?: string;                  // assigned on upload or create; missing on legacy artifacts
  scenario: string;             // "WM" | "WAM"
  technology: string;
  year: number;
  added_mw: number;
  name: string;
  notes: string;
}

export interface EnergyPAMInput {
  scenario: string;             // "WM" | "WAM"
  technology: string;
  year: number;
  added_mw: number;
  name?: string;
  notes?: string;
}

export interface EnergySystem {
  country_code: string;
  technologies: EnergyTechRow[];
  demand_history_gwh: Record<string, number>;
  import_gwh: Record<string, number>;
  export_gwh: Record<string, number>;
  demand_projection_gwh: Record<string, number>;
  pams: EnergyPAM[];
}

export interface EnergyDispatchYear {
  year: number;
  scenario: string;
  generation_gwh: Record<string, number>;
  emissions_kt: Record<string, number>;
  capacity_mw: Record<string, number>;
  unserved_gwh: number;
  total_emissions_kt: number;
  total_generation_gwh: number;
}

export interface EnergyCharacterisation {
  name: string;
  emission_factor_kt_per_gwh: number;
  capacity_factor: number;
  last_capacity_mw: number;
  merit_rank: number;
}

export interface EnergyResult {
  horizon_year: number;
  characterisation: EnergyCharacterisation[];
  dispatch: EnergyDispatchYear[];
  scenario_totals: Record<string, Record<string, number>>;
  merit_order?: string[];
  ref?: string;
}

export { ApiError };
