"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Activity, Play, AlertCircle, CheckCircle2, Info } from "lucide-react";

import { api, type MacroResult } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";

// ---- Parse helpers ---------------------------------------------------------

function parseYVCsv(text: string): { year: number; value: number }[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !/^(year|#)/i.test(l))
    .map((l) => l.split(/[,;\t\s]+/).filter(Boolean))
    .filter((parts) => parts.length >= 2)
    .map((parts) => ({ year: Number(parts[0]), value: Number(parts[1]) }))
    .filter((r) => Number.isFinite(r.year) && Number.isFinite(r.value));
}

function parseSGDPCsv(text: string): { year: number; primary: number; secondary: number; tertiary: number }[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !/^(year|#)/i.test(l))
    .map((l) => l.split(/[,;\t\s]+/).filter(Boolean))
    .filter((parts) => parts.length >= 4)
    .map((parts) => ({
      year: Number(parts[0]),
      primary: Number(parts[1]),
      secondary: Number(parts[2]),
      tertiary: Number(parts[3]),
    }))
    .filter((r) =>
      Number.isFinite(r.year) &&
      Number.isFinite(r.primary) &&
      Number.isFinite(r.secondary) &&
      Number.isFinite(r.tertiary)
    );
}

// ---- Demo data (synthetic LAC-like country) --------------------------------

const DEMO = {
  gdp: Array.from({ length: 18 }, (_, i) => ({ year: 2005 + i, value: 100 + i * 4.7 })),
  pop: Array.from({ length: 18 }, (_, i) => ({ year: 2005 + i, value: 10_000_000 + i * 150_000 })),
  sgdp: Array.from({ length: 18 }, (_, i) => {
    const gdp = 100 + i * 4.7;
    const prim = 0.14 * gdp - i * 0.05;
    const sec = 0.33 * gdp + i * 0.1;
    return { year: 2005 + i, primary: prim, secondary: sec, tertiary: gdp - prim - sec };
  }),
  projGdp: [{ year: 2030, value: 230 }],
};

function toCsv(rows: { year: number; value: number }[]): string {
  return rows.map((r) => `${r.year},${r.value}`).join("\n");
}
function sgdpToCsv(rows: { year: number; primary: number; secondary: number; tertiary: number }[]): string {
  return rows.map((r) => `${r.year},${r.primary.toFixed(2)},${r.secondary.toFixed(2)},${r.tertiary.toFixed(2)}`).join("\n");
}

// ---- Page ------------------------------------------------------------------

export default function MacroModulePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);

  const [region, setRegion] = useState("LAC");
  const [horizon, setHorizon] = useState<number>(2030);
  const [shrinkage, setShrinkage] = useState<number>(0.5);

  const [gdpCsv, setGdpCsv] = useState<string>("");
  const [popCsv, setPopCsv] = useState<string>("");
  const [sgdpCsv, setSgdpCsv] = useState<string>("");
  const [projGdpCsv, setProjGdpCsv] = useState<string>("");

  // Load any existing result (if the user has run it before)
  const existing = useQuery<MacroResult>({
    queryKey: ["macro-result", id],
    queryFn: () => api.getMacroResult(id),
    retry: false,
  });

  const run = useMutation({
    mutationFn: () =>
      api.runMacro(id, {
        region,
        horizon_year: horizon,
        shrinkage,
        gdp_tot: parseYVCsv(gdpCsv),
        population: parseYVCsv(popCsv),
        sgdp: parseSGDPCsv(sgdpCsv),
        proj_gdp_tot: projGdpCsv.trim() ? parseYVCsv(projGdpCsv) : undefined,
      }),
    onSuccess: () => existing.refetch(),
  });

  function fillDemo() {
    setGdpCsv(toCsv(DEMO.gdp));
    setPopCsv(toCsv(DEMO.pop));
    setSgdpCsv(sgdpToCsv(DEMO.sgdp));
    setProjGdpCsv(toCsv(DEMO.projGdp));
    setHorizon(2030);
  }

  const result: MacroResult | undefined = run.data ?? existing.data ?? undefined;

  return (
    <div className="space-y-8">
      <div>
        <div className="mb-2 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-indigo-600">
            <Activity className="h-5 w-5" />
          </div>
          <div>
            <div className="eyebrow">Module · SI-002</div>
            <h2 className="font-serif text-2xl font-[460]">Macroeconomic module</h2>
          </div>
        </div>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Provide historical GDP, Population and sectoral GDP (primary / secondary / tertiary). Optionally fix
          a projected GDP path. The module detects the flow (F1 / F2 / F3), estimates behavioural
          parameters with Bayesian shrinkage toward regional priors, and returns the projected series
          plus a validation report.
        </p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Inputs</CardTitle>
          <Button size="sm" variant="outline" onClick={fillDemo}>
            Use demo data
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label>Region (prior)</Label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
              >
                {["LAC", "SSA", "MENA", "APAC", "EEU", "HIC"].map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Horizon year</Label>
              <Input type="number" value={horizon} onChange={(e) => setHorizon(Number(e.target.value))} />
            </div>
            <div>
              <Label>
                Prior shrinkage (0 = OLS · 1 = prior only): <span className="font-mono">{shrinkage.toFixed(2)}</span>
              </Label>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={shrinkage}
                onChange={(e) => setShrinkage(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <CsvField
              label="GDP_tot (historical)"
              helper="Two columns: year, total GDP. One row per year."
              value={gdpCsv}
              onChange={setGdpCsv}
            />
            <CsvField
              label="Population (historical)"
              helper="Two columns: year, population."
              value={popCsv}
              onChange={setPopCsv}
            />
            <CsvField
              label="SGDP (historical)"
              helper="Four columns: year, primary, secondary, tertiary. Must sum ≈ GDP_tot."
              value={sgdpCsv}
              onChange={setSgdpCsv}
              rows={8}
            />
            <CsvField
              label="Projected GDP_tot — optional"
              helper="Leave empty for F3 (pure-historical projection)."
              value={projGdpCsv}
              onChange={setProjGdpCsv}
              rows={4}
            />
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={() => run.mutate()} disabled={run.isPending || !gdpCsv.trim()}>
              <Play className="mr-2 h-4 w-4" />
              {run.isPending ? "Running…" : "Run macro module"}
            </Button>
            {run.error && <span className="text-sm text-destructive">{(run.error as Error).message}</span>}
            {run.isSuccess && (
              <span className="inline-flex items-center gap-1.5 text-sm text-primary">
                <CheckCircle2 className="h-4 w-4" /> Run complete — flow {result?.flow_detected}
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      {result && <MacroResults result={result} />}
    </div>
  );
}

// ---- CsvField --------------------------------------------------------------

function CsvField({
  label,
  helper,
  value,
  onChange,
  rows = 6,
}: {
  label: string;
  helper?: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
}) {
  return (
    <div>
      <Label>{label}</Label>
      {helper && <p className="mb-1 text-[11px] text-muted-foreground">{helper}</p>}
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        placeholder="2005, 123.4"
        className="w-full resize-y rounded-md border border-input bg-background px-2 py-1.5 font-mono text-xs"
      />
    </div>
  );
}

// ---- Results view ----------------------------------------------------------

function MacroResults({ result }: { result: MacroResult }) {
  const gdpSeries = useMemo(() => {
    const years = result.gdp_tot.map((r) => r.Year);
    const values = result.gdp_tot.map((r) => r.GDP_tot);
    return { years, values };
  }, [result]);

  const popSeries = useMemo(() => {
    const years = result.population.map((r) => r.Year);
    const values = result.population.map((r) => r.Pop);
    return { years, values };
  }, [result]);

  const sgdpShares = useMemo(() => {
    return result.sgdp.map((r) => ({
      year: r.Year as number,
      primary: (r.SGDP_primary / r.GDP_tot) * 100 || (r.SGDP_primary / (r.SGDP_primary + r.SGDP_secondary + r.SGDP_tertiary)) * 100,
      secondary: (r.SGDP_secondary / (r.SGDP_primary + r.SGDP_secondary + r.SGDP_tertiary)) * 100,
      tertiary: (r.SGDP_tertiary / (r.SGDP_primary + r.SGDP_secondary + r.SGDP_tertiary)) * 100,
    }));
  }, [result]);

  const originCounts = useMemo(() => {
    const c = { estimated: 0, adjusted: 0, calibrated: 0 };
    result.parameter_log.forEach((p) => {
      const k = p.origin as keyof typeof c;
      if (k in c) c[k] += 1;
    });
    return c;
  }, [result]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-3">
        <Pill label="Flow" value={result.flow_detected} accent="primary" />
        <Pill label="Region" value={result.region} />
        <Pill label="Horizon" value={String(result.horizon_year)} />
        <Pill label="Estimated" value={String(originCounts.estimated)} />
        <Pill label="Adjusted" value={String(originCounts.adjusted)} />
        <Pill label="Calibrated" value={String(originCounts.calibrated)} />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">GDP_tot & Population</CardTitle>
          </CardHeader>
          <CardContent>
            <PlotlyChart
              height={280}
              data={[
                {
                  x: gdpSeries.years,
                  y: gdpSeries.values,
                  type: "scatter",
                  mode: "lines+markers",
                  name: "GDP_tot",
                  line: { color: "#147A6E", width: 2 },
                },
                {
                  x: popSeries.years,
                  y: popSeries.values,
                  type: "scatter",
                  mode: "lines",
                  name: "Population",
                  yaxis: "y2",
                  line: { color: "#5b6dcd", width: 2, dash: "dot" },
                },
              ]}
              layout={{
                yaxis: { title: "GDP" },
                yaxis2: { overlaying: "y", side: "right", title: "Pop" },
              }}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sectoral GDP shares (%)</CardTitle>
          </CardHeader>
          <CardContent>
            <PlotlyChart
              height={280}
              data={[
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.primary),
                  name: "Primary",
                  type: "scatter",
                  stackgroup: "one",
                  line: { color: "#8a7d5a" },
                },
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.secondary),
                  name: "Secondary",
                  type: "scatter",
                  stackgroup: "one",
                  line: { color: "#147A6E" },
                },
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.tertiary),
                  name: "Tertiary",
                  type: "scatter",
                  stackgroup: "one",
                  line: { color: "#1A2438" },
                },
              ]}
              layout={{ yaxis: { ticksuffix: "%" } }}
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Validation report (Layer C)</CardTitle>
        </CardHeader>
        <CardContent>
          {result.validation_report.length === 0 ? (
            <p className="text-sm text-muted-foreground">No flags raised — all six tests green.</p>
          ) : (
            <ul className="divide-y divide-border text-sm">
              {result.validation_report.map((f, i) => (
                <li key={i} className="flex items-start gap-3 py-2.5">
                  <SeverityIcon severity={f.severity} />
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="font-mono text-xs text-muted-foreground">{f.test_id}</span>
                      <span className="text-sm font-medium">{f.variable}</span>
                      {f.has_proposed_fix && (
                        <span className="rounded-full border border-amber-600/30 bg-amber-600/10 px-2 py-0.5 text-[10px] text-amber-700">
                          retouch available
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{f.message}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Proxies ready for ANNALIST</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-3 text-xs text-muted-foreground">
            These are the proxy series ANNALIST consumes during the Integration Module's WoM forecast.
          </p>
          <div className="flex flex-wrap gap-1.5">
            {result.annalist_proxies_index.map((k) => (
              <code key={k} className="rounded-sm bg-muted px-2 py-0.5 font-mono text-[11px]">
                {k}
              </code>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Pill({ label, value, accent }: { label: string; value: string; accent?: "primary" }) {
  return (
    <div
      className={
        accent === "primary"
          ? "rounded-sm border border-primary/30 bg-primary/5 px-3 py-1.5 text-xs"
          : "rounded-sm border border-border bg-card px-3 py-1.5 text-xs"
      }
    >
      <span className="text-muted-foreground">{label}: </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function SeverityIcon({ severity }: { severity: "red" | "amber" | "info" }) {
  if (severity === "red") return <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />;
  if (severity === "amber") return <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />;
  return <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />;
}
