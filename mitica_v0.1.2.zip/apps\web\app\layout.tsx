import type { Metadata } from "next";
import Link from "next/link";
import { Fraunces, Inter, JetBrains_Mono } from "next/font/google";
import "../styles/globals.css";
import { QueryProvider } from "@/lib/query";
import { cn } from "@/lib/utils";

const fontSans = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const fontSerif = Fraunces({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
  axes: ["opsz", "SOFT"],
});

const fontMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "MITICA Next",
  description: "Mitigation-Inventory Tool for Integrated Climate Action",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={cn(fontSans.variable, fontSerif.variable, fontMono.variable)}>
      <body className="min-h-screen bg-background font-sans text-foreground antialiased">
        <QueryProvider>
          <div className="flex min-h-screen flex-col">
            <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
              <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
                <Link href="/" className="group flex items-center gap-3">
                  <span className="relative flex h-8 w-8 items-center justify-center overflow-hidden rounded-sm bg-primary text-primary-foreground">
                    <span className="font-serif text-base italic leading-none">M</span>
                    <span className="absolute -bottom-0.5 left-1/2 h-0.5 w-2 -translate-x-1/2 bg-primary-foreground/70" />
                  </span>
                  <div className="flex flex-col leading-none">
                    <span className="font-serif text-[17px] font-medium tracking-tight">
                      Mitica
                    </span>
                    <span className="mt-0.5 text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                      by Gauss International
                    </span>
                  </div>
                </Link>

                <nav className="hidden items-center gap-0 md:flex">
                  {[
                    { href: "/modules/macro", label: "Macro" },
                    { href: "/modules/sectoral", label: "Sectoral" },
                    { href: "/projects", label: "Integration" },
                  ].map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="group relative px-4 py-2 text-sm text-foreground/75 transition-colors hover:text-foreground"
                    >
                      {item.label}
                      <span className="pointer-events-none absolute bottom-1 left-1/2 h-[1.5px] w-0 -translate-x-1/2 bg-primary transition-all duration-300 group-hover:w-6" />
                    </Link>
                  ))}
                </nav>

                <div className="flex items-center gap-4">
                  <span className="hidden items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.15em] text-muted-foreground sm:inline-flex">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
                    dev · localhost
                  </span>
                  <a
                    href="/api/v1/docs"
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm text-foreground/75 transition-colors hover:text-foreground"
                  >
                    API docs
                  </a>
                </div>
              </div>
            </header>
            <main className="flex-1">{children}</main>
            <footer className="border-t border-border/60 bg-background/70">
              <div className="mx-auto flex max-w-7xl flex-col items-start gap-6 px-5 py-10 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="font-serif text-base italic text-foreground">
                    Mitica Next
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Mitigation-Inventory Tool for Integrated Climate Action —{" "}
                    <a
                      href="https://gauss-int.com"
                      className="underline decoration-dotted underline-offset-2 hover:text-foreground"
                    >
                      Gauss International Consulting
                    </a>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-5 text-xs text-muted-foreground">
                  <a href="/api/v1/docs" className="hover:text-foreground">
                    API reference
                  </a>
                  <Link href="/modules/macro" className="hover:text-foreground">
                    Macro module
                  </Link>
                  <Link href="/modules/sectoral" className="hover:text-foreground">
                    Sectoral
                  </Link>
                  <Link href="/projects" className="hover:text-foreground">
                    Integration
                  </Link>
                  <span className="font-mono text-[10px] tracking-wider">v0.1 · April 2026</span>
                </div>
              </div>
            </footer>
          </div>
        </QueryProvider>
      </body>
    </html>
  );
}
