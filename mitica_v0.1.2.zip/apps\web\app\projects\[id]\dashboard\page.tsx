"use client";

import { use, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { ReferenceBacktest } from "@/components/mitica/ReferenceBacktest";
import { formatNumber } from "@/lib/utils";

const SECTORS = ["All Sectors", "Energy", "IPPU", "Agriculture", "LULUCF", "Waste"];

export default function DashboardPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [sector, setSector] = useState<string>("All Sectors");
  const { data: project } = useQuery({ queryKey: ["project", id], queryFn: () => api.getProject(id) });

  const { data: macc, isLoading } = useQuery({
    queryKey: ["macc", id, sector],
    queryFn: () => api.macc(id, sector),
    retry: false,
  });
  const { data: scenarios } = useQuery({
    queryKey: ["scenarios", id],
    queryFn: () => api.scenarios(id),
    retry: false,
  });
  const { data: targetsEval } = useQuery({
    queryKey: ["targets-eval", id],
    queryFn: () => api.evaluateTargets(id),
    retry: false,
  });

  // MACC layout: cumulative mitigation on x (bar widths = mitigation_kt), cost on y.
  const maccTraces = (() => {
    if (!macc || macc.points.length === 0) return [];
    let x = 0;
    return macc.points.map((p) => {
      const start = x;
      x += p.mitigation_kt;
      const mid = (start + x) / 2;
      return {
        x: [mid],
        y: [p.cost_per_ton ?? 0],
        width: [p.mitigation_kt],
        name: p.pam_name,
        type: "bar" as const,
        text: [p.pam_name],
        textposition: "inside" as const,
        marker: { line: { width: 1, color: "rgba(0,0,0,0.25)" } },
        hovertemplate: `<b>${p.pam_name}</b><br>Mitigation: ${formatNumber(p.mitigation_kt)} kt<br>Cost: $${formatNumber(p.cost_per_ton ?? 0)}/t<extra></extra>`,
      };
    });
  })();

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-semibold">Dashboard</h2>
        <div className="flex items-center gap-2">
          <select
            className="h-9 rounded-md border border-input bg-background px-3 text-sm"
            value={sector}
            onChange={(e) => setSector(e.target.value)}
          >
            {SECTORS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <Button asChild>
            <a href={api.exportCRTUrl(id)} download>
              <Download className="mr-2 h-4 w-4" /> Export CRT (.xlsx)
            </a>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>MACC curve — {sector}</CardTitle>
          <CardDescription>
            Each bar = one PAM. Width = cumulative mitigation (kt CO₂eq). Height = cost per ton.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-80" />
          ) : maccTraces.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              No costed PAMs in this sector — define one on the PAMs step with a cost.
            </p>
          ) : (
            <PlotlyChart
              height={420}
              data={maccTraces}
              layout={{
                barmode: "overlay",
                yaxis: { title: { text: "USD / tCO₂eq" } },
                xaxis: { title: { text: "Cumulative mitigation (kt CO₂eq)" } },
                showlegend: false,
              }}
            />
          )}
        </CardContent>
      </Card>

      {scenarios && (
        <Card>
          <CardHeader>
            <CardTitle>Scenario totals</CardTitle>
            <CardDescription>
              Totals across all sectors · WOM / WEM / WAM.
              {targetsEval && targetsEval.targets.length > 0 && (
                <> Dashed red lines = your defined targets (BI-003).</>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <PlotlyChart
              data={[
                ...(["WOM", "WEM", "WAM"] as const).map((k) => ({
                  x: scenarios.years,
                  y: scenarios.totals[k],
                  type: "scatter" as const,
                  mode: "lines+markers" as const,
                  name: k,
                })),
                ...((targetsEval?.targets ?? [])
                  .filter((t) => t.evaluation != null && t.target.scope === "all")
                  .map((t) => ({
                    x: [t.target.target_year],
                    y: [t.evaluation!.threshold_kt],
                    type: "scatter" as const,
                    mode: "markers+text" as const,
                    name: t.target.name,
                    marker: { color: "#ef4444", symbol: "diamond" as const, size: 12 },
                    text: [t.target.name],
                    textposition: "top center" as const,
                  }))),
              ]}
              layout={{
                shapes: (targetsEval?.targets ?? [])
                  .filter((t) => t.evaluation != null && t.target.scope === "all")
                  .map((t) => ({
                    type: "line" as const,
                    x0: scenarios.years[0],
                    x1: scenarios.years.at(-1)!,
                    y0: t.evaluation!.threshold_kt,
                    y1: t.evaluation!.threshold_kt,
                    line: { color: "rgba(239,68,68,0.35)", width: 1, dash: "dash" as const },
                  })),
              }}
            />
          </CardContent>
        </Card>
      )}

      <ReferenceBacktest projectId={id} referenceYear={project?.reference_year ?? null} />
    </div>
  );
}
