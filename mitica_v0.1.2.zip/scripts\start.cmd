@echo off
rem ============================================================================
rem MITICA Next - production launcher.
rem
rem Spawns two child windows (API + Web frontend) in production mode.
rem Close either window or run scripts\stop.cmd to stop the stack.
rem
rem Usage:
rem   scripts\start.cmd
rem ============================================================================

setlocal
set ROOT=%~dp0..
pushd "%ROOT%"

rem --- pre-flight checks ----------------------------------------------------
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo  ERROR: .venv\Scripts\python.exe missing.
    echo  Run scripts\install.cmd first.
    echo.
    pause
    popd
    endlocal
    exit /b 1
)

if not exist "apps\web\.next\BUILD_ID" (
    echo.
    echo  ERROR: apps\web\.next is missing.
    echo  Run scripts\install.cmd first.
    echo.
    pause
    popd
    endlocal
    exit /b 1
)

rem --- free the ports if something is left running --------------------------
echo [start] Checking ports 8000 + 3000 ...
call "%~dp0stop.cmd" >nul 2>nul

rem --- launch API in its own window -----------------------------------------
echo [start] Launching API on http://127.0.0.1:8000 ...
start "MITICA API" cmd /k call "%~dp0_run_api_prod.cmd"

rem --- short pause so the API binds before the web tries to proxy to it -----
ping -n 3 127.0.0.1 >nul

rem --- launch Web in its own window -----------------------------------------
echo [start] Launching Web on http://localhost:3000 ...
start "MITICA Web" cmd /k call "%~dp0_run_web_prod.cmd"

rem --- background browser opener (waits for :3000 then opens the page) ------
start "" /min cmd /c call "%~dp0open_browser.cmd"

echo.
echo ============================================================================
echo  MITICA Next is starting.
echo.
echo    Web UI    http://localhost:3000
echo    API docs  http://127.0.0.1:8000/api/v1/docs
echo.
echo  Close the two windows or run scripts\stop.cmd to stop.
echo ============================================================================
echo.

popd
endlocal
exit /b 0
