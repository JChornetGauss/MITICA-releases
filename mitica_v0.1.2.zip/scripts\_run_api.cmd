@echo off
rem Helper invoked by dev.cmd — runs the API in its own window.
rem Kept separate so dev.cmd does not have to nest quotes.

set ROOT=%~dp0..
cd /d "%ROOT%"
title MITICA API
echo [MITICA API] starting uvicorn on http://127.0.0.1:8000 ...
echo.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -m uvicorn mitica_api.main:app --reload --host 127.0.0.1 --port 8000
) else (
    python -m uvicorn mitica_api.main:app --reload --host 127.0.0.1 --port 8000
)
echo.
echo [MITICA API] server exited. Press any key to close this window.
pause >nul
