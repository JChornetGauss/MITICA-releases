"use client";

import { use, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = {
  WOM: "#b91c1c",
  WEM: "#059669",
  WAM: "#0f766e",
};

export default function ScenariosPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, isLoading, error } = useQuery({
    queryKey: ["scenarios", id],
    queryFn: () => api.scenarios(id),
    retry: false,
  });

  const [sector, setSector] = useState<string>("all");

  const sectors = useMemo(() => Object.keys(data?.by_sector ?? {}), [data]);

  if (isLoading) return <Skeleton className="h-96" />;
  if (error || !data)
    return (
      <Card>
        <CardContent className="py-8 text-sm text-muted-foreground">
          Run the forecast first to see scenarios.
        </CardContent>
      </Card>
    );

  const activeSeries = sector === "all" ? data.totals : data.by_sector[sector];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Scenarios WOM / WEM / WAM</CardTitle>
          <CardDescription>
            WEM = WOM − ∑(WEM PAMs). WAM = WOM − ∑(WEM+WAM PAMs). Aggregations come from
            <code className="ml-1">mitica_core.scenarios</code>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={sector} onValueChange={setSector}>
            <TabsList>
              <TabsTrigger value="all">All sectors</TabsTrigger>
              {sectors.map((s) => (
                <TabsTrigger key={s} value={s}>
                  {s}
                </TabsTrigger>
              ))}
            </TabsList>
            <TabsContent value={sector} className="mt-4">
              <PlotlyChart
                data={(["WOM", "WEM", "WAM"] as const).map((k) => ({
                  x: data.years,
                  y: activeSeries[k],
                  type: "scatter",
                  mode: "lines+markers",
                  name: k,
                  line: { color: COLORS[k], width: k === "WOM" ? 2 : 2.5 },
                }))}
                layout={{
                  yaxis: { title: { text: "kt CO₂ eq" } },
                  xaxis: { title: { text: "Year" } },
                }}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
