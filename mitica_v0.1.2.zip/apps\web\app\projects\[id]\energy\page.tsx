"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Zap, Play, CheckCircle2, Plus, Pencil, Trash2, Check, X, Download } from "lucide-react";

import {
  api,
  type EnergyPAM,
  type EnergyPAMInput,
  type EnergyResult,
  type EnergySystem,
  type EnergyUploadResponse,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { UploadBox } from "@/components/mitica/UploadBox";

const SCENARIO_COLORS: Record<string, string> = {
  WoM: "#1A2438",
  WM: "#147A6E",
  WAM: "#8a7d5a",
};

export default function EnergyModulePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);

  const [horizon, setHorizon] = useState<string>("");
  const [losses, setLosses] = useState<number>(0);

  const system = useQuery<EnergySystem>({
    queryKey: ["energy-system", id],
    queryFn: () => api.getEnergySystem(id),
    retry: false,
  });
  const result = useQuery<EnergyResult>({
    queryKey: ["energy-result", id],
    queryFn: () => api.getEnergyResult(id),
    retry: false,
  });

  const upload = useMutation({
    mutationFn: (file: File) => api.uploadEnergyTemplate(id, file),
    onSuccess: () => system.refetch(),
  });

  const run = useMutation({
    mutationFn: () =>
      api.runEnergy(id, {
        horizon_year: horizon ? Number(horizon) : null,
        losses_pct: losses,
        scenarios: ["WoM", "WM", "WAM"],
      }),
    onSuccess: () => result.refetch(),
  });

  const sys = system.data;
  const res = run.data ?? result.data;

  return (
    <div className="space-y-8">
      <div>
        <div className="mb-2 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-amber-700">
            <Zap className="h-5 w-5" />
          </div>
          <div>
            <div className="eyebrow">Module · SI-003 · IPCC 1A1</div>
            <h2 className="font-serif text-2xl font-[460]">Energy industries module</h2>
          </div>
        </div>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Merit-order dispatch of <em>public electricity and heat generation</em> (IPCC 1A1a/b/c only —
          not 1A2 manufacturing, not 1A3 transport). Upload the legacy Excel template{" "}
          <code className="rounded bg-muted px-1 font-mono">templates.xlsx</code> — sheets
          <em> System / Supply / Proyection / PAM_Energia</em> — and the module will derive
          per-technology emission factor and capacity factor, then project WoM, WM and WAM
          trajectories. Activating the module in a project overrides ANNALIST for category 1A1a.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">1. Upload the Energy template</CardTitle>
        </CardHeader>
        <CardContent>
          <UploadBox
            label={sys ? "Template uploaded" : "Choose templates.xlsx"}
            description="Legacy Energy module layout (Tecnologia × Data type × year matrix)."
            accept=".xlsx,.xlsm,.xls"
            onUpload={async (file) => {
              await upload.mutateAsync(file);
            }}
            uploaded={Boolean(sys)}
          />
          {upload.error && (
            <p className="mt-2 text-sm text-destructive">{(upload.error as Error).message}</p>
          )}
          {sys && (
            <SystemSummary
              projectId={id}
              system={sys}
              uploadResp={upload.data ?? undefined}
            />
          )}
        </CardContent>
      </Card>

      {sys && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">2. Run the dispatch</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <Label>Horizon year (optional)</Label>
                <Input
                  type="number"
                  placeholder={`default: ${sys.demand_projection_gwh && Object.keys(sys.demand_projection_gwh).length ? Math.max(...Object.keys(sys.demand_projection_gwh).map(Number)) : ""}`}
                  value={horizon}
                  onChange={(e) => setHorizon(e.target.value)}
                />
              </div>
              <div>
                <Label>
                  Transmission losses:{" "}
                  <span className="font-mono">{losses.toFixed(1)}%</span>
                </Label>
                <input
                  type="range"
                  min={0}
                  max={20}
                  step={0.5}
                  value={losses}
                  onChange={(e) => setLosses(Number(e.target.value))}
                  className="w-full"
                />
              </div>
              <div className="self-end">
                <Button onClick={() => run.mutate()} disabled={run.isPending}>
                  <Play className="mr-2 h-4 w-4" />
                  {run.isPending ? "Dispatching…" : "Run WoM + WM + WAM"}
                </Button>
              </div>
            </div>
            {run.error && <p className="text-sm text-destructive">{(run.error as Error).message}</p>}
            {run.isSuccess && (
              <p className="inline-flex items-center gap-1.5 text-sm text-primary">
                <CheckCircle2 className="h-4 w-4" /> Dispatch complete — horizon {run.data.horizon_year}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {res && <EnergyResults projectId={id} result={res} />}
    </div>
  );
}

// ----------------------------------------------------------------------------

function SystemSummary({
  projectId,
  system,
  uploadResp,
}: {
  projectId: string;
  system: EnergySystem;
  uploadResp?: EnergyUploadResponse;
}) {
  const techs = system.technologies.map((t) => t.name);
  const histYears = Object.keys(system.demand_history_gwh).map(Number).sort((a, b) => a - b);
  const projYears = Object.keys(system.demand_projection_gwh).map(Number).sort((a, b) => a - b);
  const lastHist = uploadResp?.last_historical_year ?? (histYears.at(-1) ?? 0);

  return (
    <div className="mt-5 space-y-4">
      <div className="flex flex-wrap gap-3">
        <Pill label="Country" value={system.country_code} />
        <Pill label="Techs" value={String(techs.length)} />
        <Pill label="PAMs" value={String(system.pams.length)} />
        <Pill label="Last hist" value={String(lastHist)} />
        {projYears.length > 0 && (
          <Pill label="Projection" value={`${projYears[0]} → ${projYears.at(-1)}`} />
        )}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {techs.map((t) => (
          <code key={t} className="rounded-sm bg-muted px-2 py-0.5 font-mono text-[11px]">
            {t}
          </code>
        ))}
      </div>
      <PAMEditor projectId={projectId} system={system} />
    </div>
  );
}

// Palette for the stacked per-tech charts — deterministic from the tech
// name so the same colour maps across all three charts.
const TECH_PALETTE = [
  "#147A6E", // Gauss teal (primary)
  "#1A2438", // Gauss navy
  "#8a7d5a", // warm earth
  "#5b6dcd", // indigo
  "#c97064", // terracotta
  "#3ea99f", // teal mid
  "#b08a3e", // mustard
  "#6e7aa0", // slate
  "#94634c", // sienna
  "#44756c", // moss
];

function colorForTech(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) | 0;
  }
  return TECH_PALETTE[Math.abs(hash) % TECH_PALETTE.length];
}

function EnergyResults({ projectId, result }: { projectId: string; result: EnergyResult }) {
  const scenarios = Object.keys(result.scenario_totals);
  const years = useMemo(
    () => Array.from(new Set(result.dispatch.map((d) => d.year))).sort((a, b) => a - b),
    [result.dispatch]
  );

  // Selected scenario for the three stacked charts (default first = WoM).
  const [selectedScen, setSelectedScen] = useState<string>(scenarios[0] ?? "WoM");

  // Per-scenario total emissions trajectory (the top chart — always shows all 3).
  const totalTrace = scenarios.map((scen) => {
    const m = result.scenario_totals[scen] || {};
    return {
      x: years,
      y: years.map((y) => m[String(y)] ?? null),
      type: "scatter" as const,
      mode: "lines+markers" as const,
      name: scen,
      line: { color: SCENARIO_COLORS[scen] || "#666", width: 2 },
    };
  });

  // Dispatches for the selected scenario, sorted by year.
  const rowsForScen = useMemo(
    () => result.dispatch.filter((d) => d.scenario === selectedScen).sort((a, b) => a.year - b.year),
    [result.dispatch, selectedScen]
  );

  // Union of tech names in the selected scenario (covers new techs added via PAMs).
  const techs = useMemo(
    () =>
      Array.from(
        new Set(rowsForScen.flatMap((d) => [
          ...Object.keys(d.emissions_kt),
          ...Object.keys(d.generation_gwh),
          ...Object.keys(d.capacity_mw),
        ]))
      ),
    [rowsForScen]
  );

  // Sort techs by merit rank so the stack ordering matches the dispatch order.
  const rankByName = Object.fromEntries(result.characterisation.map((c) => [c.name, c.merit_rank]));
  const orderedTechs = [...techs].sort(
    (a, b) => (rankByName[a] ?? 999) - (rankByName[b] ?? 999)
  );

  function stackedBy(field: "emissions_kt" | "generation_gwh" | "capacity_mw") {
    return orderedTechs.map((t) => ({
      x: rowsForScen.map((d) => d.year),
      y: rowsForScen.map((d) => (d as any)[field][t] ?? 0),
      name: t,
      type: "bar" as const,
      marker: { color: colorForTech(t) },
    }));
  }

  const emisStack = stackedBy("emissions_kt");
  const genStack = stackedBy("generation_gwh");
  const capStack = stackedBy("capacity_mw");

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Scenario comparison — total emissions (kt CO₂-eq)</CardTitle>
          <div className="flex gap-2">
            <a
              href={api.energyExportCsvUrl(projectId)}
              className="inline-flex items-center gap-1.5 rounded-sm border border-border bg-card px-3 py-1.5 text-xs font-medium hover:border-foreground/40"
            >
              <Download className="h-3.5 w-3.5" /> CSV
            </a>
            <a
              href={api.energyExportJsonUrl(projectId)}
              className="inline-flex items-center gap-1.5 rounded-sm border border-border bg-card px-3 py-1.5 text-xs font-medium hover:border-foreground/40"
            >
              <Download className="h-3.5 w-3.5" /> JSON
            </a>
          </div>
        </CardHeader>
        <CardContent>
          <PlotlyChart height={340} data={totalTrace} layout={{ yaxis: { title: "kt CO₂-eq" } }} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Per-technology stack — {selectedScen}</CardTitle>
          <div className="flex overflow-hidden rounded-sm border border-border text-xs">
            {scenarios.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSelectedScen(s)}
                className={
                  s === selectedScen
                    ? "bg-primary px-3 py-1 font-medium text-primary-foreground"
                    : "bg-card px-3 py-1 text-muted-foreground hover:bg-muted"
                }
              >
                {s}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <StackedChartBlock
            title="Capacity (MW)"
            note="WoM holds last-historical capacity constant. WM/WAM add cumulative PAM capacity each year."
            data={capStack}
            unit="MW"
          />
          <StackedChartBlock
            title="Generation (GWh)"
            note="Dispatched output per technology, capped by capacity × CF × 8760 h."
            data={genStack}
            unit="GWh"
          />
          <StackedChartBlock
            title="Emissions (kt CO₂-eq)"
            note="Generation × emission factor. Renewables contribute 0."
            data={emisStack}
            unit="kt CO₂-eq"
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Technology characterisation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs text-muted-foreground">
                <tr>
                  <th className="px-2 py-1.5 text-left">Rank</th>
                  <th className="px-2 py-1.5 text-left">Technology</th>
                  <th className="px-2 py-1.5 text-right">EF (kt/GWh)</th>
                  <th className="px-2 py-1.5 text-right">CF</th>
                  <th className="px-2 py-1.5 text-right">Cap (MW)</th>
                </tr>
              </thead>
              <tbody>
                {result.characterisation.map((c) => (
                  <tr key={c.name} className="border-t border-border">
                    <td className="px-2 py-1.5 font-mono text-xs">{c.merit_rank}</td>
                    <td className="px-2 py-1.5">
                      <span
                        className="inline-block h-2 w-2 rounded-full align-middle"
                        style={{ backgroundColor: colorForTech(c.name) }}
                      />{" "}
                      <span className="font-mono text-xs">{c.name}</span>
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono text-xs">
                      {c.emission_factor_kt_per_gwh.toFixed(4)}
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono text-xs">
                      {c.capacity_factor.toFixed(3)}
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono text-xs">
                      {c.last_capacity_mw.toFixed(0)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <UnservedNote result={result} />
    </div>
  );
}

function StackedChartBlock({
  title,
  note,
  data,
  unit,
}: {
  title: string;
  note: string;
  data: unknown[];
  unit: string;
}) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <div className="font-serif text-sm font-medium">{title}</div>
        <div className="text-[11px] text-muted-foreground">{note}</div>
      </div>
      <PlotlyChart
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data={data as any}
        height={280}
        layout={{ barmode: "stack", yaxis: { title: unit }, legend: { orientation: "h", y: -0.25 } }}
      />
    </div>
  );
}

function UnservedNote({ result }: { result: EnergyResult }) {
  const withUnserved = result.dispatch.filter((d) => d.unserved_gwh > 1);
  if (withUnserved.length === 0) return null;
  const byScenario: Record<string, number> = {};
  withUnserved.forEach((d) => {
    byScenario[d.scenario] = (byScenario[d.scenario] ?? 0) + d.unserved_gwh;
  });
  return (
    <Card className="border-amber-600/30 bg-amber-600/5">
      <CardContent className="py-4 text-sm">
        <p className="mb-1 font-medium">Unserved demand detected</p>
        <p className="text-muted-foreground">
          Projected demand exceeds the dispatchable stack in some years. Add capacity through PAMs to close the gap.
        </p>
        <ul className="mt-2 text-xs">
          {Object.entries(byScenario).map(([scen, gwh]) => (
            <li key={scen}>
              <span className="font-mono">{scen}</span>: {gwh.toFixed(0)} GWh unserved over the horizon
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

function Pill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-sm border border-border bg-card px-3 py-1.5 text-xs">
      <span className="text-muted-foreground">{label}: </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

// ----------------------------------------------------------------------------
// PAM Editor — CRUD without re-uploading the Excel template.
// ----------------------------------------------------------------------------

function PAMEditor({ projectId, system }: { projectId: string; system: EnergySystem }) {
  const qc = useQueryClient();
  const techNames = system.technologies.map((t) => t.name);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const pams = useQuery<EnergyPAM[]>({
    queryKey: ["energy-pams", projectId],
    queryFn: () => api.listEnergyPAMs(projectId),
    initialData: system.pams as EnergyPAM[],
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["energy-pams", projectId] });
    qc.invalidateQueries({ queryKey: ["energy-system", projectId] });
  };

  const create = useMutation({
    mutationFn: (body: EnergyPAMInput) => api.createEnergyPAM(projectId, body),
    onSuccess: () => {
      invalidate();
      setCreating(false);
    },
  });

  const update = useMutation({
    mutationFn: ({ id, body }: { id: string; body: Partial<EnergyPAMInput> }) =>
      api.updateEnergyPAM(projectId, id, body),
    onSuccess: () => {
      invalidate();
      setEditingId(null);
    },
  });

  const del = useMutation({
    mutationFn: (pamId: string) => api.deleteEnergyPAM(projectId, pamId),
    onSuccess: invalidate,
  });

  const rows = pams.data ?? [];
  const sortedTechs = [...new Set([...techNames, ...rows.map((p) => p.technology)])];

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <div className="eyebrow">PAMs by scenario</div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setCreating(true);
            setEditingId(null);
          }}
          disabled={creating}
        >
          <Plus className="mr-1 h-3 w-3" /> Add PAM
        </Button>
      </div>
      <div className="overflow-hidden rounded-sm border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-1.5 text-left">Scenario</th>
              <th className="px-3 py-1.5 text-left">Technology</th>
              <th className="px-3 py-1.5 text-right">Year</th>
              <th className="px-3 py-1.5 text-right">MW added</th>
              <th className="px-3 py-1.5 text-left">Name</th>
              <th className="px-3 py-1.5 text-right"></th>
            </tr>
          </thead>
          <tbody>
            {creating && (
              <PAMRowEditor
                techs={sortedTechs}
                initial={{
                  scenario: "WM",
                  technology: techNames[0] ?? "",
                  year: new Date().getFullYear() + 1,
                  added_mw: 0,
                  name: "",
                  notes: "",
                }}
                onSave={(body) => create.mutate(body)}
                onCancel={() => setCreating(false)}
                saving={create.isPending}
              />
            )}
            {rows.map((p) =>
              editingId === p.id ? (
                <PAMRowEditor
                  key={p.id ?? `${p.scenario}-${p.technology}-${p.year}`}
                  techs={sortedTechs}
                  initial={{
                    scenario: p.scenario,
                    technology: p.technology,
                    year: p.year,
                    added_mw: p.added_mw,
                    name: p.name ?? "",
                    notes: p.notes ?? "",
                  }}
                  onSave={(body) => update.mutate({ id: p.id!, body })}
                  onCancel={() => setEditingId(null)}
                  saving={update.isPending}
                />
              ) : (
                <tr
                  key={p.id ?? `${p.scenario}-${p.technology}-${p.year}`}
                  className="border-t border-border"
                >
                  <td className="px-3 py-1.5">
                    <span
                      className={
                        p.scenario === "WAM"
                          ? "rounded bg-amber-700/10 px-1.5 py-0.5 text-xs text-amber-800"
                          : "rounded bg-primary/10 px-1.5 py-0.5 text-xs text-primary"
                      }
                    >
                      {p.scenario}
                    </span>
                  </td>
                  <td className="px-3 py-1.5 font-mono text-xs">{p.technology}</td>
                  <td className="px-3 py-1.5 text-right font-mono">{p.year}</td>
                  <td className="px-3 py-1.5 text-right font-mono">
                    {p.added_mw.toFixed(0)}
                  </td>
                  <td className="px-3 py-1.5 text-xs text-muted-foreground">{p.name}</td>
                  <td className="px-3 py-1.5 text-right">
                    <div className="flex justify-end gap-1">
                      <button
                        type="button"
                        aria-label="Edit PAM"
                        className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"
                        disabled={!p.id || del.isPending}
                        onClick={() => {
                          setEditingId(p.id ?? null);
                          setCreating(false);
                        }}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label="Delete PAM"
                        className="rounded p-1 text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-50"
                        disabled={!p.id || del.isPending}
                        onClick={() => {
                          if (p.id && confirm(`Delete PAM "${p.name || p.technology}"?`)) {
                            del.mutate(p.id);
                          }
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              )
            )}
            {rows.length === 0 && !creating && (
              <tr>
                <td colSpan={6} className="px-3 py-4 text-center text-xs text-muted-foreground">
                  No PAMs yet. Click "Add PAM" to create one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {(create.error || update.error || del.error) && (
        <p className="mt-2 text-xs text-destructive">
          {(create.error as Error | null)?.message ??
            (update.error as Error | null)?.message ??
            (del.error as Error | null)?.message}
        </p>
      )}
      <p className="mt-2 text-[11px] text-muted-foreground">
        Adding a PAM here updates <code className="rounded bg-muted px-1 font-mono">system.json</code>{" "}
        immediately. Re-run the dispatch to see it reflected in the charts.
      </p>
    </div>
  );
}

function PAMRowEditor({
  techs,
  initial,
  onSave,
  onCancel,
  saving,
}: {
  techs: string[];
  initial: EnergyPAMInput;
  onSave: (body: EnergyPAMInput) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [scenario, setScenario] = useState(initial.scenario);
  const [technology, setTechnology] = useState(initial.technology);
  const [year, setYear] = useState<number>(initial.year);
  const [mw, setMw] = useState<number>(initial.added_mw);
  const [name, setName] = useState(initial.name ?? "");

  const canSave = technology.trim().length > 0 && mw >= 0 && year > 1990;

  return (
    <tr className="border-t border-border bg-primary/5">
      <td className="px-3 py-1.5">
        <select
          value={scenario}
          onChange={(e) => setScenario(e.target.value)}
          className="h-7 rounded-sm border border-input bg-background px-1 text-xs"
        >
          <option value="WM">WM</option>
          <option value="WAM">WAM</option>
        </select>
      </td>
      <td className="px-3 py-1.5">
        <input
          list="energy-tech-options"
          value={technology}
          onChange={(e) => setTechnology(e.target.value)}
          className="h-7 w-full rounded-sm border border-input bg-background px-2 font-mono text-xs"
          placeholder="e.g. Solar"
        />
        <datalist id="energy-tech-options">
          {techs.map((t) => (
            <option key={t} value={t} />
          ))}
        </datalist>
      </td>
      <td className="px-3 py-1.5 text-right">
        <input
          type="number"
          value={year}
          onChange={(e) => setYear(Number(e.target.value))}
          className="h-7 w-20 rounded-sm border border-input bg-background px-1 text-right font-mono text-xs"
        />
      </td>
      <td className="px-3 py-1.5 text-right">
        <input
          type="number"
          step="any"
          value={mw}
          onChange={(e) => setMw(Number(e.target.value))}
          className="h-7 w-24 rounded-sm border border-input bg-background px-1 text-right font-mono text-xs"
        />
      </td>
      <td className="px-3 py-1.5">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Optional label"
          className="h-7 w-full rounded-sm border border-input bg-background px-2 text-xs"
        />
      </td>
      <td className="px-3 py-1.5 text-right">
        <div className="flex justify-end gap-1">
          <button
            type="button"
            aria-label="Save PAM"
            className="rounded p-1 text-primary hover:bg-primary/10 disabled:opacity-50"
            disabled={!canSave || saving}
            onClick={() =>
              onSave({ scenario, technology: technology.trim(), year, added_mw: mw, name })
            }
          >
            <Check className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Cancel"
            className="rounded p-1 text-muted-foreground hover:bg-muted"
            disabled={saving}
            onClick={onCancel}
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}
