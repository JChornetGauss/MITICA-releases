@echo off
rem Helper invoked by start.cmd -- runs the Next frontend in PRODUCTION mode.
rem
rem Works both in dev mode (node in PATH) and in installed mode (portable tools).
rem All paths are relative to this script -- no hardcoded paths.
rem
rem Folder structure:
rem   <INSTDIR>\
rem     app\
rem       scripts\        <- this script (%~dp0)
rem       apps\web\       <- Next.js app
rem       node_modules\   <- installed Node dependencies
rem     tools\
rem       pnpm.exe        <- portable pnpm
rem       node\           <- portable Node.js

setlocal EnableDelayedExpansion

rem Resolve paths relative to this script -- works on any machine
rem %~dp0 = <INSTDIR>\app\scripts\
for %%i in ("%~dp0..") do set "APP_DIR=%%~fi"
for %%i in ("%~dp0..\..") do set "INSTDIR=%%~fi"

set "TOOLS_DIR=!INSTDIR!\tools"
set "NODE_EXE=!TOOLS_DIR!\node\node.exe"
set "NEXT_BIN=!APP_DIR!\node_modules\.bin\next"

cd /d "!APP_DIR!\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd first.
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

rem Installed mode: call node.exe directly with the next binary path.
rem This bypasses pnpm entirely so there are no PATH issues at all.
if exist "!NODE_EXE!" (
    "!NODE_EXE!" "!NEXT_BIN!" start -p 3000
) else (
    rem Dev mode: node and pnpm are in the system PATH
    call pnpm start
)

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul

endlocal
