@echo off
rem Helper invoked by start.cmd -- runs the Next frontend in PRODUCTION mode.
rem
rem Works both in dev mode (pnpm/node in PATH) and in installed mode (portable tools).
rem All paths are relative to this script's location -- no hardcoded paths.
rem
rem Folder structure assumed by this script:
rem   <INSTDIR>\
rem     app\
rem       scripts\        <- this script lives here (%~dp0)
rem       apps\web\       <- Next.js app
rem     tools\
rem       pnpm.exe        <- portable pnpm (installed mode)
rem       node\           <- portable Node.js (installed mode)

setlocal EnableDelayedExpansion

rem Resolve the tools folder relative to this script
rem %~dp0 = <INSTDIR>\app\scripts\  (always ends with \)
rem going up two levels: scripts\ -> app\ -> <INSTDIR>\
set "TOOLS_DIR=%~dp0..\..\tools"

rem Resolve to absolute path to avoid any ambiguity
for %%i in ("%TOOLS_DIR%") do set "TOOLS_DIR=%%~fi"

set "PNPM_EXE=%TOOLS_DIR%\pnpm.exe"
set "NODE_DIR=%TOOLS_DIR%\node"

rem Navigate to the web app folder
set "ROOT=%~dp0.."
for %%i in ("%ROOT%") do set "ROOT=%%~fi"
cd /d "%ROOT%\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd first.
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

rem Installed mode: portable pnpm.exe exists in tools\
rem Inject portable node into PATH so "next start" can find node.exe internally
if exist "!PNPM_EXE!" (
    set "PATH=!NODE_DIR!;%PATH%"
    "!PNPM_EXE!" start
) else (
    rem Dev mode: pnpm and node are already in the system PATH
    call pnpm start
)

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul

endlocal
