@echo off
rem MITICA Next -- stop whatever is on :8000 and :3000.
rem
rem Works both in dev mode (node in PATH) and in installed mode (portable node).
rem
rem Path logic:
rem   %~dp0 = this script's folder = $INSTDIR\app\scripts\
rem   %~dp0..\..\  = $INSTDIR\
rem   $INSTDIR\tools\node\node.exe = portable node installed by the MITICA installer

set ROOT=%~dp0..
pushd "%ROOT%"

rem Try portable node first (installed mode), then fall back to system node (dev mode)
if exist "%~dp0..\..\tools\node\node.exe" (
    "%~dp0..\..\tools\node\node.exe" scripts\stop.mjs
) else (
    node scripts\stop.mjs
)

popd
