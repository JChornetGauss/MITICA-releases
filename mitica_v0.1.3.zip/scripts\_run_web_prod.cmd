@echo off
rem Helper invoked by start.cmd -- runs the Next frontend in PRODUCTION mode.
rem
rem Works both in dev mode (pnpm in PATH) and in installed mode (portable pnpm).
rem
rem Path logic:
rem   %~dp0 = this script's folder = $INSTDIR\app\scripts\
rem   %~dp0..\..\  = $INSTDIR\
rem   $INSTDIR\tools\pnpm.exe = portable pnpm installed by the MITICA installer

set ROOT=%~dp0..
cd /d "%ROOT%\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd first.
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

rem Try portable pnpm first (installed mode), then fall back to system pnpm (dev mode)
if exist "%~dp0..\..\tools\pnpm.exe" (
    "%~dp0..\..\tools\pnpm.exe" start
) else (
    call pnpm start
)

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul
