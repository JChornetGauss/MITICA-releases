@echo off
rem Helper invoked by start.cmd -- runs the Next frontend in PRODUCTION mode.
rem
rem Works on any machine -- uses portable Node from tools\ folder.
rem All paths are relative to this script -- no hardcoded paths.
rem
rem Folder structure:
rem   <INSTDIR>\
rem     app\
rem       scripts\              <- this script (%~dp0)
rem       apps\
rem         web\
rem           .next\            <- production build
rem           node_modules\
rem             .bin\
rem               next.cmd      <- next binary for Windows (next is bash, next.cmd is Windows)
rem     tools\
rem       node\                 <- portable Node.js

setlocal EnableDelayedExpansion

rem Resolve paths relative to this script
rem %~dp0 = <INSTDIR>\app\scripts\
for %%i in ("%~dp0..") do set "APP_DIR=%%~fi"
for %%i in ("%~dp0..\..") do set "INSTDIR=%%~fi"

set "NODE_EXE=!INSTDIR!\tools\node\node.exe"

rem On Windows the correct binary is next.cmd not next (next is a bash script)
set "NEXT_BIN=!APP_DIR!\apps\web\node_modules\.bin\next.cmd"

cd /d "!APP_DIR!\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd first.
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

rem Installed mode: inject portable node into PATH and call next.cmd directly
rem next.cmd internally calls node, which it will find via the injected PATH
if exist "!NODE_EXE!" (
    set "PATH=!INSTDIR!\tools\node;%PATH%"
    call "!NEXT_BIN!" start -p 3000
) else (
    rem Dev mode fallback: use system pnpm
    call pnpm start
)

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul

endlocal
