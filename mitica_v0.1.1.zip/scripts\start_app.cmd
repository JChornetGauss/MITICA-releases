@echo off
:: start_app.cmd
:: This script lives in scripts\ inside the ZIP.
:: When called from Start MITICA.cmd in $INSTDIR, %~dp0 points to scripts\
:: so we go up one level to reach the app root.
cd /d "%~dp0.."
if not exist "scripts\start.cmd" (
    echo ERROR: MITICA Next is not installed correctly.
    echo Expected to find scripts\start.cmd in %CD%
    pause
    exit /b 1
)
call scripts\start.cmd
