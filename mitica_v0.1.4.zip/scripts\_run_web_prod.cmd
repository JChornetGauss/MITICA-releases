@echo off
rem Helper invoked by start.cmd -- runs the Next frontend in PRODUCTION mode.
rem
rem Works both in dev mode (pnpm/node in PATH) and in installed mode (portable tools).
rem
rem Path logic:
rem   %~dp0 = this script folder = $INSTDIR\app\scripts\
rem   %~dp0..\..\ = $INSTDIR\
rem   $INSTDIR\tools\pnpm.exe  = portable pnpm
rem   $INSTDIR\tools\node\     = portable Node.js (needed by next start internally)

set ROOT=%~dp0..
cd /d "%ROOT%\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd first.
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

rem Installed mode: use portable pnpm and inject portable node into PATH
rem so that "next start" (called by pnpm start internally) can find node.exe
if exist "%~dp0..\..\tools\pnpm.exe" (
    cmd /c "set "PATH=%~dp0..\..\tools\node;%PATH%" && "%~dp0..\..\tools\pnpm.exe" start"
) else (
    rem Dev mode: pnpm and node are already in the system PATH
    call pnpm start
)

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul
