@echo off
rem Helper invoked by start.cmd — runs the Next frontend in PRODUCTION mode.
rem
rem Requires that scripts\install.cmd has already done `pnpm build` so that
rem apps\web\.next\BUILD_ID is present.
rem
rem Uses the portable pnpm.exe and Node bundled by the installer so that this
rem works on machines that have no system-wide pnpm / Node installation.
rem   Installer layout:
rem     $INSTDIR\tools\pnpm.exe
rem     $INSTDIR\tools\node\
rem     $INSTDIR\app\scripts\_run_web_prod.cmd  <- this file

setlocal EnableDelayedExpansion

rem ── Locate portable tools relative to this script ────────────────────────
rem   %~dp0 = <INSTDIR>\app\scripts\
set TOOLS=%~dp0..\..\tools
set PNPM=%TOOLS%\pnpm.exe
set NODE_DIR=%TOOLS%\node

rem ── Fall back to system pnpm if the portable one is missing ──────────────
rem   (allows developers to run directly from the source repo)
if not exist "%PNPM%" (
    where pnpm >nul 2>&1
    if errorlevel 1 (
        echo.
        echo [MITICA Web] ERROR: pnpm not found.
        echo              Expected portable pnpm at: %PNPM%
        echo              And no system pnpm in PATH either.
        echo.
        pause
        exit /b 1
    )
    set PNPM=pnpm
)

rem ── Inject portable Node into PATH so pnpm can find node.exe ─────────────
if exist "%NODE_DIR%\node.exe" (
    set "PATH=%NODE_DIR%;!PATH!"
)

set ROOT=%~dp0..
cd /d "%ROOT%\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd  (or  cd apps\web ^&^& pnpm build^).
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

call "%PNPM%" start

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul
