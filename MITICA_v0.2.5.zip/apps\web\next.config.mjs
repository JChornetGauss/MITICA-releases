import path from "node:path";

// The Next dev server proxies /api/* to the FastAPI backend. In dev we talk
// to 127.0.0.1:8000 directly; in Docker we talk to the service name on the
// compose network. Override via MITICA_API_URL when needed.
const API_URL = process.env.MITICA_API_URL ?? "http://127.0.0.1:8000";

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Silence the "multiple lockfiles detected" warning in monorepo root
  outputFileTracingRoot: path.resolve(process.cwd(), "../.."),
  // CRT JSON files from the IPCC Inventory Software can exceed the 10 MB
  // default body limit that Next.js applies to its rewrite proxy. Raise it
  // to 100 MB — FastAPI imposes its own limit on the other side.
  experimental: {
    proxyClientMaxBodySize: "100mb",
  },
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: `${API_URL}/api/:path*`,
      },
    ];
  },
};

export default nextConfig;
