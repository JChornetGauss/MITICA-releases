@echo off
setlocal EnableDelayedExpansion

:: ============================================================================
:: package.cmd — Packages MITICA Next for distribution
::
:: Usage: scripts\package.cmd v0.1.0
::
:: What it does:
::   1. Compiles Python code to .pyc (unreadable bytecode)
::   2. Copies only the necessary files to a staging folder
::   3. Generates a ZIP ready to upload to GitHub Releases
:: ============================================================================

:: Read version from first argument
set VERSION=%1
if "%VERSION%"=="" (
    echo Usage: scripts\package.cmd ^<version^>
    echo Example: scripts\package.cmd v0.1.0
    exit /b 1
)

:: Main paths — use absolute paths to avoid PowerShell resolution issues
set ROOT=%~dp0..
for %%i in ("%ROOT%") do set ROOT=%%~fi
set DIST=%ROOT%\dist
set STAGING=%DIST%\staging
set ZIPNAME=mitica_%VERSION%.zip

echo.
echo ============================================================
echo   MITICA Next -- Packaging version %VERSION%
echo   Root:    %ROOT%
echo   Staging: %STAGING%
echo   Output:  %DIST%\%ZIPNAME%
echo ============================================================
echo.

:: ── STEP 1: Compile Python to bytecode ───────────────────────────────────────
echo [1/4] Compiling Python to bytecode (.pyc)...
"%ROOT%\.venv\Scripts\python.exe" -m compileall "%ROOT%\packages" -b -q
if errorlevel 1 (
    echo ERROR: Python compilation failed.
    exit /b 1
)
echo       OK.

:: ── STEP 2: Clean previous staging folder ────────────────────────────────────
echo [2/4] Preparing staging folder...
if exist "%STAGING%" rmdir /s /q "%STAGING%"
mkdir "%STAGING%"
echo       OK.

:: ── STEP 3: Copy only what is needed ─────────────────────────────────────────
echo [3/4] Copying files...

:: Python packages -- .pyc only, no .py source files
robocopy "%ROOT%\packages" "%STAGING%\packages" /E /XF *.py /NFL /NDL /NJH /NJS

:: Frontend -- exclude node_modules and .next (installed on tester's machine)
robocopy "%ROOT%\apps" "%STAGING%\apps" /E /XD node_modules .next /NFL /NDL /NJH /NJS

:: Launch scripts
robocopy "%ROOT%\scripts" "%STAGING%\scripts" /E /NFL /NDL /NJH /NJS

:: Sample data
robocopy "%ROOT%\sample_data" "%STAGING%\sample_data" /E /NFL /NDL /NJH /NJS

:: Loose config files
copy "%ROOT%\package.json"        "%STAGING%\" >nul
copy "%ROOT%\pyproject.toml"      "%STAGING%\" >nul
copy "%ROOT%\pnpm-workspace.yaml" "%STAGING%\" >nul

echo       OK.

:: ── STEP 4: Create the ZIP ───────────────────────────────────────────────────
echo [4/4] Generating ZIP...
if exist "%DIST%\%ZIPNAME%" del "%DIST%\%ZIPNAME%"

powershell -NoProfile -Command "Compress-Archive -Path '%STAGING%\*' -DestinationPath '%DIST%\%ZIPNAME%' -Force"
if errorlevel 1 (
    echo ERROR: Could not create ZIP. PowerShell exit code: %errorlevel%
    exit /b 1
)

:: Verify ZIP was created
if not exist "%DIST%\%ZIPNAME%" (
    echo ERROR: ZIP file was not created.
    exit /b 1
)

:: Clean up staging folder
rmdir /s /q "%STAGING%"

:: ── STEP 5: Publish ZIP to public releases repo ──────────────────────────────
echo [5/5] Publishing to public releases repo...

:: Copy ZIP to the public repo
copy "%DIST%\%ZIPNAME%" "C:\Users\Trabajo\Desktop\MITICA-releases\%ZIPNAME%" >nul

:: Commit and push from the public repo
pushd "C:\Users\Trabajo\Desktop\MITICA-releases"
git add "%ZIPNAME%"
git commit -m "Release %VERSION%"
git push origin main
popd

echo       ZIP published to MITICA-releases.
echo       Download URL: https://github.com/JChornetGauss/MITICA-releases/raw/main/%ZIPNAME%

echo.
echo ============================================================
echo   ZIP ready: dist\%ZIPNAME%
echo   Next step: scripts\release.cmd %VERSION%
echo ============================================================
echo.

endlocal