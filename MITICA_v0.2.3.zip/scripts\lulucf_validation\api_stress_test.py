"""
api_stress_test.py
==================

Rigorous stress / simulation harness for the LULUCF **HTTP boundary**
(``packages/api/src/mitica_api/routers/lulucf.py``).

The PAM and WoM harnesses drive the *engine*. This one drives the real
FastAPI app end-to-end via an in-process ASGI transport (no sockets, no
uvicorn) — exactly the path a focal point's browser hits. The point is to
confirm the production HTTP contract:

  * a well-formed upload returns **200** with finite outputs;
  * EVERY malformed upload returns a clean **422** (the router maps
    ``ValueError`` / ``KeyError`` from the engine, and Pydantic maps schema
    violations) — **never an opaque 500** and never a silent 200;
  * project / scenario lookups return **404** when absent;
  * a hostile scenario_name (path traversal) is rejected, not used as a key.

For every probe it captures the REAL HTTP status + a detail snippet,
contrasts it against the contract, and tags:

  PASS    — behaved correctly (expected status).
  ANOMALY — wrong status: a 500 (opaque crash) or a 200 (silent accept) where
            a 4xx was required, or a 4xx where success was required.
  CRASH   — the harness itself raised while issuing the probe.
  FAIL    — a harness-level assertion failed.

Run::

    python scripts/lulucf_validation/api_stress_test.py

Exit code is the number of CRASH+ANOMALY+FAIL findings (0 = clean).
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import traceback
from pathlib import Path
from typing import Any

# --- env wiring: MUST precede importing the app (mirror api/tests/conftest) ---
_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_API_SRC = _REPO_ROOT / "packages" / "api" / "src"
for p in (str(_CORE_SRC), str(_API_SRC)):
    if p not in sys.path:
        sys.path.insert(0, p)

_TMP_ROOT = Path(tempfile.mkdtemp(prefix="mitica-api-stress-"))
os.environ["MITICA_DATA_DIR"] = str(_TMP_ROOT)
os.environ["MITICA_DATABASE_URL"] = f"sqlite+aiosqlite:///{_TMP_ROOT / 'stress.db'}"
os.environ["MITICA_ENV"] = "test"


# ---------------------------------------------------------------------------
# Findings collector (same shape as pam_stress_test / wom_stress_test)
# ---------------------------------------------------------------------------

class Findings:
    def __init__(self) -> None:
        self.rows: list[dict[str, Any]] = []

    def add(self, probe: str, status: str, detail: str) -> None:
        self.rows.append({"probe": probe, "status": status, "detail": detail})
        marker = {
            "PASS": "  ok ",
            "ANOMALY": ">>ANOM",
            "CRASH": ">>CRASH",
            "FAIL": ">>FAIL",
        }.get(status, "  ?  ")
        # cap detail so a giant traceback / response body stays one line
        print(f"[{marker}] {probe}: {detail[:110]}")

    @property
    def defects(self) -> list[dict[str, Any]]:
        return [r for r in self.rows if r["status"] != "PASS"]


F = Findings()


# ---------------------------------------------------------------------------
# Payload builder (mirrors api/tests/test_modules_http._demo_lulucf_payload)
# ---------------------------------------------------------------------------

def demo_payload() -> dict[str, Any]:
    """A minimal valid CRI-shaped LULUCF run: 100 kha split 60/20/20,
    a 10-year 4A sink inventory."""
    years = list(range(2015, 2025))  # last_hist = 2024
    inventory = [
        {"Year": y, "Category": "4A", "Gas": "CO2",
         "Emissions": -5000.0 + 200.0 * (y - 2015)}
        for y in years
    ]
    land: list[dict[str, Any]] = []
    for y in years:
        land.extend([
            {"Year": y, "Category": "4A", "Area_kha": 60_000.0},
            {"Year": y, "Category": "4B", "Area_kha": 20_000.0},
            {"Year": y, "Category": "4C", "Area_kha": 20_000.0},
            {"Year": y, "Category": "4D", "Area_kha": 0.0},
            {"Year": y, "Category": "4E", "Area_kha": 0.0},
            {"Year": y, "Category": "4F", "Area_kha": 0.0},
        ])
    return {
        "country": "CRI",
        "region": "LAC",
        "horizon_year": 2030,
        "climate_zone": "tropical",
        "tier": 0,
        "profile": "L-A",
        "inventory_emissions": inventory,
        "land_areas": land,
    }


def _detail(res: Any) -> str:
    """A one-line snippet of the response for the log."""
    try:
        body = res.json()
    except Exception:
        return f"HTTP {res.status_code} <non-JSON body>"
    if isinstance(body, dict) and "detail" in body:
        return f"HTTP {res.status_code}: {body['detail']}"
    return f"HTTP {res.status_code}"


def assert_status(probe: str, res: Any, *, expect: int) -> None:
    """PASS iff res.status_code == expect. A 500 where a 4xx was required is the
    headline ANOMALY (opaque crash); a 200 where a 4xx was required is a silent
    accept; anything else is a status mismatch."""
    got = res.status_code
    if got == expect:
        F.add(probe, "PASS", _detail(res))
        return
    if expect >= 400 and got == 500:
        F.add(probe, "ANOMALY", f"expected {expect}, got OPAQUE 500. {_detail(res)}")
    elif expect >= 400 and got == 200:
        F.add(probe, "ANOMALY", f"expected {expect}, got 200 (SILENT ACCEPT).")
    elif expect == 200 and got >= 400:
        F.add(probe, "ANOMALY", f"expected 200, run rejected with {got}. {_detail(res)}")
    else:
        F.add(probe, "ANOMALY", f"expected {expect}, got {got}. {_detail(res)}")


# ---------------------------------------------------------------------------
# Probes
# ---------------------------------------------------------------------------

BASE = "/api/v1"


async def _make_project(client: Any, name: str) -> str:
    res = await client.post(f"{BASE}/projects",
                            json={"name": name, "country_code": "TST"})
    if res.status_code != 201:
        raise RuntimeError(f"project create failed: {_detail(res)}")
    return res.json()["id"]


async def run_clean(client: Any, pid: str) -> None:
    """PART A — the well-formed upload must succeed with finite outputs."""
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=demo_payload())
    if res.status_code != 200:
        F.add("clean/run", "ANOMALY", f"clean payload rejected: {_detail(res)}")
        return
    data = res.json()
    net = data.get("net_co2eq_by_year")
    ok = bool(net) and all(
        isinstance(r.get("Net_kt_CO2eq", r.get("value")), (int, float))
        for r in net
    ) if net else False
    if net is None:
        F.add("clean/run", "ANOMALY", "200 but no net_co2eq_by_year in body.")
    else:
        F.add("clean/run", "PASS",
              f"200, {len(net)} net-series rows, profile={data.get('profile_used')}.")


async def run_edge_cases(client: Any, pid: str) -> None:
    """PART B — malformed uploads: each must be a clean 4xx, never a 500/200."""

    # HC1: empty inventory list -> dict adapter collapses [] to None.
    p = demo_payload(); p["inventory_emissions"] = []
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC1/empty-inventory-list", res, expect=422)

    # HC2: empty land list -> same None-collapse on the other mandatory frame.
    p = demo_payload(); p["land_areas"] = []
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC2/empty-land-list", res, expect=422)

    # HC3: every inventory row missing the 'Emissions' key -> column absent.
    p = demo_payload()
    p["inventory_emissions"] = [
        {"Year": r["Year"], "Category": r["Category"], "Gas": r["Gas"]}
        for r in p["inventory_emissions"]
    ]
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC3/missing-Emissions-col", res, expect=422)

    # HC4: a null emission (JSON null) -> NaN after coercion.
    p = demo_payload()
    p["inventory_emissions"][0]["Emissions"] = None
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC4/null-emission", res, expect=422)

    # HC5: a non-numeric emission string -> NaN after coercion.
    p = demo_payload()
    p["inventory_emissions"][0]["Emissions"] = "not-a-number"
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC5/string-emission", res, expect=422)

    # HC6: horizon at/before the last inventory year (2024) but inside the
    #      Pydantic [2000,2100] band -> engine rejects with a clean ValueError.
    p = demo_payload(); p["horizon_year"] = 2020
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC6/horizon-before-history", res, expect=422)

    # HC7: an absurd horizon -> caught by the Pydantic le=2100 bound (422).
    p = demo_payload(); p["horizon_year"] = 99999
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC7/absurd-horizon", res, expect=422)

    # HC8: a hostile scenario_name (path traversal) must be rejected, not used
    #      to build a storage path.
    res = await client.post(
        f"{BASE}/projects/{pid}/lulucf/run?scenario_name=../../etc/passwd",
        json=demo_payload(),
    )
    assert_status("HC8/path-traversal-scenario", res, expect=422)

    # HC9: a PAM referencing an unknown catalog_id -> engine KeyError/ValueError.
    p = demo_payload()
    p["pams"] = [{
        "catalog_id": "LULUCF::nonexistent::999",
        "category": "4A", "scenario": "WEM", "variables": {}, "t0": 2025,
    }]
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC9/unknown-pam-catalog-id", res, expect=422)

    # HC10: a PAM with an out-of-range t0 -> Pydantic ge=2000/le=2100 (422).
    p = demo_payload()
    p["pams"] = [{
        "catalog_id": "LULUCF::afforestation::0",
        "category": "4A", "scenario": "WEM", "variables": {}, "t0": 1500,
    }]
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC10/pam-t0-out-of-range", res, expect=422)

    # HC11: a PAM category that violates the CRT pattern -> Pydantic (422).
    p = demo_payload()
    p["pams"] = [{
        "catalog_id": "LULUCF::afforestation::0",
        "category": "9Z", "scenario": "WEM", "variables": {}, "t0": 2025,
    }]
    res = await client.post(f"{BASE}/projects/{pid}/lulucf/run", json=p)
    assert_status("HC11/pam-bad-category", res, expect=422)


async def run_lookup_cases(client: Any, pid: str) -> None:
    """PART C — project / scenario lookups."""

    # HC12: run against a non-existent project -> 404.
    res = await client.post(
        f"{BASE}/projects/does-not-exist/lulucf/run", json=demo_payload())
    assert_status("HC12/unknown-project", res, expect=404)

    # HC13: GET result for a scenario that was never run -> 404.
    res = await client.get(
        f"{BASE}/projects/{pid}/lulucf/result?scenario_name=NeverRan")
    assert_status("HC13/result-missing-scenario", res, expect=404)

    # HC14: GET result with a hostile scenario_name -> 422 (validated, not used).
    res = await client.get(
        f"{BASE}/projects/{pid}/lulucf/result?scenario_name=../../secret")
    assert_status("HC14/result-path-traversal", res, expect=422)


async def main() -> int:
    import httpx
    from httpx import ASGITransport
    from mitica_api.db import init_db
    from mitica_api.main import app

    await init_db()
    transport = ASGITransport(app=app, raise_app_exceptions=False)

    print("LULUCF API (HTTP boundary) stress test")
    print("=" * 70)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        pid = await _make_project(client, "api-stress")

        print("\n=== PART A: well-formed upload ===")
        await run_clean(client, pid)

        print("\n=== PART B: malformed uploads (must be clean 4xx, never 500/200) ===")
        await run_edge_cases(client, pid)

        print("\n=== PART C: project / scenario lookups ===")
        await run_lookup_cases(client, pid)

    print("\n" + "=" * 70)
    n_def = len(F.defects)
    print(f"Probes: {len(F.rows)}  |  PASS={len(F.rows) - n_def}")
    if n_def:
        print(f"\n{n_def} finding(s) need attention:")
        for r in F.defects:
            print(f"  [{r['status']}] {r['probe']}: {r['detail'][:90]}")
    else:
        print("\nClean - no crashes, anomalies, or failures.")
    return n_def


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(main()))
    except Exception:
        traceback.print_exc()
        sys.exit(99)
