"""English technical report - Part II: Model Specification, Estimation Strategy,
Data and Calibration (sections 4-6). Exposed as content_part2(S, data)."""

from __future__ import annotations

from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, Spacer, PageBreak

from report_common import header_table, fmt_num, fmt_se


def P(s, sty):
    return Paragraph(s, sty)


def content_part2(S, data):
    """Sections 4, 5, 6."""
    out = []

    # ============================================================
    # 4. MODEL SPECIFICATION
    # ============================================================
    out.append(P("4.&nbsp;&nbsp; Model Specification", S["H1"]))
    out.append(P(
        "This section states the working equations for every layer. The "
        "equations are presented in their final form; the algebra "
        "supporting the Bayesian posterior is in Section 5 and Appendix A. "
        "Each layer is a single Python module in "
        "<font face='Courier'>packages/core/src/mitica_core/modules/macro/"
        "</font>.", S["BODY"]))

    out.append(P("4.1&nbsp; Notation", S["H2"]))
    out.append(P("Indices: c &isin; countries, t &isin; years, s &isin; "
                  "{primary, secondary, tertiary}, k &isin; {primary, "
                  "manufacturing, construction, services, transport_pass, "
                  "transport_freight}, r &isin; {LAC, SSA, MENA, APAC, EEU, "
                  "HIC, HIC_TRANS}.", S["BODY"]))
    out.append(P("Variables: GDP_tot total GDP at constant prices; Pop "
                  "population; GDPpc = GDP_tot / Pop; SGDP_s sectoral "
                  "value added; SInv_s sectoral gross fixed capital "
                  "formation; GFCF_pub_s public sectoral capital "
                  "formation; iRate effective interest rate (proxied by "
                  "long-term sovereign bond yield); SED_k sectoral final "
                  "energy consumption; SED_hh residential final energy "
                  "consumption.", S["BODY"]))

    out.append(P("4.2&nbsp; Layer A &mdash; Accounting Identities",
                  S["H2"]))
    out.append(P("Layer A enforces three identities on the historical "
                  "data and on the projected output:", S["BODY"]))
    out.append(P("GDP_tot,t = SGDP_primary,t + SGDP_secondary,t "
                  "+ SGDP_tertiary,t&emsp;&emsp;(I-1)", S["EQN"]))
    out.append(P("share_crops,t + share_livestock,t + share_other,t = 1"
                  "&emsp;&emsp;(I-2)", S["EQN"]))
    out.append(P("TED_t = SED_hh,t + sum_k SED_k,t,&emsp;&emsp;"
                  "TED_t &gt; 0 and finite&emsp;&emsp;(I-3)", S["EQN"]))
    out.append(P("Violations of (I-1) or (I-2) raise a red flag in Layer "
                  "C and the projection aborts. (I-3) is derived rather "
                  "than verified: the module always computes TED as the "
                  "sum and reports infeasibility (negative or non-finite) "
                  "as a red flag. The relative tolerance on (I-1) is 5% "
                  "to accommodate the small reconciliation gap between "
                  "GDP at market prices (B1GQ) and the sum of sectoral "
                  "gross value added (B1G) in Eurostat data; the absolute "
                  "tolerance on (I-2) is 0.02.", S["BODY"]))

    out.append(P("4.3&nbsp; Layer B1 &mdash; Population", S["H2"]))
    out.append(P("The population path is taken verbatim from the user in "
                  "F1 or F2 flows. In F3 a constant-growth projection from "
                  "the last observed growth rate is used. Demographic "
                  "decomposition (age, sex, fertility, migration) is out "
                  "of scope; users with UN World Population Prospects "
                  "scenarios pass them as a projected input.", S["BODY"]))

    out.append(P("4.4&nbsp; Layer B2 &mdash; Sectoral GDP", S["H2"]))
    out.append(P("Three forms coexist, selected by the configuration "
                  "field <font face='Courier'>b2_form</font>. Let Y_s,t = "
                  "log SGDP_s,t and &epsilon;_s,t ~ N(0, &sigma;&sup2;_s) "
                  "be the unobserved disturbance.", S["BODY"]))

    out.append(P("4.4.1&nbsp; Log-log form (default, b2_form='log_log')",
                  S["H3"]))
    out.append(P("Y_s,t = &alpha;_s + &beta;_s log SInv_s,t + &gamma;_s "
                  "log GFCF_pub_s,t + &zeta;_s log Pop_t + &delta;_s "
                  "iRate_t + &epsilon;_s,t&emsp;(2-LL)", S["EQN"]))
    out.append(P("Five coefficients per sector: an intercept &alpha;_s, "
                  "three log-elasticities (&beta;_s on sectoral "
                  "investment, &gamma;_s on public capital, &zeta;_s on "
                  "population), and one semi-elasticity &delta;_s on the "
                  "interest rate (the rate enters linearly rather than "
                  "in log because policy rates can be negative). The "
                  "expected sign pattern: &beta;, &gamma;, &zeta; &gt; 0; "
                  "&delta; &le; 0 (a higher cost of capital depresses "
                  "output, especially in capital-intensive secondary "
                  "activities).", S["BODY"]))

    out.append(P("4.4.2&nbsp; Kuznets-Chenery linear "
                  "(b2_form='kuznets_chenery')", S["H3"]))
    out.append(P("Y_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1}&emsp;&emsp;"
                  "(2-KC)", S["EQN"]))
    out.append(P("The shifter uses lag-1 GDP per capita. Lagging by one "
                  "year removes the simultaneity that would arise if "
                  "contemporaneous GDP/Pop_t were on the right-hand side: "
                  "GDP_tot at t is itself the sum of SGDP_s at t which "
                  "is what we are projecting. Use of GDPpc_{t-1} is "
                  "predetermined in the projection loop and identification "
                  "is well posed under cross-country panel variation in "
                  "the training data.", S["BODY"]))
    out.append(P("Expected signs from Chenery-Syrquin: &kappa;_primary "
                  "&lt; 0, &kappa;_tertiary &gt; 0, "
                  "&kappa;_secondary &asymp; 0 (the linear approximation "
                  "averages the rising and falling phases of the hump and "
                  "tends toward zero in steady state).", S["BODY"]))

    out.append(P("4.4.3&nbsp; Kuznets-Chenery quadratic "
                  "(b2_form='kuznets_chenery_quad')", S["H3"]))
    out.append(P("Y_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1} + "
                  "&kappa;&sup2;_s [log(GDP/Pop)_{t-1}]&sup2;&emsp;(2-KCQ)",
                  S["EQN"]))
    out.append(P("Adds the quadratic in log GDP per capita to capture the "
                  "non-monotonic hump. The implied peak (or trough) is at "
                  "log(GDP/Pop)* = &minus; &kappa;_s / (2 &kappa;&sup2;_s) "
                  "and the curvature is &kappa;&sup2;_s. For secondary "
                  "with &kappa;&sup2;_secondary &lt; 0 the shape is a "
                  "hump; for tertiary with &kappa;&sup2;_tertiary &lt; 0 "
                  "(observed in the calibrated values) the form is a "
                  "saturation curve.", S["BODY"]))

    out.append(P("4.4.4&nbsp; Active-driver discovery", S["H3"]))
    out.append(P("A given driver enters the regression only if the user "
                  "supplied historical data for it with at least 3 "
                  "non-null observations, strict positivity (for log "
                  "variables), and non-trivial variation (std &gt; 1e-9). "
                  "Drivers that fail any of these checks have their "
                  "coefficient fixed at the regional prior and tagged "
                  "<i>calibrated</i>. This is the v2.0 departure from "
                  "v1.1s where missing covariates were synthesised as "
                  "constant fractions of SGDP_s.", S["BODY"]))

    out.append(P("4.5&nbsp; Layer B3 &mdash; Primary Decomposition",
                  S["H2"]))
    out.append(P("Splits SGDP_primary into crops, livestock and other "
                  "via shares that sum to 1. Two forms:", S["BODY"]))
    out.append(P("4.5.1&nbsp; Constant (b3_form='constant')", S["H3"]))
    out.append(P("share_crops_t = share_crops_{last obs}, share_livestock_t "
                  "= share_livestock_{last obs}. The regional default is "
                  "used when no historical share data exists. share_other "
                  "is the residual.", S["BODY"]))
    out.append(P("4.5.2&nbsp; Bennett logistic (b3_form='bennett_logistic')",
                  S["H3"]))
    out.append(P("logit(share_livestock_t) = a_B + b_B log(GDP/Pop_t)"
                  "&emsp;(3-BL)", S["EQN"]))
    out.append(P("with logit(p) = log(p / (1 &minus; p)). share_crops_t = "
                  "1 &minus; share_livestock_t &minus; share_other "
                  "(constant at the regional prior). The regional "
                  "intercept a_B is back-solved so that at a regional "
                  "anchor GDP/Pop level the implied share_livestock "
                  "matches the constant-form default; see Section 6.5.",
                  S["BODY"]))

    out.append(P("4.6&nbsp; Layer B4 &mdash; Livestock Heads", S["H2"]))
    out.append(P("Two-stage projection. First, animal productivity "
                  "converges to a regional target:", S["BODY"]))
    out.append(P("prod_animal,t = prod_animal,t-1 + &theta;_g "
                  "(prod_animal* &minus; prod_animal,t-1)&emsp;(4-A)",
                  S["EQN"]))
    out.append(P("with prod_animal* a regional target factor and "
                  "&theta;_g a convergence speed (per-year fraction "
                  "closed). Second, the heads identity:", S["BODY"]))
    out.append(P("log Heads_t = &alpha;_g + &beta;_g log "
                  "SGDP_prim_livestock,t &minus; &gamma;_g log "
                  "prod_animal_t + &epsilon;_g,t&emsp;(4-B)", S["EQN"]))
    out.append(P("With &beta;_g &lt; 1 and &gamma;_g &asymp; 1 the form "
                  "encodes a roughly proportional relationship between "
                  "livestock output and heads, adjusted for "
                  "productivity gains over time.", S["BODY"]))

    out.append(P("4.7&nbsp; Layer B5 &mdash; Sectoral Energy Demand",
                  S["H2"]))
    out.append(P("Six energy sectors k. Two forms via "
                  "<font face='Courier'>b5_form</font>:", S["BODY"]))
    out.append(P("4.7.1&nbsp; Log-log (b5_form='log_log')", S["H3"]))
    out.append(P("log SED_k,t = &alpha;_k + &beta;_k log d&sup1;_k,t "
                  "[+ &gamma;_k log d&sup2;_k,t] + &epsilon;_k,t&emsp;"
                  "(5-LL)", S["EQN"]))
    out.append(P("d&sup1; is the primary driver (SGDP_secondary for "
                  "manufacturing, GDPpc for passenger transport, etc.) "
                  "and d&sup2; the optional secondary driver (Pop for "
                  "passenger transport, SGDP_primary for freight). The "
                  "expected sign: &beta;_k &gt; 0 with magnitude near 1 "
                  "for capital-intensive sectors and below 1 for "
                  "services.", S["BODY"]))

    out.append(P("4.7.2&nbsp; Intensity convergence "
                  "(b5_form='intensity_convergence')", S["H3"]))
    out.append(P("log(SED_k,t / scale_k,t) = &phi;_k + &psi;_k "
                  "log(GDP/Pop_t) + &epsilon;_k,t&emsp;(5-IC)", S["EQN"]))
    out.append(P("Equivalently log SED_k,t = &phi;_k + log scale_k,t + "
                  "&psi;_k log(GDP/Pop_t) + &epsilon;. The activity "
                  "elasticity is pinned to 1 (constant returns to "
                  "activity at given intensity); the income elasticity "
                  "of intensity &psi;_k carries the secular trend. "
                  "&psi;_k &lt; 0 implies efficiency-driven decoupling; "
                  "&psi;_k &gt; 0 implies rising intensity (the "
                  "industrialisation phase).", S["BODY"]))

    out.append(P("4.8&nbsp; Layer B6 &mdash; Residential Energy",
                  S["H2"]))
    out.append(P("Two forms via <font face='Courier'>b6_form</font>:",
                  S["BODY"]))
    out.append(P("4.8.1&nbsp; Log-log (b6_form='log_log')", S["H3"]))
    out.append(P("log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) + "
                  "&zeta;_hh log Pop_t + &epsilon;_hh,t&emsp;(6-LL)",
                  S["EQN"]))
    out.append(P("4.8.2&nbsp; Saturation (b6_form='saturation')", S["H3"]))
    out.append(P("log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) + "
                  "&gamma;_hh [log(GDP/Pop_t)]&sup2; + &zeta;_hh log "
                  "Pop_t + &epsilon;_hh,t&emsp;(6-SAT)", S["EQN"]))
    out.append(P("With &gamma;_hh &lt; 0 the marginal income response "
                  "decelerates at high GDP/Pop, producing the appliance-"
                  "saturation plateau. The inflection point is at "
                  "log(GDP/Pop)* = &minus; &beta;_hh / (2 &gamma;_hh).",
                  S["BODY"]))

    out.append(P("4.9&nbsp; Layer B7 &mdash; Fuel Mix", S["H2"]))
    out.append(P("Per (sector, fuel) shares default to the last observed "
                  "value or a regional template. User-supplied projected "
                  "shares override. Cross-fuel identity (shares per "
                  "sector sum to 1) is enforced by I-2'. The B7 layer "
                  "does no estimation; it is a pure book-keeping layer "
                  "between SED_k and downstream emission factors.",
                  S["BODY"]))

    out.append(P("4.10&nbsp; Layer C &mdash; Validation", S["H2"]))
    out.append(P("Eight tests run on the complete output. The full "
                  "specifications are in <font face='Courier'>"
                  "g_Macro_LayerC.py</font>; summary:", S["BODY"]))
    out.append(header_table([
        ["#", "Test name", "Trigger", "Severity"],
        ["T1", "Accounting identities", "I-1 or I-2 violated", "red"],
        ["T2", "Historical range deviation",
         "projection &gt; ±2 sigma of last 15 years", "amber"],
        ["T3", "Sustained productivity bands",
         "5-y rolling g_Prod outside regional band", "amber"],
        ["T4", "Structural monotonicity",
         "share series reverses sign", "amber"],
        ["T5", "Cross-variable coherence",
         "GDPpc vs SED inconsistent with intensity bounds", "amber"],
        ["T6", "External benchmark",
         "endpoint outside literature range", "info"],
        ["T7", "Plausibility of user path",
         "user path deviates from model by 25%/60%", "amber/red"],
        ["T8", "Structural break at boundary",
         "first 3 projected growths &gt; 2.5/4.0 sigma "
         "of historical 10-y distribution", "amber/red"],
    ], col_widths=[1*cm, 4.5*cm, 8*cm, 3*cm]))
    out.append(Spacer(1, 0.3*cm))
    out.append(P("Red flags block the projection. Amber flags emit a "
                  "touch-up proposal: an alternative path the user can "
                  "accept, reject, or edit. T7 and T8 are new in v2.0; "
                  "they exist because the constant-elasticity machinery "
                  "is structurally incapable of detecting regime change "
                  "from inside the projection loop.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 5. ESTIMATION STRATEGY
    # ============================================================
    out.append(P("5.&nbsp;&nbsp; Estimation Strategy", S["H1"]))
    out.append(P(
        "The module estimates parameters by closed-form Bayesian "
        "regression with regional priors. This section derives the "
        "estimator and discusses the design choices. Appendix A contains "
        "the full algebra.", S["BODY"]))

    out.append(P("5.1&nbsp; The Bayesian model", S["H2"]))
    out.append(P("For each layer that estimates parameters, write the "
                  "model in matrix form:", S["BODY"]))
    out.append(P("y = X &theta; + &epsilon;,&emsp;&emsp;"
                  "&epsilon; ~ N(0, &sigma;&sup2; I_n)&emsp;(5-1)", S["EQN"]))
    out.append(P("with y &isin; R^n the demeaned log-target, X &isin; "
                  "R^{n &times; p} the design matrix of regressors "
                  "(intercept plus active drivers, in log scale where "
                  "appropriate), &theta; &isin; R^p the coefficient "
                  "vector, &sigma;&sup2; the unknown noise variance. "
                  "Place a Gaussian prior on &theta;:", S["BODY"]))
    out.append(P("&theta; ~ N(&theta;_prior, &Sigma;_prior,eff)&emsp;(5-2)",
                  S["EQN"]))
    out.append(P("with &theta;_prior the regional prior mean and "
                  "&Sigma;_prior,eff = &Sigma;_prior / k a scaled "
                  "covariance whose strength is controlled by a single "
                  "user-facing knob &lambda; &isin; [0, 1] via the odds "
                  "transformation k = &lambda; / (1 &minus; &lambda;) "
                  "(see 5.3).", S["BODY"]))

    out.append(P("5.2&nbsp; Closed-form posterior", S["H2"]))
    out.append(P("Under the conjugate Gaussian-Gaussian setup the "
                  "posterior is analytical. Combine the likelihood "
                  "(5-1) and the prior (5-2). The posterior precision "
                  "is the sum of the data precision and the prior "
                  "precision:", S["BODY"]))
    out.append(P("&Sigma;_post&#8315;&sup1; = X'X / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1;&emsp;(5-3)", S["EQN"]))
    out.append(P("And the posterior mean is the precision-weighted "
                  "average of the OLS estimator and the prior mean:",
                  S["BODY"]))
    out.append(P("&theta;_hat = &Sigma;_post (X'y / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1; &theta;_prior)&emsp;(5-4)",
                  S["EQN"]))
    out.append(P("Equation (5-3) is the standard precision-update form. "
                  "It is the algebraic identity behind ridge regression "
                  "in the Bayesian interpretation. Two properties matter "
                  "operationally. First, the posterior variance "
                  "&Sigma;_post depends on the data variance "
                  "(&sigma;&sup2;) as well as on the prior &mdash; this "
                  "is the v2.0 correction: v1.1s wrote "
                  "&Sigma;_post = &sigma;&sup2; (X'X + &lambda; I)&#8315;&sup1; "
                  "which is the wrong scale and collapses the credible "
                  "intervals at high shrinkage. Second, when X is empty "
                  "(no data) the posterior collapses to the prior, as "
                  "intended.", S["BODY"]))
    out.append(P("The noise variance &sigma;&sup2; is estimated by a "
                  "first-pass OLS:", S["BODY"]))
    out.append(P("&sigma;&sup2;_hat = (y &minus; X &theta;_OLS)' (y &minus; "
                  "X &theta;_OLS) / (n &minus; p)&emsp;(5-5)", S["EQN"]))
    out.append(P("when n &gt; p. In the underdetermined regime n &le; p "
                  "we use the prior variance scale as a robust fallback "
                  "(equivalent to placing an improper prior on "
                  "&sigma;&sup2; with mode at the prior&apos;s implied "
                  "scale).", S["BODY"]))

    out.append(P("5.3&nbsp; Shrinkage parameterisation", S["H2"]))
    out.append(P("The single user-facing knob is "
                  "<font face='Courier'>estimation_shrinkage</font> "
                  "&lambda; &isin; [0, 1]. Internally the prior variance "
                  "is scaled by the symmetric odds transformation:",
                  S["BODY"]))
    out.append(P("k = &lambda; / (1 &minus; &lambda;),&emsp;&emsp;"
                  "&Sigma;_prior,eff = &Sigma;_prior / k&emsp;(5-6)",
                  S["EQN"]))
    out.append(P("Properties: &lambda; = 0 implies k = 0 hence "
                  "&Sigma;_prior,eff = &infin; and the prior is "
                  "uninformative &mdash; the posterior collapses to OLS. "
                  "&lambda; = 0.5 implies k = 1 hence &Sigma;_prior,eff = "
                  "&Sigma;_prior &mdash; the effective prior variance "
                  "equals the documented prior, an equal-weights "
                  "interpretation. &lambda; = 1 implies k = &infin; hence "
                  "&Sigma;_prior,eff = 0 and the prior is dogmatic &mdash; "
                  "&theta;_hat = &theta;_prior. The intermediate values "
                  "interpolate smoothly. The intercept always receives an "
                  "uninformative prior (the convention &Sigma;_prior[0, 0] "
                  "= 10&sup6;) since its main role is to absorb the "
                  "country&apos;s level scale.", S["BODY"]))

    out.append(P("5.4&nbsp; Why Bayesian shrinkage on small panels",
                  S["H2"]))
    out.append(P("National inventories typically contain 10-25 years of "
                  "historical data &mdash; barely enough to identify five "
                  "coefficients in the log-log form. Pure OLS on such "
                  "short series produces high-variance estimates that "
                  "extrapolate poorly. Pure prior-only projection "
                  "(equivalent to &lambda; = 1) discards the country&apos;s "
                  "own experience. Bayesian shrinkage offers a principled "
                  "interpolation: when the data are informative, the "
                  "posterior follows them; when they are not, the prior "
                  "fills the gap. The single knob &lambda; lets the user "
                  "control the trade-off and the origin tag tells them "
                  "where each parameter landed.", S["BODY"]))

    out.append(P("5.5&nbsp; Honest treatment of missing drivers", S["H2"]))
    out.append(P("The v1.1s implementation, when faced with a missing "
                  "SInv or GFCF_pub series, synthesised the covariate as "
                  "a fixed fraction of SGDP_s (e.g., SInv_secondary &equiv; "
                  "0.20 SGDP_secondary). The design matrix was then "
                  "linearly dependent on the target, and the regression "
                  "returned coefficients that fit the noise. The v2.0 "
                  "implementation excludes missing drivers from the "
                  "regression entirely: a driver enters X only if a real "
                  "historical series exists. Inactive drivers retain "
                  "their coefficient at the regional prior and are "
                  "tagged <i>calibrated</i> in the parameter log. The "
                  "user is informed which parts of the projection rely "
                  "on country information vs literature.", S["BODY"]))

    out.append(P("5.6&nbsp; Multicollinearity diagnostic", S["H2"]))
    out.append(P("When two or more drivers are active the Variance "
                  "Inflation Factor is computed for each:", S["BODY"]))
    out.append(P("VIF_j = 1 / (1 &minus; R&sup2;_j)&emsp;(5-7)", S["EQN"]))
    out.append(P("where R&sup2;_j is the coefficient of determination "
                  "from regressing column j of X on the others. VIF_j "
                  "&gt; 10 emits a diagnostic note on the affected "
                  "parameter but does not block the projection. The "
                  "posterior covariance &Sigma;_post already inflates "
                  "the standard errors in the presence of "
                  "collinearity; VIF is a complementary, more "
                  "interpretable diagnostic for the user.", S["BODY"]))

    out.append(P("5.7&nbsp; Origin tags as the audit trail", S["H2"]))
    out.append(P("Every parameter carries one of three origins:",
                  S["BODY"]))
    out.append(P("&bull; <b>estimated</b>: n_obs &ge; 15 AND shrinkage "
                  "&lt; 0.10. The country data dominate. The value "
                  "should be reported as country-derived in any "
                  "methodology annex.", S["BULLET"]))
    out.append(P("&bull; <b>adjusted</b>: n_obs &ge; 8 (default) and "
                  "shrinkage in [0.10, 0.999). Data and prior contribute "
                  "roughly equally. Report as Bayesian compromise.",
                  S["BULLET"]))
    out.append(P("&bull; <b>calibrated</b>: prior dominates because "
                  "the driver is inactive, n_obs is too small, or "
                  "shrinkage is at the dogmatic extreme. Report the "
                  "regional source.", S["BULLET"]))
    out.append(P("Origin tags are part of "
                  "<font face='Courier'>ParameterEstimate</font> in the "
                  "module&apos;s output contract and surface to the "
                  "frontend wizard. The intended use in the ETF context: "
                  "national modellers can demonstrate to the UNFCCC "
                  "review team which parameters reflect country evidence "
                  "vs literature, in line with Decision 18/CMA.1 paragraph "
                  "47 on methodological transparency.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 6. DATA AND CALIBRATION
    # ============================================================
    out.append(P("6.&nbsp;&nbsp; Data and Calibration", S["H1"]))
    out.append(P("The regional priors are calibrated against two "
                  "panels: World Bank&apos;s WDI (217 countries, "
                  "1960-2024) for the B2 layer (sectoral GDP) and "
                  "Eurostat&apos;s nrg_bal_c (29 European countries, "
                  "1990-2024) for the B5/B6 layer (energy demand). The "
                  "pipeline is fully reproducible and offline: all "
                  "Eurostat and WDI pulls are made once via dedicated "
                  "bulk scripts that save local CSVs; downstream "
                  "calibration and validation scripts never touch the "
                  "API.", S["BODY"]))

    out.append(P("6.1&nbsp; Data sources", S["H2"]))
    out.append(header_table([
        ["Indicator", "Source", "Code", "Coverage"],
        ["GDP, sectoral GVA",       "Eurostat",   "nama_10_gdp / nama_10_a10",
         "EU-27 + UK + NO + CH, 1995-2024"],
        ["Sectoral GFCF",           "Eurostat",   "nama_10_a64_p5",
         "EU-27 + UK + NO, 1995-2024"],
        ["Population",              "Eurostat",   "demo_pjan",
         "EU-27 + UK + NO + CH, 1990-2024"],
        ["Long-term bond yield",    "Eurostat",   "irt_lt_mcby_a",
         "EU-27 + UK, 1990-2024"],
        ["Sectoral energy demand",  "Eurostat",   "nrg_bal_c",
         "EU-27 + UK + NO, 1990-2024"],
        ["Global GDP / Pop / SGDP", "World Bank", "WDI (NY.*, NV.*, SP.*)",
         "217 countries, 1960-2024"],
        ["Country classification",  "World Bank", "WDI income+region",
         "All countries"],
    ], col_widths=[3.5*cm, 2.5*cm, 4.5*cm, 5.7*cm]))
    out.append(Spacer(1, 0.3*cm))

    out.append(P("6.2&nbsp; Country classification", S["H2"]))
    out.append(P("MITICA regions are derived from World Bank&apos;s "
                  "income level + geographic region with an empirical "
                  "refinement for the high-income (HIC) class. The "
                  "refinement uses the 1990 GDP per capita threshold "
                  "of USD 15,000 constant 2015 prices, chosen by "
                  "inspection of a natural gap in the high-income "
                  "distribution. Countries with HIC income but 1990 "
                  "GDPpc below the threshold are placed in HIC_TRANS "
                  "(transitioning); the rest in HIC (mature).",
                  S["BODY"]))
    out.append(header_table([
        ["MITICA region", "Definition", "n"],
        ["HIC",       "income = HIC AND 1990 GDPpc &ge; $15k", "61"],
        ["HIC_TRANS", "income = HIC AND 1990 GDPpc &lt; $15k", "25"],
        ["LAC",       "income &ne; HIC AND WB region = LCN",    "23"],
        ["SSA",       "income &ne; HIC AND WB region = SSF",    "47"],
        ["MENA",      "income &ne; HIC AND WB region = MEA",    "15"],
        ["APAC",      "income &ne; HIC AND WB region &isin; {EAS, SAS}", "28"],
        ["EEU",       "income &ne; HIC AND WB region = ECS",    "18"],
    ], col_widths=[3.5*cm, 8.5*cm, 1.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("The HIC_TRANS membership reflects an economically "
                  "meaningful distinction. Korea, Singapore, the EU 2004 "
                  "accession states (Estonia, Latvia, Lithuania, Poland, "
                  "Hungary, Czechia, Slovakia, Slovenia, Malta), Chile, "
                  "Portugal, Romania, Bulgaria, Croatia and several "
                  "Gulf and Caribbean states share the property that "
                  "they were middle-income at the start of the "
                  "calibration window and converged into HIC during the "
                  "sample. Pooling them with mature OECD economies in "
                  "the calibration smears two structurally distinct "
                  "regimes &mdash; the transition phase still on the "
                  "rising side of the industrial hump versus the post-"
                  "industrial mature phase. Stratifying reveals the "
                  "difference cleanly (Section 6.4).", S["BODY"]))

    out.append(P("6.3&nbsp; The level-form joint calibration of B2",
                  S["H2"]))
    out.append(P("The B2 calibration runs a one-way country-fixed-effects "
                  "panel regression in the LEVEL form that matches the "
                  "module&apos;s equation (2-KCQ) exactly:", S["BODY"]))
    out.append(P("log SGDP_s,c,t = &alpha;_c,s + &zeta;_s log Pop_c,t + "
                  "&kappa;_s log GDPpc_c,t&minus;1 + "
                  "&kappa;&sup2;_s [log GDPpc_c,t&minus;1]&sup2; + "
                  "&epsilon;_c,s,t&emsp;(6-1)", S["EQN"]))
    out.append(P("estimated by within-country demeaning. The country "
                  "fixed effects &alpha;_c,s absorb level scale; the "
                  "cross-country, within-time variation in income "
                  "identifies (&zeta;, &kappa;, &kappa;&sup2;). HC1 "
                  "standard errors. Panel size approximately 10,000 "
                  "country-year rows; countries with fewer than 5 "
                  "observations are dropped.", S["BODY"]))
    out.append(P("An earlier draft of the calibration estimated the "
                  "SHARE form log(SGDP_s / GDP_tot) on log GDPpc. The "
                  "share form is theoretically clean (the country level "
                  "is absorbed by the fixed effect) but introduces an "
                  "algebraic mismatch with the module&apos;s level "
                  "specification: in the share form &kappa;_share is "
                  "(approximately) (&kappa;_level &minus; 1) when "
                  "&zeta;_s = 1. Importing the share-form &kappa; into "
                  "the level equation produces a systematic +1 bias. "
                  "The current level-form calibration eliminates the "
                  "mismatch by exporting all three coefficients (&zeta;, "
                  "&kappa;, &kappa;&sup2;) jointly. The trade-off is "
                  "larger calibrated magnitudes &mdash; the level-form "
                  "&kappa; on tertiary income elasticity is +2.22 in HIC "
                  "rather than the share-form &asymp; 0 &mdash; offset by "
                  "wider prior standard deviations (&sigma;_&kappa; = "
                  "0.50) so the country-level Bayesian fit retains "
                  "freedom to move.", S["BODY"]))

    out.append(P("6.4&nbsp; B5 / B6 energy calibration", S["H2"]))
    out.append(P("Two regressions, both with country fixed effects.",
                  S["BODY"]))
    out.append(P("B5 (intensity convergence):", S["BODY"]))
    out.append(P("log(SED_k,c,t / scale_k,c,t) = &alpha;_c,k + "
                  "&psi;_k log GDPpc_c,t + &epsilon;&emsp;(6-2)", S["EQN"]))
    out.append(P("for k &isin; {primary, manufacturing (incl. "
                  "construction), services, transport (pass + freight)}. "
                  "Eurostat aggregates the four; we map the calibrated "
                  "&psi; to the module&apos;s six sectors by copying "
                  "manufacturing &psi; to construction and transport "
                  "&psi; to both passenger and freight.", S["BODY"]))
    out.append(P("B6 (saturation):", S["BODY"]))
    out.append(P("log SED_hh,c,t = &alpha;_c + &beta;_hh log GDPpc_c,t "
                  "+ &gamma;_hh [log GDPpc_c,t]&sup2; + &zeta;_hh log "
                  "Pop_c,t + &epsilon;&emsp;(6-3)", S["EQN"]))
    out.append(P("Panel size: 992 rows for B5 manufacturing, 555 for B6 "
                  "in HIC; smaller in HIC_TRANS. Calibrated values for "
                  "non-HIC regions are not estimable on Eurostat alone "
                  "and fall back to literature-derived stylised priors.",
                  S["BODY"]))

    out.append(P("6.5&nbsp; Bootstrap robustness", S["H2"]))
    out.append(P("Country-clustered bootstrap (n = 200 replicates; "
                  "resample whole countries with replacement, preserving "
                  "within-country serial correlation) is run on every "
                  "panel regression. The bootstrap standard deviation "
                  "across replicates is the robustness statistic. A "
                  "coefficient with |t| = |&theta;_hat| / SE_boot &gt; 2 "
                  "is statistically distinguishable from zero at the "
                  "regional level.", S["BODY"]))
    out.append(P("Headline result: the &zeta;_s in B2 and the "
                  "&psi;_manuf, &psi;_transport in B5 are robust. The "
                  "&kappa; and &kappa;&sup2; in B2 are mostly NOT "
                  "(confidence intervals cross zero), except for "
                  "HIC_TRANS secondary where both are tightly "
                  "identified. The methodological consequence is "
                  "important: the wide priors we set on &kappa; and "
                  "&kappa;&sup2; (Section 5.3 with &lambda; = 0.5 gives "
                  "&sigma;_&kappa;,eff = 0.50, &sigma;_&kappa;&sup2;,eff "
                  "= 0.08) are not a methodological precaution &mdash; "
                  "they reflect that the global panel signal on the "
                  "income shifters is genuinely weak. The country-level "
                  "Bayesian fit with 11+ years of local data does "
                  "most of the identification. This is the right place "
                  "to be: we transfer the statistically identifiable "
                  "priors (&zeta; from levels, &psi;_manuf and "
                  "&psi;_transport from energy) and let the local data "
                  "refine the noisy ones (&kappa;, &kappa;&sup2;).",
                  S["BODY"]))

    out.append(P("6.6&nbsp; Calibrated values, B2", S["H2"]))
    out.append(P("The calibrated (&zeta;, &kappa;, &kappa;&sup2;) per "
                  "(region, sector). Bootstrap SE in parentheses; "
                  "highlighted cells have |t| &gt; 2 against the "
                  "bootstrap SE.", S["BODY"]))
    rows = [["Region", "Sector", "&zeta; (SE)", "&kappa; (SE)",
             "&kappa;&sup2; (SE)"]]
    highlights = []
    zeta = data["calib_b2"].get("zeta", {})
    kappa = data["calib_b2"].get("kappa", {})
    kappa2 = data["calib_b2"].get("kappa2", {})
    boot = data["calib_b2"].get("boot_se", {})
    ri = 1
    for r in ("HIC", "HIC_TRANS", "EEU", "LAC", "MENA", "APAC", "SSA"):
        for sec in ("primary", "secondary", "tertiary"):
            z = (zeta.get(r) or {}).get(sec)
            k = (kappa.get(r) or {}).get(sec)
            k2 = (kappa2.get(r) or {}).get(sec)
            ses = (boot.get(r) or {}).get(sec, {})
            zse = ses.get("zeta_se"); kse = ses.get("kappa_se")
            k2se = ses.get("kappa2_se")
            rows.append([r, sec, fmt_se(z, zse, 3), fmt_se(k, kse, 3),
                          fmt_se(k2, k2se, 3)])
            for col, (v, se) in enumerate([(z, zse), (k, kse), (k2, k2se)],
                                           start=2):
                if v is not None and se is not None and se > 0 and abs(v/se) > 2:
                    highlights.append((ri, col))
            ri += 1
    out.append(header_table(rows,
        col_widths=[2.2*cm, 2.5*cm, 3.8*cm, 3.8*cm, 3.8*cm],
        highlight_cells=highlights))
    out.append(Spacer(1, 0.3*cm))

    out.append(P("6.7&nbsp; Calibrated values, B5 (&psi;_k)", S["H2"]))
    psi = data["calib_energy"].get("psi", {})
    psi_se = data["calib_energy"].get("psi_boot_se", {})
    rows = [["Region", "&psi;_primary", "&psi;_manuf",
             "&psi;_services", "&psi;_transport"]]
    highlights = []
    ri = 1
    for r in ("HIC", "HIC_TRANS"):
        row = [r]
        for ci, sec in enumerate(("primary", "manufacturing", "services",
                                    "transport"), start=1):
            v = (psi.get(r) or {}).get(sec)
            se = (psi_se.get(r) or {}).get(sec)
            row.append(fmt_se(v, se, 3))
            if v is not None and se is not None and se > 0 and abs(v/se) > 2:
                highlights.append((ri, ci))
        rows.append(row)
        ri += 1
    out.append(header_table(rows,
        col_widths=[2.5*cm, 3.5*cm, 3.5*cm, 3.5*cm, 3.5*cm],
        highlight_cells=highlights))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("Calibration covers HIC and HIC_TRANS only. Other "
                  "regions use literature-derived stylised priors (see "
                  "Appendix B).", S["NOTE"]))

    out.append(P("6.8&nbsp; Calibrated values, B6", S["H2"]))
    b6 = data["calib_energy"].get("b6", {})
    rows = [["Region", "&beta;_hh", "&gamma;_hh", "&zeta;_hh",
             "Inflection log(GDPpc)*"]]
    for r in ("HIC", "HIC_TRANS"):
        d = (b6.get(r) or {})
        beta = d.get("beta_hh"); gamma = d.get("gamma_hh")
        zeta_hh = d.get("zeta_hh")
        if beta is not None and gamma is not None and abs(gamma) > 1e-6:
            infl = -beta / (2 * gamma)
            try:
                infl_str = f"{infl:.2f} (~${int(2.71828**infl):,})"
            except Exception:
                infl_str = f"{infl:.2f}"
        else:
            infl_str = "n/a"
        rows.append([r, fmt_num(beta, 3), fmt_num(gamma, 3),
                      fmt_num(zeta_hh, 3), infl_str])
    out.append(header_table(rows,
        col_widths=[2.5*cm, 2.8*cm, 2.8*cm, 2.8*cm, 5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("The B6 calibrated &beta;_hh is large in magnitude "
                  "(~14 in HIC) because the quadratic is centered on the "
                  "regional sample mean of log GDPpc; the inflection "
                  "log(GDPpc)* coincides with that mean, confirming "
                  "appliance saturation in mature economies. The "
                  "prior std on &beta;_hh is widened to 20% of the "
                  "calibrated magnitude (Section 5.3) so the country-level "
                  "fit retains flexibility.", S["NOTE"]))

    out.append(PageBreak())

    return out
