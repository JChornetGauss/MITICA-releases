#!/usr/bin/env node
// MITICA Next — dev status. Answers: "is my stack running?"
// Pings :8000 and :3000, reports what's there, prints process PIDs.
import { execSync } from "node:child_process";
import { request } from "node:http";

const COLORS = {
  reset: "\x1b[0m",
  dim: "\x1b[2m",
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
  cyan: "\x1b[36m",
  bold: "\x1b[1m",
};

function ping(host, port, path) {
  return new Promise((resolve) => {
    const req = request(
      { host, port, path, method: "GET", timeout: 1500 },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => resolve({ ok: true, status: res.statusCode, body: body.slice(0, 200) }));
      }
    );
    req.on("error", (e) => resolve({ ok: false, error: e.code || e.message }));
    req.on("timeout", () => {
      req.destroy();
      resolve({ ok: false, error: "TIMEOUT" });
    });
    req.end();
  });
}

function listPortOwners() {
  try {
    const out = execSync("netstat -ano", { encoding: "utf-8" });
    const rows = out.split("\n").filter((l) => /:(8000|3000)\s+.*LISTENING/.test(l));
    return rows.map((l) => l.trim().replace(/\s+/g, " "));
  } catch {
    return [];
  }
}

async function main() {
  console.log(`\n${COLORS.bold}MITICA Next — dev status${COLORS.reset}\n`);

  const api = await ping("127.0.0.1", 8000, "/api/v1/health");
  const web = await ping("127.0.0.1", 3000, "/");

  const apiLabel = api.ok
    ? `${COLORS.green}✓ UP${COLORS.reset}  (status ${api.status})`
    : `${COLORS.red}✗ DOWN${COLORS.reset}  (${api.error})`;
  const webLabel = web.ok
    ? `${COLORS.green}✓ UP${COLORS.reset}  (status ${web.status})`
    : `${COLORS.red}✗ DOWN${COLORS.reset}  (${web.error})`;

  console.log(`  ${COLORS.cyan}API${COLORS.reset}  http://127.0.0.1:8000    ${apiLabel}`);
  console.log(`  ${COLORS.cyan}WEB${COLORS.reset}  http://localhost:3000    ${webLabel}`);

  if (api.ok && api.body) {
    try {
      const json = JSON.parse(api.body);
      console.log(`       ${COLORS.dim}api_version ${json.api_version}${COLORS.reset}`);
    } catch {
      /* ignore */
    }
  }

  const owners = listPortOwners();
  if (owners.length > 0) {
    console.log(`\n  ${COLORS.dim}port listeners:${COLORS.reset}`);
    for (const row of owners) console.log(`    ${row}`);
  }

  console.log("");
  if (api.ok && web.ok) {
    console.log(`  ${COLORS.green}Everything running. Open http://localhost:3000${COLORS.reset}\n`);
    process.exit(0);
  }
  console.log(`  ${COLORS.yellow}Run 'pnpm dev' (or scripts\\dev.cmd) to start what's down.${COLORS.reset}\n`);
  process.exit(1);
}

main();
