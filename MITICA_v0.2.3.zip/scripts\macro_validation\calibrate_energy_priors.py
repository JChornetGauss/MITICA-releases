"""Calibrate B5 and B6 energy priors against Eurostat SED + WDI panels.

B5 — intensity convergence (M8)
-------------------------------
For each MITICA region r and energy sector k:

    log(SED_k / scale_k)_{c,t} = phi_{c,k}
                               + psi_k_r * log(GDPpc_{c,t})
                               + eps_{c,k,t}

where scale_k is the natural activity driver (e.g. SGDP_secondary for
manufacturing). psi_k < 0 means efficiency-driven decoupling (intensity
falls with income); psi_k > 0 means rising intensity (industrialisation).

B6 — saturation (M9)
--------------------
For each MITICA region r:

    log(SED_hh)_{c,t} = alpha_{c} + beta_hh_r  * log(GDPpc_{c,t})
                                  + gamma_hh_r * log(GDPpc_{c,t})^2
                                  + zeta_hh_r  * log(Pop_{c,t})
                                  + eps_{c,t}

gamma_hh < 0 produces appliance saturation (the income response decelerates
at high GDPpc). The peak is at log(GDPpc*) = -beta_hh / (2 gamma_hh).

Data sources
------------
- ``wdi_data/{GDP_pc,Pop,SGDP_*,GDP_tot}.csv``: from bulk_download_wdi.py.
- ``data/<CC>_sed.csv``: Eurostat nrg_bal_c (FC_OTH_AF_E, FC_IND_E,
  FC_OTH_CP_E, FC_TRA_E, FC_OTH_HH_E). Eurostat uses 2-letter geo codes
  while WDI uses iso3, so we map them via _EUROSTAT_TO_ISO3 below.

The output JSON is wired into ``g_Macro_Priors.py`` via the same auto-load
mechanism used for B2.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

WDI_DIR  = Path("scripts/macro_validation/wdi_data")
SED_DIR  = Path("scripts/macro_validation/data")
OUT_PATH = WDI_DIR / "calibrated_energy_priors.json"

REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")
# Eurostat-to-WDI iso3 (same map as run_backtest.py)
EUROSTAT_TO_ISO3 = {
    "AT": "AUT", "BE": "BEL", "BG": "BGR", "CY": "CYP", "CZ": "CZE",
    "DE": "DEU", "DK": "DNK", "EE": "EST", "EL": "GRC", "ES": "ESP",
    "FI": "FIN", "FR": "FRA", "HR": "HRV", "HU": "HUN", "IE": "IRL",
    "IT": "ITA", "LT": "LTU", "LU": "LUX", "LV": "LVA", "MT": "MLT",
    "NL": "NLD", "PL": "POL", "PT": "PRT", "RO": "ROU", "SE": "SWE",
    "SI": "SVN", "SK": "SVK", "UK": "GBR", "NO": "NOR", "CH": "CHE",
}

# Eurostat SED column -> (MITICA energy sector, scale driver name)
SED_SECTOR_TO_DRIVER = {
    "SED_primary":       ("primary",       "SGDP_primary"),
    "SED_manufacturing": ("manufacturing", "SGDP_secondary"),
    # Eurostat does not separate construction from industry; we map both
    # MITICA sectors (manufacturing + construction) to the same Eurostat
    # bin. For calibration purposes manufacturing is the larger pool and
    # gives the right elasticity signal.
    "SED_services":      ("services",      "SGDP_tertiary"),
    # Transport is also lumped (pass + freight) in Eurostat. For
    # calibration we treat it as the average of the two and scale by Pop
    # (the natural scale for passenger transport) since most transport
    # energy is road-based and tracks population.
    "SED_transport":     ("transport",     "Pop"),
}


# ---------------------------------------------------------------------------
# Panel assembly
# ---------------------------------------------------------------------------


def _load_wdi_indicator(name: str) -> pd.DataFrame:
    df = pd.read_csv(WDI_DIR / f"{name}.csv")
    return df.rename(columns={"value": name})


def load_country_classifications() -> pd.DataFrame:
    cc = pd.read_csv(WDI_DIR / "countries.csv")
    return cc[["iso3", "mitica_region"]].dropna(subset=["mitica_region"])


def load_sed_long() -> pd.DataFrame:
    """Stack all ``data/*_sed.csv`` into a long DataFrame keyed by iso3."""
    rows = []
    for code, iso3 in EUROSTAT_TO_ISO3.items():
        p = SED_DIR / f"{code}_sed.csv"
        if not p.exists() or p.stat().st_size < 10:
            continue
        try:
            df = pd.read_csv(p)
        except Exception:
            continue
        if df.empty or "Year" not in df.columns:
            continue
        df["iso3"] = iso3
        rows.append(df)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True)


def build_panel() -> pd.DataFrame:
    """Inner-join SED, WDI indicators, and the region classification."""
    sed = load_sed_long()
    if sed.empty:
        return pd.DataFrame()

    wdi = _load_wdi_indicator("GDP_pc")
    wdi = wdi.merge(_load_wdi_indicator("Pop"),          on=["iso3", "Year"], how="outer")
    wdi = wdi.merge(_load_wdi_indicator("GDP_tot"),      on=["iso3", "Year"], how="outer")
    wdi = wdi.merge(_load_wdi_indicator("SGDP_primary"), on=["iso3", "Year"], how="outer")
    wdi = wdi.merge(_load_wdi_indicator("SGDP_secondary"),on=["iso3", "Year"], how="outer")
    wdi = wdi.merge(_load_wdi_indicator("SGDP_tertiary"),on=["iso3", "Year"], how="outer")

    panel = sed.merge(wdi, on=["iso3", "Year"], how="inner")
    panel = panel.merge(load_country_classifications(), on="iso3", how="inner")

    # Logs
    panel["log_gpc"] = np.log(panel["GDP_pc"].where(panel["GDP_pc"] > 0))
    panel["log_pop"] = np.log(panel["Pop"].where(panel["Pop"] > 0))
    panel = panel.replace([np.inf, -np.inf], np.nan)
    return panel


# ---------------------------------------------------------------------------
# Within-FE estimator (same as B2 calibration)
# ---------------------------------------------------------------------------


def _fit_within_fe(df: pd.DataFrame, y_col: str, X_cols: list[str]
                   ) -> tuple[np.ndarray, np.ndarray, int]:
    """One-way country FE regression via demeaning + OLS. HC1 SEs."""
    use = df.dropna(subset=[y_col] + X_cols).copy()
    if len(use) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0
    counts = use.groupby("iso3").size()
    keep = counts[counts >= 5].index
    use = use[use["iso3"].isin(keep)]
    if len(use) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0
    cols = [y_col] + X_cols
    means = use.groupby("iso3")[cols].transform("mean")
    dm = use.copy()
    dm[cols] = dm[cols] - means
    y = dm[y_col].values
    X = dm[X_cols].values
    try:
        XtX_inv = np.linalg.inv(X.T @ X)
        beta = XtX_inv @ (X.T @ y)
        resid = y - X @ beta
        n, k = len(y), X.shape[1]
        S = (X * resid[:, None]).T @ (X * resid[:, None])
        var_hc1 = (n / (n - k)) * XtX_inv @ S @ XtX_inv
        se = np.sqrt(np.diag(var_hc1))
        return beta, se, n
    except np.linalg.LinAlgError:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0


def _cluster_bootstrap_fe(df: pd.DataFrame, y_col: str, X_cols: list[str],
                           n_boot: int = 500, seed: int = 42
                           ) -> tuple[np.ndarray, np.ndarray]:
    """Country-clustered bootstrap CIs for the within-FE estimator.

    Resamples whole countries with replacement (preserving within-country
    serial correlation). Returns (mean, std) per coefficient across the
    bootstrap replicates. Returns NaN-filled arrays if the panel is too
    small to bootstrap meaningfully.
    """
    use = df.dropna(subset=[y_col] + X_cols).copy()
    if len(use) < 30:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan)
    countries = use["iso3"].unique()
    if len(countries) < 5:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan)
    rng = np.random.default_rng(seed)
    coefs = []
    for _ in range(n_boot):
        sampled = rng.choice(countries, size=len(countries), replace=True)
        # Re-stack the rows from the sampled countries (with replacement
        # countries getting their data duplicated, with new pseudo-iso3
        # labels so the FE demean handles them as separate clusters).
        parts = []
        for k, cc in enumerate(sampled):
            chunk = use[use["iso3"] == cc].copy()
            chunk["iso3"] = f"{cc}_{k}"  # unique cluster id
            parts.append(chunk)
        boot_df = pd.concat(parts, ignore_index=True)
        beta, _se, n = _fit_within_fe(boot_df, y_col, X_cols)
        if not np.isnan(beta).any():
            coefs.append(beta)
    if len(coefs) < n_boot // 2:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan)
    arr = np.asarray(coefs)
    return arr.mean(axis=0), arr.std(axis=0, ddof=1)


# ---------------------------------------------------------------------------
# B5 — intensity convergence
# ---------------------------------------------------------------------------


# Per-sector minimum year for calibration. We tested sub-period stratification
# for services (post-2000 only, on the hypothesis that the 1990s pattern was
# structurally different) but the SED backtest showed it made the EU
# projection WORSE (more decoupling than reality during 2006-2023). All
# sectors therefore use the full 1990-2024 panel; the bootstrap CIs computed
# below are the operative robustness statistic.
SECTOR_YEAR_MIN = {
    "primary":       1990,
    "manufacturing": 1990,
    "services":      1990,
    "transport":     1990,
}


def calibrate_b5(panel: pd.DataFrame, n_boot: int = 200) -> dict:
    """Per region, per energy sector: estimate psi_k.

    Sub-period stratification is applied per sector (see SECTOR_YEAR_MIN).
    Country-clustered bootstrap CIs are computed alongside the point estimate.
    """
    out: dict = {r: {} for r in REGIONS}
    se_boot: dict = {r: {} for r in REGIONS}
    n_obs: dict = {r: {} for r in REGIONS}

    for r in REGIONS:
        sub = panel[panel["mitica_region"] == r].copy()
        for sed_col, (sector_name, scale_col) in SED_SECTOR_TO_DRIVER.items():
            if sed_col not in sub.columns or scale_col not in sub.columns:
                out[r][sector_name] = None
                se_boot[r][sector_name] = None
                n_obs[r][sector_name] = 0
                continue
            year_min = SECTOR_YEAR_MIN.get(sector_name, 1990)
            df = sub[sub["Year"] >= year_min][
                [sed_col, scale_col, "iso3", "Year", "log_gpc"]
            ].copy()
            df = df[(df[sed_col] > 0) & (df[scale_col] > 0)]
            df["log_intensity"] = np.log(df[sed_col] / df[scale_col])
            df = df.dropna(subset=["log_intensity", "log_gpc"])
            beta, _se, n = _fit_within_fe(df, "log_intensity", ["log_gpc"])
            out[r][sector_name] = (
                float(beta[0]) if not np.isnan(beta[0]) else None
            )
            n_obs[r][sector_name] = int(n)
            # Bootstrap CI
            _bmu, bse = _cluster_bootstrap_fe(df, "log_intensity",
                                              ["log_gpc"], n_boot=n_boot)
            se_boot[r][sector_name] = (
                float(bse[0]) if not np.isnan(bse[0]) else None
            )
    return {"psi": out, "psi_boot_se": se_boot, "n_obs": n_obs}


# ---------------------------------------------------------------------------
# B6 — saturation (residential)
# ---------------------------------------------------------------------------


def calibrate_b6(panel: pd.DataFrame) -> dict:
    """Per region: estimate (beta_hh, gamma_hh, zeta_hh) jointly."""
    out: dict = {}
    n_obs: dict = {}

    for r in REGIONS:
        sub = panel[panel["mitica_region"] == r].copy()
        if "SED_households" not in sub.columns:
            out[r] = {"beta_hh": None, "gamma_hh": None, "zeta_hh": None}
            n_obs[r] = 0
            continue
        df = sub[["SED_households", "iso3", "Year",
                  "log_gpc", "log_pop"]].copy()
        df = df[df["SED_households"] > 0]
        df["log_sed_hh"]   = np.log(df["SED_households"])
        df["log_gpc_sq"]   = df["log_gpc"] ** 2
        df = df.dropna(subset=["log_sed_hh", "log_gpc",
                                "log_gpc_sq", "log_pop"])
        beta, _se, n = _fit_within_fe(
            df, "log_sed_hh", ["log_gpc", "log_gpc_sq", "log_pop"]
        )
        if np.isnan(beta).any() or n < 50:
            out[r] = {"beta_hh": None, "gamma_hh": None, "zeta_hh": None}
        else:
            out[r] = {
                "beta_hh":  float(beta[0]),
                "gamma_hh": float(beta[1]),
                "zeta_hh":  float(beta[2]),
            }
        n_obs[r] = int(n)
    return {"b6": out, "n_obs": n_obs}


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

STYLISED_PSI = {
    "HIC":       {"primary": -0.30, "manufacturing": -0.50, "services": -0.10, "transport": -0.10},
    "HIC_TRANS": {"primary": -0.21, "manufacturing": -0.35, "services": -0.07, "transport": -0.07},
    "EEU":       {"primary": -0.15, "manufacturing": -0.25, "services": -0.05, "transport": -0.05},
    "LAC":       {"primary": -0.15, "manufacturing": -0.25, "services": -0.05, "transport": -0.05},
    "MENA":      {"primary": -0.15, "manufacturing": -0.25, "services": -0.05, "transport": -0.05},
    "APAC":      {"primary": -0.10, "manufacturing": +0.10, "services": -0.05, "transport": +0.10},
    "SSA":       {"primary": +0.10, "manufacturing": +0.20, "services":  0.00, "transport": +0.15},
}
STYLISED_B6 = {
    "beta_hh":  0.70,
    "gamma_hh": -0.04,
    "zeta_hh":  1.00,
}


def print_results(b5: dict, b6: dict) -> None:
    print("\n" + "=" * 90)
    print("B5 intensity convergence: psi_k_r per (region, energy sector)")
    print("Bootstrap SE (n=200) shown alongside the point estimate")
    print("=" * 90)
    print(f"{'region':<10} {'sector':<14} {'stylised':>10} {'psi':>10} "
          f"{'bse':>8} {'95% CI':>22} {'n':>5}")
    for r in REGIONS:
        for sector in ("primary", "manufacturing", "services", "transport"):
            sty = STYLISED_PSI.get(r, {}).get(sector, 0.0)
            cal = b5["psi"][r].get(sector)
            bse = b5["psi_boot_se"][r].get(sector)
            n = b5["n_obs"][r].get(sector, 0)
            if cal is None:
                print(f"{r:<10} {sector:<14} {sty:>+10.4f} {'n/a':>10}")
                continue
            cal_str = f"{cal:+.4f}"
            if bse is not None:
                bse_str = f"{bse:>7.4f}"
                ci = f"[{cal - 1.96*bse:+.3f}, {cal + 1.96*bse:+.3f}]"
            else:
                bse_str = "  n/a "
                ci = "    n/a"
            print(f"{r:<10} {sector:<14} {sty:>+10.4f} {cal_str:>10} "
                  f"{bse_str:>8} {ci:>22} {n:>5}")

    print("\n" + "=" * 80)
    print("B6 saturation: (beta_hh, gamma_hh, zeta_hh) per region")
    print("=" * 80)
    print(f"{'region':<10} {'beta_hh':>10} {'gamma_hh':>10} {'zeta_hh':>10} {'n_obs':>7}   shape")
    for r in REGIONS:
        d = b6["b6"].get(r, {})
        b = d.get("beta_hh"); g = d.get("gamma_hh"); z = d.get("zeta_hh")
        if b is None:
            print(f"{r:<10} {'n/a':>10} {'n/a':>10} {'n/a':>10}")
            continue
        peak = -b / (2 * g) if g and abs(g) > 1e-6 else None
        shape = f"peak @ logGDPpc={peak:.2f}" if peak is not None else "monotone"
        n = b6["n_obs"].get(r, 0)
        print(f"{r:<10} {b:>+10.4f} {g:>+10.4f} {z:>+10.4f} {n:>7}   {shape}")


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------


def write_json(b5: dict, b6: dict, path: Path) -> None:
    payload = {
        "_meta": {
            "source": "Eurostat nrg_bal_c (annual final energy consumption "
                      "by sector) + World Bank WDI (GDPpc, Pop, SGDP_*); "
                      "one-way country FE; HC1 SE",
            "year_range": [1990, 2024],
            "b5_specification": (
                "log(SED_k / scale_k) = alpha_c + psi_k * log(GDPpc)"
            ),
            "b6_specification": (
                "log(SED_hh) = alpha_c + beta_hh * log(GDPpc) "
                "+ gamma_hh * log(GDPpc)^2 + zeta_hh * log(Pop)"
            ),
            "sector_to_driver": {
                k: {"sector": v[0], "scale_driver": v[1]}
                for k, v in SED_SECTOR_TO_DRIVER.items()
            },
        },
        "psi":  b5["psi"],
        "psi_boot_se": b5["psi_boot_se"],
        "b6":   b6["b6"],
        "n_obs": {"b5": b5["n_obs"], "b6": b6["n_obs"]},
        "sub_period_year_min": SECTOR_YEAR_MIN,
    }
    path.write_text(json.dumps(payload, indent=2))
    print(f"\nWrote calibrated energy priors to {path.resolve()}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    print("=== MITICA energy priors (B5 + B6) — Eurostat/WDI calibration ===\n")
    print("Loading panel ...")
    panel = build_panel()
    if panel.empty:
        print("ERROR: empty panel. Run bulk_download_wdi.py and "
              "bulk_download_sed.py first.")
        return
    print(f"Panel size: {len(panel):,} rows")
    print(f"Countries:  {panel['iso3'].nunique()}")
    print(f"Years:      {int(panel['Year'].min())}-{int(panel['Year'].max())}")
    print(f"Regions present: "
          f"{sorted(panel['mitica_region'].dropna().unique())}")

    print("\nRunning B5 panel regressions ...")
    b5 = calibrate_b5(panel)
    print("\nRunning B6 panel regressions ...")
    b6 = calibrate_b6(panel)

    print_results(b5, b6)
    write_json(b5, b6, OUT_PATH)


if __name__ == "__main__":
    main()
