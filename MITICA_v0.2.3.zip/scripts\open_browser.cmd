@echo off
rem Wait until the web server is up and then open the browser.
set URL=http://localhost:3000
echo [MITICA] waiting for %URL% to come up ...
:loop
curl -s -o nul -w "%%{http_code}" %URL% > "%TEMP%\mitica_status.txt" 2>nul
set /p CODE=<"%TEMP%\mitica_status.txt"
if "%CODE%"=="200" goto ready
timeout /t 1 /nobreak >nul
goto loop
:ready
echo [MITICA] opening %URL% ...
start "" %URL%
