"""EU-29 real-data backtest of the Energy industries module (SI-003).

Protocol (mirrors the validated MITICA pattern — macro/TED/LULUCF/transport):
train on history → 2018, project the OBSERVED window 2019–2024 (observed final
consumption fed as the projected demand input — the TED trick), score the WoM
against reality:

- **M1 (primary)**: 1A1a CO₂ MAPE + mean signed bias vs Eurostat env_air_gge
  (airpol=CO2, src_crf=CRF1A1A) — GWP-free (CO₂ = 99% of EU 1A1a GHG).
- **M2**: same on GHG (kt CO₂-eq, inventory GWPs).
- **M3 (mix allocation)**: per-year Σ_tech|gen_model − gen_obs| / Σ gen_obs ×100
  vs Eurostat main-activity-producer generation by fuel (the TED
  mis-allocation mirror).
- **M4**: plausibility (no NaN/negatives; validation flags).
- **M5 (decomposition, legacy mode)**: Variant A = pure WoM; Variant B =
  observed per-tech capacity additions 2019–2024 fed as WM PAMs → splits
  capacity-path error from mix/EF error.
- Both engine modes scored: ``legacy_excel`` (the faithful default) and
  ``merit_dispatch`` (the alternative) — honest model comparison.

Data: scripts/energy_validation/data/eurostat/tidy_*.csv (raw bulk-API
downloads parsed with pandas — no LLM-extracted numbers). Emissions history is
the observed CRF1A1A total allocated to fossil techs ∝ generation × IPCC
default EF (coal 1.0 / gas 0.40 / oil 0.75 / other 0.9 kt/GWh) — totals match
the inventory exactly; the split is a documented construction.

Run:  .venv\\Scripts\\python.exe scripts\\energy_validation\\eu_energy_backtest.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.energy import (  # noqa: E402
    EnergyConfig,
    EnergyPAM,
    EnergySystem,
    TechRow,
    run_energy_module,
)

DATA = Path(__file__).parent / "data" / "eurostat"
OUT = Path(__file__).parent / "results" / "eu"

EU29 = (
    "AT BE BG CY CZ DE DK EE EL ES FI FR HR HU IE IT LT LU LV MT NL PL PT RO "
    "SE SI SK IS NO"
).split()

TRAIN_END = 2018
SCORE_YEARS = list(range(2019, 2025))

# Main-activity-producer generation = the CRF1A1A scope
GEN_BALS = ("GEP_MAPE", "GEP_MAPCHP")

SIEC_TO_TECH = {
    "Hydropower large": ["RA100"],
    "Wind": ["RA300"],
    "Solar": ["RA410", "RA420"],
    "Geothermal": ["RA200"],
    "Biomass": ["BIOE"],
    "Nuclear": ["N900H"],
    "Thermal (Natural Gas)": ["G3000"],
    "Thermal (Coal)": ["C0000X0350-0370", "P1000", "S2000", "C0350-0370"],
    "Thermal (Naphtha - Gas/Diesel Oil - Residual fuel oil)": ["O4000XBIO"],
}
RESIDUAL_TECH = "Thermal (Other incl. waste)"

CAP_SIEC = {  # nrg_inf_epc capacity per tech (operator PRR_MAIN)
    "Hydropower large": ["RA100"],
    "Wind": ["RA300"],
    "Solar": ["RA410", "RA420"],
    "Geothermal": ["RA200"],
    "Nuclear": ["N9000"],
}
COMBUSTIBLE_CAP_SIEC = "CF"   # single aggregate; split ∝ base-year generation
COMBUSTIBLE_TECHS = [
    "Biomass",
    "Thermal (Natural Gas)",
    "Thermal (Coal)",
    "Thermal (Naphtha - Gas/Diesel Oil - Residual fuel oil)",
    RESIDUAL_TECH,
]

# IPCC-default CO2 intensity weights for allocating the observed CRF1A1A total
EF_WEIGHT = {
    "Thermal (Coal)": 1.0,
    "Thermal (Natural Gas)": 0.40,
    "Thermal (Naphtha - Gas/Diesel Oil - Residual fuel oil)": 0.75,
    RESIDUAL_TECH: 0.9,
}


def load_data():
    peh = pd.read_csv(DATA / "tidy_nrg_bal_peh.csv")
    epc = pd.read_csv(DATA / "tidy_nrg_inf_epc.csv")
    cbe = pd.read_csv(DATA / "tidy_nrg_cb_e.csv")
    gge = pd.read_csv(DATA / "tidy_env_air_gge.csv")
    return peh, epc, cbe, gge


def tech_generation(peh: pd.DataFrame, geo: str) -> pd.DataFrame:
    """Year × tech main-activity generation (GWh), incl. the residual row."""
    d = peh[(peh.geo == geo) & (peh.nrg_bal.isin(GEN_BALS))]
    pivot = d.pivot_table(index="year", columns="siec", values="value", aggfunc="sum")
    out = pd.DataFrame(index=pivot.index)
    for tech, codes in SIEC_TO_TECH.items():
        cols = [c for c in codes if c in pivot.columns]
        out[tech] = pivot[cols].sum(axis=1) if cols else 0.0
    total = pivot["TOTAL"] if "TOTAL" in pivot.columns else out.sum(axis=1)
    out[RESIDUAL_TECH] = (total - out.sum(axis=1)).clip(lower=0.0)
    return out.fillna(0.0)


def tech_capacity(epc: pd.DataFrame, geo: str, gen_base: pd.Series) -> pd.DataFrame:
    d = epc[
        (epc.geo == geo)
        & (epc.plant_tec == "CAP_NET_ELC")
        & (epc.operator == "PRR_MAIN")
    ]
    pivot = d.pivot_table(index="year", columns="siec", values="value", aggfunc="sum")
    out = pd.DataFrame(index=pivot.index)
    for tech, codes in CAP_SIEC.items():
        cols = [c for c in codes if c in pivot.columns]
        out[tech] = pivot[cols].sum(axis=1) if cols else 0.0
    cf_total = pivot[COMBUSTIBLE_CAP_SIEC] if COMBUSTIBLE_CAP_SIEC in pivot.columns else 0.0
    # Split the combustible-fuels aggregate ∝ base-year generation share
    w = {t: max(0.0, float(gen_base.get(t, 0.0))) for t in COMBUSTIBLE_TECHS}
    sw = sum(w.values())
    for t in COMBUSTIBLE_TECHS:
        out[t] = cf_total * (w[t] / sw if sw > 0 else 1.0 / len(COMBUSTIBLE_TECHS))
    return out.fillna(0.0)


def allocate_emissions(
    gen: pd.DataFrame, observed_total: pd.Series
) -> pd.DataFrame:
    """Distribute the observed CRF1A1A total over fossil techs ∝ gen × EF weight."""
    out = pd.DataFrame(0.0, index=gen.index, columns=gen.columns)
    for y in gen.index:
        tot = observed_total.get(y)
        if tot is None or np.isnan(tot):
            continue
        weights = {
            t: gen.loc[y, t] * EF_WEIGHT.get(t, 0.0) for t in gen.columns
        }
        sw = sum(weights.values())
        if sw <= 0:
            continue
        for t in gen.columns:
            out.loc[y, t] = tot * weights[t] / sw
    return out


def balance_series(cbe: pd.DataFrame, geo: str, code: str) -> pd.Series:
    d = cbe[(cbe.geo == geo) & (cbe.nrg_bal == code)]
    return d.set_index("year")["value"].sort_index()


def observed_series(gge: pd.DataFrame, geo: str, pollutant: str) -> pd.Series:
    d = gge[(gge.geo == geo) & (gge.airpol == pollutant) & (gge.src_crf == "CRF1A1A")]
    return d.set_index("year")["value"].sort_index()


def build_system(
    geo: str, gen: pd.DataFrame, cap: pd.DataFrame, emis: pd.DataFrame,
    fc: pd.Series, imp: pd.Series, exp: pd.Series,
) -> EnergySystem:
    hist_years = [y for y in gen.index if y <= TRAIN_END]
    techs = []
    for tech in gen.columns:
        techs.append(
            TechRow(
                name=tech,
                generation_gwh={int(y): float(gen.loc[y, tech]) for y in hist_years},
                capacity_mw={
                    int(y): float(cap.loc[y, tech]) for y in hist_years if y in cap.index
                },
                emissions_kt={int(y): float(emis.loc[y, tech]) for y in hist_years},
            )
        )
    return EnergySystem(
        country_code=geo,
        technologies=techs,
        demand_history_gwh={int(y): float(v) for y, v in fc.items() if y <= TRAIN_END},
        import_gwh={int(y): float(v) for y, v in imp.items() if y <= TRAIN_END},
        export_gwh={int(y): float(v) for y, v in exp.items() if y <= TRAIN_END},
        demand_projection_gwh={
            int(y): float(fc.get(y)) for y in SCORE_YEARS if y in fc.index
        },
    )


def score_run(out, scenario: str, observed: pd.Series, gen_obs: pd.DataFrame):
    """Return (per-year rows, mape, bias, alloc_err_mean)."""
    rows = []
    apes, errs, allocs = [], [], []
    by_year = {d.year: d for d in out.dispatch if d.scenario == scenario}
    for y in SCORE_YEARS:
        if y not in by_year or y not in observed.index:
            continue
        model = by_year[y].total_emissions_kt()
        obs = float(observed[y])
        pe = (model - obs) / obs * 100.0 if obs else np.nan
        apes.append(abs(pe))
        errs.append(pe)
        alloc = np.nan
        if y in gen_obs.index:
            g_obs = gen_obs.loc[y]
            g_mod = by_year[y].generation_gwh
            tot_obs = float(g_obs.sum())
            if tot_obs > 0:
                alloc = (
                    sum(abs(g_mod.get(t, 0.0) - float(g_obs[t])) for t in gen_obs.columns)
                    / tot_obs * 100.0
                )
                allocs.append(alloc)
        rows.append(
            {"year": y, "model_kt": model, "obs_kt": obs, "pct_err": pe,
             "alloc_err_pct": alloc}
        )
    mape = float(np.mean(apes)) if apes else np.nan
    bias = float(np.mean(errs)) if errs else np.nan
    alloc_mean = float(np.mean(allocs)) if allocs else np.nan
    return rows, mape, bias, alloc_mean


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    peh, epc, cbe, gge = load_data()

    detail_rows = []
    summary_rows = []

    for geo in EU29:
        try:
            gen = tech_generation(peh, geo)
            obs_co2 = observed_series(gge, geo, "CO2")
            obs_ghg = observed_series(gge, geo, "GHG")
            fc = balance_series(cbe, geo, "FC")
            imp = balance_series(cbe, geo, "IMP")
            exp = balance_series(cbe, geo, "EXP")
            gen_base = gen.loc[TRAIN_END] if TRAIN_END in gen.index else gen.iloc[-1]
            cap = tech_capacity(epc, geo, gen_base)
            emis_co2 = allocate_emissions(gen, obs_co2)

            system = build_system(geo, gen, cap, emis_co2, fc, imp, exp)
            gen_obs_score = gen.loc[[y for y in SCORE_YEARS if y in gen.index]]

            # ---- legacy mode, Variant A (pure WoM) ----
            out_legacy = run_energy_module(
                system, EnergyConfig(scenarios=("WoM",), mode="legacy_excel")
            )
            rows, mape, bias, alloc = score_run(out_legacy, "WoM", obs_co2, gen_obs_score)
            for r in rows:
                detail_rows.append({"geo": geo, "mode": "legacy", "variant": "A", **r})

            # M2 — GHG run (emissions histories allocated from the GHG series)
            emis_ghg = allocate_emissions(gen, obs_ghg)
            sys_ghg = build_system(geo, gen, cap, emis_ghg, fc, imp, exp)
            out_ghg = run_energy_module(
                sys_ghg, EnergyConfig(scenarios=("WoM",), mode="legacy_excel")
            )
            _, mape_ghg, bias_ghg, _ = score_run(out_ghg, "WoM", obs_ghg, gen_obs_score)

            # ---- legacy mode, Variant B (observed capacity additions as WM PAMs) ----
            pams = []
            cap_score = tech_capacity(epc, geo, gen_base)
            for tech in gen.columns:
                prev = None
                for y in SCORE_YEARS:
                    if y not in cap_score.index:
                        continue
                    cur = float(cap_score.loc[y, tech])
                    base = float(cap_score.loc[TRAIN_END, tech]) if prev is None else prev
                    delta = cur - base
                    if delta > 1e-6:
                        pams.append(
                            EnergyPAM(scenario="WM", technology=tech, year=int(y),
                                      added_mw=delta)
                        )
                    prev = cur
            sys_b = build_system(geo, gen, cap, emis_co2, fc, imp, exp)
            sys_b.pams = pams
            out_b = run_energy_module(
                sys_b, EnergyConfig(scenarios=("WoM", "WM"), mode="legacy_excel")
            )
            rows_b, mape_b, bias_b, alloc_b = score_run(out_b, "WM", obs_co2, gen_obs_score)
            for r in rows_b:
                detail_rows.append({"geo": geo, "mode": "legacy", "variant": "B", **r})

            # ---- merit mode, Variant A ----
            out_merit = run_energy_module(
                system, EnergyConfig(scenarios=("WoM",), mode="merit_dispatch")
            )
            rows_m, mape_m, bias_m, alloc_m = score_run(out_merit, "WoM", obs_co2, gen_obs_score)
            for r in rows_m:
                detail_rows.append({"geo": geo, "mode": "merit", "variant": "A", **r})

            n_flags = len(out_legacy.validation_report)
            finite_ok = all(
                np.isfinite(v)
                for d in out_legacy.dispatch
                for v in list(d.generation_gwh.values()) + list(d.emissions_kt.values())
            )
            summary_rows.append(
                {
                    "geo": geo,
                    "mape_legacy_A": mape, "bias_legacy_A": bias, "alloc_legacy_A": alloc,
                    "mape_ghg": mape_ghg, "bias_ghg": bias_ghg,
                    "mape_legacy_B": mape_b, "bias_legacy_B": bias_b, "alloc_legacy_B": alloc_b,
                    "mape_merit_A": mape_m, "bias_merit_A": bias_m, "alloc_merit_A": alloc_m,
                    "n_pams_B": len(pams), "n_flags": n_flags, "finite": finite_ok,
                }
            )
            print(f"{geo}: legacy A MAPE {mape:6.1f}%  bias {bias:+6.1f}%  "
                  f"alloc {alloc:5.1f}%  | B MAPE {mape_b:6.1f}%  "
                  f"| merit MAPE {mape_m:6.1f}%")
        except Exception as exc:  # noqa: BLE001 — report, don't hide
            print(f"{geo}: FAILED — {exc}")
            summary_rows.append({"geo": geo, "error": str(exc)})

    det = pd.DataFrame(detail_rows)
    summ = pd.DataFrame(summary_rows)
    det.to_csv(OUT / "results_by_year.csv", index=False)
    summ.to_csv(OUT / "summary.csv", index=False)

    ok = summ.dropna(subset=["mape_legacy_A"]) if "mape_legacy_A" in summ else summ
    if len(ok):
        print("\n=== EU panel medians (n=%d) ===" % len(ok))
        for col in ("mape_legacy_A", "bias_legacy_A", "alloc_legacy_A",
                    "mape_legacy_B", "alloc_legacy_B", "mape_merit_A", "alloc_merit_A"):
            med = ok[col].median()
            p90 = ok[col].abs().quantile(0.9)
            print(f"  {col:16s} median {med:7.2f}   p90|.| {p90:7.2f}")
    print(f"\nwrote {OUT / 'results_by_year.csv'}")
    print(f"wrote {OUT / 'summary.csv'}")


if __name__ == "__main__":
    main()
