"""BTR-tier real-data backtest of the Energy industries module (SI-003).

Mirrors scripts/energy_validation/eu_energy_backtest.py but for 8 non-Annex-I
BTR countries (BRA CHL COL EGY GEO IDN KAZ TUR): train on history -> 2018,
project the OBSERVED window 2019-2022 (observed final consumption fed as the
projected demand input -- the TED trick), score the WoM against the country's
own CRT inventory:

- **M1 (primary)**: 1A1a CO2 MAPE + mean signed bias vs the CRT
  Table1.A(a)s1 total row (data/btr/{ISO}_1a1a.csv, parsed + spot-checked by
  parse_btr_1a1a.py).
- **M3 (thermal allocation)**: per-year
  Sigma_fuel |model_fuel_CO2 - obs_fuel_CO2| / obs_total x 100, mapping model
  techs -> CRT fuel groups (Coal tech -> solid+other_fossil+peat,
  Gas tech -> gaseous, Oil tech -> liquid). Biomass CO2 is a memo item and is
  EXCLUDED everywhere.
- Both engine modes scored: ``legacy_excel`` and ``merit_dispatch``.
  No Variant B (no observed per-tech capacity-addition data at this tier).

Input assembly (all parsed files on disk -- no LLM-extracted numbers):

- generation_gwh: WDI panel (data/wdi/wdi_energy_panel.csv). Total production
  = elec_prod_kwh_recon, falling back per-year to
  elec_use_total_kwh / (1 - elec_loss_pct/100) (demand-implied production --
  flagged per country), split by the WDI by-source shares
  (elec_coal/gas/oil/hydro/nucl/renew pct), kWh -> GWh (/1e6).
- emissions_kt: CRT per-fuel CO2 rows (solid -> Coal tech, gaseous -> Gas,
  liquid -> Oil, other_fossil+peat -> Coal; biomass excluded). History <=2018.
- capacity_mw: SYNTHETIC (WDI has no per-tech capacity):
  max(gen 2016-2018) / (8760 x CF_mid) x 1000, with CF_mid = midpoint of the
  technology's class band in mitica_core.modules.energy.model._TYPICAL_CF
  (resolved with the model's own _match_typical -- read-only import), held
  constant over the training history. Capacity is a free scale parameter in
  legacy WoM (only the frozen GWh/MW ratio matters); in merit mode it sets the
  dispatch ceilings.
- demand_history / demand_projection: elec_use_total_kwh / 1e6; projection =
  observed 2019-2022, truncated to the years the country's CRT covers
  (COL -> 2021).

Run:  .venv\\Scripts\\python.exe scripts\\energy_validation\\btr_energy_backtest.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.energy import (  # noqa: E402
    EnergyConfig,
    EnergySystem,
    TechRow,
    run_energy_module,
)
from mitica_core.modules.energy.model import (  # noqa: E402  (read-only import)
    _TYPICAL_CF,
    _match_typical,
)

DATA = Path(__file__).parent / "data"
OUT = Path(__file__).parent / "results" / "btr"

ISOS = ["BRA", "CHL", "COL", "EGY", "GEO", "IDN", "KAZ", "TUR"]

TRAIN_END = 2018
SCORE_YEARS_MAX = list(range(2019, 2023))   # truncated per country to CRT span

# WDI by-source share column -> engine tech name (EXACT names)
TECH_SHARE_COL = {
    "Hydropower large": "elec_hydro_pct",
    "Nuclear": "elec_nucl_pct",
    "Thermal (Natural Gas)": "elec_gas_pct",
    "Thermal (Coal)": "elec_coal_pct",
    "Thermal (Naphtha - Gas/Diesel Oil - Residual fuel oil)": "elec_oil_pct",
    "NCRE": "elec_renew_pct",
}
COAL = "Thermal (Coal)"
GAS = "Thermal (Natural Gas)"
OIL = "Thermal (Naphtha - Gas/Diesel Oil - Residual fuel oil)"

# CRT fuel row -> engine tech (memo: biomass excluded from the 1.A.1.a total)
FUEL_TO_TECH = {
    "solid": COAL,
    "gaseous": GAS,
    "liquid": OIL,
    "other_fossil": COAL,
    "peat": COAL,
}
# M3 fuel groups: model tech -> the CRT fuels it must account for
TECH_TO_FUELS = {
    COAL: ("solid", "other_fossil", "peat"),
    GAS: ("gaseous",),
    OIL: ("liquid",),
}


def cf_mid(tech: str) -> float:
    """Midpoint of the model's own _TYPICAL_CF band for this tech name."""
    band = _match_typical(tech, _TYPICAL_CF)
    if band is None:
        raise ValueError(f"No _TYPICAL_CF band for {tech!r}")
    return (band[0] + band[1]) / 2.0


def load_wdi(iso: str) -> tuple[pd.DataFrame, pd.Series, dict]:
    """Return (gen GWh year x tech, demand GWh series, provenance notes)."""
    panel = pd.read_csv(DATA / "wdi" / "wdi_energy_panel.csv")
    d = panel[panel.iso3 == iso].set_index("year").sort_index()

    recon = d["elec_prod_kwh_recon"]
    implied = d["elec_use_total_kwh"] / (1.0 - d["elec_loss_pct"] / 100.0)
    prod_kwh = recon.fillna(implied)
    prod_gwh = prod_kwh / 1e6

    gen = pd.DataFrame(index=d.index)
    for tech, col in TECH_SHARE_COL.items():
        gen[tech] = prod_gwh * d[col] / 100.0
    gen = gen.dropna(how="any")

    demand = (d["elec_use_total_kwh"] / 1e6).dropna()

    hist = [y for y in gen.index if y <= TRAIN_END]
    n_fallback = int(recon.loc[hist].isna().sum()) if hist else 0
    share_sum_base = (
        float(sum(d.loc[TRAIN_END, c] for c in TECH_SHARE_COL.values()))
        if TRAIN_END in d.index else np.nan
    )
    notes = {
        "n_hist_years_fallback_prod": n_fallback,
        "n_hist_years": len(hist),
        "base_prod_is_implied": bool(pd.isna(recon.get(TRAIN_END, np.nan))),
        "share_sum_2018_pct": share_sum_base,
    }
    return gen, demand, notes


def load_crt(iso: str) -> tuple[pd.Series, pd.DataFrame]:
    """Return (total CO2 kt series, per-fuel CO2 kt year x fuel)."""
    df = pd.read_csv(DATA / "btr" / f"{iso}_1a1a.csv")
    total = (
        df[df.fuel == "total"].set_index("year")["co2_kt"].sort_index()
    )
    fuels = (
        df[df.fuel != "total"]
        .pivot_table(index="year", columns="fuel", values="co2_kt", aggfunc="sum")
        .reindex(columns=["liquid", "solid", "gaseous", "other_fossil",
                          "peat", "biomass"])
        .fillna(0.0)
        .sort_index()
    )
    return total, fuels


def build_system(
    iso: str, gen: pd.DataFrame, fuels: pd.DataFrame, demand: pd.Series,
    hist_years: list[int], score_years: list[int],
) -> EnergySystem:
    # Per-tech CRT CO2 history (fossil only; biomass = memo, excluded)
    emis = pd.DataFrame(0.0, index=fuels.index, columns=list(TECH_SHARE_COL))
    for fuel, tech in FUEL_TO_TECH.items():
        emis[tech] += fuels[fuel]

    # Synthetic capacity: max recent generation at the class-band CF midpoint
    recent = [y for y in (2016, 2017, 2018) if y in gen.index]
    techs = []
    for tech in TECH_SHARE_COL:
        gmax = float(gen.loc[recent, tech].max()) if recent else 0.0
        cap = gmax * 1000.0 / (8760.0 * cf_mid(tech)) if gmax > 0 else 0.0
        techs.append(
            TechRow(
                name=tech,
                generation_gwh={int(y): float(gen.loc[y, tech]) for y in hist_years},
                capacity_mw={int(y): cap for y in hist_years},
                emissions_kt={
                    int(y): float(emis.loc[y, tech]) if y in emis.index else 0.0
                    for y in hist_years
                },
            )
        )
    return EnergySystem(
        country_code=iso,
        technologies=techs,
        demand_history_gwh={
            int(y): float(v) for y, v in demand.items() if y <= TRAIN_END
        },
        demand_projection_gwh={
            int(y): float(demand.loc[y]) for y in score_years
        },
    )


def score_run(out, score_years, obs_total: pd.Series, obs_fuels: pd.DataFrame):
    """Return (per-year rows, mape, bias, thermal-allocation mean)."""
    rows, apes, errs, allocs = [], [], [], []
    by_year = {d.year: d for d in out.dispatch if d.scenario == "WoM"}
    for y in score_years:
        if y not in by_year or y not in obs_total.index:
            continue
        model = by_year[y].total_emissions_kt()
        obs = float(obs_total[y])
        pe = (model - obs) / obs * 100.0 if obs else np.nan
        apes.append(abs(pe))
        errs.append(pe)
        alloc = np.nan
        if y in obs_fuels.index and obs > 0:
            emis_y = by_year[y].emissions_kt
            alloc = sum(
                abs(emis_y.get(t, 0.0) - float(obs_fuels.loc[y, list(fl)].sum()))
                for t, fl in TECH_TO_FUELS.items()
            ) / obs * 100.0
            allocs.append(alloc)
        rows.append({"year": y, "model_kt": model, "obs_kt": obs,
                     "pct_err": pe, "alloc_err_pct": alloc})
    mape = float(np.mean(apes)) if apes else np.nan
    bias = float(np.mean(errs)) if errs else np.nan
    alloc_mean = float(np.mean(allocs)) if allocs else np.nan
    return rows, mape, bias, alloc_mean


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    detail_rows, summary_rows = [], []

    for iso in ISOS:
        try:
            gen, demand, notes = load_wdi(iso)
            obs_total, obs_fuels = load_crt(iso)

            hist_years = sorted(
                y for y in gen.index
                if y <= TRAIN_END and y in obs_fuels.index and y in demand.index
            )
            if TRAIN_END not in hist_years:
                raise ValueError(f"no {TRAIN_END} in joint history")
            score_years = [
                y for y in SCORE_YEARS_MAX
                if y in obs_total.index and y in demand.index
            ]
            if not score_years:
                raise ValueError("no overlapping score years")

            system = build_system(iso, gen, obs_fuels, demand,
                                  hist_years, score_years)

            results = {}
            for mode, tag in (("legacy_excel", "legacy"),
                              ("merit_dispatch", "merit")):
                out = run_energy_module(
                    system, EnergyConfig(scenarios=("WoM",), mode=mode)
                )
                rows, mape, bias, alloc = score_run(
                    out, score_years, obs_total, obs_fuels
                )
                for r in rows:
                    detail_rows.append({"iso": iso, "mode": tag, **r})
                finite_ok = all(
                    np.isfinite(v)
                    for d in out.dispatch
                    for v in list(d.generation_gwh.values())
                            + list(d.emissions_kt.values())
                )
                results[tag] = (mape, bias, alloc,
                                len(out.validation_report), finite_ok)

            (mape_l, bias_l, alloc_l, nfl_l, fin_l) = results["legacy"]
            (mape_m, bias_m, alloc_m, nfl_m, fin_m) = results["merit"]
            summary_rows.append({
                "iso": iso,
                "train_start": hist_years[0], "train_end": hist_years[-1],
                "n_train": len(hist_years),
                "score_years": f"{score_years[0]}-{score_years[-1]}",
                "n_score": len(score_years),
                "mape_legacy": mape_l, "bias_legacy": bias_l,
                "alloc_legacy": alloc_l,
                "mape_merit": mape_m, "bias_merit": bias_m,
                "alloc_merit": alloc_m,
                "n_flags_legacy": nfl_l, "n_flags_merit": nfl_m,
                "finite": fin_l and fin_m,
                **notes,
            })
            print(f"{iso}: train {hist_years[0]}-{hist_years[-1]} "
                  f"score {score_years[0]}-{score_years[-1]} | "
                  f"legacy MAPE {mape_l:6.1f}% bias {bias_l:+6.1f}% "
                  f"alloc {alloc_l:5.1f}% | "
                  f"merit MAPE {mape_m:6.1f}% bias {bias_m:+6.1f}% "
                  f"alloc {alloc_m:5.1f}% | "
                  f"fallback-prod {notes['n_hist_years_fallback_prod']}/"
                  f"{notes['n_hist_years']}y")
        except Exception as exc:  # noqa: BLE001 -- report, don't hide
            print(f"{iso}: FAILED -- {exc}")
            summary_rows.append({"iso": iso, "error": str(exc)})

    det = pd.DataFrame(detail_rows)
    summ = pd.DataFrame(summary_rows)
    det.to_csv(OUT / "results_by_year.csv", index=False)
    summ.to_csv(OUT / "summary.csv", index=False)

    ok = summ.dropna(subset=["mape_legacy"]) if "mape_legacy" in summ else summ
    if len(ok):
        print(f"\n=== BTR panel medians (n={len(ok)}) ===")
        for col in ("mape_legacy", "bias_legacy", "alloc_legacy",
                    "mape_merit", "bias_merit", "alloc_merit"):
            med = ok[col].median()
            p90 = ok[col].abs().quantile(0.9)
            print(f"  {col:14s} median {med:7.2f}   p90|.| {p90:7.2f}")
    print(f"\nwrote {OUT / 'results_by_year.csv'}")
    print(f"wrote {OUT / 'summary.csv'}")


if __name__ == "__main__":
    main()
