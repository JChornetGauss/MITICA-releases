"""Assemble and render the English technical report.

Output: docs/MITICA_MACRO_TECHNICAL_REPORT_EN.pdf
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the script directory is on the path so module siblings resolve.
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from report_common import (DOCS_DIR, load_all_data, make_doc_template,
                           make_styles)
from report_en_part1 import content_part1
from report_en_part2 import content_part2
from report_en_part3 import content_part3


def main() -> None:
    out_path = DOCS_DIR / "MITICA_MACRO_TECHNICAL_REPORT_EN.pdf"
    data = load_all_data()
    S = make_styles()

    story = []
    story += content_part1(S, data)
    story += content_part2(S, data)
    story += content_part3(S, data)

    doc = make_doc_template(
        out_path,
        title="MITICA Macro Module - Technical Report v2.0",
        author="Gauss",
        header_left="MITICA Macro Module - Technical Report v2.0",
        header_right="Gauss / UNFCCC",
    )
    doc.build(story)
    print(f"Wrote {out_path.resolve()}")


if __name__ == "__main__":
    main()
