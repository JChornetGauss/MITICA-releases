"""Compute 3 numerical sensitivity examples used in the technical report.

Each sensitivity runs the macro module on a real EU country under two
configurations and reports the gap in the projected endpoint. Results are
written to ``scripts/macro_validation/results/sensitivities.json`` for the
technical report PDF builder to consume.

Examples
--------
1. Spain GDP growth pinned at 2% vs 3% annual: effect on SGDP_secondary and
   SGDP_tertiary endpoints (F1 / F2 flow comparison).
2. Germany under b2_form="log_log" vs "kuznets_chenery_quad": effect on
   SGDP_tertiary endpoint.
3. Italy under b5_form="log_log" vs "intensity_convergence": effect on
   SED_manufacturing endpoint (proxy for industrial CO2 trajectory).
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, "scripts/macro_validation")
from run_backtest import load_country, build_hist_from, build_projected_drivers  # noqa: E402

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData,
    MacroConfig,
    ProjectedInputs,
    run_macro_module,
)

OUT = Path("scripts/macro_validation/results/sensitivities.json")


def _f(v):
    return float(v)


# ---------------------------------------------------------------------------
# Sensitivity 1 — Spain GDP growth scenarios
# ---------------------------------------------------------------------------


def sensitivity_spain_gdp_growth() -> dict:
    """Spain: pin GDP_tot growth at 2% vs 3% from 2024-2050 in F2 flow.
    Report SGDP_secondary and SGDP_tertiary at 2050."""
    raw = load_country("ES")
    hist = build_hist_from(raw, 1995, 2023)
    last_year = 2023
    last_gdp = float(hist.gdp_tot.iloc[-1]["GDP_tot"])
    last_pop = float(hist.population.iloc[-1]["Pop"])

    horizon = 2050
    years_fut = list(range(last_year + 1, horizon + 1))

    out_by_growth = {}
    for g in (0.02, 0.03):
        gdp_fut = [last_gdp * (1 + g) ** (y - last_year) for y in years_fut]
        proj_gdp = pd.DataFrame({"Year": years_fut, "GDP_tot": gdp_fut})
        # constant population
        proj_pop = pd.DataFrame({"Year": years_fut,
                                  "Pop": [last_pop] * len(years_fut)})
        proj = ProjectedInputs(gdp_tot=proj_gdp, population=proj_pop)
        cfg = MacroConfig(region="HIC", horizon_year=horizon,
                          estimation_shrinkage=0.5,
                          b2_form="log_log")
        try:
            out = run_macro_module(hist, proj, cfg)
            row = out.sgdp[out.sgdp["Year"] == horizon].iloc[0]
            out_by_growth[g] = {
                "SGDP_primary":   _f(row["SGDP_primary"]),
                "SGDP_secondary": _f(row["SGDP_secondary"]),
                "SGDP_tertiary":  _f(row["SGDP_tertiary"]),
                "GDP_tot":        _f(row.get("GDP_primary", 0)
                                     + row.get("SGDP_primary", 0)
                                     + row.get("SGDP_secondary", 0)
                                     + row.get("SGDP_tertiary", 0)),
            }
        except Exception as e:
            out_by_growth[g] = {"error": str(e)}

    # Diff at horizon
    diff = {}
    if "error" not in out_by_growth[0.02] and "error" not in out_by_growth[0.03]:
        for s in ("SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
            v_lo = out_by_growth[0.02][s]
            v_hi = out_by_growth[0.03][s]
            diff[s] = {
                "abs": v_hi - v_lo,
                "pct": 100.0 * (v_hi - v_lo) / v_lo,
            }

    return {
        "country": "ES (Spain)",
        "horizon": horizon,
        "last_observed_year": last_year,
        "scenarios": {f"GDP_g_{int(100*g)}pct": d
                       for g, d in out_by_growth.items()},
        "diff_endpoint_pct": diff,
    }


# ---------------------------------------------------------------------------
# Sensitivity 2 — Form selection (LL vs KCQ) on Germany tertiary
# ---------------------------------------------------------------------------


def sensitivity_form_choice() -> dict:
    """Germany 2050 SGDP_tertiary: LL vs KCQ.

    Run F3-style projection (no pinned GDP path) with realistic driver
    futures derived from the historical growth rates.
    """
    raw = load_country("DE")
    hist = build_hist_from(raw, 1995, 2023)
    last_year = 2023
    horizon = 2050
    years_fut = list(range(last_year + 1, horizon + 1))

    # Extend drivers via the macro module's helpers (constant-growth)
    # — easier: pass the last observed values constant since this is a
    # didactic comparison of forms, not of driver paths.
    last_pop = float(hist.population.iloc[-1]["Pop"])
    last_sinv = hist.sinv.iloc[-1]
    last_irate = float(hist.irate.iloc[-1]["iRate"])

    proj_pop = pd.DataFrame({"Year": years_fut,
                              "Pop": [last_pop * (1.001 ** (y - last_year))
                                       for y in years_fut]})
    proj_sinv = pd.DataFrame({
        "Year": years_fut,
        "SInv_primary":   [float(last_sinv["SInv_primary"])   * (1.015 ** (y - last_year)) for y in years_fut],
        "SInv_secondary": [float(last_sinv["SInv_secondary"]) * (1.015 ** (y - last_year)) for y in years_fut],
        "SInv_tertiary":  [float(last_sinv["SInv_tertiary"])  * (1.020 ** (y - last_year)) for y in years_fut],
    })
    proj_irate = pd.DataFrame({"Year": years_fut,
                                "iRate": [last_irate] * len(years_fut)})

    proj = ProjectedInputs(population=proj_pop, sinv=proj_sinv, irate=proj_irate)

    results = {}
    for form in ("log_log", "kuznets_chenery_quad"):
        cfg = MacroConfig(region="HIC", horizon_year=horizon,
                          estimation_shrinkage=0.5, b2_form=form)
        try:
            out = run_macro_module(hist, proj, cfg)
            row = out.sgdp[out.sgdp["Year"] == horizon].iloc[0]
            tot = float(row["SGDP_primary"] + row["SGDP_secondary"]
                         + row["SGDP_tertiary"])
            results[form] = {
                "SGDP_primary":   _f(row["SGDP_primary"]),
                "SGDP_secondary": _f(row["SGDP_secondary"]),
                "SGDP_tertiary":  _f(row["SGDP_tertiary"]),
                "GDP_tot":        tot,
                "share_tertiary": _f(row["SGDP_tertiary"]) / tot,
            }
        except Exception as e:
            results[form] = {"error": str(e)}

    diff = {}
    if "error" not in results["log_log"] and "error" not in results["kuznets_chenery_quad"]:
        for s in ("SGDP_primary", "SGDP_secondary", "SGDP_tertiary", "GDP_tot"):
            v_ll = results["log_log"][s]
            v_kcq = results["kuznets_chenery_quad"][s]
            diff[s] = {
                "abs":  v_kcq - v_ll,
                "pct":  100.0 * (v_kcq - v_ll) / v_ll,
            }
    return {
        "country": "DE (Germany)",
        "horizon": horizon,
        "scenarios": results,
        "diff_kcq_vs_ll_pct": diff,
    }


# ---------------------------------------------------------------------------
# Sensitivity 3 — B5 form choice (LL vs IC) on Italy manufacturing SED
# ---------------------------------------------------------------------------


def sensitivity_b5_form() -> dict:
    """Italy SED_manufacturing in 2023: log_log vs intensity_convergence,
    fit on the truncated training window 1995-2005, projected to 2023.
    This is the same setup as the SED backtest harness (Section 7.3 of the
    technical report); we just report two endpoints under the two forms."""
    sys.path.insert(0, "scripts/macro_validation")
    from run_backtest_sed import build_hist as build_hist_sed  # type: ignore
    from run_backtest_sed import build_proj as build_proj_sed  # type: ignore

    raw = load_country("IT")
    # Need SED data also
    sed_path = Path("scripts/macro_validation/data/IT_sed.csv")
    raw["sed"] = pd.read_csv(sed_path) if sed_path.exists() else pd.DataFrame()

    train_start, train_end, horizon = 1995, 2005, 2023
    hist = build_hist_sed(raw, train_start, train_end)
    proj = build_proj_sed(raw, train_end, horizon)

    results = {}
    for form in ("log_log", "intensity_convergence"):
        cfg = MacroConfig(region="HIC", horizon_year=horizon,
                          estimation_shrinkage=0.5,
                          b5_form=form)
        try:
            out = run_macro_module(hist, proj, cfg)
            row = out.sed[out.sed["Year"] == horizon].iloc[0]
            manuf = float(row["SED_manufacturing"]) + float(row["SED_construction"])
            results[form] = {
                "SED_manufacturing_plus_construction_ktoe": manuf,
                "SED_services_ktoe": _f(row["SED_services"]),
                "SED_transport_pass_ktoe": _f(row["SED_transport_pass"]),
                "SED_transport_freight_ktoe": _f(row["SED_transport_freight"]),
            }
        except Exception as e:
            results[form] = {"error": str(e)}

    diff = {}
    if "error" not in results["log_log"] and "error" not in results["intensity_convergence"]:
        for k in results["log_log"]:
            v_ll = results["log_log"][k]
            v_ic = results["intensity_convergence"][k]
            diff[k] = {
                "abs": v_ic - v_ll,
                "pct": 100.0 * (v_ic - v_ll) / v_ll,
            }
    return {
        "country": "IT (Italy)",
        "horizon": horizon,
        "scenarios": results,
        "diff_ic_vs_ll_pct": diff,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    print("Running sensitivity 1 (Spain GDP growth) ...")
    s1 = sensitivity_spain_gdp_growth()
    print("Running sensitivity 2 (Germany LL vs KCQ) ...")
    s2 = sensitivity_form_choice()
    print("Running sensitivity 3 (Italy LL vs IC for manufacturing) ...")
    s3 = sensitivity_b5_form()
    payload = {
        "_meta": {
            "purpose": "Numerical illustrations for the technical report",
            "module_version": "v2.0 (May 2026)",
        },
        "sensitivity_1_spain_gdp_growth": s1,
        "sensitivity_2_form_choice_germany": s2,
        "sensitivity_3_b5_form_italy": s3,
    }
    OUT.write_text(json.dumps(payload, indent=2, default=float))
    print(f"\nWrote {OUT.resolve()}")


if __name__ == "__main__":
    main()
