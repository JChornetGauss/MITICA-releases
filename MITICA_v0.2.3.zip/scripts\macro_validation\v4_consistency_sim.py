"""v4 macro — input-configuration CONSISTENCY simulation (EU-27).

Question (JL): simulate country users who supply DIFFERENT data — only GDP,
GDP + a sectoral/services view, GDP + population, everything, or nothing — and
check whether the resulting projections are CONSISTENT with each other.

What "consistent" means here, derived from the model's dependency structure
(verified empirically: population is exogenous to income; structure responds to
the income path; pinning a series reproduces it):

  IDEMPOTENT class — if the user pins values EQUAL to the model's own WoM (F3)
  output, the projection must recover the WoM EXACTLY on every variable. Pinning
  the model's own answer must be a no-op. Any drift is an inconsistency.

  LOCALISED-RESPONSE class — if the user pins a value that DIFFERS from WoM,
  only the pinned variable (reproduced exactly) and its legitimate downstream
  (structure responds to income) may change; population must not move, and the
  accounting identity GDP = Σ SGDP must always hold.

Setup: full Eurostat history to 2025, project to 2035 (forward WoM, the real
user case — not a backtest). Monetary series scaled to constant-2015 USD
(x1.1095) for the income norm, as in the backtest.

Outputs: results/eurostat_v4/consistency_*.csv and a pass/fail console report.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA = Path(__file__).resolve().parent / "eurostat_v4"
OUTDIR = Path(__file__).resolve().parent / "results" / "eurostat_v4"
# v4 structure projection is currency-invariant → feed Eurostat's native
# constant-EUR-millions as-is (any scale gives identical structure).
S = 1.0
SEC = ["primary", "secondary", "tertiary"]
HORIZON = 2035

# region per country (dev_group = H for all EU-27)
REGION = {
    "AT": "HIC", "BE": "HIC", "BG": "HIC_TRANS", "HR": "HIC_TRANS", "CY": "HIC",
    "CZ": "HIC_TRANS", "DK": "HIC", "EE": "HIC_TRANS", "FI": "HIC", "FR": "HIC",
    "DE": "HIC", "EL": "HIC", "HU": "HIC_TRANS", "IE": "HIC", "IT": "HIC",
    "LV": "HIC_TRANS", "LT": "HIC_TRANS", "LU": "HIC", "MT": "HIC_TRANS",
    "NL": "HIC", "PL": "HIC_TRANS", "PT": "HIC_TRANS", "RO": "HIC_TRANS",
    "SK": "HIC_TRANS", "SI": "HIC_TRANS", "ES": "HIC", "SE": "HIC",
}
TOL_REL = 1e-6   # idempotency tolerance on levels (relative)
TOL_PP = 1e-4    # idempotency tolerance on shares (pp)


def _hist(cc: str):
    d = pd.read_csv(DATA / f"{cc}.csv")
    d = d.dropna(subset=["GDP_tot", "Pop"] + [f"SGDP_{s}" for s in SEC]).sort_values("Year")
    g = d[["Year", "GDP_tot"]].copy(); g["GDP_tot"] *= S
    sg = d[["Year"] + [f"SGDP_{s}" for s in SEC]].copy()
    for s in SEC:
        sg[f"SGDP_{s}"] *= S
    hist = HistoricalData(gdp_tot=g.reset_index(drop=True),
                          population=d[["Year", "Pop"]].reset_index(drop=True),
                          sgdp=sg.reset_index(drop=True))
    return hist, d


def _shares_frame(sgdp: pd.DataFrame) -> pd.DataFrame:
    s = sgdp.set_index("Year")
    tot = sum(s[f"SGDP_{x}"] for x in SEC)
    return pd.DataFrame({x: s[f"SGDP_{x}"] / tot for x in SEC})


def _outputs(o):
    return (o.gdp_tot.set_index("Year")["GDP_tot"],
            o.population.set_index("Year")["Pop"],
            _shares_frame(o.sgdp))


def run_country(cc: str) -> list[dict]:
    hist, d = _hist(cc)
    region = REGION[cc]
    cfg = MacroConfig(region=region, dev_group="H", horizon_year=HORIZON,
                      validate_historical=False, verbose=False)
    fut = list(range(int(d["Year"].max()) + 1, HORIZON + 1))

    # baseline F3
    o0 = run_macro_module(hist, ProjectedInputs(), cfg)
    g0, p0, sh0 = _outputs(o0)

    def pin_gdp(series):  # build a projected GDP DataFrame (already USD-scaled)
        return pd.DataFrame({"Year": fut, "GDP_tot": [series[y] for y in fut]})

    def pin_sgdp_from_shares(shares_by_year, gdp_series):
        cols = {"Year": fut}
        for s in SEC:
            cols[f"SGDP_{s}"] = [shares_by_year[y][s] * gdp_series[y] for y in fut]
        return pd.DataFrame(cols)

    # WoM-equal projected inputs (idempotent class)
    gdp_wom = pin_gdp(g0)
    pop_wom = pd.DataFrame({"Year": fut, "Pop": [p0[y] for y in fut]})
    sh0_by_year = {y: {s: sh0.loc[y, s] for s in SEC} for y in fut}
    sgdp_wom = pin_sgdp_from_shares(sh0_by_year, g0)

    # stress inputs
    g25 = float(g0[fut[0] - 1]) if (fut[0] - 1) in g0.index else float(hist.gdp_tot["GDP_tot"].iloc[-1])
    # aspirational: +1pp/yr above the WoM compound growth
    wom_cagr = (g0[fut[-1]] / g25) ** (1 / len(fut)) - 1
    aspir_rate = wom_cagr + 0.01
    gdp_aspir = pin_gdp(pd.Series({y: g25 * (1 + aspir_rate) ** (y - (fut[0] - 1)) for y in fut}))
    # frozen structure: hold the last historical shares flat, applied to WoM GDP
    last_sh = {s: sh0.loc[fut[0], s] for s in SEC}  # ~ current structure entering projection
    # use the true last-historical shares
    lhy = int(d["Year"].max())
    tot_lh = sum(float(d[d.Year == lhy][f"SGDP_{s}"].iloc[0]) for s in SEC)
    cur_sh = {s: float(d[d.Year == lhy][f"SGDP_{s}"].iloc[0]) / tot_lh for s in SEC}
    sgdp_frozen = pin_sgdp_from_shares({y: cur_sh for y in fut}, g0)
    # services shift: tertiary +5pp linearly by horizon, primary/secondary shrink pro-rata
    def services_path(y):
        f = (y - (fut[0] - 1)) / len(fut)
        add = 0.05 * f
        ter = min(0.98, cur_sh["tertiary"] + add)
        rest = 1 - ter
        base_rest = cur_sh["primary"] + cur_sh["secondary"]
        scale = rest / base_rest if base_rest > 0 else 0
        return {"primary": cur_sh["primary"] * scale,
                "secondary": cur_sh["secondary"] * scale, "tertiary": ter}
    sgdp_services = pin_sgdp_from_shares({y: services_path(y) for y in fut}, g0)

    scenarios = {
        # idempotent class — must recover WoM exactly
        "C1_gdp=wom":        (ProjectedInputs(gdp_tot=gdp_wom), "idem"),
        "C2_gdp+pop=wom":    (ProjectedInputs(gdp_tot=gdp_wom, population=pop_wom), "idem"),
        "C3_gdp+sec=wom":    (ProjectedInputs(gdp_tot=gdp_wom, sgdp=sgdp_wom), "idem"),
        "C4_full=wom":       (ProjectedInputs(gdp_tot=gdp_wom, population=pop_wom, sgdp=sgdp_wom), "idem"),
        # localised-response class — pin a deviation
        "E1_gdp_aspir":      (ProjectedInputs(gdp_tot=gdp_aspir), "stress_gdp"),
        "F1_frozen_struct":  (ProjectedInputs(gdp_tot=gdp_wom, sgdp=sgdp_frozen), "stress_sec"),
        "F2_services_shift": (ProjectedInputs(gdp_tot=gdp_wom, sgdp=sgdp_services), "stress_sec"),
    }

    rows = []
    for name, (pi, klass) in scenarios.items():
        try:
            o = run_macro_module(hist, pi, cfg)
        except Exception as e:
            rows.append({"cc": cc, "region": region, "scenario": name, "class": klass,
                         "error": str(e)[:100]})
            continue
        g, p, sh = _outputs(o)
        yrs = [y for y in fut if y in g.index]
        # drift vs WoM baseline
        gdp_drift = max(abs(g[y] - g0[y]) / abs(g0[y]) for y in yrs)
        pop_drift = max(abs(p[y] - p0[y]) / abs(p0[y]) for y in yrs)
        struct_drift = max(abs(sh.loc[y, s] - sh0.loc[y, s]) * 100 for y in yrs for s in SEC)
        # identity residual
        recon = o.gdp_tot.set_index("Year")["GDP_tot"]
        sgsum = sum(o.sgdp.set_index("Year")[f"SGDP_{s}"] for s in SEC)
        ident = max(abs(recon[y] - sgsum[y]) / abs(recon[y]) for y in yrs)
        # negative / NaN guards
        bad = bool(sh.lt(0).any().any() or sh.isna().any().any() or g.isna().any())
        # fidelity to the pinned series (where pinned)
        gdp_fidelity = None
        if pi.gdp_tot is not None:
            pinned = pi.gdp_tot.set_index("Year")["GDP_tot"]
            gdp_fidelity = max(abs(g[y] - pinned[y]) / abs(pinned[y]) for y in yrs)
        sec_fidelity = None
        if pi.sgdp is not None:
            ps = _shares_frame(pi.sgdp)
            sec_fidelity = max(abs(sh.loc[y, s] - ps.loc[y, s]) * 100 for y in yrs for s in SEC)
        rows.append({
            "cc": cc, "region": region, "scenario": name, "class": klass,
            "gdp_drift_vs_wom": gdp_drift, "pop_drift_vs_wom": pop_drift,
            "struct_drift_vs_wom_pp": struct_drift, "identity_resid": ident,
            "gdp_fidelity": gdp_fidelity, "sec_fidelity_pp": sec_fidelity,
            "bad_values": bad,
        })
    return rows


def main() -> int:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    print(f"=== v4 input-configuration consistency simulation (EU-27, project to {HORIZON}) ===\n")
    all_rows = []
    for cc in REGION:
        all_rows.extend(run_country(cc))
    df = pd.DataFrame(all_rows)
    df.to_csv(OUTDIR / "consistency_by_country_scenario.csv", index=False)

    errs = df[df.get("error").notna()] if "error" in df.columns else pd.DataFrame()
    ok = df[~df.index.isin(errs.index)] if not errs.empty else df

    print("CONSISTENCY VERDICT (max across all 27 countries)\n")
    # 1) idempotent class — everything should be ~0
    idem = ok[ok["class"] == "idem"]
    print("A) IDEMPOTENT: pin = model WoM -> must recover WoM exactly")
    for sc in ["C1_gdp=wom", "C2_gdp+pop=wom", "C3_gdp+sec=wom", "C4_full=wom"]:
        s = idem[idem.scenario == sc]
        if s.empty:
            continue
        gd, pd_, sd, idn = (s.gdp_drift_vs_wom.max(), s.pop_drift_vs_wom.max(),
                            s.struct_drift_vs_wom_pp.max(), s.identity_resid.max())
        verdict = "PASS" if (gd < TOL_REL and pd_ < TOL_REL and sd < TOL_PP and idn < 1e-6) else "FAIL"
        print(f"   {sc:18} GDP drift={gd:.2e}  pop drift={pd_:.2e}  "
              f"struct drift={sd:.2e}pp  ident={idn:.2e}  -> {verdict}")

    # 2) localised-response class
    print("\nB) LOCALISED RESPONSE: pin a deviation -> only that var + downstream moves")
    e1 = ok[ok.scenario == "E1_gdp_aspir"]
    print(f"   E1_gdp_aspir (pin aggressive GDP): "
          f"pop drift max={e1.pop_drift_vs_wom.max():.2e} (expect ~0)  "
          f"GDP fidelity max={e1.gdp_fidelity.max():.2e} (expect ~0)  "
          f"struct moves up to {e1.struct_drift_vs_wom_pp.max():.2f}pp (income response)  "
          f"ident={e1.identity_resid.max():.2e}")
    for sc in ["F1_frozen_struct", "F2_services_shift"]:
        s = ok[ok.scenario == sc]
        print(f"   {sc:18} pop drift max={s.pop_drift_vs_wom.max():.2e} (expect ~0)  "
              f"GDP drift max={s.gdp_drift_vs_wom.max():.2e} (expect ~0)  "
              f"sectoral fidelity max={s.sec_fidelity_pp.max():.3f}pp (expect ~0)  "
              f"ident={s.identity_resid.max():.2e}")

    # 3) global guards
    print("\nC) GLOBAL GUARDS")
    print(f"   negative/NaN shares anywhere: {bool(ok.bad_values.any())} (expect False)")
    print(f"   max identity residual any scenario: {ok.identity_resid.max():.2e} (expect ~0)")
    if not errs.empty:
        print(f"\n   [{len(errs)} run errors]")
        for _, r in errs.iterrows():
            print(f"     {r.cc} {r.scenario}: {r.error}")

    print(f"\nWrote {OUTDIR / 'consistency_by_country_scenario.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
