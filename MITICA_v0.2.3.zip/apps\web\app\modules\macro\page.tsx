"use client";

import Link from "next/link";
import {
  ArrowLeft,
  ArrowUpRight,
  Activity,
  Layers,
  ShieldCheck,
  Globe2,
  Construction,
} from "lucide-react";

export default function MacroModulePage() {
  return (
    <div className="relative">
      <div
        aria-hidden
        className="absolute inset-x-0 top-0 h-[340px] bg-[radial-gradient(ellipse_at_top,hsl(240_40%_85%/0.3),transparent_65%)]"
      />

      <div className="relative mx-auto max-w-5xl px-5 py-14">
        <Link
          href="/"
          className="mb-8 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" /> Home
        </Link>

        {/* Header */}
        <header className="mb-14 grid gap-8 md:grid-cols-[auto_1fr] md:items-start">
          <div className="flex h-14 w-14 items-center justify-center rounded-sm border border-border bg-card text-indigo-600">
            <Activity className="h-7 w-7" />
          </div>
          <div>
            <div className="mb-3 flex items-center gap-3">
              <span className="eyebrow">01 / Module · SI-002</span>
              <span className="rounded-full border border-amber-600/30 bg-amber-600/10 px-2.5 py-0.5 text-[10px] font-medium text-amber-700">
                Beta · v0.1.0
              </span>
            </div>
            <h1 className="mb-5 max-w-3xl font-serif text-display-lg font-[440] tracking-tight">
              Macro<em className="italic">economic</em> module.
            </h1>
            <p className="max-w-3xl text-lg leading-relaxed text-foreground/75">
              Generates consistent macroeconomic and activity proxies that feed ANNALIST and the
              sectoral modules — replacing user-owned, unchecked proxies of the previous MITICA
              with a coherence-by-design layer.
            </p>
          </div>
        </header>

        {/* Construction notice */}
        <div className="mb-14 flex items-start gap-3 rounded-sm border border-dashed border-amber-600/30 bg-amber-600/[0.04] p-5 text-sm">
          <Construction className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" />
          <div>
            <p className="font-medium">Wiring into the Integration Module is in progress.</p>
            <p className="mt-1 text-foreground/75">
              The Python package <code className="rounded bg-muted px-1 font-mono">g_Macro</code>{" "}
              is ready (11 tests passing) and lives under{" "}
              <code className="rounded bg-muted px-1 font-mono">Modules/g_Macro_v0.1.0/</code>.
              Next step is exposing it through this UI: region selector, optional
              projected-paths upload, Layer C traffic-light review with touch-up accept / reject,
              and hand-off to ANNALIST.
            </p>
          </div>
        </div>

        <div className="hairline mb-14" />

        {/* Three-layer + flows */}
        <section className="mb-20 grid gap-12 md:grid-cols-2">
          <div>
            <div className="mb-5 flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" />
              <span className="eyebrow">Three-layer architecture</span>
            </div>
            <h2 className="mb-8 font-serif text-2xl font-[440]">
              A semi-structured model with{" "}
              <em className="italic">hard identities</em> and soft behavioural priors.
            </h2>
            <dl className="space-y-5">
              <div>
                <dt className="mb-1 font-serif text-lg font-[460]">
                  Layer A <span className="text-foreground/40">— accounting identities</span>
                </dt>
                <dd className="text-sm leading-relaxed text-foreground/75">
                  Hard constraints enforced by construction. GDP_tot = Σ sectoral GDP; primary
                  GDP = crops + livestock; sectoral energy demand sums to total by fuel.
                </dd>
              </div>
              <div>
                <dt className="mb-1 font-serif text-lg font-[460]">
                  Layer B <span className="text-foreground/40">— behavioural equations</span>
                </dt>
                <dd className="text-sm leading-relaxed text-foreground/75">
                  Demography (B1), sectoral GDP (B2), primary split (B3), livestock heads (B4),
                  sectoral energy (B5), residential (B6). Each estimated with Bayesian shrinkage
                  toward regional priors to stabilise identification on short series.
                </dd>
              </div>
              <div>
                <dt className="mb-1 font-serif text-lg font-[460]">
                  Layer C <span className="text-foreground/40">— validation & touch-up</span>
                </dt>
                <dd className="text-sm leading-relaxed text-foreground/75">
                  Six traffic-light tests over the outputs. Red blocks execution. Amber surfaces
                  a dialog with the proposed retouch; the user can accept / reject / edit per
                  test.
                </dd>
              </div>
            </dl>
          </div>

          <div>
            <div className="mb-5 flex items-center gap-2">
              <Globe2 className="h-4 w-4 text-primary" />
              <span className="eyebrow">Three user flows</span>
            </div>
            <h2 className="mb-8 font-serif text-2xl font-[440]">
              Adapts to <em className="italic">what data you have</em>.
            </h2>
            <ol className="space-y-6">
              {[
                {
                  id: "F1",
                  title: "Complete projected paths",
                  body: "The module validates your paths against identities and behavioural bands, and may propose retouches when a test fires amber.",
                },
                {
                  id: "F2",
                  title: "Partial projections",
                  body: "Typically only an aspirational GDP path. The module fills the missing series consistently while preserving what you fixed.",
                },
                {
                  id: "F3",
                  title: "Historical only",
                  body: "The module projects everything using country-local estimation with priors as support for the short-series case.",
                },
              ].map((f) => (
                <li key={f.id} className="flex gap-4">
                  <span className="mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border font-mono text-xs font-medium">
                    {f.id}
                  </span>
                  <div>
                    <div className="font-serif text-lg font-[460]">{f.title}</div>
                    <p className="mt-0.5 text-sm leading-relaxed text-foreground/75">{f.body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <div className="hairline mb-14" />

        {/* Outputs + regions */}
        <section className="grid gap-12 md:grid-cols-2">
          <div>
            <div className="mb-5 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-primary" />
              <span className="eyebrow">Outputs for ANNALIST</span>
            </div>
            <h2 className="mb-6 font-serif text-2xl font-[440]">
              Year-indexed frames, named as ANNALIST expects.
            </h2>
            <ul className="space-y-2 text-sm">
              {[
                ["GDP_tot", "population", "GDP_per_cap"],
                ["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"],
                ["SGDP_crops", "SGDP_livestock"],
                ["SED_<sector>", "× 7 energy sectors"],
                ["SED_households", "Heads"],
              ].map((row, i) => (
                <li
                  key={i}
                  className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-border/50 pb-2 last:border-0"
                >
                  {row.map((item, j) => (
                    <code
                      key={j}
                      className="rounded-sm bg-muted px-2 py-0.5 font-mono text-[12px]"
                    >
                      {item}
                    </code>
                  ))}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="mb-5 flex items-center gap-2">
              <span className="eyebrow">Regional priors</span>
            </div>
            <h2 className="mb-6 font-serif text-2xl font-[440]">
              Six regions for Bayesian{" "}
              <em className="italic">shrinkage</em> stabilisation.
            </h2>
            <div className="mb-5 grid grid-cols-3 gap-2">
              {[
                ["LAC", "Latin America & Caribbean"],
                ["SSA", "Sub-Saharan Africa"],
                ["MENA", "Middle East & N. Africa"],
                ["APAC", "Asia-Pacific"],
                ["EEU", "Eastern Europe"],
                ["HIC", "High-income"],
              ].map(([code, name]) => (
                <div
                  key={code}
                  className="rounded-sm border border-border bg-card p-3 text-center"
                >
                  <div className="font-serif text-base font-[460]">{code}</div>
                  <div className="mt-0.5 text-[10px] text-muted-foreground">{name}</div>
                </div>
              ))}
            </div>
            <p className="text-xs italic leading-relaxed text-muted-foreground">
              Current priors are plausible order-of-magnitude placeholders. Training on
              WDI&nbsp;/&nbsp;Penn&nbsp;World&nbsp;Table&nbsp;/&nbsp;FAOSTAT panels is a
              separate offline workstream — the <code className="rounded bg-muted px-1 font-mono">Priors</code> interface
              does not change, only the numeric constants do.
            </p>
          </div>
        </section>

        {/* CTA */}
        <div className="mt-20 flex flex-wrap items-center justify-between gap-4 rounded-sm border border-border bg-card p-6">
          <div>
            <div className="font-serif text-lg">
              Once the UI is wired, a single click activates this module per project.
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              Outputs persist as a checkpoint and ANNALIST picks them up automatically.
            </p>
          </div>
          <Link
            href="/projects"
            className="group inline-flex items-center gap-2 rounded-sm border border-border px-4 py-2 text-sm font-medium hover:border-foreground/40"
          >
            Continue to Integration
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
