"""Informe técnico español - Parte II: Especificación, Estimación, Calibración
(secciones 4-6)."""

from __future__ import annotations

from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, Spacer, PageBreak

from report_common import header_table, fmt_num, fmt_se


def P(s, sty):
    return Paragraph(s, sty)


def content_part2(S, data):
    out = []

    # ============================================================
    # 4. ESPECIFICACIÓN DEL MODELO
    # ============================================================
    out.append(P("4.&nbsp;&nbsp; Especificación del modelo", S["H1"]))
    out.append(P("Esta sección expone las ecuaciones operativas para "
                  "cada capa. Las ecuaciones se presentan en su forma "
                  "final; el álgebra que respalda el posterior bayesiano "
                  "está en la sección 5 y en el apéndice A. Cada capa "
                  "es un módulo Python único en "
                  "<font face='Courier'>packages/core/src/mitica_core/"
                  "modules/macro/</font>.", S["BODY"]))

    out.append(P("4.1&nbsp; Notación", S["H2"]))
    out.append(P("Índices: c &isin; países, t &isin; años, s &isin; "
                  "{primary, secondary, tertiary}, k &isin; {primary, "
                  "manufacturing, construction, services, "
                  "transport_pass, transport_freight}, r &isin; "
                  "{LAC, SSA, MENA, APAC, EEU, HIC, HIC_TRANS}.",
                  S["BODY"]))
    out.append(P("Variables: GDP_tot PIB total a precios constantes; "
                  "Pop población; GDPpc = GDP_tot / Pop; SGDP_s valor "
                  "añadido sectorial; SInv_s formación bruta de capital "
                  "sectorial; GFCF_pub_s formación pública sectorial; "
                  "iRate tipo de interés efectivo (proxy: rentabilidad "
                  "bono soberano a largo plazo); SED_k consumo "
                  "energético final sectorial; SED_hh consumo "
                  "energético residencial.", S["BODY"]))

    out.append(P("4.2&nbsp; Capa A &mdash; Identidades contables",
                  S["H2"]))
    out.append(P("La Capa A impone tres identidades sobre los datos "
                  "históricos y la salida proyectada:", S["BODY"]))
    out.append(P("GDP_tot,t = SGDP_primary,t + SGDP_secondary,t + "
                  "SGDP_tertiary,t&emsp;&emsp;(I-1)", S["EQN"]))
    out.append(P("share_crops,t + share_livestock,t + share_other,t = 1"
                  "&emsp;&emsp;(I-2)", S["EQN"]))
    out.append(P("TED_t = SED_hh,t + sum_k SED_k,t,&emsp;TED_t &gt; 0 "
                  "y finito&emsp;&emsp;(I-3)", S["EQN"]))
    out.append(P("Las violaciones de (I-1) o (I-2) elevan una marca "
                  "roja en la Capa C y abortan la proyección. La "
                  "identidad (I-3) se deriva más que se verifica.",
                  S["BODY"]))

    out.append(P("4.3&nbsp; Capa B1 &mdash; Población", S["H2"]))
    out.append(P("La trayectoria de población se toma verbatim del "
                  "usuario en los flujos F1 o F2. En F3 se usa una "
                  "proyección de crecimiento constante. La "
                  "descomposición demográfica (edad, sexo, fertilidad, "
                  "migración) queda fuera del alcance; los usuarios con "
                  "escenarios UN WPP los pasan como input proyectado.",
                  S["BODY"]))

    out.append(P("4.4&nbsp; Capa B2 &mdash; PIB sectorial", S["H2"]))
    out.append(P("Coexisten tres formas, seleccionadas por el campo "
                  "<font face='Courier'>b2_form</font>. Sea Y_s,t = "
                  "log SGDP_s,t y &epsilon;_s,t ~ N(0, "
                  "&sigma;&sup2;_s) la perturbación.", S["BODY"]))

    out.append(P("4.4.1&nbsp; Forma log-log (defecto, b2_form='log_log')",
                  S["H3"]))
    out.append(P("Y_s,t = &alpha;_s + &beta;_s log SInv_s,t + &gamma;_s "
                  "log GFCF_pub_s,t + &zeta;_s log Pop_t + &delta;_s "
                  "iRate_t + &epsilon;_s,t&emsp;(2-LL)", S["EQN"]))
    out.append(P("Cinco coeficientes por sector: una constante "
                  "&alpha;_s, tres log-elasticidades (&beta;_s sobre "
                  "inversión sectorial, &gamma;_s sobre capital "
                  "público, &zeta;_s sobre población), y una "
                  "semielasticidad &delta;_s sobre el tipo de interés. "
                  "Patrón de signos esperado: &beta;, &gamma;, &zeta; "
                  "&gt; 0; &delta; &le; 0.", S["BODY"]))

    out.append(P("4.4.2&nbsp; Kuznets-Chenery lineal "
                  "(b2_form='kuznets_chenery')", S["H3"]))
    out.append(P("Y_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1}&emsp;(2-KC)",
                  S["EQN"]))
    out.append(P("El shifter usa el PIB per cápita rezagado en un "
                  "periodo. Rezagar un año elimina la simultaneidad "
                  "que surgiría con GDP/Pop_t contemporáneo en el lado "
                  "derecho.", S["BODY"]))

    out.append(P("4.4.3&nbsp; Kuznets-Chenery cuadrático "
                  "(b2_form='kuznets_chenery_quad')", S["H3"]))
    out.append(P("Y_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1} + "
                  "&kappa;&sup2;_s [log(GDP/Pop)_{t-1}]&sup2;&emsp;"
                  "(2-KCQ)", S["EQN"]))
    out.append(P("Añade el cuadrático en log PIB per cápita para "
                  "capturar la joroba no monótona. El pico (o valle) "
                  "implícito está en log(GDP/Pop)* = &minus; &kappa;_s "
                  "/ (2 &kappa;&sup2;_s).", S["BODY"]))

    out.append(P("4.4.4&nbsp; Detección activa de drivers", S["H3"]))
    out.append(P("Un driver entra en la regresión sólo si el usuario "
                  "aportó datos históricos con al menos 3 observaciones "
                  "no nulas, positividad estricta (para variables en "
                  "log), y variación no trivial (std &gt; 1e-9). Los "
                  "drivers que fallan cualquier check tienen su "
                  "coeficiente fijado en el prior regional y etiquetado "
                  "<i>calibrated</i>. Esta es la separación de v2.0 "
                  "respecto a v1.1s donde las covariables faltantes se "
                  "sintetizaban como fracciones constantes de SGDP_s.",
                  S["BODY"]))

    out.append(P("4.5&nbsp; Capa B3 &mdash; Descomposición primaria",
                  S["H2"]))
    out.append(P("Divide SGDP_primary en cultivos, ganadería y otros "
                  "vía cuotas que suman 1. Dos formas:", S["BODY"]))
    out.append(P("4.5.1&nbsp; Constante (b3_form='constant')", S["H3"]))
    out.append(P("share_crops_t = share_crops_{última obs}, "
                  "share_livestock_t = share_livestock_{última obs}. "
                  "Se usa el default regional cuando no existen datos "
                  "históricos de cuotas. share_other es el residual.",
                  S["BODY"]))
    out.append(P("4.5.2&nbsp; Bennett logístico (b3_form='bennett_logistic')",
                  S["H3"]))
    out.append(P("logit(share_livestock_t) = a_B + b_B log(GDP/Pop_t)"
                  "&emsp;(3-BL)", S["EQN"]))

    out.append(P("4.6&nbsp; Capa B4 &mdash; Cabezas de ganado", S["H2"]))
    out.append(P("Proyección en dos etapas. Primero, productividad "
                  "animal converge a un objetivo regional:", S["BODY"]))
    out.append(P("prod_animal,t = prod_animal,t-1 + &theta;_g "
                  "(prod_animal* &minus; prod_animal,t-1)&emsp;(4-A)",
                  S["EQN"]))
    out.append(P("Segundo, la identidad de cabezas:", S["BODY"]))
    out.append(P("log Heads_t = &alpha;_g + &beta;_g log "
                  "SGDP_prim_livestock,t &minus; &gamma;_g log "
                  "prod_animal_t + &epsilon;_g,t&emsp;(4-B)", S["EQN"]))

    out.append(P("4.7&nbsp; Capa B5 &mdash; Demanda energética sectorial",
                  S["H2"]))
    out.append(P("Seis sectores energéticos k. Dos formas vía "
                  "<font face='Courier'>b5_form</font>:", S["BODY"]))
    out.append(P("4.7.1&nbsp; Log-log (b5_form='log_log')", S["H3"]))
    out.append(P("log SED_k,t = &alpha;_k + &beta;_k log d&sup1;_k,t "
                  "[+ &gamma;_k log d&sup2;_k,t] + &epsilon;_k,t&emsp;"
                  "(5-LL)", S["EQN"]))
    out.append(P("4.7.2&nbsp; Convergencia de intensidad "
                  "(b5_form='intensity_convergence')", S["H3"]))
    out.append(P("log(SED_k,t / scale_k,t) = &phi;_k + &psi;_k "
                  "log(GDP/Pop_t) + &epsilon;_k,t&emsp;(5-IC)", S["EQN"]))
    out.append(P("Equivalentemente log SED_k,t = &phi;_k + log "
                  "scale_k,t + &psi;_k log(GDP/Pop_t) + &epsilon;. La "
                  "elasticidad de actividad se fija a 1 (retornos "
                  "constantes a actividad para intensidad dada); la "
                  "elasticidad-renta de la intensidad &psi;_k transporta "
                  "la tendencia secular.", S["BODY"]))

    out.append(P("4.8&nbsp; Capa B6 &mdash; Energía residencial",
                  S["H2"]))
    out.append(P("Dos formas vía <font face='Courier'>b6_form</font>:",
                  S["BODY"]))
    out.append(P("4.8.1&nbsp; Log-log (b6_form='log_log')", S["H3"]))
    out.append(P("log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) "
                  "+ &zeta;_hh log Pop_t + &epsilon;_hh,t&emsp;(6-LL)",
                  S["EQN"]))
    out.append(P("4.8.2&nbsp; Saturación (b6_form='saturation')",
                  S["H3"]))
    out.append(P("log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) "
                  "+ &gamma;_hh [log(GDP/Pop_t)]&sup2; + &zeta;_hh log "
                  "Pop_t + &epsilon;_hh,t&emsp;(6-SAT)", S["EQN"]))

    out.append(P("4.9&nbsp; Capa B7 &mdash; Mezcla de combustibles",
                  S["H2"]))
    out.append(P("Las cuotas por (sector, combustible) por defecto se "
                  "fijan al último valor observado o una plantilla "
                  "regional. Las cuotas proyectadas por el usuario "
                  "sobreescriben. La identidad cross-fuel (cuotas por "
                  "sector suman 1) se impone por I-2'.", S["BODY"]))

    out.append(P("4.10&nbsp; Capa C &mdash; Validación", S["H2"]))
    out.append(P("Ocho tests corren sobre la salida completa.",
                  S["BODY"]))
    out.append(header_table([
        ["#", "Nombre", "Disparador", "Severidad"],
        ["T1", "Identidades contables", "I-1 o I-2 violadas", "red"],
        ["T2", "Desviación de rango histórico",
         "proyección &gt; ±2 sigma de últimos 15 años", "amber"],
        ["T3", "Bandas de productividad sostenida",
         "g_Prod 5-y rolling fuera de banda regional", "amber"],
        ["T4", "Monotonicidad estructural",
         "serie de cuotas invierte signo", "amber"],
        ["T5", "Coherencia entre variables",
         "GDPpc vs SED inconsistente con bandas", "amber"],
        ["T6", "Benchmark externo",
         "endpoint fuera del rango de literatura", "info"],
        ["T7", "Plausibilidad de la trayectoria del usuario",
         "trayectoria del usuario desvía 25%/60% del modelo",
         "amber/red"],
        ["T8", "Cambio estructural en la frontera",
         "primeros 3 crecimientos proyectados &gt; 2,5/4,0 sigma "
         "de la distribución histórica de 10 años", "amber/red"],
    ], col_widths=[1*cm, 4.5*cm, 8*cm, 3*cm]))
    out.append(Spacer(1, 0.3*cm))

    out.append(PageBreak())

    # ============================================================
    # 5. ESTRATEGIA DE ESTIMACIÓN
    # ============================================================
    out.append(P("5.&nbsp;&nbsp; Estrategia de estimación", S["H1"]))
    out.append(P(
        "El módulo estima parámetros mediante regresión bayesiana "
        "en forma cerrada con priors regionales. Esta sección deriva "
        "el estimador y discute las elecciones de diseño.", S["BODY"]))

    out.append(P("5.1&nbsp; El modelo bayesiano", S["H2"]))
    out.append(P("Para cada capa que estima parámetros, se escribe el "
                  "modelo en forma matricial:", S["BODY"]))
    out.append(P("y = X &theta; + &epsilon;,&emsp;&epsilon; ~ N(0, "
                  "&sigma;&sup2; I_n)&emsp;(5-1)", S["EQN"]))
    out.append(P("Con prior gaussiano sobre &theta;:", S["BODY"]))
    out.append(P("&theta; ~ N(&theta;_prior, &Sigma;_prior,eff)&emsp;"
                  "(5-2)", S["EQN"]))
    out.append(P("donde &theta;_prior es la media del prior regional y "
                  "&Sigma;_prior,eff = &Sigma;_prior / k es una "
                  "covarianza escalada cuya fuerza se controla por una "
                  "única perilla &lambda; &isin; [0, 1].", S["BODY"]))

    out.append(P("5.2&nbsp; Posterior en forma cerrada", S["H2"]))
    out.append(P("Bajo el setup conjugado gaussiano-gaussiano el "
                  "posterior es analítico. La precisión posterior es "
                  "la suma de la precisión de los datos y la del "
                  "prior:", S["BODY"]))
    out.append(P("&Sigma;_post&#8315;&sup1; = X'X / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1;&emsp;(5-3)", S["EQN"]))
    out.append(P("Y la media posterior es el promedio ponderado por "
                  "precisión del estimador OLS y la media del prior:",
                  S["BODY"]))
    out.append(P("&theta;_hat = &Sigma;_post (X'y / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1; &theta;_prior)&emsp;"
                  "(5-4)", S["EQN"]))
    out.append(P("Esta es la corrección de v2.0: v1.1s escribía "
                  "&Sigma;_post = &sigma;&sup2; (X'X + &lambda; I)"
                  "&#8315;&sup1;, escala incorrecta que colapsaba los "
                  "intervalos creíbles a shrinkage alto.", S["BODY"]))
    out.append(P("La varianza del ruido &sigma;&sup2; se estima por "
                  "una primera pasada OLS:", S["BODY"]))
    out.append(P("&sigma;&sup2;_hat = (y &minus; X &theta;_OLS)' (y "
                  "&minus; X &theta;_OLS) / (n &minus; p)&emsp;(5-5)",
                  S["EQN"]))

    out.append(P("5.3&nbsp; Parametrización de la shrinkage", S["H2"]))
    out.append(P("La única perilla del usuario es "
                  "<font face='Courier'>estimation_shrinkage</font> "
                  "&lambda; &isin; [0, 1]. Internamente la varianza "
                  "del prior se escala por la transformación de odds "
                  "simétrica:", S["BODY"]))
    out.append(P("k = &lambda; / (1 &minus; &lambda;),&emsp;"
                  "&Sigma;_prior,eff = &Sigma;_prior / k&emsp;(5-6)",
                  S["EQN"]))
    out.append(P("Propiedades: &lambda; = 0 implica k = 0 y "
                  "&Sigma;_prior,eff = &infin; (prior no informativo, "
                  "OLS). &lambda; = 0,5 implica k = 1 y "
                  "&Sigma;_prior,eff = &Sigma;_prior (interpretación "
                  "de pesos iguales). &lambda; = 1 implica k = "
                  "&infin; y &Sigma;_prior,eff = 0 (prior dogmático, "
                  "&theta;_hat = &theta;_prior).", S["BODY"]))

    out.append(P("5.4&nbsp; Por qué shrinkage bayesiana sobre paneles "
                  "cortos", S["H2"]))
    out.append(P("Los inventarios nacionales típicamente contienen "
                  "10-25 años de datos &mdash; apenas suficiente para "
                  "identificar cinco coeficientes en la forma log-log. "
                  "OLS puro sobre tales series cortas produce "
                  "estimaciones de alta varianza que extrapolan mal. "
                  "La proyección sólo con prior (equivalente a &lambda; "
                  "= 1) descarta la propia experiencia del país. La "
                  "shrinkage bayesiana ofrece una interpolación "
                  "principiada.", S["BODY"]))

    out.append(P("5.5&nbsp; Tratamiento honesto de drivers faltantes",
                  S["H2"]))
    out.append(P("v1.1s, ante una serie SInv o GFCF_pub faltante, "
                  "sintetizaba la covariable como fracción fija del "
                  "SGDP_s (e.g., SInv_secondary &equiv; 0,20 "
                  "SGDP_secondary). La matriz de diseño quedaba "
                  "linealmente dependiente del target y la regresión "
                  "devolvía coeficientes que ajustaban el ruido. v2.0 "
                  "excluye los drivers faltantes íntegramente de la "
                  "regresión.", S["BODY"]))

    out.append(P("5.6&nbsp; Diagnóstico de multicolinealidad", S["H2"]))
    out.append(P("Cuando hay dos o más drivers activos se computa el "
                  "Factor de Inflación de la Varianza para cada uno:",
                  S["BODY"]))
    out.append(P("VIF_j = 1 / (1 &minus; R&sup2;_j)&emsp;(5-7)",
                  S["EQN"]))
    out.append(P("VIF_j &gt; 10 emite una nota diagnóstica sobre el "
                  "parámetro afectado pero no bloquea la proyección.",
                  S["BODY"]))

    out.append(P("5.7&nbsp; Etiquetas de origen como traza de auditoría",
                  S["H2"]))
    out.append(P("Cada parámetro lleva una de tres etiquetas:",
                  S["BODY"]))
    out.append(P("&bull; <b>estimated</b>: n_obs &ge; 15 Y shrinkage "
                  "&lt; 0,10. Los datos del país dominaron.",
                  S["BULLET"]))
    out.append(P("&bull; <b>adjusted</b>: datos y prior contribuyeron "
                  "aproximadamente por igual.", S["BULLET"]))
    out.append(P("&bull; <b>calibrated</b>: el prior domina porque "
                  "el driver es inactivo o n_obs muy pequeño.",
                  S["BULLET"]))

    out.append(PageBreak())

    # ============================================================
    # 6. DATOS Y CALIBRACIÓN
    # ============================================================
    out.append(P("6.&nbsp;&nbsp; Datos y calibración", S["H1"]))
    out.append(P("Los priors regionales se calibran contra dos paneles: "
                  "el WDI del Banco Mundial (217 países, 1960-2024) "
                  "para la capa B2, y el nrg_bal_c de Eurostat (29 "
                  "economías europeas, 1990-2024) para las capas B5 / "
                  "B6. El pipeline es completamente reproducible y "
                  "offline.", S["BODY"]))

    out.append(P("6.1&nbsp; Fuentes de datos", S["H2"]))
    out.append(header_table([
        ["Indicador", "Fuente", "Código", "Cobertura"],
        ["PIB, valor añadido sectorial", "Eurostat",
         "nama_10_gdp / nama_10_a10", "UE-27 + UK + NO + CH, 1995-2024"],
        ["GFCF sectorial",   "Eurostat", "nama_10_a64_p5",
         "UE-27 + UK + NO, 1995-2024"],
        ["Población",        "Eurostat", "demo_pjan",
         "UE-27 + UK + NO + CH, 1990-2024"],
        ["Rentabilidad bono LP", "Eurostat", "irt_lt_mcby_a",
         "UE-27 + UK, 1990-2024"],
        ["Demanda energética sectorial", "Eurostat", "nrg_bal_c",
         "UE-27 + UK + NO, 1990-2024"],
        ["PIB / Pop / SGDP globales", "Banco Mundial",
         "WDI (NY.*, NV.*, SP.*)", "217 países, 1960-2024"],
        ["Clasificación países", "Banco Mundial", "WDI ingreso+región",
         "Todos los países"],
    ], col_widths=[3.5*cm, 2.5*cm, 4.5*cm, 5.7*cm]))
    out.append(Spacer(1, 0.3*cm))

    out.append(P("6.2&nbsp; Clasificación de países", S["H2"]))
    out.append(P("Las regiones MITICA se derivan del nivel de ingreso "
                  "+ región geográfica del Banco Mundial, con un "
                  "refinamiento empírico para la clase HIC. El "
                  "refinamiento usa el umbral de PIB per cápita 1990 "
                  "= USD 15.000 a precios constantes 2015. Los países "
                  "con ingreso HIC pero PIB/Pop 1990 inferior al "
                  "umbral van a HIC_TRANS; el resto a HIC.", S["BODY"]))
    out.append(header_table([
        ["Región", "Definición", "n"],
        ["HIC",       "ingreso = HIC Y 1990 GDPpc &ge; $15k", "61"],
        ["HIC_TRANS", "ingreso = HIC Y 1990 GDPpc &lt; $15k", "25"],
        ["LAC",       "ingreso &ne; HIC Y región WB = LCN",    "23"],
        ["SSA",       "ingreso &ne; HIC Y región WB = SSF",    "47"],
        ["MENA",      "ingreso &ne; HIC Y región WB = MEA",    "15"],
        ["APAC",      "ingreso &ne; HIC Y región WB &isin; {EAS, SAS}",
         "28"],
        ["EEU",       "ingreso &ne; HIC Y región WB = ECS",    "18"],
    ], col_widths=[3.5*cm, 8.5*cm, 1.5*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("6.3&nbsp; Calibración B2 en forma de nivel",
                  S["H2"]))
    out.append(P("La calibración B2 corre una regresión panel de "
                  "efectos fijos por país, en la forma de NIVEL que "
                  "coincide con la ecuación (2-KCQ) del módulo:",
                  S["BODY"]))
    out.append(P("log SGDP_s,c,t = &alpha;_c,s + &zeta;_s log Pop_c,t "
                  "+ &kappa;_s log GDPpc_c,t&minus;1 + "
                  "&kappa;&sup2;_s [log GDPpc_c,t&minus;1]&sup2; + "
                  "&epsilon;&emsp;(6-1)", S["EQN"]))

    out.append(P("6.4&nbsp; Calibración energética B5 / B6", S["H2"]))
    out.append(P("Dos regresiones, ambas con efectos fijos por país.",
                  S["BODY"]))
    out.append(P("B5 (convergencia de intensidad):", S["BODY"]))
    out.append(P("log(SED_k,c,t / scale_k,c,t) = &alpha;_c,k + "
                  "&psi;_k log GDPpc_c,t + &epsilon;&emsp;(6-2)",
                  S["EQN"]))
    out.append(P("B6 (saturación):", S["BODY"]))
    out.append(P("log SED_hh,c,t = &alpha;_c + &beta;_hh log GDPpc_c,t "
                  "+ &gamma;_hh [log GDPpc_c,t]&sup2; + &zeta;_hh log "
                  "Pop_c,t + &epsilon;&emsp;(6-3)", S["EQN"]))

    out.append(P("6.5&nbsp; Robustez bootstrap", S["H2"]))
    out.append(P("Se corre bootstrap clusterizado por país (n = 200 "
                  "réplicas; remuestreo de países enteros con "
                  "reemplazo, preservando la correlación serial "
                  "intra-país) sobre cada regresión panel. La "
                  "desviación estándar bootstrap a lo largo de "
                  "réplicas es el estadístico de robustez. |t| = "
                  "|&theta;_hat| / SE_boot &gt; 2 indica significación "
                  "regional.", S["BODY"]))
    out.append(P("Resultado titular: los &zeta;_s en B2 y los "
                  "&psi;_manuf, &psi;_transport en B5 son robustos. "
                  "Los &kappa; y &kappa;&sup2; en B2 son en su mayoría "
                  "NO (intervalos de confianza cruzan cero), excepto "
                  "HIC_TRANS secundario donde ambos están identificados "
                  "con precisión. La consecuencia metodológica es "
                  "importante: los priors anchos que fijamos sobre "
                  "&kappa; y &kappa;&sup2; no son una precaución "
                  "metodológica &mdash; reflejan que la señal panel "
                  "global sobre los shifters de renta es genuinamente "
                  "débil.", S["BODY"]))

    out.append(P("6.6&nbsp; Valores calibrados B2", S["H2"]))
    rows = [["Región", "Sector", "&zeta; (SE)", "&kappa; (SE)",
             "&kappa;&sup2; (SE)"]]
    highlights = []
    zeta = data["calib_b2"].get("zeta", {})
    kappa = data["calib_b2"].get("kappa", {})
    kappa2 = data["calib_b2"].get("kappa2", {})
    boot = data["calib_b2"].get("boot_se", {})
    ri = 1
    for r in ("HIC", "HIC_TRANS", "EEU", "LAC", "MENA", "APAC", "SSA"):
        for sec in ("primary", "secondary", "tertiary"):
            z = (zeta.get(r) or {}).get(sec)
            k = (kappa.get(r) or {}).get(sec)
            k2 = (kappa2.get(r) or {}).get(sec)
            ses = (boot.get(r) or {}).get(sec, {})
            zse = ses.get("zeta_se"); kse = ses.get("kappa_se")
            k2se = ses.get("kappa2_se")
            rows.append([r, sec, fmt_se(z, zse, 3), fmt_se(k, kse, 3),
                          fmt_se(k2, k2se, 3)])
            for col, (v, se) in enumerate([(z, zse), (k, kse),
                                            (k2, k2se)], start=2):
                if v is not None and se is not None and se > 0 and \
                        abs(v / se) > 2:
                    highlights.append((ri, col))
            ri += 1
    out.append(header_table(rows,
        col_widths=[2.2*cm, 2.5*cm, 3.8*cm, 3.8*cm, 3.8*cm],
        highlight_cells=highlights))
    out.append(Spacer(1, 0.3*cm))

    out.append(P("6.7&nbsp; Valores calibrados B5 (&psi;_k)", S["H2"]))
    psi = data["calib_energy"].get("psi", {})
    psi_se = data["calib_energy"].get("psi_boot_se", {})
    rows = [["Región", "&psi;_primario", "&psi;_manuf",
             "&psi;_servicios", "&psi;_transporte"]]
    highlights = []
    ri = 1
    for r in ("HIC", "HIC_TRANS"):
        row = [r]
        for ci, sec in enumerate(("primary", "manufacturing", "services",
                                    "transport"), start=1):
            v = (psi.get(r) or {}).get(sec)
            se = (psi_se.get(r) or {}).get(sec)
            row.append(fmt_se(v, se, 3))
            if v is not None and se is not None and se > 0 and \
                    abs(v / se) > 2:
                highlights.append((ri, ci))
        rows.append(row)
        ri += 1
    out.append(header_table(rows,
        col_widths=[2.5*cm, 3.5*cm, 3.5*cm, 3.5*cm, 3.5*cm],
        highlight_cells=highlights))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("La calibración cubre HIC y HIC_TRANS. Las demás "
                  "regiones usan priors estilizados (Apéndice B).",
                  S["NOTE"]))

    out.append(P("6.8&nbsp; Valores calibrados B6", S["H2"]))
    b6 = data["calib_energy"].get("b6", {})
    rows = [["Región", "&beta;_hh", "&gamma;_hh", "&zeta;_hh",
             "Inflexión log(GDPpc)*"]]
    for r in ("HIC", "HIC_TRANS"):
        d = (b6.get(r) or {})
        beta = d.get("beta_hh"); gamma = d.get("gamma_hh")
        zeta_hh = d.get("zeta_hh")
        if beta is not None and gamma is not None and abs(gamma) > 1e-6:
            infl = -beta / (2 * gamma)
            try:
                infl_str = f"{infl:.2f} (~${int(2.71828**infl):,})"
            except Exception:
                infl_str = f"{infl:.2f}"
        else:
            infl_str = "n/a"
        rows.append([r, fmt_num(beta, 3), fmt_num(gamma, 3),
                      fmt_num(zeta_hh, 3), infl_str])
    out.append(header_table(rows,
        col_widths=[2.5*cm, 2.8*cm, 2.8*cm, 2.8*cm, 5*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(PageBreak())

    return out
