"""Shared utilities for the bilingual technical report builders.

Provides ReportLab styles, table helpers, JSON loaders, and the page-template
factory used by both ``build_technical_report_en.py`` and
``build_technical_report_es.py``.
"""

from __future__ import annotations

import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle,
                                PageBreak, KeepTogether)

DOCS_DIR = Path("docs")
WDI_DIR  = Path("scripts/macro_validation/wdi_data")
RES_DIR  = Path("scripts/macro_validation/results")


# ---------------------------------------------------------------------------
# Styles
# ---------------------------------------------------------------------------

_styles = getSampleStyleSheet()


def make_styles():
    """Return a dict of named ParagraphStyles. Created fresh each call so
    cross-document mutation does not happen."""
    H1 = ParagraphStyle("H1", parent=_styles["Heading1"], fontSize=16,
                        spaceBefore=18, spaceAfter=10,
                        textColor=colors.HexColor("#0b1d4f"),
                        fontName="Helvetica-Bold")
    H2 = ParagraphStyle("H2", parent=_styles["Heading2"], fontSize=12.5,
                        spaceBefore=12, spaceAfter=5,
                        textColor=colors.HexColor("#1a3268"),
                        fontName="Helvetica-Bold")
    H3 = ParagraphStyle("H3", parent=_styles["Heading3"], fontSize=11,
                        spaceBefore=10, spaceAfter=3,
                        textColor=colors.HexColor("#2b3a67"),
                        fontName="Helvetica-Bold")
    H4 = ParagraphStyle("H4", parent=_styles["Heading4"], fontSize=10.2,
                        spaceBefore=8, spaceAfter=2,
                        textColor=colors.HexColor("#444"),
                        fontName="Helvetica-Oblique")
    BODY = ParagraphStyle("Body", parent=_styles["BodyText"], fontSize=10,
                          leading=13.5, alignment=TA_JUSTIFY, spaceAfter=5,
                          firstLineIndent=0)
    BODY_FIRST = ParagraphStyle("BodyFirst", parent=BODY,
                                 firstLineIndent=14)
    BULLET = ParagraphStyle("Bullet", parent=BODY, leftIndent=14,
                             spaceAfter=2)
    EQN = ParagraphStyle("Eqn", parent=_styles["BodyText"], fontSize=10,
                          leading=13, alignment=TA_CENTER, spaceBefore=6,
                          spaceAfter=6, textColor=colors.HexColor("#202020"),
                          fontName="Courier",
                          backColor=colors.HexColor("#f7f7fc"),
                          borderPadding=5,
                          borderColor=colors.HexColor("#dde4f2"),
                          borderWidth=0.5)
    EQN_NUMBERED = ParagraphStyle("EqnN", parent=EQN, alignment=TA_LEFT)
    DERIV = ParagraphStyle("Deriv", parent=EQN, fontSize=9.5, leading=12,
                            spaceBefore=3, spaceAfter=3)
    NOTE = ParagraphStyle("Note", parent=BODY, fontSize=9,
                          textColor=colors.gray, spaceAfter=2)
    QUOTE = ParagraphStyle("Quote", parent=BODY, leftIndent=1*cm,
                            rightIndent=1*cm,
                            textColor=colors.HexColor("#333"),
                            fontName="Helvetica-Oblique",
                            spaceBefore=4, spaceAfter=4)
    ABSTRACT = ParagraphStyle("Abstract", parent=BODY, fontSize=10,
                               leading=13.5, leftIndent=1.2*cm,
                               rightIndent=1.2*cm,
                               backColor=colors.HexColor("#f3f5fa"),
                               borderColor=colors.HexColor("#dde4f2"),
                               borderPadding=10, borderWidth=0.5)
    TITLE = ParagraphStyle("Title", parent=_styles["Title"], fontSize=22,
                            textColor=colors.HexColor("#0b1d4f"),
                            spaceAfter=8, alignment=TA_CENTER)
    SUB = ParagraphStyle("Sub", parent=BODY, fontSize=13, alignment=TA_CENTER,
                          textColor=colors.HexColor("#444"))
    AUTHOR = ParagraphStyle("Author", parent=BODY, fontSize=11,
                             alignment=TA_CENTER,
                             textColor=colors.HexColor("#333"),
                             spaceAfter=18)
    return dict(H1=H1, H2=H2, H3=H3, H4=H4, BODY=BODY, BODY_FIRST=BODY_FIRST,
                BULLET=BULLET, EQN=EQN, EQN_NUMBERED=EQN_NUMBERED,
                DERIV=DERIV, NOTE=NOTE, QUOTE=QUOTE, ABSTRACT=ABSTRACT,
                TITLE=TITLE, SUB=SUB, AUTHOR=AUTHOR)


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


def header_table(data, col_widths=None, header_bg="#0b1d4f",
                  header_fg="#ffffff", highlight_cells=None,
                  highlight_rows=None, font_size=8.5):
    t = Table(data, colWidths=col_widths, hAlign="LEFT")
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(header_bg)),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.HexColor(header_fg)),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME",   (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",   (0, 0), (-1, -1), font_size),
        ("ALIGN",      (1, 0), (-1, -1), "RIGHT"),
        ("ALIGN",      (0, 0), (0, -1), "LEFT"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
            [colors.white, colors.HexColor("#f7f7fc")]),
        ("LINEBELOW", (0, 0), (-1, 0), 1.0, colors.HexColor("#0b1d4f")),
        ("BOX",       (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for ri in (highlight_rows or []):
        style.append(("BACKGROUND", (0, ri), (-1, ri),
                      colors.HexColor("#dfeacb")))
    for (r, c) in (highlight_cells or []):
        style.append(("BACKGROUND", (c, r), (c, r),
                      colors.HexColor("#dfeacb")))
        style.append(("FONTNAME", (c, r), (c, r), "Helvetica-Bold"))
    t.setStyle(TableStyle(style))
    return t


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------


def load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def load_all_data():
    """Return a dict with the calibrated priors and sensitivities."""
    return {
        "calib_b2":     load_json(WDI_DIR / "calibrated_priors.json") or {},
        "calib_energy": load_json(WDI_DIR / "calibrated_energy_priors.json") or {},
        "sensitivities": load_json(RES_DIR / "sensitivities.json") or {},
    }


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def fmt_num(v, digits=3, sign=True):
    if v is None or (isinstance(v, float) and v != v):
        return "n/a"
    fmt = f"{{:+.{digits}f}}" if sign else f"{{:.{digits}f}}"
    return fmt.format(v)


def fmt_se(v, se, digits=3):
    s = fmt_num(v, digits)
    if se is None or (isinstance(se, float) and se != se):
        return s
    return f"{s} ({se:.2f})"


def fmt_pct(v, digits=2, sign=True):
    if v is None or (isinstance(v, float) and v != v):
        return "n/a"
    fmt = f"{{:+.{digits}f}}%" if sign else f"{{:.{digits}f}}%"
    return fmt.format(v)


def fmt_int(v):
    if v is None:
        return "n/a"
    return f"{int(v):,}"


# ---------------------------------------------------------------------------
# Page template factory
# ---------------------------------------------------------------------------


def make_doc_template(out_path: Path, title: str, author: str,
                       header_left: str, header_right: str):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc = BaseDocTemplate(
        str(out_path), pagesize=A4,
        leftMargin=2.2*cm, rightMargin=2.2*cm,
        topMargin=2.0*cm, bottomMargin=2.0*cm,
        title=title, author=author,
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin,
                   doc.width, doc.height, id="main")

    def _hf(canvas, document):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#666"))
        canvas.drawString(2.2*cm, A4[1] - 1.2*cm, header_left)
        canvas.drawRightString(A4[0] - 2.2*cm, A4[1] - 1.2*cm, header_right)
        canvas.line(2.2*cm, A4[1] - 1.4*cm,
                    A4[0] - 2.2*cm, A4[1] - 1.4*cm)
        canvas.drawCentredString(A4[0]/2, 1.2*cm, f"- {document.page} -")
        canvas.restoreState()

    doc.addPageTemplates([
        PageTemplate(id="all", frames=[frame], onPage=_hf),
    ])
    return doc
