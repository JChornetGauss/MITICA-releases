"""EU real-data backtest of the Waste module (SI-007) — C2, Eurostat panel.

Protocol (mirrors the validated MITICA pattern — energy/TED/transport):
train on history → 2018, project the OBSERVED window 2019–2024 with the OBSERVED
drivers (population, gdp_pc) fed as the projected inputs (the "TED trick"), and
score the WoM against the reported inventory:

- per CATEGORY (5A/5B/5C/5D): MAPE + mean signed bias over 2019–2024,
- for the SECTOR-5 TOTAL (Σ of the modelled categories vs Σ of the SAME observed
  categories — apples-to-apples; 5E/5F are not modelled so CRF5 is reported only
  as context),
- plausibility: finite, non-negative, validation-flag counts.

Anchor's role (design §2.1): the per-category scale+offset reproduces the 2018
inventory EXACTLY, so the LEVEL is absorbed by construction. What this backtest
scores is the projected TREND 2019→2024.

Realistic input rule: a category is fed only if its 2018 reported value is > 0.
An all-zero reported series (e.g. DE 5C — incineration emissions reported under
Energy) carries no level to anchor to; the correct WoM is zero, and feeding it
trips an engine bug (the anchor scale<=0 guard → population leaks as kt). That
defect is documented in WASTE_BACKTEST.md; here we exclude zero-base categories,
mirroring how an SI-008 reader treats a notation-key/NO line.

DATA (parsed with pandas; no LLM numbers):
- Eurostat env_air_gge waste sector → scripts/waste_validation/data/eurostat/
  tidy_waste_gge.csv (CRF5A/5B/5C/5D, airpol GHG = kt CO2-eq).
- Drivers: WDI pop.csv + gdp_const_usd.csv (gdp_pc = gdp/pop).

Run: .venv\\Scripts\\python.exe scripts\\waste_validation\\eu_waste_backtest.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.waste import (  # noqa: E402
    WasteConfig,
    WasteInputs,
    run_waste_module,
)

GGE = Path(__file__).parent / "data" / "eurostat" / "tidy_waste_gge.csv"
WDI = ROOT / "scripts" / "energy_validation" / "data" / "wdi"
OUT = Path(__file__).parent / "results"

TRAIN_END = 2018
SCORE_YEARS = list(range(2019, 2025))
CATS = (("5A", "CRF5A"), ("5B", "CRF5B"), ("5C", "CRF5C"), ("5D", "CRF5D"))

# Eurostat 2-letter geo → WDI iso3
GEO_ISO = {
    "AT": "AUT", "BE": "BEL", "BG": "BGR", "CY": "CYP", "CZ": "CZE", "DE": "DEU",
    "DK": "DNK", "EE": "EST", "EL": "GRC", "ES": "ESP", "FI": "FIN", "FR": "FRA",
    "HR": "HRV", "HU": "HUN", "IE": "IRL", "IT": "ITA", "LT": "LTU", "LU": "LUX",
    "LV": "LVA", "MT": "MLT", "NL": "NLD", "PL": "POL", "PT": "PRT", "RO": "ROU",
    "SE": "SWE", "SI": "SVN", "SK": "SVK", "IS": "ISL", "NO": "NOR",
}
# IPCC climate zone for the bulk-k. Nordic+Baltic = boreal/cool; rest = temperate.
BOREAL = {"FI", "SE", "NO", "IS", "EE", "LV", "LT"}


def climate(geo: str) -> str:
    return "boreal_dry" if geo in BOREAL else "temperate_wet"


def obs_series(gge: pd.DataFrame, geo: str, crf: str) -> dict[int, float]:
    d = gge[(gge.geo == geo) & (gge.src_crf == crf) & (gge.airpol == "GHG")]
    return {int(r.year): float(r.value) for r in d.itertuples()}


def mape_bias(model: dict[int, float], obs: dict[int, float]) -> tuple[float, float, int]:
    apes, errs = [], []
    for y in SCORE_YEARS:
        if y not in obs or y not in model:
            continue
        o = obs[y]
        if o == 0:
            continue
        pe = (model[y] - o) / o * 100.0
        apes.append(abs(pe))
        errs.append(pe)
    if not apes:
        return np.nan, np.nan, 0
    return float(np.mean(apes)), float(np.mean(errs)), len(apes)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    gge = pd.read_csv(GGE)
    pop = pd.read_csv(WDI / "pop.csv")
    gdp = pd.read_csv(WDI / "gdp_const_usd.csv")

    detail, summary = [], []

    for geo, iso in GEO_ISO.items():
        try:
            p = pop[pop.iso3 == iso].set_index("year")["value"].to_dict()
            g = gdp[gdp.iso3 == iso].set_index("year")["value"].to_dict()
            gdp_pc = {y: g[y] / p[y] for y in p if y in g and p[y] > 0}
            if not gdp_pc:
                raise ValueError("no overlapping pop/gdp years")

            # observed per category (full window) + the categories we will feed
            obs = {cat: obs_series(gge, geo, crf) for cat, crf in CATS}
            inv: dict[str, dict[int, float]] = {}
            skipped = []
            for cat, crf in CATS:
                hist = {y: v for y, v in obs[cat].items() if y <= TRAIN_END}
                base = hist.get(TRAIN_END, 0.0)
                if base > 0:               # realistic: anchorable, occurring sector
                    inv[cat] = hist
                else:
                    skipped.append(cat)
            if not inv:
                raise ValueError("no category with a positive 2018 base year")

            inp = WasteInputs(
                country_code=geo,
                population={y: p[y] for y in p if 1990 <= y <= 2024},
                gdp_pc={y: gdp_pc[y] for y in gdp_pc if 1990 <= y <= 2024},
                inventory=inv,
            )
            cfg = WasteConfig(horizon_year=2024, climate_zone=climate(geo),
                              scenarios=("WoM",))
            out = run_waste_module(inp, cfg)

            # modelled per-category total per year
            model_cat: dict[str, dict[int, float]] = {c: {} for c in inv}
            for r in out.rows:
                bc = r.by_category()
                for c in inv:
                    if c in bc:
                        model_cat[c][r.year] = bc[c]

            # per-category skill
            row: dict[str, object] = {"geo": geo, "iso": iso,
                                      "climate": climate(geo),
                                      "income": out.income_group, "tier": out.tier}
            for cat in ("5A", "5B", "5C", "5D"):
                if cat in inv:
                    m, b, n = mape_bias(model_cat[cat], obs[cat])
                    row[f"mape_{cat}"] = m
                    row[f"bias_{cat}"] = b
                    detail.append({"geo": geo, "cat": cat,
                                   "mape": m, "bias": b, "n": n,
                                   "scale_log": out.resolution_log.get(cat, "")})
                else:
                    row[f"mape_{cat}"] = np.nan
                    row[f"bias_{cat}"] = np.nan

            # sector total over the FED categories (apples-to-apples)
            model_tot = {y: sum(model_cat[c].get(y, 0.0) for c in inv)
                         for y in SCORE_YEARS}
            obs_tot = {y: sum(obs[c].get(y, 0.0) for c in inv if y in obs[c])
                       for y in SCORE_YEARS}
            mt, bt, nt = mape_bias(model_tot, obs_tot)
            row["mape_tot"] = mt
            row["bias_tot"] = bt
            row["fed_cats"] = "+".join(inv)
            row["skipped"] = "+".join(skipped) if skipped else ""

            # plausibility
            allv = [v for r in out.rows for v in r.kt_co2eq.values()]
            row["finite"] = bool(np.all(np.isfinite(allv))) if allv else True
            row["nonneg"] = all(v >= 0 for v in allv)
            row["n_flags"] = len(out.validation_report)
            summary.append(row)
            print(f"{geo} ({out.income_group},{climate(geo)[:4]}): "
                  f"tot MAPE {mt:6.1f}% bias {bt:+6.1f}%  | "
                  f"5A {row['mape_5A'] if not pd.isna(row['mape_5A']) else float('nan'):6.1f}% "
                  f"5D {row['mape_5D'] if not pd.isna(row['mape_5D']) else float('nan'):6.1f}% "
                  f"| fed {row['fed_cats']} skip[{row['skipped']}]")
        except Exception as exc:  # noqa: BLE001 — report, don't hide
            print(f"{geo}: FAILED — {exc}")
            summary.append({"geo": geo, "error": str(exc)})

    det = pd.DataFrame(detail)
    summ = pd.DataFrame(summary)
    det.to_csv(OUT / "eu_by_category.csv", index=False)
    summ.to_csv(OUT / "eu_summary.csv", index=False)

    ok = summ.dropna(subset=["mape_tot"]) if "mape_tot" in summ else pd.DataFrame()
    print(f"\n=== EU panel (n={len(ok)} countries) ===")
    for col in ("mape_tot", "mape_5A", "mape_5B", "mape_5C", "mape_5D"):
        if col in ok and ok[col].notna().any():
            print(f"  {col:9s} median {ok[col].median():6.1f}%   "
                  f"p90 {ok[col].quantile(0.9):6.1f}%   n={ok[col].notna().sum()}")
    for col in ("bias_tot", "bias_5A", "bias_5D"):
        if col in ok and ok[col].notna().any():
            print(f"  {col:9s} median {ok[col].median():+6.1f}%")
    print(f"\nwrote {OUT / 'eu_summary.csv'}\nwrote {OUT / 'eu_by_category.csv'}")


if __name__ == "__main__":
    main()
