"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowRight, Play, Zap, Activity } from "lucide-react";

import { api } from "@/lib/api";
import type { ForecastMethod, JobStatus } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

const METHOD_DESCRIPTIONS: Record<ForecastMethod, string> = {
  ANNALIST: "Hybrid: HP filter + Ridge trend + ARIMA noise. MITICA's flagship model. Slowest but most nuanced.",
  LINREG: "OLS / WLS with Breusch-Pagan + max-weight proxy constraint. Medium speed.",
  AG: "Annual growth (mean of historical pct_change). Fastest. Good for smoke tests.",
  SARIMAX: "Not yet wired in this build — falls back to ANNALIST.",
  ThymeBoost: "Not yet wired in this build — falls back to ANNALIST.",
};

export default function ForecastPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data: project } = useQuery({ queryKey: ["project", id], queryFn: () => api.getProject(id) });

  const [horizon, setHorizon] = useState<number>(2035);
  const [refYear, setRefYear] = useState<string>("");
  const [method, setMethod] = useState<ForecastMethod>("ANNALIST");
  const [jobId, setJobId] = useState<string | null>(null);

  const run = useMutation({
    mutationFn: () =>
      api.runForecast(id, {
        horizon_year: horizon,
        reference_year: refYear ? Number(refYear) : null,
        method,
      }),
    onSuccess: (j) => setJobId(j.id),
  });

  const { data: job } = useQuery<JobStatus>({
    queryKey: ["job", id, jobId],
    queryFn: () => api.jobStatus(id, jobId!),
    enabled: jobId !== null,
    refetchInterval: (q) =>
      q.state.data && ["done", "error"].includes(q.state.data.status) ? false : 1500,
  });

  useEffect(() => {
    if (project?.horizon_year) setHorizon(project.horizon_year);
    if (project?.reference_year) setRefYear(String(project.reference_year));
  }, [project?.horizon_year, project?.reference_year]);

  const done = job?.status === "done";
  const err = job?.status === "error";
  const running = job?.status === "running" || job?.status === "pending";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" /> Run the baseline forecast (WOM)
        </CardTitle>
        <CardDescription>
          One run per category, executed in a background thread. Progress is polled every 1.5 s.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {(project?.use_macro_module || project?.use_energy_module) && (
          <div className="flex flex-wrap items-start gap-3 rounded-md border border-primary/30 bg-primary/5 p-3 text-xs">
            <div className="font-medium text-primary">SI-008 hand-off active</div>
            <div className="flex-1 text-foreground/80">
              {project.use_macro_module && (
                <div className="flex items-center gap-1.5">
                  <Activity className="h-3 w-3" />
                  <span>
                    Macro module proxies will replace the uploaded GDP / Population / SGDP / SED
                    series for this run.
                  </span>
                </div>
              )}
              {project.use_energy_module && (
                <div className="mt-1 flex items-start gap-1.5">
                  <Zap className="h-3 w-3 mt-0.5 shrink-0" />
                  <span>
                    Energy industries module will override{" "}
                    <code className="rounded bg-muted px-1 font-mono">1A1a</code> WoM forecast with
                    its merit-order dispatch totals, and contribute{" "}
                    <code className="rounded bg-muted px-1 font-mono">electricity_demand_gwh</code>{" "}
                    / <code className="rounded bg-muted px-1 font-mono">thermal_generation_gwh</code>{" "}
                    as Energy-sector proxies for 1A1b, 1A1c, 1A2, 1A4.
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <Label htmlFor="horizon">Horizon year</Label>
            <Input
              id="horizon"
              type="number"
              min={1990}
              max={2100}
              value={horizon}
              onChange={(e) => setHorizon(Number(e.target.value))}
            />
          </div>
          <div>
            <Label htmlFor="ref">Reference year (optional)</Label>
            <Input
              id="ref"
              type="number"
              placeholder="e.g. 2015"
              value={refYear}
              onChange={(e) => setRefYear(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="method">Method</Label>
            <select
              id="method"
              className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={method}
              onChange={(e) => setMethod(e.target.value as ForecastMethod)}
            >
              <option value="ANNALIST">ANNALIST (recommended)</option>
              <option value="LINREG">Linear regression (OLS/WLS)</option>
              <option value="AG">Annual growth (fastest)</option>
            </select>
          </div>
        </div>

        <div className="rounded-md border bg-muted/40 p-3 text-xs text-muted-foreground">
          <strong>{method}:</strong> {METHOD_DESCRIPTIONS[method]}
        </div>

        <div className="flex items-center gap-3">
          <Button onClick={() => run.mutate()} disabled={running || run.isPending}>
            <Play className="mr-2 h-4 w-4" />
            {run.isPending ? "Submitting…" : running ? "Running…" : "Run forecast"}
          </Button>
          {job && (
            <Badge variant={done ? "success" : err ? "destructive" : "secondary"}>
              {job.status}
            </Badge>
          )}
          {run.error && (
            <span className="text-sm text-destructive">{(run.error as Error).message}</span>
          )}
        </div>

        {job && (
          <div className="space-y-2">
            <Progress value={Math.round(job.progress * 100)} />
            <p className="text-xs text-muted-foreground">{job.message}</p>
            {err && (
              <pre className="whitespace-pre-wrap rounded-md border border-destructive/30 bg-destructive/5 p-2 text-xs text-destructive">
                {job.message}
              </pre>
            )}
          </div>
        )}

        {done && (
          <div className="flex items-center justify-end">
            <Button asChild>
              <Link href={`/projects/${id}/validate`}>
                Next: Validate <ArrowRight className="ml-2 h-3 w-3" />
              </Link>
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
