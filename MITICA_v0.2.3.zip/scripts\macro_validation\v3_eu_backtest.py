"""
EU-27 backtest of the v3 macro module.

For each EU country with cached data (Eurostat 1995-2024):

  1. Truncate the historical series at year T_split = 2014.
  2. Train v3 on 1995-2014.
  3. Project 2015-2024 under Profile A (Solow-derived Y; engine projects
     everything from population alone — the hardest test).
  4. Compare projected to actual GDP_tot and sectoral GDP shares.
  5. Compute per-country MAPE and the deviation of sectoral shares
     at horizon (2024) vs actual.

Variables compared:
  - GDP_tot
  - σ_primary, σ_secondary, σ_tertiary (sectoral shares)

The backtest also runs v2.0 (log_log) on the same data as a baseline.
The headline number for the paper is the median per-country MAPE on
total GDP and the worst-case primary-share deviation in percentage
points.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# Ensure the core package is importable
ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (    # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA_DIR = Path("scripts/macro_validation/data")
OUT_PATH = Path("scripts/macro_validation/results/v3_eu_backtest.csv")

TRAIN_END = 2014
TEST_END  = 2024

# Region mapping for EU countries. Most EU members are HIC; the recent
# accession states are HIC_TRANS (the 2004+ entrants whose Kuznets
# transition is in the sample).
EU_REGION = {
    "AT": "HIC", "BE": "HIC", "DE": "HIC", "DK": "HIC", "ES": "HIC",
    "FI": "HIC", "FR": "HIC", "IE": "HIC", "IT": "HIC", "LU": "HIC",
    "NL": "HIC", "NO": "HIC", "PT": "HIC", "SE": "HIC", "UK": "HIC",
    "CH": "HIC", "EL": "HIC", "CY": "HIC", "MT": "HIC",
    # Eastern / accession HIC_TRANS
    "BG": "HIC_TRANS", "CZ": "HIC_TRANS", "EE": "HIC_TRANS",
    "HR": "HIC_TRANS", "HU": "HIC_TRANS", "LT": "HIC_TRANS",
    "LV": "HIC_TRANS", "PL": "HIC_TRANS", "RO": "HIC_TRANS",
    "SI": "HIC_TRANS", "SK": "HIC_TRANS",
}


# ---------------------------------------------------------------------------


def load_country(country: str) -> HistoricalData | None:
    """Load Eurostat-cached CSVs for a country into a HistoricalData."""
    gdp_pop_p = DATA_DIR / f"{country}_gdp_pop.csv"
    sgdp_p = DATA_DIR / f"{country}_sgdp.csv"
    if not gdp_pop_p.exists() or not sgdp_p.exists():
        return None
    gdp_pop = pd.read_csv(gdp_pop_p)
    sgdp = pd.read_csv(sgdp_p)
    if "GDP_tot" not in gdp_pop.columns or "Pop" not in gdp_pop.columns:
        return None
    expected_sgdp_cols = {"Year", "SGDP_primary", "SGDP_secondary",
                          "SGDP_tertiary"}
    if not expected_sgdp_cols.issubset(sgdp.columns):
        return None
    gdp_df = gdp_pop[["Year", "GDP_tot"]].dropna()
    pop_df = gdp_pop[["Year", "Pop"]].dropna()
    sgdp_df = sgdp[list(expected_sgdp_cols)].dropna()
    if len(gdp_df) < 15 or len(sgdp_df) < 15:
        return None
    return HistoricalData(gdp_tot=gdp_df, population=pop_df, sgdp=sgdp_df)


def truncate_hist(hist: HistoricalData, year_max: int) -> HistoricalData:
    def _filter(df):
        if df is None:
            return df
        return df[df["Year"] <= year_max].reset_index(drop=True)
    return HistoricalData(
        gdp_tot=_filter(hist.gdp_tot),
        population=_filter(hist.population),
        sgdp=_filter(hist.sgdp),
    )


def actual_population_for_horizon(hist: HistoricalData) -> ProjectedInputs:
    """Use the country's ACTUAL population over the test window so we
    isolate the B2 + Solow fit error from B1 (population)."""
    pop = hist.population[
        (hist.population["Year"] > TRAIN_END)
        & (hist.population["Year"] <= TEST_END)
    ][["Year", "Pop"]].copy()
    return ProjectedInputs(population=pop)


def variable_mape(predicted: pd.Series, actual: pd.Series) -> float:
    aligned = pd.concat({"p": predicted, "a": actual}, axis=1).dropna()
    aligned = aligned[aligned["a"].abs() > 1e-9]
    if len(aligned) < 2:
        return float("nan")
    return float(np.mean(np.abs(aligned["a"] - aligned["p"]) / np.abs(aligned["a"])))


def shares(df: pd.DataFrame) -> pd.DataFrame:
    """Year-indexed sectoral share matrix."""
    s = df.copy().set_index("Year")
    total = s.sum(axis=1)
    return s.div(total, axis=0)


# ---------------------------------------------------------------------------


def run_one_country(country: str, b2_form: str) -> dict | None:
    """Train on 1995-TRAIN_END, project TRAIN_END+1..TEST_END, score."""
    hist_full = load_country(country)
    if hist_full is None:
        return None
    # Skip countries that don't cover the full test window — partial
    # coverage would silently truncate the comparison.
    needed_years = set(range(TRAIN_END + 1, TEST_END + 1))
    actual_pop_years = set(hist_full.population["Year"].astype(int).tolist())
    actual_gdp_years = set(hist_full.gdp_tot["Year"].astype(int).tolist())
    actual_sgdp_years = set(hist_full.sgdp["Year"].astype(int).tolist())
    if not (needed_years.issubset(actual_pop_years)
            and needed_years.issubset(actual_gdp_years)
            and needed_years.issubset(actual_sgdp_years)):
        return None
    hist_train = truncate_hist(hist_full, TRAIN_END)
    proj = actual_population_for_horizon(hist_full)
    cfg = MacroConfig(
        region=EU_REGION.get(country, "HIC"),
        horizon_year=TEST_END,
        b2_form=b2_form,
        b3_form="constant",
        b5_form="log_log",
        b6_form="log_log",
        profile="A",          # the hardest test — engine projects everything
        verbose=False,
        validate_historical=False,
    )
    try:
        out = run_macro_module(hist_train, proj, cfg)
    except (ValueError, RuntimeError) as e:
        return {"country": country, "b2_form": b2_form, "error": str(e)}

    test_years = list(range(TRAIN_END + 1, TEST_END + 1))
    actual_gdp = hist_full.gdp_tot.set_index("Year")["GDP_tot"]
    actual_sgdp = hist_full.sgdp.set_index("Year")
    pred_gdp = out.gdp_tot.set_index("Year")["GDP_tot"]
    pred_sgdp = out.sgdp.set_index("Year")

    test_actual_gdp = actual_gdp[actual_gdp.index.isin(test_years)]
    test_pred_gdp = pred_gdp[pred_gdp.index.isin(test_years)]
    mape_gdp = variable_mape(test_pred_gdp, test_actual_gdp)

    # Per-sector share deviation at horizon
    sect_cols = ["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"]
    horizon = TEST_END
    if horizon not in actual_sgdp.index or horizon not in pred_sgdp.index:
        return None
    actual_total = actual_sgdp.loc[horizon, sect_cols].sum()
    pred_total = pred_sgdp.loc[horizon, sect_cols].sum()
    actual_share = actual_sgdp.loc[horizon, sect_cols] / actual_total
    pred_share = pred_sgdp.loc[horizon, sect_cols] / pred_total
    dev_pp = {col: 100.0 * abs(pred_share[col] - actual_share[col])
              for col in sect_cols}

    return {
        "country":  country,
        "region":   cfg.region,
        "b2_form":  b2_form,
        "n_train":  int(hist_train.gdp_tot["Year"].max() - hist_train.gdp_tot["Year"].min() + 1),
        "mape_gdp": mape_gdp,
        "dev_pp_primary":   dev_pp["SGDP_primary"],
        "dev_pp_secondary": dev_pp["SGDP_secondary"],
        "dev_pp_tertiary":  dev_pp["SGDP_tertiary"],
        "actual_share_primary":   float(actual_share["SGDP_primary"]),
        "pred_share_primary":     float(pred_share["SGDP_primary"]),
        "actual_share_secondary": float(actual_share["SGDP_secondary"]),
        "pred_share_secondary":   float(pred_share["SGDP_secondary"]),
    }


def main() -> int:
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    print(f"=== v3 EU-27 backtest (train 1995-{TRAIN_END}, "
          f"project {TRAIN_END+1}-{TEST_END}) ===\n")

    rows = []
    for country in sorted(EU_REGION.keys()):
        for b2_form in ("log_log", "compositional"):
            r = run_one_country(country, b2_form)
            if r is None:
                continue
            rows.append(r)
            if "error" in r:
                print(f"  {country:<3}  {b2_form:<13}  ERROR: {r['error'][:60]}")
            else:
                print(f"  {country:<3}  {b2_form:<13}  "
                      f"mape_gdp={r['mape_gdp']:.1%}  "
                      f"|d_sig_P|={r['dev_pp_primary']:5.1f}pp  "
                      f"|d_sig_S|={r['dev_pp_secondary']:5.1f}pp")
    df = pd.DataFrame(rows)
    df.to_csv(OUT_PATH, index=False)

    # Headline summary
    print("\n" + "=" * 80)
    print("Summary (median per-country across EU-27)")
    print("=" * 80)
    df_ok = df[~df.get("error", pd.Series([False] * len(df))).astype(bool)] \
        if "error" in df.columns else df
    for b2 in ("log_log", "compositional"):
        sub = df_ok[df_ok["b2_form"] == b2]
        if len(sub) == 0:
            continue
        print(f"\n  b2_form = {b2}  (n={len(sub)})")
        print(f"    GDP MAPE median           : {sub['mape_gdp'].median():.1%}")
        print(f"    GDP MAPE 90th pctile      : {sub['mape_gdp'].quantile(0.90):.1%}")
        print(f"    Primary share |dev| median  : {sub['dev_pp_primary'].median():.1f} pp")
        print(f"    Secondary share |dev| median: {sub['dev_pp_secondary'].median():.1f} pp")
        print(f"    Tertiary share |dev| median : {sub['dev_pp_tertiary'].median():.1f} pp")
    print(f"\nWrote {OUT_PATH.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
