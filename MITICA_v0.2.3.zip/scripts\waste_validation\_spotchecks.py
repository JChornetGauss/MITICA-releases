"""Three independent hand-verification spot checks for WASTE_BACKTEST.md.

1. BTR Table5 raw-cell re-read: fresh openpyxl load of a specific year-workbook,
   read the 5.A CH4 cell, and reproduce the AR4 CO2-eq the CSV recorded.
2. Module anchor reproduces the 2018 base year EXACTLY (per category).
3. Independent recompute of one EU country's 2019 per-category % error from the
   raw inputs (no harness code), matching the summary CSV.
"""
from __future__ import annotations

import io
import sys
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))
from mitica_core.modules.waste import WasteConfig, WasteInputs, run_waste_module  # noqa: E402

BTR = ROOT / "scripts" / "energy_validation" / "data" / "btr"
GGE = Path(__file__).parent / "data" / "eurostat" / "tidy_waste_gge.csv"
T5 = Path(__file__).parent / "data" / "btr"
WDI = ROOT / "scripts" / "energy_validation" / "data" / "wdi"


def check1_btr_cell():
    print("=== SPOT CHECK 1: BTR Table5 raw-cell re-read (BRA, 5.A CH4) ===")
    z = zipfile.ZipFile(BTR / "BRA_CRT.zip")
    # find the 2020 workbook by reading each sheet's header year
    target_year = 2020
    for name in sorted(z.namelist()):
        if not name.lower().endswith(".xlsx") or "~$" in name:
            continue
        wb = openpyxl.load_workbook(io.BytesIO(z.read(name)), read_only=True, data_only=True)
        if "Table5" not in wb.sheetnames:
            wb.close(); continue
        ws = wb["Table5"]
        yr = None
        for r in ws.iter_rows(max_row=3, max_col=12):
            for c in r:
                if isinstance(c.value, (int, float)) and 1989 <= int(c.value) <= 2030:
                    yr = int(c.value)
                elif isinstance(c.value, str):
                    import re
                    m = re.search(r"\b((?:19|20)\d{2})\b", c.value)
                    if m:
                        yr = int(m.group(1))
                if yr:
                    break
            if yr:
                break
        if yr != target_year:
            wb.close(); continue
        # locate 5.A row + CH4 col fresh
        ch4_col = None
        for r in ws.iter_rows(max_row=12, max_col=12):
            for j, c in enumerate(r):
                if str(c.value or "").strip().upper() == "CH4":
                    ch4_col = j + 1
            if ch4_col:
                break
        ch4_val = None
        for r in ws.iter_rows(max_row=30, max_col=12):
            lab = str(r[1].value or "")
            if lab.strip().startswith("5.A.") and "Solid waste" in lab:
                ch4_val = r[ch4_col - 1].value
                break
        wb.close()
        co2eq = float(ch4_val) * 25.0
        print(f"  workbook={name.split('/')[-1]}")
        print(f"  raw 5.A CH4 cell (col {ch4_col}) = {ch4_val!r} kt")
        print(f"  AR4 CO2-eq = {ch4_val} * 25 = {co2eq:.2f} kt")
        csv = pd.read_csv(T5 / "BRA_table5.csv")
        row = csv[(csv.year == target_year) & (csv.cat == "5A")].iloc[0]
        print(f"  CSV: ch4_kt={row.ch4_kt}  co2eq_ar4_kt={row.co2eq_ar4_kt:.2f}")
        ok = abs(row.co2eq_ar4_kt - co2eq) < 0.01 and abs(row.ch4_kt - float(ch4_val)) < 1e-6
        print(f"  -> {'MATCH' if ok else 'MISMATCH'}")
        return
    print("  2020 workbook not found")


def check2_anchor():
    print("\n=== SPOT CHECK 2: module reproduces 2018 base year EXACTLY (ES) ===")
    gge = pd.read_csv(GGE)
    pop = pd.read_csv(WDI / "pop.csv"); gdp = pd.read_csv(WDI / "gdp_const_usd.csv")
    iso = "ESP"
    p = pop[pop.iso3 == iso].set_index("year")["value"].to_dict()
    g = gdp[gdp.iso3 == iso].set_index("year")["value"].to_dict()
    gdp_pc = {y: g[y] / p[y] for y in p if y in g}
    inv = {}
    for cat, crf in (("5A", "CRF5A"), ("5B", "CRF5B"), ("5C", "CRF5C"), ("5D", "CRF5D")):
        d = gge[(gge.geo == "ES") & (gge.src_crf == crf) & (gge.airpol == "GHG")]
        s = {int(r.year): float(r.value) for r in d.itertuples() if r.year <= 2018}
        if s.get(2018, 0) > 0:
            inv[cat] = s
    out = run_waste_module(
        WasteInputs(country_code="ES",
                    population={y: p[y] for y in p if 1990 <= y <= 2024},
                    gdp_pc={y: gdp_pc[y] for y in gdp_pc if 1990 <= y <= 2024},
                    inventory=inv),
        WasteConfig(horizon_year=2024, climate_zone="temperate_wet"))
    row2018 = next(r for r in out.rows if r.year == 2018)
    bc = row2018.by_category()
    for cat in inv:
        rep = inv[cat][2018]; mod = bc.get(cat, 0.0)
        print(f"  {cat}: reported 2018 = {rep:8.2f}  model 2018 = {mod:8.2f}  "
              f"diff {mod - rep:+.4f}  {'OK' if abs(mod - rep) < 0.05 else 'OFF'}")


def check3_eu_recompute():
    print("\n=== SPOT CHECK 3: independent 2019 5A %-error recompute (IT) ===")
    gge = pd.read_csv(GGE)
    pop = pd.read_csv(WDI / "pop.csv"); gdp = pd.read_csv(WDI / "gdp_const_usd.csv")
    iso = "ITA"
    p = pop[pop.iso3 == iso].set_index("year")["value"].to_dict()
    g = gdp[gdp.iso3 == iso].set_index("year")["value"].to_dict()
    gdp_pc = {y: g[y] / p[y] for y in p if y in g}
    inv = {}
    for cat, crf in (("5A", "CRF5A"), ("5B", "CRF5B"), ("5C", "CRF5C"), ("5D", "CRF5D")):
        d = gge[(gge.geo == "IT") & (gge.src_crf == crf) & (gge.airpol == "GHG")]
        s = {int(r.year): float(r.value) for r in d.itertuples() if r.year <= 2018}
        if s.get(2018, 0) > 0:
            inv[cat] = s
    out = run_waste_module(
        WasteInputs(country_code="IT",
                    population={y: p[y] for y in p if 1990 <= y <= 2024},
                    gdp_pc={y: gdp_pc[y] for y in gdp_pc if 1990 <= y <= 2024},
                    inventory=inv),
        WasteConfig(horizon_year=2024, climate_zone="temperate_wet"))
    model_5a_2019 = next(r for r in out.rows if r.year == 2019).by_category()["5A"]
    d = gge[(gge.geo == "IT") & (gge.src_crf == "CRF5A") & (gge.airpol == "GHG")]
    obs_5a_2019 = {int(r.year): float(r.value) for r in d.itertuples()}[2019]
    pe = (model_5a_2019 - obs_5a_2019) / obs_5a_2019 * 100
    print(f"  IT 5A 2019: model={model_5a_2019:.1f}  obs={obs_5a_2019:.1f}  %err={pe:+.1f}%")
    print(f"  (summary CSV IT mape_5A = 2.1% over 2019-2024)")


if __name__ == "__main__":
    check1_btr_cell()
    check2_anchor()
    check3_eu_recompute()
