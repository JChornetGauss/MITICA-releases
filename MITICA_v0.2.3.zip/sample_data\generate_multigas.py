"""Generate a MITICA v1.1s-style multi-gas inventory Excel for smoke-testing BI-001.

Produces `sample_data/inventory_multigas.xlsx` with one sheet per gas
(CO2, CH4, N2O, SF6, NF3, HFC, PFC) in the v1.1s template layout:
    Row 1 (free text) with country code at col C and unit at col E
    Row 2: Key Category | Country Code |  | Units | ktCO2eq | Initial Year | <years>
    Row 3+: `TRUE | "    <IPCC code>.  Description" | … | values…`

Values are already in kt CO2-eq per the MITICA convention (multiplied by GWP).

Run:  python sample_data/generate_multigas.py
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import openpyxl

HERE = Path(__file__).resolve().parent

# Category (code, label, {gas: [base_value, yoy_growth]}).  base_value is in
# kt CO2-eq; values already reflect GWP weighting per the MITICA convention.
#
# The per-gas composition we embed here roughly mimics real national profiles:
# - 1A1a (Power): CO2 dominates (~95%), some CH4 + N2O
# - 1A3b (Road transport): CO2 ~96%, N2O ~3%, CH4 ~1%
# - 3A1 (Enteric fermentation): CH4 100%
# - 3D (Agri soils): N2O 100%
# - 2A1 (Cement): CO2 100%
# - 2F (HFC refrigeration): HFCs 100%
# - 4A (Forest land, sink): CO2 only
# - 5A1 (Waste): CH4 ~92%, some CO2
CATEGORIES: dict[str, dict[str, tuple[float, float]]] = {
    "1A1a": {"CO2": (8000.0, 0.025), "CH4": (80.0, 0.020), "N2O": (40.0, 0.020)},
    "1A3b": {"CO2": (2900.0, 0.018), "CH4": (30.0, 0.015), "N2O": (90.0, 0.015)},
    "3A1": {"CH4": (2000.0, 0.005)},
    "3D": {"N2O": (800.0, 0.008)},
    "2A1": {"CO2": (400.0, 0.012)},
    "2F": {"HFCs": (120.0, 0.06)},
    "4A": {"CO2": (-500.0, 0.00)},  # Net sink
    "5A1": {"CH4": (540.0, 0.015), "CO2": (45.0, 0.010)},
}

YEARS = list(range(2000, 2023))
ALL_GASES = ("CO2", "CH4", "N2O", "SF6", "NF3", "HFCs", "PFCs")


def _generate_series(base: float, growth: float, n: int, seed: int) -> list[float]:
    rng = np.random.default_rng(seed)
    val = base
    out = []
    for _ in range(n):
        val *= 1.0 + growth + 0.02 * rng.standard_normal()
        out.append(float(val))
    return out


def write_multigas_template(path: Path) -> Path:
    wb = openpyxl.Workbook()
    # Remove the default sheet
    wb.remove(wb.active)

    for gas in ALL_GASES:
        ws = wb.create_sheet(title=gas)

        # Row 1 — freeform metadata (country at col C, unit at col E — matches v1.1s)
        ws.cell(row=1, column=1, value=f"MITICA multi-gas inventory — {gas}")
        ws.cell(row=1, column=3, value="TST")
        ws.cell(row=1, column=5, value="ktCO2eq")

        # Row 2 — MITICA header
        ws.cell(row=2, column=1, value="Key Category")
        ws.cell(row=2, column=2, value="Country Code")
        ws.cell(row=2, column=4, value="Units")
        ws.cell(row=2, column=5, value="ktCO2eq")
        ws.cell(row=2, column=6, value="Initial Year")
        for i, y in enumerate(YEARS, start=7):
            ws.cell(row=2, column=i, value=y)

        # Data rows — for every category, write only if this gas is present
        row_i = 3
        seed_bump = 0
        for code, gas_map in CATEGORIES.items():
            if gas not in gas_map:
                # Skip: this category has no data for this gas
                continue
            base, growth = gas_map[gas]
            series = _generate_series(base, growth, len(YEARS), seed=hash((code, gas)) % (2**31))
            # KCA flag (arbitrary — we leave empty)
            ws.cell(row=row_i, column=1, value=None)
            # "Country Code" column carries the indented IPCC code (v1.1s style)
            ws.cell(row=row_i, column=2, value=f"    {code}. {code}")
            for i, v in enumerate(series, start=7):
                ws.cell(row=row_i, column=i, value=float(v))
            row_i += 1
            seed_bump += 1

    # Also add a Units sheet for format compatibility
    units = wb.create_sheet(title="Units")
    units.cell(row=1, column=1, value="CO2 equivalente")
    units.cell(row=1, column=2, value="ktCO2eq")

    wb.save(path)
    return path


def main():
    out = write_multigas_template(HERE / "inventory_multigas.xlsx")
    print(f"[OK] {out}")
    # Print per-category, per-gas totals in a sanity-check table
    import pandas as pd
    all_dfs = []
    for gas in ALL_GASES:
        try:
            df = pd.read_excel(out, sheet_name=gas, header=1)
            df["Gas"] = gas
            all_dfs.append(df)
        except Exception:
            pass
    merged = pd.concat(all_dfs, ignore_index=True)
    year_cols = [c for c in merged.columns if isinstance(c, int)]
    if year_cols:
        latest = year_cols[-1]
        pivot = merged.pivot_table(
            index="Country Code", columns="Gas", values=latest, aggfunc="first"
        ).fillna(0)
        print(f"\nValues at year {latest} (kt CO2-eq):\n{pivot}")


if __name__ == "__main__":
    main()
