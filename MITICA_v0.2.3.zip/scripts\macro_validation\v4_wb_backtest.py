"""
v4 macro backtest on the World Bank panel (scripts/macro_validation/wdi_data/).

For each eligible country:
  1. T_end = last year with all series; T_split = T_end - H.
  2. Train the v4 engine on years <= T_split (>= MIN_TRAIN years required).
  3. Project T_split+1 .. T_end, supplying the country's ACTUAL population over
     the horizon (so we isolate the B0 + B2-EC fit error from B1 population).
  4. Score: GDP_tot MAPE over the test window, and the sectoral-share
     deviation (percentage points) at the horizon.

This is the hardest test (flow F3: the engine projects GDP and structure from
the country's own history alone). Reported by EU-27 vs the rest, and by income
group. The headline is the median / 90th-pctile per-country GDP MAPE — to be
read against the v3 figure (compositional+Solow: MAPE p90 ≈ 13.9%).

Per JL: China is intentionally NOT used as a representative case.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA = Path(__file__).resolve().parent / "wdi_data"
OUT = Path(__file__).resolve().parent / "results" / "v4_wb_backtest.csv"

INCOME_MAP = {"LIC": "L", "LMC": "LM", "UMC": "UM", "HIC": "H"}
H = 8            # project this many years
MIN_TRAIN = 12   # require at least this many training years

EU27 = {
    "AUT", "BEL", "BGR", "HRV", "CYP", "CZE", "DNK", "EST", "FIN", "FRA",
    "DEU", "GRC", "HUN", "IRL", "ITA", "LVA", "LTU", "LUX", "MLT", "NLD",
    "POL", "PRT", "ROU", "SVK", "SVN", "ESP", "SWE",
}
VALID_REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")


def _load(short: str) -> pd.DataFrame:
    return pd.read_csv(DATA / f"{short}.csv").rename(columns={"value": short})[
        ["iso3", "Year", short]]


def build_panel() -> pd.DataFrame:
    f = _load("GDP_tot")
    for s in ("Pop", "SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        f = f.merge(_load(s), on=["iso3", "Year"], how="inner")
    c = pd.read_csv(DATA / "countries.csv")[
        ["iso3", "name", "wb_income", "mitica_region"]]
    f = f.merge(c, on="iso3", how="inner")
    for col in ("GDP_tot", "Pop", "SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        f = f[f[col].notna() & (f[col] > 0)]
    f = f[f["mitica_region"].isin(VALID_REGIONS)]
    f = f[f["wb_income"].isin(INCOME_MAP.keys())]
    return f.sort_values(["iso3", "Year"]).reset_index(drop=True)


def run_country(sub: pd.DataFrame) -> dict | None:
    yrs = sub["Year"].astype(int).tolist()
    t_end = max(yrs)
    t_split = t_end - H
    test_years = [y for y in range(t_split + 1, t_end + 1) if y in yrs]
    if len(test_years) < H:
        return None
    train = sub[sub["Year"] <= t_split]
    if len(train) < MIN_TRAIN:
        return None

    hist = HistoricalData(
        gdp_tot=train[["Year", "GDP_tot"]].reset_index(drop=True),
        population=train[["Year", "Pop"]].reset_index(drop=True),
        sgdp=train[["Year", "SGDP_primary", "SGDP_secondary",
                    "SGDP_tertiary"]].reset_index(drop=True),
    )
    pop_fut = sub[(sub["Year"] > t_split) & (sub["Year"] <= t_end)][
        ["Year", "Pop"]].reset_index(drop=True)
    grp = INCOME_MAP[sub["wb_income"].iloc[0]]
    region = sub["mitica_region"].iloc[0]
    cfg = MacroConfig(region=region, dev_group=grp, horizon_year=t_end,
                      validate_historical=False)
    try:
        out = run_macro_module(hist, ProjectedInputs(population=pop_fut), cfg)
    except Exception as e:  # pragma: no cover — diagnostic
        return {"iso3": sub["iso3"].iloc[0], "error": str(e)[:80]}

    a_gdp = sub.set_index("Year")["GDP_tot"]
    p_gdp = out.gdp_tot.set_index("Year")["GDP_tot"]
    mape = float(np.mean([abs(a_gdp[y] - p_gdp[y]) / abs(a_gdp[y])
                          for y in test_years]))

    sect = ["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"]
    a_h = sub.set_index("Year").loc[t_end, sect]
    p_h = out.sgdp.set_index("Year").loc[t_end, sect]
    a_sh = a_h / a_h.sum()
    p_sh = p_h / p_h.sum()
    dev = {s: 100.0 * abs(p_sh[s] - a_sh[s]) for s in sect}

    return {
        "iso3": sub["iso3"].iloc[0],
        "income": sub["wb_income"].iloc[0],
        "group": grp,
        "region": region,
        "is_eu": sub["iso3"].iloc[0] in EU27,
        "n_train": len(train),
        "t_split": t_split,
        "t_end": t_end,
        "mape_gdp": mape,
        "dev_pp_primary": dev["SGDP_primary"],
        "dev_pp_secondary": dev["SGDP_secondary"],
        "dev_pp_tertiary": dev["SGDP_tertiary"],
    }


def _summ(df: pd.DataFrame, label: str) -> None:
    if len(df) == 0:
        print(f"  {label:<28} (no countries)")
        return
    print(f"  {label:<28} n={len(df):<3}  "
          f"MAPE med={df['mape_gdp'].median():6.1%}  "
          f"p90={df['mape_gdp'].quantile(0.90):6.1%}  "
          f"|dσ_prim| med={df['dev_pp_primary'].median():4.1f}pp  "
          f"|dσ_sec| med={df['dev_pp_secondary'].median():4.1f}pp")


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    panel = build_panel()
    print(f"=== v4 WB backtest (project last {H}y, train >= {MIN_TRAIN}y, "
          f"flow F3) ===")
    print(f"Panel: {panel['iso3'].nunique()} countries with all series\n")

    rows, errs = [], []
    for iso, sub in panel.groupby("iso3"):
        r = run_country(sub)
        if r is None:
            continue
        if "error" in r:
            errs.append(r)
            continue
        rows.append(r)
    df = pd.DataFrame(rows)
    df.to_csv(OUT, index=False)
    if errs:
        print(f"[{len(errs)} countries errored, e.g. {errs[0]}]\n")

    eu = df[df["is_eu"]]
    rest = df[~df["is_eu"]]
    print("EU-27:")
    _summ(eu, "EU-27")
    print("\nRest of the world, by income group:")
    for g in ("H", "UM", "LM", "L"):
        _summ(rest[rest["group"] == g], f"{g} (non-EU)")
    print("\nOverall:")
    _summ(df, "all countries")
    print(f"\nWrote {OUT.resolve()}  ({len(df)} countries scored)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
