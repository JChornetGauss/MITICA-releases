r"""Probe KAZ/CHL (and the other 6) CRT zips for the multi-sector coverage the
Phase-F acceptance test needs: Table1.A(a)s1 (1A1a), Table1s1 (1A2/1A3b/1A4),
Table2(I)s1 + Table2(II) (2A, 2F1/HFCs), Table4 (LULUCF), Table5 (5A-5D).

Read-only probe — prints sheet availability and the category rows found in
ONE latest-year workbook per country.

Run: .venv\Scripts\python.exe scripts\acceptance_f\probe_coverage.py [ISO ...]
"""
from __future__ import annotations

import io
import re
import sys
import zipfile
from pathlib import Path

import openpyxl

BTR = Path(__file__).resolve().parents[1] / "energy_validation" / "data" / "btr"
SHEETS_WANTED = [
    "Table1.A(a)s1", "Table1s1", "Table1s2", "Table2(I)s1", "Table2(I)s2",
    "Table2(II)", "Table4", "Table5", "Summary1.As1", "Summary1.As2",
]

ROW_PATTERNS = {
    "1A2": re.compile(r"^\s*1\.A\.2\.?\s+Manufacturing industries", re.I),
    "1A3b": re.compile(r"^\s*(1\.A\.3\.b\.?\s|b\.\s+Road transportation)", re.I),
    "1A4": re.compile(r"^\s*1\.A\.4\.?\s+Other sectors", re.I),
    "2A": re.compile(r"^\s*2\.A\.?\s+Mineral industry", re.I),
    "2F1": re.compile(r"^\s*2\.F\.1\.?\s+Refrigeration", re.I),
    "4TOT": re.compile(r"^\s*4\.\s+Total LULUCF", re.I),
    "4A": re.compile(r"^\s*4\.A\.?\s+Forest land", re.I),
    "5A": re.compile(r"^\s*5\.A\.?\s+Solid waste disposal", re.I),
}


def probe(iso: str) -> None:
    zpath = BTR / f"{iso}_CRT.zip"
    if not zpath.exists():
        print(f"{iso}: zip missing")
        return
    z = zipfile.ZipFile(zpath)
    members = sorted(n for n in z.namelist() if n.lower().endswith(".xlsx") and "~$" not in n)
    print(f"\n=== {iso}: {len(members)} workbooks; probing {members[-1]} ===")
    wb = openpyxl.load_workbook(io.BytesIO(z.read(members[-1])), read_only=True, data_only=True)
    have = set(wb.sheetnames)
    for s in SHEETS_WANTED:
        print(f"  sheet {s:16s} {'YES' if s in have else 'no'}")
    # scan each present sheet for the category rows
    for sheet in ("Table1s1", "Table1s2", "Table2(I)s1", "Table2(II)", "Table4", "Table5"):
        if sheet not in have:
            continue
        ws = wb[sheet]
        found = {}
        for r in ws.iter_rows(max_row=120, max_col=4):
            for c in r:
                v = c.value
                if not isinstance(v, str):
                    continue
                for key, pat in ROW_PATTERNS.items():
                    if key not in found and pat.match(v):
                        found[key] = (c.row, v.strip()[:60])
        print(f"  {sheet}: rows -> {sorted(found)}")
        for k, (row, lab) in sorted(found.items()):
            print(f"      {k:5s} r{row:<4d} {lab}")
    wb.close()


if __name__ == "__main__":
    isos = sys.argv[1:] or ["KAZ", "CHL"]
    for iso in isos:
        probe(iso)
