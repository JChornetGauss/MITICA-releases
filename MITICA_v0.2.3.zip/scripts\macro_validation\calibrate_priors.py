"""Estimate joint (zeta, kappa, kappa2) priors from the WDI panel — LEVEL form.

Specification
-------------
For each MITICA region r and sector s in {primary, secondary, tertiary}:

    log(SGDP_s)_{c,t} = alpha_{c,s} + zeta_s_r  * log(Pop_{c,t})
                                    + kappa_s_r  * log(GDPpc_{c,t-1})
                                    + kappa2_s_r * [log(GDPpc_{c,t-1})]^2
                                    + eps_{c,s,t}

This LEVEL form matches exactly the macro module's B2 equation, so the
recovered (zeta, kappa, kappa2) are usable verbatim as priors. The output
JSON contains the joint set; ``g_Macro_Priors.py`` overrides all three
fields when present.

We also report the SHARE-form (zeta-free) calibration as a sanity check
and historical comparator. The level form is the one wired to the module.

Identification & robustness
---------------------------
* Within-country demeaning -> one-way FE estimator (equivalent to including
  country dummies).
* We require at least 5 years of within-country variation; countries with
  shorter panels are dropped.
* HC1 standard errors via the standard within-FE formula.
* We report both the LINEAR (kappa only) and QUADRATIC (kappa+kappa2) priors;
  the quadratic ones inform the M8-bis hump variant.

Output
------
Writes ``scripts/macro_validation/wdi_data/calibrated_priors.json`` with the
estimated kappa / kappa2 per region per sector, ready to be loaded by
``g_Macro_Priors.py``. Also prints a side-by-side comparison with the
current stylised priors.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path("scripts/macro_validation/wdi_data")
OUT_PATH = DATA_DIR / "calibrated_priors.json"

REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")
SECTORS = ("primary", "secondary", "tertiary")

# Current stylised priors (kept for the side-by-side comparison)
STYLISED = {
    "kappa": {
        "LAC":       {"primary": -0.40, "secondary": -0.05, "tertiary": +0.20},
        "SSA":       {"primary": -0.40, "secondary": -0.05, "tertiary": +0.20},
        "MENA":      {"primary": -0.40, "secondary": -0.05, "tertiary": +0.20},
        "APAC":      {"primary": -0.40, "secondary": -0.05, "tertiary": +0.20},
        "EEU":       {"primary": -0.30, "secondary": -0.05, "tertiary": +0.15},
        "HIC":       {"primary": -0.20, "secondary": -0.05, "tertiary": +0.10},
        # HIC_TRANS starts as a copy of HIC; the empirical calibration will
        # then differentiate it.
        "HIC_TRANS": {"primary": -0.30, "secondary": -0.05, "tertiary": +0.15},
    },
    "kappa2": {
        r: {"primary": 0.0, "secondary": -0.05, "tertiary": 0.0}
        for r in REGIONS
    },
}


# ---------------------------------------------------------------------------
# Build the panel
# ---------------------------------------------------------------------------


def load_panel() -> pd.DataFrame:
    """Assemble the panel [iso3, mitica_region, Year, log_sgdp_*, log_pop,
    log_gpc_lag]."""
    countries = pd.read_csv(DATA_DIR / "countries.csv")
    countries = countries.dropna(subset=["mitica_region"])

    indicators = {
        "GDP_pc":         "GDP_pc",
        "GDP_tot":        "GDP_tot",
        "Pop":            "Pop",
        "SGDP_primary":   "SGDP_primary",
        "SGDP_secondary": "SGDP_secondary",
        "SGDP_tertiary":  "SGDP_tertiary",
    }
    frames = []
    for short_name in indicators:
        df = pd.read_csv(DATA_DIR / f"{short_name}.csv")
        df = df.rename(columns={"value": short_name})
        frames.append(df.set_index(["iso3", "Year"]))
    panel = frames[0]
    for f in frames[1:]:
        panel = panel.join(f, how="outer")
    panel = panel.reset_index()

    # Restrict to classified countries
    panel = panel.merge(countries[["iso3", "mitica_region"]], on="iso3", how="inner")

    # Log levels (the module's B2 form is in logs of LEVELS, not shares)
    for s in SECTORS:
        col = f"SGDP_{s}"
        panel[f"log_sgdp_{s}"] = np.log(panel[col].where(panel[col] > 0))
    panel["log_pop"] = np.log(panel["Pop"].where(panel["Pop"] > 0))
    panel = panel.replace([np.inf, -np.inf], np.nan)

    # Lagged log GDPpc per country (the M8-bis Kuznets-Chenery driver)
    panel = panel.sort_values(["iso3", "Year"])
    panel["log_gpc"] = np.log(panel["GDP_pc"].where(panel["GDP_pc"] > 0))
    panel["log_gpc_lag"] = panel.groupby("iso3")["log_gpc"].shift(1)

    return panel


# ---------------------------------------------------------------------------
# One-way FE estimator (within demeaning + OLS)
# ---------------------------------------------------------------------------


def _cluster_bootstrap_fe(df: pd.DataFrame, y_col: str, X_cols: list[str],
                           n_boot: int = 200, seed: int = 42
                           ) -> np.ndarray:
    """Country-clustered bootstrap CIs for the within-FE estimator.

    Returns the per-coefficient standard deviation across n_boot resamples
    (or NaN-filled if the panel is too small).
    """
    use = df.dropna(subset=[y_col] + X_cols).copy()
    if len(use) < 30:
        return np.full(len(X_cols), np.nan)
    countries = use["iso3"].unique()
    if len(countries) < 5:
        return np.full(len(X_cols), np.nan)
    rng = np.random.default_rng(seed)
    coefs = []
    for _ in range(n_boot):
        sampled = rng.choice(countries, size=len(countries), replace=True)
        parts = []
        for k, cc in enumerate(sampled):
            chunk = use[use["iso3"] == cc].copy()
            chunk["iso3"] = f"{cc}_{k}"
            parts.append(chunk)
        boot_df = pd.concat(parts, ignore_index=True)
        beta, _se, n = _fit_within_fe(boot_df, y_col, X_cols)
        if not np.isnan(beta).any():
            coefs.append(beta)
    if len(coefs) < n_boot // 2:
        return np.full(len(X_cols), np.nan)
    return np.asarray(coefs).std(axis=0, ddof=1)


def _fit_within_fe(df: pd.DataFrame, y_col: str, X_cols: list[str]
                   ) -> tuple[np.ndarray, np.ndarray, int]:
    """Run a one-way fixed-effects regression by demeaning within country.

    Returns (coefs, hc1_se, n_obs). coefs and hc1_se are ordered as X_cols.
    """
    # Drop rows missing y or any X
    use = df.dropna(subset=[y_col] + X_cols).copy()
    if len(use) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0

    # Drop singletons (countries with only one obs contribute nothing).
    counts = use.groupby("iso3").size()
    keep = counts[counts >= 5].index
    use = use[use["iso3"].isin(keep)]
    if len(use) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0
    # Within-country demean of the numeric columns (vectorised; no apply).
    cols = [y_col] + X_cols
    means = use.groupby("iso3")[cols].transform("mean")
    dm = use.copy()
    dm[cols] = dm[cols] - means
    if len(dm) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0

    y = dm[y_col].values
    X = dm[X_cols].values
    # OLS solve
    try:
        XtX_inv = np.linalg.inv(X.T @ X)
        beta = XtX_inv @ (X.T @ y)
        resid = y - X @ beta
        n = len(y)
        k = X.shape[1]
        # HC1 (heteroskedasticity-robust)
        S = (X * resid[:, None]).T @ (X * resid[:, None])
        var_hc1 = (n / (n - k)) * XtX_inv @ S @ XtX_inv
        se = np.sqrt(np.diag(var_hc1))
        return beta, se, n
    except np.linalg.LinAlgError:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0


# ---------------------------------------------------------------------------
# Regional calibration
# ---------------------------------------------------------------------------


def calibrate(panel: pd.DataFrame) -> dict:
    """Per region, per sector: estimate (kappa) [linear] and (kappa, kappa2)
    [quadratic] in both SHARE and LEVEL form. Also estimate zeta (Pop
    elasticity) in the level form. Returns a nested dict with all sets."""
    out_linear: dict = {r: {} for r in REGIONS}
    out_quad: dict = {r: {} for r in REGIONS}
    out_level: dict = {r: {} for r in REGIONS}     # joint (zeta, kappa)
    out_level_q: dict = {r: {} for r in REGIONS}   # joint (zeta, kappa, kappa2)
    boot_se: dict = {r: {} for r in REGIONS}        # bootstrap SEs for level_q
    n_obs: dict = {r: {} for r in REGIONS}

    for r in REGIONS:
        sub = panel[panel["mitica_region"] == r].copy()
        for s in SECTORS:
            # SHARE form: log(SGDP_s / GDP_tot) = alpha_c
            #             + kappa * log(GDPpc_lag) [+ kappa2 * log(GDPpc_lag)^2]
            #
            # We deliberately stay in the share form even though the module
            # applies kappa to log(SGDP_s) directly (not to a share). The
            # share form has a small misspecification: the implied level-form
            # kappa equivalent is (1 + kappa_share), so the true elasticity is
            # off by exactly one unit. We absorb this by setting tighter
            # prior std (so the module's country-level Bayesian fit can pull
            # to the right level), and by keeping the calibrated values small.
            # See docs/MACRO_MODEL_REVISED for the methodology trade-off.
            sub[f"log_share_{s}"] = (
                np.log(sub["GDP_pc"].where(sub["GDP_pc"] > 0))
            )
            # share_s = SGDP_s / GDP_tot
            share_s = sub[f"log_sgdp_{s}"] - np.log(
                sub["GDP_tot"].where(sub["GDP_tot"] > 0)
            )
            sub[f"log_share_{s}"] = share_s

            # --- Linear KC (share form) ---
            beta, _se, n = _fit_within_fe(
                sub, f"log_share_{s}", ["log_gpc_lag"]
            )
            out_linear[r][s] = float(beta[0]) if not np.isnan(beta[0]) else None

            # --- Quadratic KC (share form) ---
            sub2 = sub.copy()
            sub2["log_gpc_lag2"] = sub2["log_gpc_lag"] ** 2
            beta_q, _se_q, n_q = _fit_within_fe(
                sub2, f"log_share_{s}", ["log_gpc_lag", "log_gpc_lag2"]
            )
            if (not np.isnan(beta_q).any()) and n_q >= 100:
                out_quad[r][s] = {
                    "kappa":  float(beta_q[0]),
                    "kappa2": float(beta_q[1]),
                }
            else:
                out_quad[r][s] = {"kappa": None, "kappa2": None}

            # --- LEVEL form: log(SGDP_s) on log(Pop) + log(GDPpc_lag)
            # Returns the JOINT (zeta, kappa). The module's B2 equation
            # uses both, so importing this jointly eliminates the
            # share-vs-level mismatch documented in v1 of this calibration.
            y_col = f"log_sgdp_{s}"
            beta_lvl, _se_lvl, n_lvl = _fit_within_fe(
                sub, y_col, ["log_pop", "log_gpc_lag"]
            )
            if not np.isnan(beta_lvl).any() and n_lvl >= 100:
                out_level[r][s] = {
                    "zeta":  float(beta_lvl[0]),
                    "kappa": float(beta_lvl[1]),
                }
            else:
                out_level[r][s] = {"zeta": None, "kappa": None}

            # --- LEVEL form (quadratic): also estimates kappa2 jointly
            beta_lvl_q, _se_lvl_q, n_lvl_q = _fit_within_fe(
                sub2, y_col, ["log_pop", "log_gpc_lag", "log_gpc_lag2"]
            )
            if not np.isnan(beta_lvl_q).any() and n_lvl_q >= 100:
                out_level_q[r][s] = {
                    "zeta":   float(beta_lvl_q[0]),
                    "kappa":  float(beta_lvl_q[1]),
                    "kappa2": float(beta_lvl_q[2]),
                }
                # Bootstrap CI on (zeta, kappa, kappa2)
                bse = _cluster_bootstrap_fe(
                    sub2, y_col, ["log_pop", "log_gpc_lag", "log_gpc_lag2"]
                )
                boot_se[r][s] = {
                    "zeta_se":   float(bse[0]) if not np.isnan(bse[0]) else None,
                    "kappa_se":  float(bse[1]) if not np.isnan(bse[1]) else None,
                    "kappa2_se": float(bse[2]) if not np.isnan(bse[2]) else None,
                }
            else:
                out_level_q[r][s] = {"zeta": None, "kappa": None,
                                      "kappa2": None}
                boot_se[r][s] = {"zeta_se": None, "kappa_se": None,
                                  "kappa2_se": None}

            n_obs[r][s] = int(n)

    return {
        "linear":     out_linear,
        "quadratic":  out_quad,
        "level":      out_level,
        "level_quad": out_level_q,
        "boot_se":    boot_se,
        "n_obs":      n_obs,
    }


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def print_comparison(calib: dict) -> None:
    print("\n" + "=" * 105)
    print("LEVEL form (used by the module): (zeta, kappa, kappa2) per region")
    print("Specification: log(SGDP_s) = alpha_c + zeta log(Pop) + kappa log(GDPpc_lag) "
          "[+ kappa2 log(GDPpc_lag)^2]")
    print("Bootstrap SE in (parentheses); * = |t|>2 (signal robust)")
    print("=" * 105)
    print(f"{'region':<10} {'sector':<10}  {'zeta':>14}  {'kappa':>14}  "
          f"{'kappa2':>14}   shape")
    for r in REGIONS:
        for s in SECTORS:
            d = calib["level_quad"][r].get(s, {})
            ses = calib["boot_se"][r].get(s, {})
            z = d.get("zeta"); k = d.get("kappa"); k2 = d.get("kappa2")
            zs = ses.get("zeta_se"); ks = ses.get("kappa_se"); k2s = ses.get("kappa2_se")
            if z is None:
                print(f"{r:<10} {s:<10}  {'n/a':>14} {'n/a':>14} {'n/a':>14}")
                continue
            def _fmt(v, se):
                if v is None: return "n/a"
                if se is None: return f"{v:+.3f}"
                mark = "*" if abs(v / se) > 2.0 else " "
                return f"{v:+.3f}({se:.2f}){mark}"
            shape = "monotone"
            if abs(k2) > 0.005:
                peak = -k / (2 * k2)
                shape = ("hump" if k2 < 0 else "valley") + f" @ logGDPpc={peak:.2f}"
            print(f"{r:<10} {s:<10}  {_fmt(z, zs):>14}  {_fmt(k, ks):>14}  "
                  f"{_fmt(k2, k2s):>14}   {shape}")

    print("\n" + "=" * 90)
    print("SHARE form (historical comparator): kappa_share per region")
    print("(level kappa would be approximately 1 + kappa_share when zeta = 1)")
    print("=" * 90)
    print(f"{'region':<10} {'sector':<10} {'kappa_share':>14}  {'n_obs':>7}")
    for r in REGIONS:
        for s in SECTORS:
            cal = calib["linear"][r].get(s)
            n = calib["n_obs"][r][s]
            cal_str = f"{cal:+.4f}" if cal is not None else "   n/a"
            print(f"{r:<10} {s:<10} {cal_str:>14}  {n:>7}")


def write_json(calib: dict, path: Path) -> None:
    # The "kappa", "kappa2" fields at the top-level are the values the macro
    # module will load and use directly. We export them from the LEVEL form
    # which matches the module's B2 equation exactly. The SHARE-form values
    # are kept under "share_form_diagnostic" for historical comparison.
    level_q = calib["level_quad"]

    def _get(form_dict: dict, r: str, s: str, key: str):
        v = form_dict.get(r, {}).get(s, {}).get(key)
        if v is None:
            return None
        return float(v)

    payload = {
        "_meta": {
            "source": "World Bank WDI panel; one-way country fixed effects; "
                      "HC1 standard errors",
            "indicators": [
                "NY.GDP.PCAP.KD", "SP.POP.TOTL", "NY.GDP.MKTP.KD",
                "NV.AGR.TOTL.KD", "NV.IND.TOTL.KD", "NV.SRV.TOTL.KD",
            ],
            "year_range": [1960, 2024],
            "specification": (
                "log(SGDP_s) = alpha_c + zeta_s * log(Pop) "
                "+ kappa_s * log(GDPpc_lag) "
                "[+ kappa2_s * log(GDPpc_lag)^2]   "
                "(LEVEL form; matches the macro module's B2 equation exactly)"
            ),
        },
        # ---- Level-form coefficients used by the module ----
        "zeta":  {r: {s: _get(level_q, r, s, "zeta")
                      for s in SECTORS} for r in REGIONS},
        "kappa": {r: {s: _get(level_q, r, s, "kappa")
                      for s in SECTORS} for r in REGIONS},
        "kappa2": {r: {s: _get(level_q, r, s, "kappa2")
                       for s in SECTORS} for r in REGIONS},
        # ---- Diagnostic: the old share-form values for comparison ----
        "share_form_diagnostic": {
            "kappa_share": calib["linear"],
            "kappa2_share": {
                r: {s: calib["quadratic"][r][s].get("kappa2", 0.0)
                    for s in SECTORS}
                for r in REGIONS
            },
        },
        # ---- Bootstrap SE for the level-form coefficients ----
        "boot_se": calib["boot_se"],
        "n_obs":   calib["n_obs"],
    }
    path.write_text(json.dumps(payload, indent=2))
    print(f"\nWrote calibrated priors to {path.resolve()}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    print("=== MITICA macro priors — WDI calibration ===\n")
    print("Loading panel ...")
    panel = load_panel()
    print(f"Panel size: {len(panel):,} country-year rows")
    print(f"Countries:  {panel['iso3'].nunique()}")
    print(f"Years:      {int(panel['Year'].min())}-{int(panel['Year'].max())}")

    print("\nRegional breakdown (with all required indicators):")
    valid_rows = panel.dropna(subset=[
        "log_gpc_lag", "log_pop", "log_sgdp_primary",
        "log_sgdp_secondary", "log_sgdp_tertiary"
    ])
    print(valid_rows["mitica_region"].value_counts().to_string())

    print("\nRunning panel regressions ...")
    calib = calibrate(panel)

    print_comparison(calib)
    write_json(calib, OUT_PATH)


if __name__ == "__main__":
    main()
