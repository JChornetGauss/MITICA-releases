"""
user_journey_real.py
====================

The Canada user journey re-run with the REAL submitted inventory (2023 CRF,
AR4 GWP) extracted by can_crf_real.py — no interpolation, no synthetic split.

I am a Canadian focal point with my actual CRF Table 4 (1990-2021), nothing
else; the tool auto-fills land from its refDB. Build WoM / WEM / WAM, compare
to the reported inventory, write everything to an Excel workbook.

Output: MITICA_LULUCF_user_journey_CAN_REAL.xlsx in the MITICA_project root.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_PROJECT_ROOT = _REPO_ROOT.parent
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS_DIR = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

import v1_country_backtest as bt  # noqa: E402
import can_crf_real as crf  # noqa: E402
from mitica_core.modules.lulucf import (  # noqa: E402
    HistoricalLULUCF, LULUCFConfig, ProjectedLULUCF, run_lulucf_module,
)
from user_journey_sim import build_pams  # noqa: E402

ISO = "CAN"
HORIZON = 2040
OUT = _PROJECT_ROOT / "MITICA_LULUCF_user_journey_CAN_REAL.xlsx"


def build_real_inputs():
    inv = crf.build_real_can_inventory()                 # 4A..4G, CO2eq, 1990-2021
    years = sorted(int(y) for y in inv["Year"].unique())
    refdb = bt.load_refdb()
    profile = bt.get_country_profile(refdb, ISO)
    land = bt._build_land_areas(ISO, profile, years)     # refDB auto-fill
    hist = HistoricalLULUCF(inventory_emissions=inv, land_areas=land, country=ISO)
    cfg = LULUCFConfig(country=ISO, region=profile["region"], horizon_year=HORIZON,
                       climate_zone=profile["climate_zone"], tier=0, profile="L-A")
    return hist, cfg, inv


def _p(s: str = "") -> None:
    sys.stdout.buffer.write((s + "\n").encode("ascii", "replace"))


def main() -> int:
    hist, cfg, inv = build_real_inputs()
    proj = ProjectedLULUCF()
    last_hist = hist.last_historical_year()
    rep_net = inv.groupby("Year")["Emissions"].sum()

    pams = build_pams()

    wom = run_lulucf_module(hist, proj, cfg)
    wom_net = {int(r["Year"]): float(r["Net_LULUCF_CO2eq_kt"])
               for _, r in wom.net_co2eq_by_year().iterrows()}
    out = run_lulucf_module(hist, proj, cfg, pams=pams)
    sc = out.scenario_net

    def net_by(scn):
        s = sc[sc["Scenario"] == scn]
        return {int(y): float(v) for y, v in s.groupby("Year")["Net_CO2eq_kt"].sum().items()}
    wom_s, wem_s, wam_s = net_by("WoM"), net_by("WEM"), net_by("WAM")

    n_red = sum(1 for f in wom.validation_report if f.severity == "red")
    n_amb = sum(1 for f in wom.validation_report if f.severity == "amber")

    _p("=" * 74)
    _p("  CANADA user journey with the REAL submitted inventory (2023 CRF, AR4)")
    _p("=" * 74)
    _p(f"  Inventory years: {min(rep_net.index)}-{max(rep_net.index)} (32 yrs, all real)")
    _p(f"  Reported net @1990={rep_net.get(1990):,.0f}  @2005={rep_net.get(2005):,.0f}  "
       f"@2021={rep_net.get(2021):,.0f} kt CO2eq (persistent SINK)")
    _p(f"  Profile L-A, horizon {HORIZON}, last inventory year {last_hist}")
    _p(f"  WoM flags: {n_red} red, {n_amb} amber")
    _p(f"  WoM net @{last_hist}={wom_net.get(last_hist, float('nan')):,.0f}  "
       f"@2030={wom_s.get(2030, float('nan')):,.0f}  @{HORIZON}={wom_s.get(HORIZON, float('nan')):,.0f}")
    rep_anchor = rep_net.get(last_hist)
    err = (wom_net.get(last_hist, float('nan')) - rep_anchor) / abs(rep_anchor) * 100
    _p(f"  Reported @ {last_hist} = {rep_anchor:,.0f}  -> WoM anchor error: {err:.0f}%")
    _p("\n  Scenarios (kt CO2eq):")
    _p(f"   {'Year':>6} | {'reported':>12} | {'WoM':>12} | {'WEM':>12} | {'WAM':>12}")
    for y in [last_hist, 2025, 2030, 2035, HORIZON]:
        if y not in wom_s:
            continue
        _p(f"   {y:>6} | {('' if y not in rep_net.index else f'{rep_net[y]:,.0f}'):>12} | "
           f"{wom_s[y]:>12,.0f} | {wem_s.get(y, wom_s[y]):>12,.0f} | {wam_s.get(y, wom_s[y]):>12,.0f}")
    for f in out.validation_report:
        if f.severity in ("red", "amber"):
            _p(f"   FLAG {f.test_id}/{f.severity}: {f.message.encode('ascii','replace').decode()[:140]}")

    # ---------------------------------------------------------------- Excel
    inv_x = inv.rename(columns={"Emissions": "Emissions_kt_CO2eq"})
    inv_x["Provenance"] = "REAL - CRF Table 4 (2023 submission, AR4)"
    net_x = pd.DataFrame({"Year": rep_net.index, "Reported_net_kt_CO2eq": rep_net.values.round(0)})
    net_x["Provenance"] = "REAL - CRF Table 4 total LULUCF"

    pam_rows = [{
        "Scenario": p["scenario"], "Name": p["name"], "Catalog id": p["catalog_id"],
        "CRT category": p["category"], "t0": p["t0"], "Time profile": p["time_distribution"],
        "Variables": ", ".join(f"{k}={v}" for k, v in p["variables"].items()),
    } for p in pams]

    res_rows = []
    for y in sorted(wom_s):
        res_rows.append({
            "Year": y,
            "Reported (real, kt)": round(float(rep_net[y]), 0) if y in rep_net.index else "",
            "WoM (kt)": round(wom_s[y], 0),
            "WEM (kt)": round(wem_s.get(y, wom_s[y]), 0),
            "WAM (kt)": round(wam_s.get(y, wom_s[y]), 0),
            "WEM mit (kt/yr)": round(wom_s[y] - wem_s.get(y, wom_s[y]), 0),
            "WAM mit (kt/yr)": round(wom_s[y] - wam_s.get(y, wom_s[y]), 0),
        })

    readme = pd.DataFrame({"CANADA user journey - REAL submitted inventory": [
        "SOURCE: can-2023-crf-14apr23_AR4.zip - Canada's 2023 CRF submission to the UNFCCC.",
        "32 Excel files (one per inventory year 1990-2021), CRF Reporter export, AR4 GWP.",
        "",
        "Inventory = CRF Table 4 (LULUCF) per category 4A..4G, converted to CO2-eq with AR4",
        "(CH4=25, N2O=298). Our per-category sum was validated against the CRF-reported",
        "'4. Total LULUCF' for every one of the 32 years - exact match (diff < 1 kt).",
        "",
        "This is 100% REAL submitted data. The only auto-filled input is the LAND AREA",
        "(MITICA refDB, FAO/FRA) - the user brought 'only the inventory', as specified.",
        "",
        "KEY FACT: in this submission Canada's LULUCF is a PERSISTENT SINK (-5,542 to",
        "-68,482 kt over 1990-2021). It is NEVER a +81 Mt source - that figure came from a",
        "LATER restated NIR with a different methodology (natural disturbances in managed",
        "forest). Data vintage matters: always validate against the actual submission.",
        "",
        "SHEETS: 1 Inventory(net) | 2 Inventory(per-cat) | 3 PAMs | 4 Results-Scenarios |",
        "        5 Results-PAM ranking",
    ]})

    rank_df = out.pam_summary.sort_values(
        "Total_Mitigation_CO2eq_kt", key=lambda s: s.abs(), ascending=False)

    # Per-category model-vs-reported at the anchor year — the headline evidence.
    em = out.emissions
    m_last = em[em["Year"] == last_hist].groupby("Category")["Emissions_CO2eq_kt"].sum()
    i_last = inv[inv["Year"] == last_hist].set_index("Category")["Emissions"]
    cmp_rows = []
    for c in ["4A", "4B", "4C", "4D", "4E", "4F", "4G"]:
        rep_v = float(i_last.get(c, 0.0)); mod_v = float(m_last.get(c, 0.0))
        cmp_rows.append({
            "Category": c,
            f"Reported {last_hist} (real, kt)": round(rep_v, 0),
            f"WoM model {last_hist} (kt)": round(mod_v, 0),
            "Modeled?": "yes" if abs(mod_v) > 1 else "NO - zeroed",
        })
    cmp_rows.append({
        "Category": "NET",
        f"Reported {last_hist} (real, kt)": round(float(i_last.sum()), 0),
        f"WoM model {last_hist} (kt)": round(float(m_last.sum()), 0),
        "Modeled?": "",
    })
    cmp_df = pd.DataFrame(cmp_rows)

    with pd.ExcelWriter(OUT, engine="openpyxl") as xl:
        readme.to_excel(xl, sheet_name="0 READ ME", index=False)
        net_x.to_excel(xl, sheet_name="1 Inventory (net)", index=False)
        inv_x.to_excel(xl, sheet_name="2 Inventory (per-cat)", index=False)
        pd.DataFrame(pam_rows).to_excel(xl, sheet_name="3 PAMs", index=False)
        pd.DataFrame(res_rows).to_excel(xl, sheet_name="4 Results-Scenarios", index=False)
        rank_df.to_excel(xl, sheet_name="5 Results-PAM ranking", index=False)
        cmp_df.to_excel(xl, sheet_name="6 Model vs Reported (cat)", index=False)
        wb = xl.book
        head_fill = PatternFill("solid", fgColor="1F4E78")
        head_font = Font(bold=True, color="FFFFFF")
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.fill = head_fill; cell.font = head_font
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            for col in ws.columns:
                w = max((len(str(c.value)) for c in col if c.value is not None), default=10)
                ws.column_dimensions[get_column_letter(col[0].column)].width = min(w + 2, 64)

    _p(f"\n  Wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
