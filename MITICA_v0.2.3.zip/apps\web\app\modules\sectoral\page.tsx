"use client";

import Link from "next/link";
import { ArrowLeft, ArrowUpRight, Zap, Leaf, Snowflake, Car, Recycle } from "lucide-react";
import type { ReactNode } from "react";

interface Sector {
  id: string;
  number: string;
  icon: ReactNode;
  title: string;
  code: string;
  tagline: string;
  description: string;
  status: "ready" | "beta" | "planned";
  methodology: string;
  ipccCategories: string[];
}

const SECTORS: Sector[] = [
  {
    id: "energy",
    number: "01",
    icon: <Zap className="h-6 w-6" />,
    title: "Energy industries",
    code: "SI-003",
    tagline: "Bottom-up merit-order dispatch of public electricity + heat generation",
    description:
      "Covers IPCC 1A1 only — public electricity and heat production (1A1a), petroleum refining (1A1b) and manufacture of solid fuels (1A1c). Characterises each generation technology, derives emission factor and capacity factor from historical data, then dispatches plants by merit order against a projected electricity demand path. 1A2 (manufacturing) and 1A3 (transport) stay with ANNALIST.",
    status: "beta",
    methodology: "IPCC Tier-2 dispatch simulation with Monte-Carlo sensitivity",
    ipccCategories: ["1A1a", "1A1b", "1A1c"],
  },
  {
    id: "fgases",
    number: "02",
    icon: <Snowflake className="h-6 w-6" />,
    title: "F-gases",
    code: "SI-005",
    tagline: "Bank-based per-equipment per-refrigerant, Kigali-aware",
    description:
      "Stock dynamics per equipment class and refrigerant blend. For each year: Bank = Σ Stock × Initial charge × Refrigerant share. Emissions = manufacturing loss + operating leak + disposal. Kigali phasedown schedules drive the transition from high-GWP HFCs to low-GWP alternatives.",
    status: "beta",
    methodology: "IPCC Tier-2 stock/bank approach with species-level GWP",
    ipccCategories: ["2F1", "2F2", "2F3", "2F4", "2F5", "2F6"],
  },
  {
    id: "lulucf",
    number: "03",
    icon: <Leaf className="h-6 w-6" />,
    title: "LULUCF",
    code: "SI-004",
    tagline: "CBM-simplified Forest + Cropland + Grassland carbon stocks",
    description:
      "Canadian CBM-CFS3 methodology simplified for national-scale use. Forest land stock-change with growth, harvest, and disturbance cycles. Cropland soil-carbon. Grassland management. Wetlands drainage. Each pool projected separately; net flux = Σ. Scientifically the most complex sector.",
    status: "planned",
    methodology: "IPCC 2006 Vol. 4 + 2019 Refinement · CBM-simplified",
    ipccCategories: ["4A", "4B", "4C", "4D", "4E"],
  },
  {
    id: "transport",
    number: "04",
    icon: <Car className="h-6 w-6" />,
    title: "Transport",
    code: "SI-006",
    tagline: "COPERT-simplified fleet turnover by technology",
    description:
      "Vehicle class × fuel technology matrix with stock = Stock + Registrations − Retirements. Survival curves per cohort. Emissions = Σ Stock × VKT × EF. PAMs such as EV penetration, low-emission zones, modal shift, and eco-driving.",
    status: "planned",
    methodology: "EEA COPERT (hot-running subset) + IPCC 2006 Vol. 2",
    ipccCategories: ["1A3b"],
  },
  {
    id: "waste",
    number: "05",
    icon: <Recycle className="h-6 w-6" />,
    title: "Waste",
    code: "SI-007",
    tagline: "FOD landfill + wastewater + incineration",
    description:
      "IPCC First-Order Decay for CH₄ from solid waste disposal. Wastewater aerobic / anaerobic split. Incineration CO₂ from fossil-carbon fraction. Activity data ideally ingested from IPCC Inventory Software via CRT JSON (BI-002).",
    status: "planned",
    methodology: "IPCC 2006 Vol. 5 + 2019 Refinement · FOD model",
    ipccCategories: ["5A", "5B", "5C", "5D"],
  },
];

const STATUS_STYLE = {
  ready: "bg-primary/15 text-primary border-primary/20",
  beta: "bg-amber-600/10 text-amber-700 border-amber-600/25",
  planned: "bg-muted text-muted-foreground border-border",
};

const STATUS_LABEL = {
  ready: "Ready",
  beta: "Beta",
  planned: "Planned",
};

export default function SectoralModulesPage() {
  return (
    <div className="relative">
      <div
        aria-hidden
        className="absolute inset-x-0 top-0 h-[340px] bg-[radial-gradient(ellipse_at_top,hsl(28_48%_85%/0.35),transparent_65%)]"
      />

      <div className="relative mx-auto max-w-6xl px-5 py-14">
        <Link
          href="/"
          className="mb-8 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" /> Home
        </Link>

        <header className="mb-14">
          <div className="mb-3 flex items-center gap-3">
            <span className="eyebrow">02 / Module · SI-003 to SI-007</span>
          </div>
          <h1 className="mb-5 max-w-3xl font-serif text-display-lg font-[440] tracking-tight">
            Sectoral <em className="italic">modules</em>.
          </h1>
          <p className="max-w-3xl text-lg leading-relaxed text-foreground/75">
            Physics-based, bottom-up projections for each IPCC sector. Each module handles one
            sector with a tier-2+ methodology — generating its own WoM baseline plus PAMs, and
            feeding them into the Integration Module. Unaffected categories keep using ANNALIST.
          </p>
        </header>

        <div className="hairline mb-10" />

        <div className="space-y-px overflow-hidden rounded-sm border border-border bg-border">
          {SECTORS.map((sector) => (
            <article
              key={sector.id}
              className="group relative bg-card p-8 transition-colors hover:bg-muted/40"
            >
              <div className="grid gap-8 md:grid-cols-[auto_1fr_auto] md:items-start">
                <div className="flex items-start gap-5">
                  <span className="font-serif text-3xl italic text-foreground/30">
                    {sector.number}
                  </span>
                  <div className="mt-1 flex h-11 w-11 items-center justify-center rounded-sm border border-border bg-background text-primary">
                    {sector.icon}
                  </div>
                </div>

                <div>
                  <div className="mb-1 flex items-center gap-3">
                    <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                      {sector.code}
                    </span>
                    <span
                      className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${
                        STATUS_STYLE[sector.status]
                      }`}
                    >
                      {STATUS_LABEL[sector.status]}
                    </span>
                  </div>
                  <h3 className="mb-2 font-serif text-2xl font-[460] tracking-tight">
                    {sector.title}
                  </h3>
                  <p className="mb-4 font-serif text-[15px] italic text-foreground/70">
                    {sector.tagline}
                  </p>
                  <p className="mb-5 max-w-2xl text-sm leading-relaxed text-foreground/75">
                    {sector.description}
                  </p>
                  <dl className="grid gap-3 text-xs sm:grid-cols-2">
                    <div>
                      <dt className="eyebrow mb-1">Method</dt>
                      <dd className="text-foreground/85">{sector.methodology}</dd>
                    </div>
                    <div>
                      <dt className="eyebrow mb-1">Covers IPCC</dt>
                      <dd className="flex flex-wrap gap-1">
                        {sector.ipccCategories.map((c) => (
                          <code
                            key={c}
                            className="rounded-sm bg-muted px-1.5 py-0.5 font-mono text-[11px]"
                          >
                            {c}
                          </code>
                        ))}
                      </dd>
                    </div>
                  </dl>
                </div>

                <div className="md:self-end">
                  <ArrowUpRight className="h-6 w-6 text-muted-foreground transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-foreground" />
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-14 flex flex-wrap items-center justify-between gap-4 rounded-sm border border-border bg-card p-6">
          <p className="max-w-2xl text-sm text-foreground/75">
            Sectoral modules are wired to the Integration Module via the SI-008 data contract.
            Activate any combination per project — the Integration falls back to ANNALIST for
            categories no module covers.
          </p>
          <Link
            href="/projects"
            className="group inline-flex items-center gap-2 rounded-sm border border-border px-4 py-2 text-sm font-medium hover:border-foreground/40"
          >
            Continue to Integration
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
