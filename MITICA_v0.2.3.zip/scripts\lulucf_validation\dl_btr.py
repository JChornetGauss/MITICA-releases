"""
dl_btr.py — download + extract all resolved BTR1 CRT zips.

Merges the resolved-URL JSON from one or more workflow output files, then for
each: curl-downloads (Incapsula bypass = primed session cookie + browser UA +
referer) and extracts to _btr_crt/<ISO>/. ISO is the first 3 letters of the zip
filename (the CRT naming convention), upper-cased.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path

_HERE = Path(__file__).resolve()
_DST = _HERE.parent / "_btr_crt"
_CJ = "/tmp/unfccc_cj.txt"
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_OUTFILES = [
    r"C:\Users\juanl\AppData\Local\Temp\claude\C--Users-juanl-Documents-Claude-MITICA-project\7868ed16-21a2-40a8-939f-80df90d085ef\tasks\win471f5t.output",
    r"C:\Users\juanl\AppData\Local\Temp\claude\C--Users-juanl-Documents-Claude-MITICA-project\7868ed16-21a2-40a8-939f-80df90d085ef\tasks\wompzxl84.output",
]


def _load_urls() -> list[dict]:
    seen, out = set(), []
    for of in _OUTFILES:
        if not os.path.exists(of):
            continue
        raw = open(of, encoding="utf-8").read()
        m = re.search(r"\[\s*\{.*\}\s*\]", raw, re.S)
        if not m:
            continue
        for d in json.loads(m.group(0)):
            u = (d.get("url") or "").strip()
            if u.endswith(".zip") and u not in seen:
                seen.add(u)
                out.append({"country": d["country"], "url": u})
    return out


def _prime() -> None:
    subprocess.run(["curl", "-s", "--max-time", "30", "-c", _CJ, "-A", _UA,
                    "-H", "Accept-Language: en-US,en;q=0.9",
                    "https://unfccc.int/", "-o", os.devnull], check=False)


def _iso(url: str) -> str:
    fname = url.rsplit("/", 1)[-1]
    fname = fname.replace("%20", " ")
    m = re.match(r"\s*([A-Za-z]{3})", fname)
    return (m.group(1).upper() if m else fname[:3].upper())


def main() -> int:
    urls = _load_urls()
    print(f"{len(urls)} resolved CRT zip URLs")
    _DST.mkdir(parents=True, exist_ok=True)
    _prime()
    print("primed cookie.")
    ok = bad = 0
    for d in urls:
        url, country = d["url"], d["country"]
        iso = _iso(url)
        tmp = f"/tmp/btr_{iso}.zip"
        r = subprocess.run(
            ["curl", "-s", "--max-time", "240", "-b", _CJ, "-c", _CJ, "-A", _UA,
             "-H", "Accept: application/zip,application/octet-stream,*/*",
             "-H", "Referer: https://unfccc.int/first-biennial-transparency-reports",
             "-L", url, "-o", tmp, "-w", "%{http_code} %{size_download}"],
            capture_output=True, text=True)
        code = r.stdout.strip()
        if not zipfile.is_zipfile(tmp):
            print(f"  FAIL  {iso:5} ({country})  http/size={code}")
            bad += 1
            if os.path.exists(tmp):
                os.remove(tmp)
            continue
        edir = _DST / iso
        if edir.exists():
            import shutil
            shutil.rmtree(edir)
        edir.mkdir(parents=True)
        try:
            with zipfile.ZipFile(tmp) as z:
                z.extractall(edir)
            nx = len(list(edir.rglob("*.xlsx")))
            print(f"  OK    {iso:5} ({country})  {int(code.split()[1]):>10}B  {nx} xlsx")
            ok += 1
        except Exception as e:
            print(f"  BADZIP {iso:5} ({country})  {type(e).__name__}: {e}")
            bad += 1
        os.remove(tmp)
    print(f"=== OK={ok} FAIL/BAD={bad} ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
