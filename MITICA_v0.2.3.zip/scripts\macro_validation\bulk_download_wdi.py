"""One-shot bulk download of World Bank WDI panel for offline prior calibration.

Pulls the indicators needed to estimate the MITICA macro priors
(B2 sectoral GDP + KC income shifters) on a global cross-country panel.

Output:
  scripts/macro_validation/wdi_data/{indicator}.csv   long-format wide-by-year
  scripts/macro_validation/wdi_data/countries.csv     mapping iso3 -> MITICA region

MITICA region map (from WB region + income level + an empirical 1990 GDPpc
threshold that stratifies HIC into "mature" and "transitioning"):
  - HIC       : HIC by income AND 1990 GDPpc >= 15,000 USD (mature OECD
                economies that finished their structural transformation
                before the calibration window opens).
  - HIC_TRANS : HIC by income AND 1990 GDPpc < 15,000 USD (Korea, Singapore,
                EU accession states, Israel, Chile, late-industrialising
                Gulf states — countries whose Kuznets transition is in the
                sample). Stratifying these out of HIC removes the selection
                bias documented in Section 8 of the May 2026 audit: the
                pooled HIC prior was pulling mature economies too
                aggressively toward transition dynamics.
  - LAC       : non-HIC in WB.region == 'LCN'
  - SSA       : non-HIC in WB.region == 'SSF'
  - MENA      : non-HIC in WB.region == 'MEA'
  - APAC      : non-HIC in WB.region in {'EAS', 'SAS'}
  - EEU       : non-HIC in WB.region == 'ECS'

The 1990 GDPpc threshold was chosen by inspecting the WDI panel: there is a
natural gap in the high-income distribution between ~$10k (transitioning
Korea / Spain / EU candidates) and ~$18k+ (mature OECD core). 15k splits
the population cleanly into ~50 mature vs ~30 transitioning.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import wbgapi as wb

OUT_DIR = Path("scripts/macro_validation/wdi_data")

# Indicators we pull. Constant 2015 USD is the harmonised volume measure.
INDICATORS = {
    "GDP_pc":         "NY.GDP.PCAP.KD",   # GDP per capita (constant 2015 USD)
    "Pop":            "SP.POP.TOTL",      # Population, total
    "GDP_tot":        "NY.GDP.MKTP.KD",   # GDP (constant 2015 USD)
    "SGDP_primary":   "NV.AGR.TOTL.KD",   # Agriculture value added
    "SGDP_secondary": "NV.IND.TOTL.KD",   # Industry value added
    "SGDP_tertiary":  "NV.SRV.TOTL.KD",   # Services value added
}

YEAR_MIN = 1960
YEAR_MAX = 2024


# ---------------------------------------------------------------------------
# Region mapping
# ---------------------------------------------------------------------------

# Empirical threshold (USD constant 2015) at year 1990 separating mature HIC
# from transitioning HIC. See the module docstring for the rationale.
HIC_TRANS_GDPPC_1990 = 15_000.0


def _mitica_region_base(wb_region: str | None, wb_income: str | None) -> str | None:
    """First-pass mapping using only WB region + income level. HIC is left
    as a single bucket here; the mature/transitioning split is applied later
    once the 1990 GDPpc data is available."""
    if not wb_region or not wb_income:
        return None
    if wb_income == "HIC":
        return "HIC"
    if wb_region == "LCN":
        return "LAC"
    if wb_region == "SSF":
        return "SSA"
    if wb_region == "MEA":
        return "MENA"
    if wb_region in ("EAS", "SAS"):
        return "APAC"
    if wb_region == "ECS":
        return "EEU"
    if wb_region == "NAC":
        return None
    return None


def build_country_table(gdp_pc_long: pd.DataFrame | None = None) -> pd.DataFrame:
    """Return DataFrame [iso3, name, wb_region, wb_income, gdp_pc_1990,
    mitica_region].

    If ``gdp_pc_long`` is supplied (the WDI GDP per capita panel), HIC is
    refined into HIC (mature, GDPpc_1990 >= 15k) and HIC_TRANS (< 15k).
    """
    rows = []
    for e in wb.economy.list():
        if e.get("aggregate"):
            continue
        iso3 = e["id"]
        name = e["value"]
        wb_r = e.get("region")
        wb_i = e.get("incomeLevel")
        m_r = _mitica_region_base(wb_r, wb_i)
        rows.append({
            "iso3": iso3, "name": name, "wb_region": wb_r,
            "wb_income": wb_i, "mitica_region": m_r,
        })
    df = pd.DataFrame(rows)

    if gdp_pc_long is None or gdp_pc_long.empty:
        df["gdp_pc_1990"] = None
        return df

    gpc_1990 = (gdp_pc_long[gdp_pc_long["Year"] == 1990]
                .set_index("iso3")["value"])
    df["gdp_pc_1990"] = df["iso3"].map(gpc_1990)
    # If 1990 is missing, fall back to the earliest year between 1990 and
    # 1995 to avoid losing late-reporting countries from the stratification.
    early = (gdp_pc_long[(gdp_pc_long["Year"] >= 1990) &
                         (gdp_pc_long["Year"] <= 1995)]
             .sort_values(["iso3", "Year"]).drop_duplicates("iso3", keep="first")
             .set_index("iso3")["value"])
    df["gdp_pc_1990"] = df["gdp_pc_1990"].fillna(df["iso3"].map(early))

    # Apply the HIC -> {HIC, HIC_TRANS} refinement.
    is_hic = df["mitica_region"] == "HIC"
    has_gpc = df["gdp_pc_1990"].notna()
    is_trans = is_hic & has_gpc & (df["gdp_pc_1990"] < HIC_TRANS_GDPPC_1990)
    df.loc[is_trans, "mitica_region"] = "HIC_TRANS"
    return df


# ---------------------------------------------------------------------------
# Bulk fetch helpers
# ---------------------------------------------------------------------------


def fetch_indicator(code: str, year_min: int, year_max: int) -> pd.DataFrame:
    """Return a long-format DataFrame [iso3, Year, value] for one indicator.

    Single API call covering all countries and all years.
    """
    print(f"  [api] {code}", flush=True)
    df = wb.data.DataFrame(code, time=range(year_min, year_max + 1),
                           skipBlanks=True, columns="series", labels=False)
    # df has MultiIndex (economy, time) and a single column = indicator code.
    df = df.reset_index()
    # wbgapi uses 'economy' for the country dim and 'time' as 'YR2020' strings
    df = df.rename(columns={"economy": "iso3", "time": "Year_str", code: "value"})
    df["Year"] = df["Year_str"].str.lstrip("YR").astype(int)
    df = df.drop(columns=["Year_str"])
    df = df.dropna(subset=["value"])
    print(f"        -> {len(df):,} rows", flush=True)
    return df[["iso3", "Year", "value"]]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print(f"=== WDI bulk download ({YEAR_MIN}-{YEAR_MAX}) ===\n")

    # Indicators (fetch first so the country classifier has access to GDPpc_1990)
    indicator_frames: dict[str, pd.DataFrame] = {}
    for short_name, code in INDICATORS.items():
        long = fetch_indicator(code, YEAR_MIN, YEAR_MAX)
        out = OUT_DIR / f"{short_name}.csv"
        long.to_csv(out, index=False)
        indicator_frames[short_name] = long
        print(f"        saved -> {out}")

    # Country table (HIC stratification uses the GDPpc panel we just fetched)
    print("\n[meta] Country / region / income classification")
    countries = build_country_table(indicator_frames["GDP_pc"])
    countries.to_csv(OUT_DIR / "countries.csv", index=False)
    print(f"       -> {len(countries)} entries; "
          f"{countries['mitica_region'].notna().sum()} classified into MITICA regions")
    print()
    print("MITICA region counts:")
    print(countries["mitica_region"].value_counts().to_string())

    hic_trans = countries[countries["mitica_region"] == "HIC_TRANS"][
        ["iso3", "name", "gdp_pc_1990"]
    ].sort_values("gdp_pc_1990")
    if not hic_trans.empty:
        print(f"\nHIC_TRANS countries (1990 GDPpc < ${HIC_TRANS_GDPPC_1990:,.0f}):")
        for _, r in hic_trans.iterrows():
            print(f"  {r['iso3']}  {r['name']:<30}  GDPpc_1990 = "
                  f"${r['gdp_pc_1990']:>10,.0f}")

    print(f"\nWrote indicator CSVs to {OUT_DIR}/")


if __name__ == "__main__":
    main()
