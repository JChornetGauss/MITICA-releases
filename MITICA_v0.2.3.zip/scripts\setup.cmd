@echo off
rem Backwards-compat alias. The setup workflow is now scripts\install.cmd
rem (which is a strict superset: detects+installs Python/Node if missing, creates
rem the desktop shortcut, builds Next in production mode).
call "%~dp0install.cmd" %*
