// TypeScript mirrors of the Pydantic contracts in mitica_core.contracts.
// Keep in sync as the API evolves.

export type Gas =
  | "CO2eq"
  | "CO2"
  | "CH4"
  | "N2O"
  | "SF6"
  | "NF3"
  | "HFCs"
  | "PFCs"
  | "F_gases";

export const NON_AGGREGATE_GASES: Gas[] = ["CO2", "CH4", "N2O", "HFCs", "PFCs", "SF6", "NF3"];

export type ForecastMethod =
  | "ANNALIST"
  | "SARIMAX"
  | "LINREG"
  | "AG"
  | "ThymeBoost";

export type ModifierKind =
  | "AVOID_INCREASE"
  | "AVOID_DECREASE"
  | "AVOID_NEGATIVE"
  | "AVOID_OUTCOMES"
  | "SMOOTH"
  | "ANNUAL_GROWTH"
  | "LINEAL_FIX"
  | "ADJUST_VALUE";

export type ScenarioKind = "WOM" | "WEM" | "WAM";
export type PAMTimeDistribution = "CONSTANT" | "VARIABLE";

export interface Project {
  id: string;
  name: string;
  country_code: string;
  // WB income group ("L" | "LM" | "UM" | "H"); null when the country code
  // never resolved in the bundled World Bank classification.
  income_group: string | null;
  description: string;
  horizon_year: number | null;
  reference_year: number | null;
  created_at: string;
  updated_at: string;
  has_inventory: boolean;
  has_forecast: boolean;
  pam_count: number;
  validated_count: number;
  category_count: number;
  // SI-008 module activation
  use_macro_module: boolean;
  use_energy_module: boolean;
  use_lulucf_module: boolean;
  use_fgases_module: boolean;
  use_transport_module: boolean;
  use_waste_module: boolean;
  has_macro_result: boolean;
  has_energy_result: boolean;
  has_lulucf_result: boolean;
  has_fgases_result: boolean;
  has_transport_result: boolean;
  has_waste_result: boolean;
}

export interface InventoryRow {
  ipcc_code: string;
  year: number;
  value: number;
  gas: Gas;
}

export interface Inventory {
  country_code: string;
  unit: string;
  start_year: number;
  end_year: number;
  rows: InventoryRow[];
}

export interface ProxyDataset {
  name: string;
  sector: "Energy" | "IPPU" | "LULUCF" | "Agri" | "Waste" | null;
  mandatory: boolean;
  unit: string | null;
  years: number[];
  values: number[];
}

// Numeric detail for the avoid_negative auto-modifier diagnostic, stored at
// CategoryForecast.metadata["auto_adjustments"]. reference_* mirrors are
// present only when the reference re-forecast was also lifted.
export interface AutoAdjustments {
  modifier: string;
  severity: "info" | "warning";
  lift_kt?: number;
  relative_shift?: number;
  raw_negative_years?: number;
  projection_years?: number;
  reference_lift_kt?: number;
  reference_relative_shift?: number;
  reference_raw_negative_years?: number;
  reference_projection_years?: number;
}

export interface CategoryForecast {
  ipcc_code: string;
  gas: Gas;
  years: number[];
  historical: (number | null)[];
  forecast: (number | null)[];
  reference?: (number | null)[] | null;
  reference_forecast?: (number | null)[] | null;
  // Proxy columns actually fed to this category's regression (empty for
  // ANNUAL_GROWTH, which uses no exogenous drivers). Absent in artifacts
  // produced by older builds.
  proxies_used?: string[];
  method: ForecastMethod;
  validated: boolean;
  historical_by_gas: Record<string, (number | null)[]>;
  by_gas: Record<string, (number | null)[]>;
  metadata: Record<string, unknown> & { auto_adjustments?: AutoAdjustments };
}

export interface PAMCatalogVariable {
  alias: string;
  name: string;
  unit: string | null;
  default: number | null;
}

export interface PAMCatalogEntry {
  catalog_id: string;
  name: string;
  categories: string[];
  formula: string;
  variables: PAMCatalogVariable[];
}

export type PAMCatalog = Record<string, Record<string, PAMCatalogEntry[]>>;

export interface ProxyCatalogEntry {
  name: string;
  label: string;
  unit: string;
}

export type ProxyCatalog = Record<string, ProxyCatalogEntry[]>;

export interface Forecast {
  config: {
    horizon_year: number;
    reference_year: number | null;
    method: ForecastMethod;
    seed: number | null;
    apply_auto_modifications: boolean;
  };
  last_inventory_year: number;
  categories: CategoryForecast[];
  created_at: string;
  input_hash: string | null;
  // Additive contract fields — absent in artifacts produced by older builds.
  // Categories that failed to forecast and were dropped (code → error message).
  failed_categories?: Record<string, string>;
  // Proxies linearly extrapolated beyond their last observed year
  // (name → last observed year). Audit C-12.
  extrapolated_proxies?: Record<string, number>;
  // Categories whose raw projection went negative and was lifted by the
  // avoid_negative auto-modifier (code → "warning: …" | "info: …" message).
  // Per-category numbers live in metadata.auto_adjustments.
  adjusted_categories?: Record<string, string>;
}

// GUY-18 — per-category "compare forecasting methods" QA/QC view.
// ANNALIST is the primary/recommended method; SARIMAX + Gradient Boosting
// (GBR) are comparison methods (MITICA manual Table 1) used to sanity-check
// the WoM. The endpoint is read-only (computes nothing persisted).
export interface CompareMethodsResponse {
  category: string;
  years: number[];
  // Observed history aligned to `years` (null where no observation).
  historical: (number | null)[];
  // series[method] is the projected path aligned to `years`; null before the
  // projection start.
  series: Record<string, (number | null)[]>;
  // notes[method] is a short status string ("ok" / "only 5 obs — SARIMAX not
  // run, showed LINREG" / etc.).
  notes: Record<string, string>;
}

export interface PAMVariable {
  alias: string;
  name: string;
  unit: string | null;
  value: number;
}

export interface PAM {
  id: string;
  name: string;
  category: string;
  scenario: ScenarioKind;
  formula: string;
  variables: PAMVariable[];
  cost_usd_per_ton: number | null;
  time_distribution: PAMTimeDistribution;
  t0: number;
  t1: number | null;
  t2: number | null;
  annual_mitigation_kt: number | null;
  dynamic: boolean;
  notes: string | null;
}

export interface MACCPoint {
  pam_id: string;
  pam_name: string;
  mitigation_kt: number;
  cost_usd: number;
  cost_per_ton: number | null;
}

export interface MACCData {
  sector: string;
  initial_year: number;
  final_year: number;
  points: MACCPoint[];
}

export interface JobStatus {
  id: string;
  project_id: string;
  kind: string;
  status: "pending" | "running" | "done" | "error";
  progress: number;
  message: string;
  result_ref: string | null;
  created_at: string;
  updated_at: string;
}

export interface ScenarioOverview {
  project_id: string;
  years: number[];
  totals: Record<ScenarioKind, number[]>;
  by_sector: Record<string, Record<ScenarioKind, number[]>>;
  by_category: Record<ScenarioKind, Record<string, number[]>>;
  // Three-level IPCC aggregation (1A1, 1A2, …) — the display granularity for
  // scenario series (JL decision 2026-06-10): scenarios continue the
  // inventory series, module-internal depth (e.g. energy's 1A1a/1A1c) rolls
  // up here. Optional: absent on artifacts from older API builds.
  by_level3?: Record<ScenarioKind, Record<string, number[]>>;
}

export interface InventoryUploadResponse {
  project_id: string;
  inventory: Inventory;
  rows: number;
  categories: string[];
}

export interface ProjectCreate {
  name: string;
  country_code?: string;
  description?: string;
  horizon_year?: number | null;
  reference_year?: number | null;
}

export interface ProjectUpdate {
  name?: string;
  country_code?: string;
  // Explicit null clears the value (modules fall back to their heuristic).
  income_group?: string | null;
  description?: string;
  horizon_year?: number | null;
  reference_year?: number | null;
  use_macro_module?: boolean;
  use_energy_module?: boolean;
  use_lulucf_module?: boolean;
  use_fgases_module?: boolean;
  use_transport_module?: boolean;
  use_waste_module?: boolean;
}

// ---- Targets (BI-003) ---------------------------------------------------

export type TargetType =
  | "PCT_FROM_WOM"
  | "PCT_FROM_BASE_YEAR"
  | "ABSOLUTE"
  | "PEAK_BEFORE_YEAR"
  | "INTENSITY_PER_GDP";
export type TargetScope = "all" | "sector" | "category";

export interface Target {
  id: string;
  name: string;
  type: TargetType;
  target_year: number;
  base_year: number | null;
  pct: number | null;
  absolute_value: number | null;
  scope: TargetScope;
  scope_filter: string | null;
  // NDC conditionality: an unconditional target stands on domestic means;
  // a conditional one depends on international support. Label only.
  conditional: boolean;
  notes: string | null;
  created_at: string;
}

export interface TargetScenarioEntry {
  value_kt: number | null;
  achieved: boolean | null;
  gap_kt: number | null;
  gap_pct: number | null;
  // PEAK_BEFORE_YEAR only: the year the scenario's emissions peak.
  peak_year?: number | null;
}

export interface TargetEvaluation {
  target_id: string;
  // null for PEAK_BEFORE_YEAR (no absolute threshold); for INTENSITY_PER_GDP
  // it is an intensity (kt per GDP unit), flagged by `unit`.
  threshold_kt: number | null;
  unit?: string;
  conditional?: boolean;
  scenarios: Record<"WOM" | "WEM" | "WAM", TargetScenarioEntry>;
}

export interface TargetEvaluationEntry {
  target: Target;
  evaluation: TargetEvaluation | null;
  error?: string;
}

export interface TargetEvaluationResponse {
  project_id: string;
  targets: TargetEvaluationEntry[];
}
