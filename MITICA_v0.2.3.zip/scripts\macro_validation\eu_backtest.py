"""Macro module — European backtest harness.

Train the B2 module on 1990-2000 historical data for a list of EU countries
and project 2001-2024. Compare projected SGDP_s against actual SGDP_s for
those years. Produces per-country MAPE / RMSE / bias diagnostics.

Data sources
------------
* **GDP, sectoral GDP, Population, Interest rate, GFCF**: Eurostat (nama_10
  family). Constant 2015 prices in million EUR. Eurostat licence: CC BY 4.0.
* **GFCF by NACE activity**: ``nama_10_a64_p5`` — aggregated to 3 economic
  sectors via NACE → primary/secondary/tertiary mapping.

Eurostat dataset references (cross-checked against the Eurostat data browser):
* ``nama_10_gdp``   — GDP and main aggregates (B1GQ = GDP, P51G = GFCF).
* ``nama_10_a10``   — Aggregates by 10 industries (B1G value added per NACE).
* ``nama_10_a64_p5`` — Gross fixed capital formation by NACE rev2 activity.
* ``demo_pjan``     — Population on 1 January.
* ``irt_st_a``      — Money market interest rates, annual.

NACE → MITICA mapping
---------------------
* Primary   = A (Agriculture, forestry, fishing)
* Secondary = B-E (Mining, Manufacturing, Energy, Water) + F (Construction)
* Tertiary  = G-T (everything else)

Units
-----
All flow variables in million euro, constant 2015 prices. Population in
persons. Interest rates in percent. These are the units the macro module
expects (numerically arbitrary but internally consistent).
"""

from __future__ import annotations

import warnings
from pathlib import Path

import numpy as np
import pandas as pd

import eurostat

warnings.filterwarnings("ignore", category=FutureWarning)


# ---------------------------------------------------------------------------
# NACE rev2 → MITICA 3-sector mapping
# ---------------------------------------------------------------------------

NACE_TO_SECTOR = {
    "A":     "primary",         # Agriculture, forestry, fishing
    "B-E":   "secondary",       # Industry (mining + manufacturing + utilities)
    "C":     "secondary",       # Manufacturing alone (used when B-E unavailable)
    "F":     "secondary",       # Construction
    "G-I":   "tertiary",        # Trade, transport, accommodation
    "G-J":   "tertiary",        # Trade, transport, accommodation, info
    "J":     "tertiary",        # Information / communication
    "K":     "tertiary",        # Financial
    "L":     "tertiary",        # Real estate
    "M_N":   "tertiary",        # Professional, scientific
    "O-Q":   "tertiary",        # Public admin, education, health
    "R-U":   "tertiary",        # Arts, other services
}


# ---------------------------------------------------------------------------
# Eurostat fetch helpers
# ---------------------------------------------------------------------------


def _fetch(
    dataset: str,
    filters: dict[str, list[str]],
) -> pd.DataFrame:
    """Run an Eurostat query and return the raw DataFrame.

    Eurostat returns one row per (dimension combination), one column per
    year. We re-orient to long format before any aggregation downstream.
    """
    df = eurostat.get_data_df(dataset, filter_pars=filters)
    if df is None or len(df) == 0:
        return pd.DataFrame()
    # Move year columns into a single 'year' column
    id_cols = [c for c in df.columns if not str(c).isdigit() and not str(c).startswith("20")]
    # Detect year columns: numeric column names
    year_cols = [c for c in df.columns if str(c).isdigit()]
    # Some versions of the library prefix with the freq letter ('A2020') — handle both
    if not year_cols:
        year_cols = [c for c in df.columns if isinstance(c, str) and c[1:].isdigit()]
    long = df.melt(id_vars=id_cols, value_vars=year_cols, var_name="year", value_name="value")
    long["year"] = long["year"].astype(str).str.lstrip("A").astype(int)
    long = long.dropna(subset=["value"])
    return long


def fetch_gdp_population(country: str, year_min: int, year_max: int) -> pd.DataFrame:
    """Return a DataFrame with columns ['Year', 'GDP_tot', 'Pop'] for one country.

    GDP_tot in millions of EUR at constant 2015 prices. Pop in persons (1 Jan).
    """
    # GDP — chain-linked volumes, reference year 2015
    gdp = _fetch(
        "nama_10_gdp",
        {
            "geo": [country],
            "unit": ["CLV15_MEUR"],
            "na_item": ["B1GQ"],
        },
    )
    gdp = gdp[(gdp["year"] >= year_min) & (gdp["year"] <= year_max)]
    gdp = gdp[["year", "value"]].rename(columns={"year": "Year", "value": "GDP_tot"})

    pop = _fetch(
        "demo_pjan",
        {
            "geo": [country],
            "sex": ["T"],
            "age": ["TOTAL"],
        },
    )
    pop = pop[(pop["year"] >= year_min) & (pop["year"] <= year_max)]
    pop = pop[["year", "value"]].rename(columns={"year": "Year", "value": "Pop"})

    return gdp.merge(pop, on="Year", how="inner").sort_values("Year").reset_index(drop=True)


def fetch_sectoral_gdp(country: str, year_min: int, year_max: int) -> pd.DataFrame:
    """Return ['Year', 'SGDP_primary', 'SGDP_secondary', 'SGDP_tertiary'].

    Aggregated from NACE rev2 activities in ``nama_10_a10`` using gross value
    added at basic prices (B1G), CLV15_MEUR.
    """
    raw = _fetch(
        "nama_10_a10",
        {
            "geo": [country],
            "unit": ["CLV15_MEUR"],
            "na_item": ["B1G"],
        },
    )
    raw = raw[(raw["year"] >= year_min) & (raw["year"] <= year_max)]
    # nace_r2 column gives the NACE code
    if "nace_r2" not in raw.columns:
        raise ValueError(f"Unexpected schema in nama_10_a10: {raw.columns.tolist()}")
    raw["sector"] = raw["nace_r2"].map(NACE_TO_SECTOR)
    raw = raw.dropna(subset=["sector"])
    agg = raw.groupby(["year", "sector"])["value"].sum().unstack("sector")
    agg.columns = [f"SGDP_{c}" for c in agg.columns]
    agg = agg.reset_index().rename(columns={"year": "Year"})
    return agg.sort_values("Year").reset_index(drop=True)


def fetch_sectoral_gfcf(country: str, year_min: int, year_max: int) -> pd.DataFrame:
    """Return ['Year', 'SInv_primary', 'SInv_secondary', 'SInv_tertiary'].

    Source: ``nama_10_a64_p5`` (Gross fixed capital formation by NACE rev2).
    Aggregated to 3 sectors using the same NACE → MITICA map.
    """
    raw = _fetch(
        "nama_10_a64_p5",
        {
            "geo": [country],
            "unit": ["CLV15_MEUR"],
            "asset10": ["N11G"],  # total assets
        },
    )
    if raw.empty:
        return pd.DataFrame(
            columns=["Year", "SInv_primary", "SInv_secondary", "SInv_tertiary"]
        )
    raw = raw[(raw["year"] >= year_min) & (raw["year"] <= year_max)]
    if "nace_r2" not in raw.columns:
        return pd.DataFrame(
            columns=["Year", "SInv_primary", "SInv_secondary", "SInv_tertiary"]
        )
    raw["sector"] = raw["nace_r2"].map(NACE_TO_SECTOR)
    raw = raw.dropna(subset=["sector"])
    agg = raw.groupby(["year", "sector"])["value"].sum().unstack("sector")
    agg.columns = [f"SInv_{c}" for c in agg.columns]
    agg = agg.reset_index().rename(columns={"year": "Year"})
    return agg.sort_values("Year").reset_index(drop=True)


def fetch_interest_rate(country: str, year_min: int, year_max: int) -> pd.DataFrame:
    """Return ['Year', 'iRate'] for a country (long-term government bond yield).

    Tries several Eurostat datasets in fallback order. If all fail, returns
    an empty DataFrame — the macro module then uses the prior for ``delta_s``.
    """
    candidates = [
        # (dataset, filters)  — listed in preferred-order
        ("irt_lt_mcby_a", {"geo": [country]}),         # long-term gov bond yield (annual)
        ("tec00027",      {"geo": [country]}),         # short-term policy rates
        ("ei_mfir_m",     {"geo": [country]}),         # monthly long-term — would need agg
    ]
    for dataset, filters in candidates:
        try:
            raw = _fetch(dataset, filters)
        except Exception:
            continue
        if raw.empty or "year" not in raw.columns or "value" not in raw.columns:
            continue
        # If multiple series come back (multi-dim), take the annual average across rows
        agg = raw.groupby("year")["value"].mean().reset_index()
        agg = agg[(agg["year"] >= year_min) & (agg["year"] <= year_max)]
        if agg.empty:
            continue
        return (agg
                .rename(columns={"year": "Year", "value": "iRate"})
                .sort_values("Year")
                .reset_index(drop=True))
    # Final fallback: empty (caller treats as missing → prior for delta_s)
    return pd.DataFrame(columns=["Year", "iRate"])


# ---------------------------------------------------------------------------
# Run the POC for a single country
# ---------------------------------------------------------------------------


def assemble_country(country: str, year_min: int = 1990, year_max: int = 2024) -> dict:
    """Return a dict with all the DataFrames needed to construct a
    ``HistoricalData`` for the backtest, plus the actuals for comparison."""
    print(f"  [fetch] {country} GDP + Pop ...", flush=True)
    gdp_pop = fetch_gdp_population(country, year_min, year_max)

    print(f"  [fetch] {country} sectoral GDP ...", flush=True)
    sgdp = fetch_sectoral_gdp(country, year_min, year_max)

    print(f"  [fetch] {country} sectoral GFCF ...", flush=True)
    sinv = fetch_sectoral_gfcf(country, year_min, year_max)

    print(f"  [fetch] {country} interest rate ...", flush=True)
    irate = fetch_interest_rate(country, year_min, year_max)

    return {
        "country": country,
        "gdp_pop": gdp_pop,
        "sgdp": sgdp,
        "sinv": sinv,
        "irate": irate,
    }


def report_coverage(data: dict) -> None:
    """Print what we have / what we miss for the country (ASCII output)."""
    c = data["country"]
    print(f"\n  Coverage report for {c}")
    print(f"  {'-' * 60}")
    for label, key in [
        ("GDP+Pop", "gdp_pop"),
        ("Sectoral GDP", "sgdp"),
        ("Sectoral GFCF (SInv)", "sinv"),
        ("Interest rate", "irate"),
    ]:
        df = data[key]
        if df is None or df.empty:
            print(f"     {label:<22}  EMPTY")
            continue
        yrs = sorted(df["Year"].unique())
        cols = [c for c in df.columns if c != "Year"]
        print(f"     {label:<22}  OK  {yrs[0]}-{yrs[-1]} ({len(yrs)} pts)  "
              f"cols={cols}")
    print(f"  {'-' * 60}")


# ---------------------------------------------------------------------------
# Main — single-country POC
# ---------------------------------------------------------------------------


def main() -> None:
    country = "ES"  # Spain — known to have full coverage
    print(f"=== European backtest POC — {country} 1990-2024 ===\n")
    data = assemble_country(country, 1990, 2024)
    report_coverage(data)

    # Save raw data for later use
    out_dir = Path("scripts/macro_validation/data")
    out_dir.mkdir(parents=True, exist_ok=True)
    for key, df in data.items():
        if isinstance(df, pd.DataFrame):
            df.to_csv(out_dir / f"{country}_{key}.csv", index=False)
    print(f"\n  Raw CSVs saved under {out_dir}/")


if __name__ == "__main__":
    main()
