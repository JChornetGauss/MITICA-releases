# MITICA Next — Windows launcher
# Runs the FastAPI backend and the Next.js frontend in parallel.

param(
    [switch]$ApiOnly,
    [switch]$WebOnly
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Start-Api {
    Write-Host "[api] starting uvicorn at http://127.0.0.1:8000" -ForegroundColor Cyan
    Set-Location (Join-Path $root "packages\api")
    uv run uvicorn mitica_api.main:app --reload --host 127.0.0.1 --port 8000
}

function Start-Web {
    Write-Host "[web] starting Next.js at http://localhost:3000" -ForegroundColor Cyan
    Set-Location (Join-Path $root "apps\web")
    pnpm dev
}

if ($ApiOnly) {
    Start-Api
} elseif ($WebOnly) {
    Start-Web
} else {
    $apiJob = Start-Job -ScriptBlock {
        param($r)
        Set-Location (Join-Path $r "packages\api")
        uv run uvicorn mitica_api.main:app --reload --host 127.0.0.1 --port 8000
    } -ArgumentList $root

    Write-Host "[api] background job id $($apiJob.Id)" -ForegroundColor Cyan
    Start-Web
    Stop-Job $apiJob -ErrorAction SilentlyContinue
    Remove-Job $apiJob -Force -ErrorAction SilentlyContinue
}
