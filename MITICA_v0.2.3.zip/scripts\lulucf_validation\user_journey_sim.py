"""
user_journey_sim.py
===================

End-to-end USER simulation — not a unit test, not an edge-case probe. I play a
real focal point who has ONLY their national LULUCF inventory (real BTR1
numbers), nothing else, and walk the full MITICA journey:

    1. load the inventory (real BTR1 LULUCF net flux, Canada),
    2. let the tool auto-fill the national land area from its refDB,
    3. run the WoM (Without Measures) baseline,
    4. define a few Policies & Measures from the catalog (WEM = existing),
    5. add more ambitious ones (WAM = additional),
    6. read off the WoM / WEM / WAM scenarios and compare to the inventory.

It prints a narrative report: what numbers came out, how they compare to the
reported inventory, and what the experience felt like (what the tool asked for,
what it gave back, what was missing). Real data, real engine, real output.

Run::

    python scripts/lulucf_validation/user_journey_sim.py
"""

from __future__ import annotations

import dataclasses
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# --- path wiring (mirror the other lulucf_validation scripts) --------------
_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS_DIR = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from mitica_core.modules.lulucf import run_lulucf_module  # noqa: E402
import v1_country_backtest as bt  # noqa: E402

COUNTRY = "CAN"


def _p(s: str = "") -> None:
    """ASCII-only print (Windows console is cp1252)."""
    sys.stdout.buffer.write((s + "\n").encode("ascii", "replace"))


# ---------------------------------------------------------------------------
# Step 1-2: inputs — I have ONLY the inventory; the tool fills the land area.
# ---------------------------------------------------------------------------

def build_inventory_only_inputs():
    """Take the real BTR1 bundle, then STRIP every optional activity-driver
    frame so all I bring is the inventory; land area is the tool's refDB
    auto-fill (the L-A minimum-viable profile)."""
    hist, proj, cfg = bt.build_country_inputs(COUNTRY)
    # Drop every optional frame the backtest fixture happened to attach.
    hist = dataclasses.replace(
        hist,
        burned_area=None, harvest_volume=None, organic_soil_area=None,
        macro_heads=None, macro_sgdp_primary=None, forest_cohort_areas=None,
        hwp_historical=None, transition_matrix=None,
    )
    return hist, proj, cfg


# ---------------------------------------------------------------------------
# Step 4-5: the PAMs I define from the catalog.
# Variable values are realistic Canadian boreal numbers (2 Billion Trees, etc.)
# WEM = measures already in place; WAM = additional, on top of WEM.
# ---------------------------------------------------------------------------

def build_pams() -> list[dict[str, Any]]:
    return [
        # --- WEM: existing measures -------------------------------------
        {
            # Afforestation/reforestation on Forest Land (4A).
            "catalog_id": "LULUCF::Forestry::0",
            "category": "4A", "scenario": "WEM",
            "time_distribution": "constant", "t0": 2025,
            "name": "Afforestation (2B Trees, existing pace)",
            "variables": {  # A=ha/yr, B=growth, C=BGB:AGB, E=CF, G=loss%, H=soil C
                "A": 50_000.0, "B": 3.0, "C": 0.25, "E": 0.47, "G": 5.0, "H": 0.7,
            },
        },
        {
            # Reducing deforestation (deforestation prevented) on 4A.
            "catalog_id": "LULUCF::Forestry::3",
            "category": "4A", "scenario": "WEM",
            "time_distribution": "constant", "t0": 2025,
            "name": "Reduced deforestation (existing)",
            "variables": {  # A=ha prevented, B=AGB, C=BGB:AGB, E=CF, G=post-def stock
                "A": 5_000.0, "B": 80.0, "C": 0.25, "E": 0.47, "G": 20.0,
            },
        },
        # --- WAM: additional measures (on top of WEM) -------------------
        {
            # A scaled-up afforestation push.
            "catalog_id": "LULUCF::Forestry::0",
            "category": "4A", "scenario": "WAM",
            "time_distribution": "variable", "t0": 2026, "t1": 2030, "t2": 2035,
            "name": "Afforestation scale-up (additional)",
            "variables": {
                "A": 80_000.0, "B": 3.0, "C": 0.25, "E": 0.47, "G": 5.0, "H": 0.7,
            },
        },
        {
            # Restoration of degraded forests on 4A.
            "catalog_id": "LULUCF::Forestry::2",
            "category": "4A", "scenario": "WAM",
            "time_distribution": "constant", "t0": 2027,
            "name": "Degraded-forest restoration (additional)",
            "variables": {  # A=ha protected, B=growth, C=BGB:AGB, E=CF, G=loss%
                "A": 200_000.0, "B": 2.5, "C": 0.25, "E": 0.47, "G": 10.0,
            },
        },
    ]


# ---------------------------------------------------------------------------
# Reporting helpers
# ---------------------------------------------------------------------------

def net_by_year(scenario_net: pd.DataFrame, scenario: str) -> dict[int, float]:
    sub = scenario_net[scenario_net["Scenario"] == scenario]
    g = sub.groupby("Year")["Net_CO2eq_kt"].sum()
    return {int(y): float(v) for y, v in g.items()}


def fmt(v: float) -> str:
    return f"{v:>+12,.0f}"


def main() -> int:
    fixture = bt.COUNTRY_FIXTURES[COUNTRY]
    reported = fixture["reported_history"]
    horizon = fixture["horizon_year"]

    _p("=" * 74)
    _p(f"  MITICA LULUCF — user journey: I am a {COUNTRY} focal point")
    _p("  I have ONLY my BTR1 LULUCF inventory. Let's build scenarios.")
    _p("=" * 74)

    _p("\n[Step 1] My inventory (real, from Canada's BTR1 / NIR 2024):")
    for y in sorted(reported):
        tag = "source" if reported[y] > 0 else "sink"
        _p(f"   {y}:  {fmt(reported[y])} kt CO2-eq   ({tag})")
    _p("   (intermediate years linear-interpolated; kt CO2-eq, AR5)")

    hist, proj, cfg = build_inventory_only_inputs()
    last_hist = hist.last_historical_year()
    _p(f"\n[Step 2] The tool auto-filled my national land area from its refDB.")
    _p(f"   Profile detected: L-A (minimum viable: only national area).")
    _p(f"   Horizon: {horizon}.  Last inventory year: {last_hist}.")
    _p(f"   Optional data I provided: NONE (inventory only).")

    # --- WoM baseline ---
    wom = run_lulucf_module(hist, proj, cfg)
    wom_net = {int(r["Year"]): float(r["Net_LULUCF_CO2eq_kt"])
               for _, r in wom.net_co2eq_by_year().iterrows()}
    n_red = sum(1 for f in wom.validation_report if f.severity == "red")
    n_amb = sum(1 for f in wom.validation_report if f.severity == "amber")

    _p(f"\n[Step 3] WoM (Without Measures) baseline ran.")
    _p(f"   Validation flags: {n_red} red, {n_amb} amber.")
    _p(f"   WoM net @ {last_hist} (anchor): {fmt(wom_net.get(last_hist, float('nan')))} kt")
    _p(f"   WoM net @ 2030:              {fmt(wom_net.get(2030, float('nan')))} kt")
    _p(f"   WoM net @ {horizon}:              {fmt(wom_net.get(horizon, float('nan')))} kt")
    # Compare WoM anchor to the reported inventory anchor.
    rep_anchor = reported[max(reported)]
    _p(f"   Reported inventory @ {max(reported)}: {fmt(rep_anchor)} kt  "
       f"(WoM anchor diff: {fmt(wom_net.get(last_hist, 0) - rep_anchor)})")

    # --- Scenarios with PAMs ---
    pams = build_pams()
    out = run_lulucf_module(hist, proj, cfg, pams=pams)
    sc = out.scenario_net
    if sc is None or len(sc) == 0:
        _p("\n[!] No scenario_net returned — PAMs did not produce a table.")
        return 1

    wom_s = net_by_year(sc, "WoM")
    wem_s = net_by_year(sc, "WEM")
    wam_s = net_by_year(sc, "WAM")

    _p(f"\n[Step 4-5] I defined {len(pams)} PAMs from the catalog:")
    for p in pams:
        _p(f"   [{p['scenario']}] {p['name']}  (cat {p['category']}, t0={p['t0']})")

    _p(f"\n[Step 6] Scenarios (national net LULUCF, kt CO2-eq; more negative = bigger sink):")
    _p(f"   {'Year':>6} | {'WoM':>12} | {'WEM':>12} | {'WAM':>12} | "
       f"{'WEM mit.':>10} | {'WAM mit.':>10}")
    _p("   " + "-" * 74)
    for y in [last_hist, 2025, 2030, 2035, horizon]:
        if y not in wom_s:
            continue
        wem_mit = wom_s[y] - wem_s.get(y, wom_s[y])
        wam_mit = wom_s[y] - wam_s.get(y, wom_s[y])
        _p(f"   {y:>6} | {fmt(wom_s[y])} | {fmt(wem_s.get(y, wom_s[y]))} | "
           f"{fmt(wam_s.get(y, wom_s[y]))} | {wem_mit:>10,.0f} | {wam_mit:>10,.0f}")

    # --- PAM ranking ---
    if out.pam_summary is not None and len(out.pam_summary) > 0:
        _p(f"\n   PAM ranking by total mitigation over the horizon (kt CO2-eq):")
        ps = out.pam_summary.sort_values(
            "Total_Mitigation_CO2eq_kt", key=lambda s: s.abs(), ascending=False)
        for _, r in ps.iterrows():
            name = r["PamName"]
            total = r["Total_Mitigation_CO2eq_kt"]
            share = r["CumulativeShare"]
            _p(f"     - [{r['Scenario']}] {str(name)[:38]:<38} {total:>10,.0f}  "
               f"(cum. share {share:.0%})")

    # --- headline comparison ---
    wom_h = wom_s.get(horizon, float("nan"))
    wem_h = wem_s.get(horizon, wom_h)
    wam_h = wam_s.get(horizon, wom_h)
    _p(f"\n   HEADLINE @ {horizon}:")
    _p(f"     WoM  {fmt(wom_h)} kt  -> WEM {fmt(wem_h)} kt  -> WAM {fmt(wam_h)} kt")
    _p(f"     Additional abatement from measures: "
       f"WEM {wom_h - wem_h:,.0f} kt/yr, WAM {wom_h - wam_h:,.0f} kt/yr.")
    _p("=" * 74)
    return 0


if __name__ == "__main__":
    sys.exit(main())
