"""Build mitica_core/data/wb_income_groups.json from the World Bank API.

Downloads the official World Bank country list (which carries each country's
current income-level classification — FY2025 at the time of writing) and maps
the WB income ids to MITICA's L/LM/UM/H vocabulary:

    LIC -> L   (Low income)
    LMC -> LM  (Lower-middle income)
    UMC -> UM  (Upper-middle income)
    HIC -> H   (High income)

Aggregates (region/income groupings, incomeLevel id "NA") and unclassified
countries (INX, e.g. Venezuela) are skipped — the product treats a missing
entry as "unknown, fall back to the heuristic".

Usage (from mitica_next/):
    .venv\\Scripts\\python.exe scripts\\build_wb_income_groups.py
"""

from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path

import requests

API_URL = "https://api.worldbank.org/v2/country?format=json&per_page=400"
OUT_PATH = (
    Path(__file__).resolve().parents[1]
    / "packages" / "core" / "src" / "mitica_core" / "data"
    / "wb_income_groups.json"
)

WB_TO_MITICA = {"LIC": "L", "LMC": "LM", "UMC": "UM", "HIC": "H"}


def main() -> int:
    resp = requests.get(API_URL, timeout=60)
    resp.raise_for_status()
    payload = resp.json()
    if not isinstance(payload, list) or len(payload) < 2:
        raise SystemExit(f"Unexpected WB API payload shape: {type(payload)}")
    meta, countries = payload[0], payload[1]
    total = int(meta.get("total", 0))
    if len(countries) < total:
        raise SystemExit(
            f"WB API returned {len(countries)} of {total} records — bump per_page."
        )

    groups: dict[str, str] = {}
    skipped: list[str] = []
    for c in countries:
        iso3 = (c.get("id") or "").strip().upper()
        income = (c.get("incomeLevel") or {}).get("id", "")
        # Aggregates carry incomeLevel "NA"; INX = unclassified (e.g. VEN).
        if income not in WB_TO_MITICA:
            skipped.append(f"{iso3}({income})")
            continue
        groups[iso3] = WB_TO_MITICA[income]

    if "GUY" not in groups or groups["GUY"] != "H":
        raise SystemExit(
            f"Sanity check failed: GUY should be 'H' (since FY2024/2023 data), "
            f"got {groups.get('GUY')!r}."
        )

    out = {
        "_source": "World Bank API v2 /country incomeLevel (official classification)",
        "_url": API_URL,
        "_retrieved": date.today().isoformat(),
        "_mapping": "LIC->L, LMC->LM, UMC->UM, HIC->H; aggregates and INX skipped",
        "groups": dict(sorted(groups.items())),
    }
    OUT_PATH.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(groups)} countries to {OUT_PATH}")
    print(f"Skipped {len(skipped)} aggregates/unclassified")
    return 0


if __name__ == "__main__":
    sys.exit(main())
