@echo off
rem Helper invoked by dev.cmd / start.cmd — runs the API in its own window.
rem Supports two layouts:
rem   DEV  : repo checkout with .venv\Scripts\python.exe
rem   PROD : installer layout with ..\tools\python\python.exe (no venv)

set ROOT=%~dp0..
cd /d "%ROOT%"
title MITICA API
echo [MITICA API] starting uvicorn on http://127.0.0.1:8000 ...
echo.

rem -- Resolve Python executable --
if exist ".venv\Scripts\python.exe" (
    set PYTHON=".venv\Scripts\python.exe"
) else if exist "..\tools\python\python.exe" (
    set PYTHON="..\tools\python\python.exe"
) else (
    echo [MITICA API] ERROR: No Python found.
    echo   Expected either .venv\Scripts\python.exe ^(dev^)
    echo   or ..\tools\python\python.exe ^(installer^)
    pause
    exit /b 1
)

echo [MITICA API] Using Python: %PYTHON%
echo.
%PYTHON% -m uvicorn mitica_api.main:app --reload --host 127.0.0.1 --port 8000

echo.
echo [MITICA API] server exited. Press any key to close this window.
pause >nul