// Typed fetch wrapper. Base URL is relative; next.config.mjs rewrites /api/* to :8000.

import type {
  CompareMethodsResponse,
  Forecast,
  InventoryUploadResponse,
  JobStatus,
  MACCData,
  PAM,
  PAMCatalog,
  Project,
  ProjectCreate,
  ProjectUpdate,
  ProxyCatalog,
  ScenarioOverview,
  Target,
  TargetEvaluationResponse,
} from "./types";

const API_PREFIX = "/api/v1";

class ApiError extends Error {
  constructor(public status: number, message: string, public body?: unknown) {
    super(message);
    this.name = "ApiError";
  }
}

/**
 * Turn a FastAPI/Pydantic `detail` payload into a readable string.
 *
 * FastAPI request-validation errors (422) return `detail` as an ARRAY
 * of `{ type, loc, msg }` objects, not a string. Naively calling
 * `String(detail)` on that array yields "[object Object]" and throws
 * away the underlying Pydantic message — which the LULUCF/macro pages
 * pattern-match on to show plain-language hints (e.g. the 5,000-row
 * cap). Flatten the array into "loc: msg; loc: msg" so those matchers
 * (and the raw fallback) see the real text.
 */
function stringifyDetail(detail: unknown): string {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    const parts = detail.map((item) => {
      if (item && typeof item === "object") {
        const rec = item as { msg?: unknown; loc?: unknown; type?: unknown };
        const loc = Array.isArray(rec.loc)
          ? rec.loc.filter((s) => s !== "body").join(".")
          : "";
        const m = typeof rec.msg === "string" ? rec.msg : JSON.stringify(item);
        // Keep the Pydantic error `type` (e.g. "too_long") in the text:
        // it's a stable matcher key even if the human `msg` wording drifts.
        const t = typeof rec.type === "string" ? ` (${rec.type})` : "";
        const head = loc ? `${loc}: ${m}` : m;
        return `${head}${t}`;
      }
      return String(item);
    });
    return parts.join("; ").slice(0, 500);
  }
  try {
    return JSON.stringify(detail);
  } catch {
    return String(detail);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_PREFIX}${path}`, {
      ...init,
      headers: {
        ...(init?.body && !(init.body instanceof FormData)
          ? { "Content-Type": "application/json" }
          : {}),
        ...init?.headers,
      },
    });
  } catch (e) {
    // Network-level failure — fetch itself threw (DNS, refused, CORS, offline).
    throw new ApiError(
      0,
      `Network error reaching the API. Is http://127.0.0.1:8000 running? (${(e as Error).message})`
    );
  }

  // Read the body exactly once, then decide how to interpret it.
  const rawText = await res.text();

  if (!res.ok) {
    let parsed: unknown = rawText;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      /* keep rawText */
    }
    const detail =
      typeof parsed === "object" && parsed && "detail" in parsed
        ? stringifyDetail((parsed as { detail: unknown }).detail)
        : typeof parsed === "string" && parsed.trim().length > 0
        ? parsed.trim().slice(0, 300)
        : `HTTP ${res.status} ${res.statusText}`.trim();
    throw new ApiError(res.status, detail, parsed);
  }

  // 2xx — may be empty (204-like), text, or JSON.
  const ct = res.headers.get("content-type") ?? "";
  if (rawText.length === 0) return undefined as unknown as T;
  if (ct.includes("application/json")) {
    try {
      return JSON.parse(rawText) as T;
    } catch (e) {
      throw new ApiError(res.status, `Malformed JSON from API: ${(e as Error).message}`);
    }
  }
  return rawText as unknown as T;
}

export const api = {
  // ---- Health
  health: () => request<{ status: string; api_version: string }>("/health"),

  // ---- Projects
  listProjects: () => request<Project[]>("/projects"),
  createProject: (data: ProjectCreate) =>
    request<Project>("/projects", { method: "POST", body: JSON.stringify(data) }),
  getProject: (id: string) => request<Project>(`/projects/${id}`),
  patchProject: (id: string, data: ProjectUpdate) =>
    request<Project>(`/projects/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),
  deleteProject: (id: string) =>
    request<{ deleted: string }>(`/projects/${id}`, { method: "DELETE" }),

  // ---- Inventory
  uploadInventoryExcel: (projectId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<InventoryUploadResponse>(
      `/projects/${projectId}/inventory/excel`,
      { method: "POST", body: fd }
    );
  },
  uploadInventoryCRT: (projectId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<InventoryUploadResponse>(
      `/projects/${projectId}/inventory/crt-json`,
      { method: "POST", body: fd }
    );
  },
  uploadInventoryGasSheet: (projectId: string, gas: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<InventoryUploadResponse>(
      `/projects/${projectId}/inventory/gas-sheet?gas=${encodeURIComponent(gas)}`,
      { method: "POST", body: fd }
    );
  },

  // ---- Proxies
  uploadProxy: (
    projectId: string,
    file: File,
    opts: {
      name: string;
      sector?: string | null;
      mandatory?: boolean;
      unit?: string | null;
    }
  ) => {
    const fd = new FormData();
    fd.append("file", file);
    const qs = new URLSearchParams();
    qs.set("name", opts.name);
    if (opts.sector) qs.set("sector", opts.sector);
    if (opts.mandatory !== undefined) qs.set("mandatory", String(opts.mandatory));
    if (opts.unit) qs.set("unit", opts.unit);
    return request<{ project_id: string; proxy: unknown }>(
      `/projects/${projectId}/proxies?${qs.toString()}`,
      { method: "POST", body: fd }
    );
  },

  // ---- Forecast
  runForecast: (
    projectId: string,
    data: {
      horizon_year: number;
      reference_year?: number | null;
      method: string;
      apply_auto_modifications?: boolean;
      seed?: number | null;
    }
  ) =>
    request<JobStatus>(`/projects/${projectId}/forecasts/run`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  jobStatus: (projectId: string, jobId: string) =>
    request<JobStatus>(`/projects/${projectId}/forecasts/jobs/${jobId}`),

  getForecast: (projectId: string) =>
    request<Forecast>(`/projects/${projectId}/forecast`),

  // ---- Modifiers
  applyModifier: (
    projectId: string,
    body: { category: string; modifier: string; params?: Record<string, unknown> }
  ) =>
    request<{
      category: string;
      modifier: string;
      years: number[];
      forecast: (number | null)[];
      validated: boolean;
    }>(`/projects/${projectId}/validate/apply-modifier`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  // ---- Compare forecasting methods (GUY-18, QA/QC) — read-only, computes
  // nothing persisted. Returns ANNALIST + comparison methods (SARIMAX, GBR,
  // LINREG by default) over the same category so users can sanity-check the WoM.
  compareMethods: (projectId: string, category: string, methods?: string[]) =>
    request<CompareMethodsResponse>(
      `/projects/${projectId}/validate/compare-methods`,
      {
        method: "POST",
        body: JSON.stringify(methods ? { category, methods } : { category }),
      }
    ),

  // ---- Validation flags
  validateCategory: (projectId: string, category: string, validated = true) =>
    request<{
      category: string;
      validated: boolean;
      total_categories: number;
      validated_count: number;
    }>(`/projects/${projectId}/validate/category`, {
      method: "POST",
      body: JSON.stringify({ category, validated }),
    }),
  validateAll: (projectId: string) =>
    request<{ total_categories: number; validated_count: number }>(
      `/projects/${projectId}/validate/all`,
      { method: "POST", body: "{}" }
    ),

  // ---- Catalogs
  pamCatalog: () => request<PAMCatalog>("/catalog/pams"),
  proxyCatalog: () => request<ProxyCatalog>("/catalog/proxies"),

  // ---- PAMs
  listPAMs: (projectId: string) => request<PAM[]>(`/projects/${projectId}/pams`),
  createPAM: (projectId: string, pam: PAM) =>
    request<PAM>(`/projects/${projectId}/pams`, {
      method: "POST",
      body: JSON.stringify(pam),
    }),
  deletePAM: (projectId: string, pamId: string) =>
    request<{ deleted: number }>(`/projects/${projectId}/pams/${pamId}`, {
      method: "DELETE",
    }),
  pamSeries: (projectId: string, pamId: string) =>
    request<{ years: number[]; forecast: (number | null)[]; mitigation: (number | null)[] }>(
      `/projects/${projectId}/pams/${pamId}/mitigation-series`
    ),

  // ---- Scenarios + MACC
  scenarios: (projectId: string) =>
    request<ScenarioOverview>(`/projects/${projectId}/scenarios`),
  macc: (projectId: string, sector = "All Sectors") =>
    request<MACCData>(
      `/projects/${projectId}/macc?sector=${encodeURIComponent(sector)}`
    ),

  // ---- Targets (BI-003)
  listTargets: (projectId: string) => request<Target[]>(`/projects/${projectId}/targets`),
  createTarget: (projectId: string, target: Target) =>
    request<Target>(`/projects/${projectId}/targets`, {
      method: "POST",
      body: JSON.stringify(target),
    }),
  deleteTarget: (projectId: string, targetId: string) =>
    request<{ deleted: number }>(`/projects/${projectId}/targets/${targetId}`, {
      method: "DELETE",
    }),
  evaluateTargets: (projectId: string) =>
    request<TargetEvaluationResponse>(`/projects/${projectId}/targets/evaluation`),

  // ---- Macro module (SI-002)
  runMacro: (projectId: string, body: MacroRunRequest) =>
    request<MacroResult>(`/projects/${projectId}/macro/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getMacroResult: (projectId: string) =>
    request<MacroResult>(`/projects/${projectId}/macro/result`),
  clearMacroResult: (projectId: string) =>
    request<{ deleted: boolean }>(`/projects/${projectId}/macro/result`, {
      method: "DELETE",
    }),
  getMacroFormsCatalog: () => request<MacroFormsCatalog>(`/macro/forms-catalog`),
  // Server-side parse of an uploaded Excel/CSV macro template. Robust to
  // header rows, locale decimal commas and blank rows; returns a clean
  // comma-separated CSV with a "Year" header. Replaces the client-side
  // SheetJS path on the macro page.
  parseMacroExcel: (projectId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<{ csv: string; columns: string[]; n_rows: number; sheet: string | null }>(
      `/projects/${projectId}/macro/parse-excel`,
      { method: "POST", body: fd }
    );
  },
  // G11 (UX audit): server-side auto-fill of SGDP from WDI shares × the
  // user's historical GDP. Resolves the "I don't have sectoral GDP"
  // blocker for low-data countries (Patrick / Vietnam).
  fetchSgdpFromWdi: (
    projectId: string,
    gdpTot: { year: number; value: number }[],
  ) =>
    request<WdiSgdpResponse>(`/projects/${projectId}/macro/sgdp-from-wdi`, {
      method: "POST",
      body: JSON.stringify({ gdp_tot: gdpTot }),
    }),

  // ---- Energy industries module (SI-003, IPCC 1A1)
  uploadEnergyTemplate: (projectId: string, file: File, countryCode = "UNK") => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("country_code", countryCode);
    return request<EnergyUploadResponse>(
      `/projects/${projectId}/energy/upload`,
      { method: "POST", body: fd }
    );
  },
  runEnergy: (
    projectId: string,
    body: {
      horizon_year?: number | null;
      // omitted/0 ⇒ losses share derived from history (legacy rule)
      losses_pct?: number | null;
      scenarios?: string[];
      mode?: "legacy_excel" | "merit_dispatch";
      // Monte-Carlo iterations (0 = off; 1000 recommended, 10000 = dissertation default)
      uncertainty_iterations?: number;
    }
  ) =>
    request<EnergyResult>(`/projects/${projectId}/energy/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getEnergySystem: (projectId: string) =>
    request<EnergySystem>(`/projects/${projectId}/energy/system`),
  getEnergyResult: (projectId: string) =>
    request<EnergyResult>(`/projects/${projectId}/energy/result`),

  // PAM CRUD (edit without re-uploading the Excel)
  listEnergyPAMs: (projectId: string) =>
    request<EnergyPAM[]>(`/projects/${projectId}/energy/pams`),
  createEnergyPAM: (projectId: string, body: EnergyPAMInput) =>
    request<EnergyPAM>(`/projects/${projectId}/energy/pams`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  updateEnergyPAM: (projectId: string, pamId: string, body: Partial<EnergyPAMInput>) =>
    request<EnergyPAM>(`/projects/${projectId}/energy/pams/${pamId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),
  deleteEnergyPAM: (projectId: string, pamId: string) =>
    request<{ deleted: number }>(`/projects/${projectId}/energy/pams/${pamId}`, {
      method: "DELETE",
    }),

  // Download URLs — hit them from a regular <a href> so the browser handles the file.
  energyExportJsonUrl: (projectId: string) =>
    `${API_PREFIX}/projects/${projectId}/energy/export.json`,
  energyExportCsvUrl: (projectId: string) =>
    `${API_PREFIX}/projects/${projectId}/energy/export.csv`,

  // ---- Export
  exportCRTUrl: (projectId: string) =>
    `${API_PREFIX}/projects/${projectId}/exports/crt.xlsx`,

  // ---- LULUCF module (SI-004)
  runLulucf: (
    projectId: string,
    body: LulucfRunRequest,
    scenarioName: string = "WoM",
  ) =>
    request<LulucfResult>(
      `/projects/${projectId}/lulucf/run?scenario_name=${encodeURIComponent(scenarioName)}`,
      { method: "POST", body: JSON.stringify(body) },
    ),
  getLulucfResult: (projectId: string, scenarioName: string = "WoM") =>
    request<LulucfResult>(
      `/projects/${projectId}/lulucf/result?scenario_name=${encodeURIComponent(scenarioName)}`,
    ),
  clearLulucfResult: (projectId: string, scenarioName: string = "WoM") =>
    request<{ deleted: boolean; scenario_name: string }>(
      `/projects/${projectId}/lulucf/result?scenario_name=${encodeURIComponent(scenarioName)}`,
      { method: "DELETE" },
    ),
  listLulucfScenarios: (projectId: string) =>
    request<{ scenarios: LulucfScenarioEntry[] }>(
      `/projects/${projectId}/lulucf/scenarios`,
    ),
  getLulucfFormsCatalog: () => request<LulucfFormsCatalog>(`/lulucf/forms-catalog`),
  getLulucfPamCatalog: () => request<LulucfPamCatalog>(`/lulucf/pam-catalog`),

  // ---- F-gases module (SI-005, CRT 2F)
  uploadFGasesTemplate: (
    projectId: string,
    file: File,
    countryCode = "UNK",
    lastHistYear = 2023,
  ) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("country_code", countryCode);
    fd.append("last_hist_year", String(lastHistYear));
    return request<FGasesUploadResponse>(
      `/projects/${projectId}/fgases/upload`,
      { method: "POST", body: fd }
    );
  },
  runFGases: (projectId: string, body: FGasesRunRequest) =>
    request<FGasesResult>(`/projects/${projectId}/fgases/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getFGasesSystem: (projectId: string) =>
    request<FGasesSystem>(`/projects/${projectId}/fgases/system`),
  getFGasesResult: (projectId: string) =>
    request<FGasesResult>(`/projects/${projectId}/fgases/result`),
  clearFGasesResult: (projectId: string) =>
    request<{ deleted: boolean }>(`/projects/${projectId}/fgases/result`, {
      method: "DELETE",
    }),
  getFGasesFormsCatalog: () =>
    request<FGasesFormsCatalog>(`/fgases/forms-catalog`),

  // ---- Transport module (SI-006, CRT 1A3b)
  runTransport: (projectId: string, body: TransportRunRequest) =>
    request<TransportResult>(`/projects/${projectId}/transport/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getTransportResult: (projectId: string) =>
    request<TransportResult>(`/projects/${projectId}/transport/result`),
  listTransportPAMs: (projectId: string) =>
    request<TransportPAM[]>(`/projects/${projectId}/transport/pams`),
  createTransportPAM: (projectId: string, body: TransportPAM) =>
    request<TransportPAM>(`/projects/${projectId}/transport/pams`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  updateTransportPAM: (
    projectId: string,
    pamId: string,
    body: Partial<TransportPAM>,
  ) =>
    request<TransportPAM>(`/projects/${projectId}/transport/pams/${pamId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),
  deleteTransportPAM: (projectId: string, pamId: string) =>
    request<{ deleted: number }>(
      `/projects/${projectId}/transport/pams/${pamId}`,
      { method: "DELETE" },
    ),

  // ---- Waste module (SI-007, CRT 5A-5D)
  runWaste: (projectId: string, body: WasteRunRequest) =>
    request<WasteResult>(`/projects/${projectId}/waste/run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  getWasteResult: (projectId: string) =>
    request<WasteResult>(`/projects/${projectId}/waste/result`),
  listWastePAMs: (projectId: string) =>
    request<WastePAM[]>(`/projects/${projectId}/waste/pams`),
  createWastePAM: (projectId: string, body: WastePAM) =>
    request<WastePAM>(`/projects/${projectId}/waste/pams`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  updateWastePAM: (
    projectId: string,
    pamId: string,
    body: Partial<WastePAM>,
  ) =>
    request<WastePAM>(`/projects/${projectId}/waste/pams/${pamId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),
  deleteWastePAM: (projectId: string, pamId: string) =>
    request<{ deleted: number }>(
      `/projects/${projectId}/waste/pams/${pamId}`,
      { method: "DELETE" },
    ),
};

// ----- Module types -----

// Per-block functional forms. B3/B5/B6 are live in v4. B2 has NO form switch
// in v4 — it is always the error-correction structure model (see
// docs/MACRO_v4_DESIGN.md).
export type B3Form = "constant" | "bennett_logistic";
export type B5Form = "log_log" | "intensity_convergence";
export type B6Form = "log_log" | "saturation";
export type MacroRegion =
  | "LAC" | "SSA" | "MENA" | "APAC" | "EEU" | "HIC" | "HIC_TRANS";
// v4 development-phase group (WB income class) → the B0 growth + B2-EC priors.
// When omitted, the engine derives it coarsely from the region.
export type MacroDevGroup = "L" | "LM" | "UM" | "H";

export interface MacroYV {
  year: number;
  value: number;
}
export interface MacroSGDP {
  year: number;
  primary: number;
  secondary: number;
  tertiary: number;
}
export interface MacroSEDRow {
  year: number;
  primary?: number | null;
  manufacturing?: number | null;
  construction?: number | null;
  services?: number | null;
  transport_pass?: number | null;
  transport_freight?: number | null;
}
export interface MacroPrimSplit {
  year: number;
  share_crops: number;
  share_livestock: number;
}
// M-03: one long-format fuel-mix cell — `share` of `fuel` in `sector`'s energy
// demand in `year`. The backend constrains the vocabulary (422 otherwise):
// sector ∈ primary|manufacturing|construction|services|transport_pass|
// transport_freight|households; fuel ∈ electricity|gas|oil_products|solids|
// biomass|heat; share ∈ [0,1]. Each historical (year, sector) must sum to 1
// (engine Layer-A red T1 aborts the run otherwise).
export interface MacroFuelShareRow {
  year: number;
  sector: string;
  fuel: string;
  share: number;
}

export interface MacroRunRequest {
  region: MacroRegion;
  horizon_year: number;
  shrinkage: number;
  dev_group?: MacroDevGroup | null;
  b3_form?: B3Form;
  b5_form?: B5Form;
  b6_form?: B6Form;
  touch_up_mode?: boolean;
  validate_historical?: boolean;

  gdp_tot: MacroYV[];
  population: MacroYV[];
  sgdp: MacroSGDP[];

  sinv?: MacroSGDP[];
  irate?: MacroYV[];
  prim_splits?: MacroPrimSplit[];
  sed?: MacroSEDRow[];
  sed_hh?: MacroYV[];
  // Optional total final energy demand (incl. transport). Historical: anchors
  // the energy block to the observed total. Energy is fully optional.
  ted?: MacroYV[];
  // M-03: historical fuel mix per energy sector, long format (one row per
  // year × sector × fuel). Calibrates the logistic fuel-share projection.
  fuel_shares?: MacroFuelShareRow[];
  heads?: MacroYV[];
  gfcf_pub_total?: MacroYV[];
  inv_total?: MacroYV[];

  proj_gdp_tot?: MacroYV[];
  proj_population?: MacroYV[];
  proj_sgdp?: MacroSGDP[];
  proj_sinv?: MacroSGDP[];
  proj_irate?: MacroYV[];
  // Projected energy total pinned by the user (their energy scenario). Honored
  // exactly and split across the macro-driven composition; benchmarked via U3.
  proj_ted?: MacroYV[];
  // M-03: future-year fuel-mix pins. Applied AFTER the engine's logistic
  // projection; the remaining fuels are renormalised into the residual
  // (design §6.6). Partial groups (Σ < 1) are fine; over-commit (Σ > 1) is red.
  proj_fuel_shares?: MacroFuelShareRow[];
  proj_gfcf_pub_total?: MacroYV[];
  proj_inv_total?: MacroYV[];
}

export interface MacroFormSlot {
  options: string[];
  descriptions: Record<string, string>;
  default: string;
}

export interface MacroFormsCatalog {
  regions: MacroRegion[];
  dev_groups: {
    options: MacroDevGroup[];
    descriptions: Record<string, string>;
    default: MacroDevGroup | null;
  };
  forms: {
    b3: MacroFormSlot;
    b5: MacroFormSlot;
    b6: MacroFormSlot;
  };
  recommended_by_region: Record<
    MacroRegion,
    { b3: B3Form; b5: B5Form; b6: B6Form }
  >;
  region_descriptions: Record<MacroRegion, string>;
}

export interface MacroResult {
  flow_detected: string;
  horizon_year: number;
  region: MacroRegion | string;
  // v4: the development-phase group used, the fitted structural attractor φ,
  // and the active B3/B5/B6 forms.
  dev_group?: MacroDevGroup | string;
  phi?: number | null;
  shrinkage: number;
  b3_form?: B3Form;
  b5_form?: B5Form;
  b6_form?: B6Form;
  gdp_tot: Record<string, number>[];
  population: Record<string, number>[];
  sgdp: Record<string, number>[];
  sed: Record<string, number>[];
  sed_hh: Record<string, number>[];
  // M-03: historical rows as-is + the projected mix (logistic continuation in
  // logit space, renormalised to Σ = 1; user pins honored with the remaining
  // fuels renormalised into the residual). Long format.
  fuel_shares: { Year: number; Sector: string; Fuel: string; Share: number | null }[];
  // v4: the income-norm sectoral shares per year (the Chenery-Syrquin
  // attractor target) — for the "structure vs norm" overlay.
  structure_norm: { Year: number; primary: number; secondary: number; tertiary: number }[];
  // TED overlay: the model's own bottom-up WoM total energy demand. Present
  // (non-empty) only when the user pinned a projected TED; lets the UI plot the
  // user's energy-intensity path (TED/GDP) against the model's own.
  wom_ted?: { Year: number; TED: number }[];
  sgdp_primary_split: Record<string, number>[];
  heads: Record<string, number>[];
  derived: Record<string, number>[];
  parameter_log: {
    name: string;
    value: number;
    origin: "estimated" | "adjusted" | "calibrated";
    std_error?: number | null;
    note?: string | null;
  }[];
  validation_report: {
    test_id: string;
    severity: "red" | "amber" | "info";
    variable: string;
    message: string;
    has_proposed_fix: boolean;
    // G10 / G12 (UX audit): short plain-language fix sentence shown as a
    // distinct "What to do" line in the UI. Null when no action is offered.
    proposed_action?: string | null;
  }[];
  annalist_proxies: Record<string, Record<string, number>[]>;
  annalist_proxies_index: string[];
  economic_sectors?: string[];
  energy_sectors?: string[];
  // G4 (UX audit): per-series flag set to true when the user did not upload
  // historical data for that series. The result is a pure prior-based
  // extrapolation rather than a country-calibrated projection. The panels
  // render a warning badge so users do not unknowingly publish those series.
  // Keys: 'sed', 'sed_hh', 'heads', 'fuel_shares'.
  extrapolated_series?: Record<string, boolean>;
  // G2 (UX audit): projection boundary year (last historical year). Used
  // by the narrative summary to phrase "from <last_hist+1> to <horizon>".
  last_historical_year?: number | null;
  ref?: string;
}

// G11 (UX audit): payload from the WDI auto-fill endpoint.
export interface WdiSgdpResponse {
  sgdp: {
    year: number;
    primary: number;
    secondary: number;
    tertiary: number;
  }[];
  country_code: string;
  years_returned: number[];
  years_missing: number[];
  source: string;
}

export interface EnergyUploadResponse {
  ref: string;
  country_code: string;
  technologies: string[];
  n_pams: number;
  last_historical_year: number;
  horizon_year: number;
  demand_history_years: number[];
  demand_projection_years: number[];
}

export interface EnergyTechRow {
  name: string;
  capacity_mw: Record<string, number>;
  generation_gwh: Record<string, number>;
  emissions_kt: Record<string, number>;
  input_energy_tj: Record<string, number>;
  // CRT category this tech books under (default "1A1a"; "1A1c" autoproducers)
  ipcc_code?: string;
  // Legacy-mode displacement group: "zero" | "low_carbon" | "fossil"
  dispatch_group?: string | null;
}

export interface EnergyPAM {
  id?: string;                  // assigned on upload or create; missing on legacy artifacts
  scenario: string;             // "WM" | "WAM"
  technology: string;
  year: number;
  added_mw: number;
  name: string;
  notes: string;
}

export interface EnergyPAMInput {
  scenario: string;             // "WM" | "WAM"
  technology: string;
  year: number;
  added_mw: number;
  name?: string;
  notes?: string;
}

export interface EnergySystem {
  country_code: string;
  technologies: EnergyTechRow[];
  demand_history_gwh: Record<string, number>;
  import_gwh: Record<string, number>;
  export_gwh: Record<string, number>;
  demand_projection_gwh: Record<string, number>;
  pams: EnergyPAM[];
}

export interface EnergyDispatchYear {
  year: number;
  scenario: string;
  generation_gwh: Record<string, number>;
  emissions_kt: Record<string, number>;
  capacity_mw: Record<string, number>;
  unserved_gwh: number;
  total_emissions_kt: number;
  total_generation_gwh: number;
}

export interface EnergyCharacterisation {
  name: string;
  emission_factor_kt_per_gwh: number;
  capacity_factor: number;
  last_capacity_mw: number;
  merit_rank: number;
  // Legacy-mode frozen-at-base-year factors (faithful Excel rule)
  ef_frozen_kt_per_gwh?: number;
  gwh_per_mw_frozen?: number;
  dispatch_group?: string;
  ipcc_code?: string;
}

export interface EnergyValidationFlag {
  test_id: string;
  severity: "amber" | "info";
  variable: string;
  message: string;
  proposed_action?: string | null;
}

export interface EnergyResult {
  horizon_year: number;
  // "legacy_excel" (faithful workbook port, default) | "merit_dispatch"
  mode?: string;
  characterisation: EnergyCharacterisation[];
  dispatch: EnergyDispatchYear[];
  scenario_totals: Record<string, Record<string, number>>;
  // Per-IPCC-code totals: {code: {scenario: {year: kt}}} (1A1a + optional 1A1c)
  scenario_totals_by_code?: Record<string, Record<string, Record<string, number>>>;
  // Per-tech historical net generation (GWh) — feeds the SI-008 proxies
  historical_generation_gwh?: Record<string, Record<string, number>>;
  // Monte-Carlo bands (dissertation §2.6); null unless requested in the run
  uncertainty?: {
    iterations: number;
    seed: number;
    sampled: string[];
    bands: Record<string, Record<string, {
      median: number; p25: number; p75: number; min: number; max: number;
    }>>;
  } | null;
  merit_order?: string[];
  // E1-E8 plausibility flags (EF/CF sanity, unserved demand, stranded
  // capacity, mitigation direction, unknown tech, inoperative PAM,
  // demand-chain integrity). Empty array when the module ran clean.
  // Severity always 'amber' or 'info' — energy never fires red.
  validation_report?: EnergyValidationFlag[];
  ref?: string;
}

// ----- LULUCF module types (SI-004) -----

export type LulucfProfile = "L-A" | "L-B" | "L-C" | "L-D" | "L-E";
export type ClimateZone = "tropical" | "temperate" | "boreal";
export type CrtLandCategory = "4A" | "4B" | "4C" | "4D" | "4E" | "4F";
export type CrtCategory = CrtLandCategory | "4G";
export type LulucfGas = "CO2" | "CH4" | "N2O" | "CO2eq";

export interface LulucfRunRequest {
  // --- Configuration ---
  country: string;                // ISO3
  region: MacroRegion;
  horizon_year: number;
  climate_zone: ClimateZone;
  tier: 0 | 1 | 2;
  profile: LulucfProfile;
  cohort_year_step?: number;
  soc_dom_coupled?: boolean;
  pest_recovery_years?: number;
  monte_carlo_samples?: number;
  mc_seed?: number | null;
  touchup_enabled?: boolean;
  touchup_residual_threshold?: number;
  refdb_version?: string;
  inventory_vintage?: string | null;

  // --- Mandatory historical ---
  inventory_emissions: Array<Record<string, unknown>>;
  land_areas: Array<Record<string, unknown>>;

  // --- Optional historical / projected (engine column names) ---
  transition_matrix?: Array<Record<string, unknown>> | null;
  burned_area?: Array<Record<string, unknown>> | null;
  forest_stock?: Array<Record<string, unknown>> | null;
  forest_increment?: Array<Record<string, unknown>> | null;
  forest_cohort_areas?: Array<Record<string, unknown>> | null;
  harvest_volume?: Array<Record<string, unknown>> | null;
  hwp_historical?: Array<Record<string, unknown>> | null;
  organic_soil_area?: Array<Record<string, unknown>> | null;
  macro_heads?: Array<Record<string, unknown>> | null;
  macro_sgdp_primary?: Array<Record<string, unknown>> | null;
  n_fertilizer_applied?: Array<Record<string, unknown>> | null;
  lime_applied?: Array<Record<string, unknown>> | null;
  urea_applied?: Array<Record<string, unknown>> | null;
  rice_cultivated_area?: Array<Record<string, unknown>> | null;
  pest_area?: Array<Record<string, unknown>> | null;
  wind_throw_area?: Array<Record<string, unknown>> | null;

  proj_land_areas?: Array<Record<string, unknown>> | null;
  proj_transition_matrix?: Array<Record<string, unknown>> | null;
  proj_burned_area?: Array<Record<string, unknown>> | null;
  afforestation_schedule?: Array<Record<string, unknown>> | null;
  deforestation_path?: Array<Record<string, unknown>> | null;
  harvest_schedule?: Array<Record<string, unknown>> | null;
  rewetting_schedule?: Array<Record<string, unknown>> | null;
  national_efs?: Array<Record<string, unknown>> | null;
  full_inventory_projection?: Array<Record<string, unknown>> | null;
  proj_n_fertilizer?: Array<Record<string, unknown>> | null;
  proj_lime?: Array<Record<string, unknown>> | null;
  proj_urea?: Array<Record<string, unknown>> | null;
  proj_rice_area?: Array<Record<string, unknown>> | null;
  proj_organic_soil_area?: Array<Record<string, unknown>> | null;
  proj_pest_area?: Array<Record<string, unknown>> | null;
  proj_wind_throw_area?: Array<Record<string, unknown>> | null;

  sgdp_proj?: Array<Record<string, unknown>> | null;
  heads_proj?: Array<Record<string, unknown>> | null;
  harvest_proj?: Array<Record<string, unknown>> | null;

  product_split?: Record<string, number> | null;

  // --- Catalog-formula PAMs (WEM/WAM scenarios, DESIGN §2.4.2) ---
  pams?: PamSpec[] | null;
}

/**
 * A single user-instantiated catalog PAM. The formula is NOT sent — it is
 * re-resolved server-side from `catalog_id`. `variables` maps each formula
 * alias to the user's value (aliases omitted fall back to the catalog
 * default).
 */
export interface PamSpec {
  catalog_id: string;
  category: string;                  // CRT code (4A-4H, optional sub-code)
  scenario: "WEM" | "WAM";
  variables: Record<string, number>;
  time_distribution: "constant" | "variable";
  t0: number;
  t1?: number | null;
  t2?: number | null;
  cost_usd_per_ton?: number | null;
  id?: string | null;
  name?: string | null;
}

export interface LulucfParameter {
  name: string;
  value: number;
  origin: string;
  std_error: number | null;
  note: string | null;
}

export interface LulucfValidationFlag {
  test_id: string;
  severity: "red" | "amber" | "info";
  variable: string;
  message: string;
  has_proposed_fix: boolean;
  proposed_action: string | null;
}

export interface LulucfAreaRow {
  Year: number;
  Category: CrtLandCategory;
  Area_kha: number;
}

export interface LulucfEmissionRow {
  Year: number;
  Category: CrtCategory;
  Gas: LulucfGas;
  Emissions_kt: number;
  Emissions_CO2eq_kt: number;
}

export interface LulucfHwpRow {
  Year: number;
  ProductClass: string;
  Pool_ktC: number;
  Inflow_ktC: number;
  DecayOutflow_ktC: number;
}

export interface LulucfNetCo2eqRow {
  Year: number;
  Net_LULUCF_CO2eq_kt: number;
}

export interface LulucfScenarioEntry {
  name: string;
  size_bytes: number;
  modified_at: number;
}

export interface LulucfResult {
  // Identifiers + config echo
  country?: string;
  region?: string;
  horizon_year?: number;
  profile_used: LulucfProfile;
  tier_used: number;
  refdb_version_used: string;
  inventory_vintage_used: string | null;
  touchup_applied: boolean;

  // Outputs
  areas: LulucfAreaRow[];
  carbon_pools: Array<Record<string, unknown>>;
  emissions: LulucfEmissionRow[];
  transitions: Array<Record<string, unknown>>;
  hwp: LulucfHwpRow[];

  // Derived views
  net_co2eq_by_year: LulucfNetCo2eqRow[];
  total_hwp_by_year: Array<Record<string, unknown>>;

  // Calibration + diagnostics
  calibrated_thetas: Record<string, number>;
  mc_band: Array<Record<string, unknown>> | null;
  parameter_log: LulucfParameter[];
  validation_report: LulucfValidationFlag[];
  origin_labels: Record<string, Array<Record<string, unknown>> | null>;

  // G4-style flags: per-input field, true = user supplied no history
  extrapolated_inputs: Record<string, boolean>;

  // Catalog-formula PAM engine outputs (DESIGN §2.4.2). Present only when
  // the run was given PAMs; null for WoM-only runs.
  pam_mitigation: LulucfPamMitigationRow[] | null;
  scenario_net: LulucfScenarioNetRow[] | null;
  pam_summary: LulucfPamSummaryRow[] | null;

  // Counters for quick UI access
  n_red_flags: number;
  n_amber_flags: number;

  // Catalogue echo
  crt_categories?: CrtCategory[];
  crt_labels?: Record<string, string>;
  ref?: string;
  // G2 (UX audit): scenario slot echoed back from POST/GET
  scenario_name?: string;
}

export interface LulucfPamMitigationRow {
  Year: number;
  PamId: string;
  PamName: string;
  Category: CrtCategory;
  Scenario: "WEM" | "WAM";
  Mitigation_CO2eq_kt: number;
}

export interface LulucfScenarioNetRow {
  Year: number;
  Category: CrtCategory;
  Scenario: "WoM" | "WEM" | "WAM";
  Net_CO2eq_kt: number;
}

export interface LulucfPamSummaryRow {
  PamId: string;
  PamName: string;
  Category: CrtCategory;
  Scenario: "WEM" | "WAM";
  Total_Mitigation_CO2eq_kt: number;
  CumulativeShare: number;
}

// ----- LULUCF PAM catalog (DESIGN §2.4.2) -----

export interface PamCatalogVariable {
  alias: string;
  name: string;
  unit: string | null;
  default: number | null;
}

export interface PamCatalogEntry {
  catalog_id: string;
  name: string;
  categories: string[];
  formula: string;
  variables: PamCatalogVariable[];
}

export interface LulucfPamCatalog {
  subsectors: Record<string, PamCatalogEntry[]>;
  n_pams: number;
  crt_labels: Record<string, string>;
}

export interface LulucfCountryEntry {
  iso3: string;
  name: string;
  region: MacroRegion | null;
  climate_zone: ClimateZone | null;
  mat_celsius: number | null;
  // G5 (UX audit): refDB-derived activity baselines for auto-fill.
  total_area_kha: number | null;
  forest_area_kha_latest: number | null;
  burned_area_kha_mean: number | null;
  organic_soil_area_kha: number | null;
  wood_removals_m3_per_year: number | null;
}

export interface LulucfRefDbMetadata {
  version: string | null;
  sealed_at: string | null;
  sources: string[];
}

export interface LulucfFormsCatalog {
  crt_land_categories: CrtLandCategory[];
  crt_hwp_code: "4G";
  crt_labels: Record<string, string>;
  profiles: LulucfProfile[];
  profile_descriptions: Record<LulucfProfile, string>;
  tiers: number[];
  climate_zones: ClimateZone[];
  hwp_product_classes: string[];
  hwp_half_lives_years: Record<string, number>;
  default_refdb_version: string;
  default_horizon_year: number;
  default_touchup_threshold: number;
  // G14 (UX audit): list of refDB-populated countries with their
  // climate_zone + region so the frontend can auto-derive on select.
  countries: LulucfCountryEntry[];
  refdb_metadata: LulucfRefDbMetadata;
}

// ----- F-gases module types (SI-005, CRT 2F) -----

export type FGasesScenario = "BaU" | "WEM" | "WAM";
export type FGasesKigaliGroup =
  | "non_article_5"
  | "article_5_group_1"
  | "article_5_group_2";

// Nested ϕ table: {subsector: {gas: {year: fraction}}}. Year keys are
// stringified because they round-trip through JSON.
export type FGasesPhiTable = Record<
  string,
  Record<string, Record<string, number>>
>;

export interface FGasesSubsectorRow {
  name: string;
  sales_units: Record<string, number>;
  stock_units: Record<string, number>;
  initial_charge_kg: number;
  lifetime_years: number;
  recovery_rate: number;
}

export interface FGasesSystem {
  country_code: string;
  subsectors: FGasesSubsectorRow[];
  refrigerant_distribution: FGasesPhiTable;
  emission_factors: Record<string, Record<string, [number, number, number]>>;
}

export interface FGasesProjectedInputs {
  sales_projected?: Record<string, Record<string, number>>;
  // Either {sub: {gas: {year: frac}}} (legacy, applies to all scenarios)
  // OR {scenario: {sub: {gas: {year: frac}}}} (per-scenario gating).
  refrigerant_distribution_projected?:
    | FGasesPhiTable
    | Record<FGasesScenario, FGasesPhiTable>;
}

export interface FGasesUploadResponse {
  system_ref: string;
  projected_ref: string;
  country_code: string;
  subsectors: string[];
  n_subsectors: number;
  last_historical_year: number;
  kigali_group_inferred: FGasesKigaliGroup;
  has_projected_overrides: boolean;
}

export interface FGasesRunRequest {
  horizon_year?: number;
  scenarios?: FGasesScenario[];
  gwp_version?: "AR4" | "AR5" | "AR6";
  apply_kigali_default?: boolean;
  kigali_group?: FGasesKigaliGroup | null;
  // Inline overrides — if provided, bypass the stored system/projected.
  system?: FGasesSystem | null;
  projected?: FGasesProjectedInputs | null;
}

export interface FGasesValidationFlag {
  test_id: string;          // "F1" | "F2" | "F4" | "F5"
  severity: "amber" | "info";
  variable: string;
  message: string;
  proposed_action?: string | null;
}

export interface FGasesEmissionRow {
  year: number;
  scenario: FGasesScenario;
  kg_of_gas: Record<string, number>;        // key: "sub|gas"
  kt_co2eq: Record<string, number>;         // key: "sub|gas"
  total_kt_co2eq: number;
  activity_kg?: Record<string, number>;     // key: "stream|sub|gas"
}

export interface FGasesResult {
  emissions: FGasesEmissionRow[];
  // {scenario: {year_string: total kt CO2-eq}}
  scenario_totals: Record<FGasesScenario, Record<string, number>>;
  // {scenario: {CRT_code: {year_string: kt CO2-eq}}}
  crt_totals: Record<FGasesScenario, Record<string, Record<string, number>>>;
  horizon_year: number;
  gwp_used: Record<string, number>;
  scenarios: FGasesScenario[];
  years: number[];
  subsector_to_crt: Record<string, string>;
  validation_report: FGasesValidationFlag[];
  n_amber_flags: number;
  n_info_flags: number;
  country_code?: string | null;
  subsector_names?: string[] | null;
  kigali_group_used?: FGasesKigaliGroup;
  apply_kigali_default?: boolean;
  ref?: string;
}

export interface FGasesFormsCatalog {
  subsectors: string[];
  gases: string[];
  scenarios: FGasesScenario[];
  subsector_to_crt: Record<string, string>;
  crt_codes: string[];
  kigali_groups: Record<FGasesKigaliGroup, string>;
  kigali_schedule: Record<FGasesKigaliGroup, Record<string, number>>;
  country_kigali_group: Record<string, FGasesKigaliGroup>;
  default_initial_charge_kg: Record<string, number>;
  default_lifetime_years: Record<string, number>;
  default_k_stock: Record<string, number>;
  default_recovery_rate: Record<string, number>;
  ic_band_kg: Record<string, [number, number]>;
  k_stock_band: Record<string, [number, number]>;
  gwp_versions: string[];
  default_gwp_version: string;
  gwp100_ar4: Record<string, number>;
  default_horizon_year: number;
}

// ----- Transport module types (SI-006, CRT 1A3b) -----

// Road transport scenarios mirror the core naming (WoM baseline + WEM/WAM
// mini-scenarios computed on the module physics).
export type TransportScenario = "WoM" | "WEM" | "WAM";

// The 5 PAM levers the module understands (ASIF operations on the cohort fleet).
export type TransportLever =
  | "ev_sales_push"
  | "fleet_renewal"
  | "biofuel_blend"
  | "modal_shift"
  | "direct_reduction";

// Fleet segments ↔ CRT 1A3b sub-codes (i cars, ii light freight,
// iii heavy freight + buses, iv two/three-wheelers).
export type TransportSegment =
  | "passenger_cars"
  | "freight_light"
  | "freight_heavy_bus"
  | "two_three_wheelers";

export interface TransportPAM {
  id?: string;
  name: string;
  scenario: "WEM" | "WAM";
  lever: TransportLever;
  // Optional for most levers; required for ev_sales_push.
  segment?: TransportSegment | null;
  start_year: number;
  target_year?: number | null;
  // Lever-specific parameters — only the ones relevant to `lever` are sent.
  ev_target_sales_share?: number | null;
  efficiency_gain_pct?: number | null;
  affected_fleet_share?: number | null;
  bio_share?: number | null;
  // The backend echoes null when unset, so accept it on reads.
  bio_ef_ratio?: number | null;
  activity_reduction_pct?: number | null;
  // direct_reduction: explicit kt CO2-eq series {year_string: kt}.
  annual_kt?: Record<string, number> | null;
}

export interface TransportRunRequest {
  horizon_year?: number;
  // default ["WoM","WEM","WAM"]
  scenarios?: string[];
  // Development-phase group override; omitted = the project's income group
  // (World Bank classification), else auto from GDP-pc (currency-sensitive).
  dev_group?: MacroDevGroup;
}

export interface TransportValidationFlag {
  test_id: string;           // "TR-01".."TR-04"
  severity: "amber" | "info";
  variable: string;
  message: string;
  proposed_action?: string | null;
}

export interface TransportResult {
  horizon_year: number;
  dev_group: string;
  // Resolution cascade = the IPCC tier ladder (T1 fuel×EF → T3 distance).
  tier: "T1" | "T2" | "T3";
  resolution_log: Record<string, string>;
  // {scenario: {year_string: kt CO2-eq}}
  scenario_totals: Record<string, Record<string, number>>;
  // {scenario: {CRT_code: {year_string: kt}}} (1A3bi–iv)
  scenario_totals_by_code: Record<string, Record<string, Record<string, number>>>;
  // {scenario: {segment: {year_string: kt}}}
  by_segment: Record<string, Record<string, Record<string, number>>>;
  // {scenario: {pam_name: {year_string: kt mitigated}}}
  pam_mitigation: Record<string, Record<string, Record<string, number>>>;
  validation_report: TransportValidationFlag[];
  pams: TransportPAM[];
  ref?: string;
}

// ----- Waste module types (SI-007, CRT 5A-5D) -----

export type WasteScenario = "WoM" | "WEM" | "WAM";

// The 5 PAM levers the module understands (operations on the FOD / MCF physics).
export type WasteLever =
  | "diversion"
  | "gas_recovery"
  | "composting_shift"
  | "ww_treatment_upgrade"
  | "direct_reduction";

// IPCC waste categories (CRT codes).
export type WasteCategory = "5A" | "5B" | "5C" | "5D";

// Bulk-MSW decay-rate climate zones (IPCC 2006 Vol.5 Table 3.3, collapsed).
export type WasteClimateZone =
  | "boreal_dry"
  | "temperate_wet"
  | "tropical_dry"
  | "tropical_wet";

// Wastewater treatment systems → MCF (IPCC 2006 Vol.5 Table 6.3).
export type WasteWWSystem =
  | "none_sea"
  | "septic"
  | "latrine"
  | "anaerobic"
  | "aerobic";

export interface WastePAM {
  id?: string;
  name: string;
  scenario: "WEM" | "WAM";
  lever: WasteLever;
  start_year: number;
  target_year?: number | null;
  // Lever-specific parameters — only the ones relevant to `lever` are sent.
  diversion_frac?: number | null;       // diversion: % of future deposition
  recovery_target?: number | null;      // gas_recovery: target R (% of generated CH4)
  composting_frac?: number | null;      // composting_shift: % of deposition → 5B
  ww_target_system?: WasteWWSystem | null; // ww_treatment_upgrade target
  ww_share_shifted?: number | null;     // ww_treatment_upgrade: pop share moved
  // direct_reduction: explicit kt CO2-eq series {year_string: kt}.
  annual_kt?: Record<string, number> | null;
  category?: WasteCategory | null;      // direct_reduction target (null → 5A)
}

export interface WasteRunRequest {
  horizon_year?: number;
  // default ["WoM","WEM","WAM"]
  scenarios?: string[];
  // Decay-rate climate zone; omitted = temperate_wet default.
  climate_zone?: WasteClimateZone;
  // WB income-class override; omitted = the project's income group
  // (World Bank classification), else auto from GDP-pc (currency-sensitive).
  income_group?: MacroDevGroup;
}

export interface WasteValidationFlag {
  test_id: string;           // "WS-01".."WS-05"
  severity: "amber" | "info";
  variable: string;
  message: string;
  proposed_action?: string | null;
}

export interface WasteResult {
  horizon_year: number;
  income_group: string;
  climate_zone: string;
  // Resolution cascade = the IPCC tier ladder (T1 prior → T3 own enrichments).
  tier: "T1" | "T2" | "T3";
  resolution_log: Record<string, string>;
  // {scenario: {year_string: kt CO2-eq}}
  scenario_totals: Record<string, Record<string, number>>;
  // {CRT_code: {scenario: {year_string: kt}}} (5A-5D)
  scenario_totals_by_code: Record<string, Record<string, Record<string, number>>>;
  // {scenario: {category: {year_string: kt}}}
  by_category: Record<string, Record<string, Record<string, number>>>;
  // {scenario: {gas: {year_string: kt}}}
  by_gas: Record<string, Record<string, Record<string, number>>>;
  // {scenario: {pam_name: {year_string: kt mitigated}}}
  pam_mitigation: Record<string, Record<string, Record<string, number>>>;
  // {pam_name: category} — the category each PAM's lever acts on.
  pam_categories: Record<string, string>;
  validation_report: WasteValidationFlag[];
  pams: WastePAM[];
  ref?: string;
}

export { ApiError };
