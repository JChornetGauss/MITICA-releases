"use client";

import Link from "next/link";
import {
  ArrowUpRight,
  Activity,
  Factory,
  GitMerge,
  Zap,
  Leaf,
  Snowflake,
  Car,
  Recycle,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ModuleCard } from "@/components/mitica/ModuleCard";
import { FlowDiagram } from "@/components/mitica/FlowDiagram";

export default function HomePage() {
  return (
    <TooltipProvider delayDuration={120}>
      {/* ─────────────── Hero ─────────────── */}
      <section className="relative overflow-hidden">
        <div
          aria-hidden
          className="absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(ellipse_at_top,hsl(174_55%_85%/0.35),transparent_60%)]"
        />
        <div
          aria-hidden
          className="absolute right-0 top-40 h-[340px] w-[340px] rounded-full bg-[radial-gradient(circle,hsl(28_48%_82%/0.4),transparent_70%)] blur-2xl"
        />

        <div className="relative mx-auto max-w-7xl px-5 pb-16 pt-16 md:pt-28">
          <div className="mb-10 flex items-center gap-3">
            <span className="h-px w-10 bg-foreground/30" />
            <span className="eyebrow">Climate scenarios · Paris Agreement ETF</span>
          </div>

          <h1 className="mb-10 max-w-4xl font-serif text-display-lg font-[430] text-foreground md:text-display-xl">
            A modular ecosystem for building{" "}
            <em className="font-[470] text-primary">consistent</em>{" "}
            GHG mitigation scenarios.
          </h1>

          <div className="grid gap-10 md:grid-cols-[1.4fr_1fr]">
            <p className="max-w-2xl text-lg leading-relaxed text-foreground/75">
              Three building blocks. Activate as many as your data allows — results flow into the
              Integration Module, where you draw the WoM / WEM / WAM storyline, apply PAMs,
              compare against targets, and export CRT-ready tables for your BTR submission.
            </p>
            <div className="flex flex-col items-start gap-3">
              <Link
                href="/projects"
                className="group inline-flex items-center gap-2 rounded-sm bg-foreground px-5 py-3 text-sm font-medium text-background transition-transform hover:-translate-y-0.5"
              >
                Open Integration Module
                <ArrowUpRight className="h-4 w-4 transition-transform group-hover:rotate-12" />
              </Link>
              <a
                href="/api/v1/docs"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-1.5 text-sm text-foreground/70 transition-colors hover:text-foreground"
              >
                Read API documentation{" "}
                <ArrowUpRight className="h-3.5 w-3.5 opacity-60 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>
          </div>
        </div>

        <div className="hairline" />
      </section>

      {/* ─────────────── Module cards ─────────────── */}
      <section className="mx-auto max-w-7xl px-5 py-24">
        <div className="mb-14 grid items-end gap-8 md:grid-cols-[1fr_auto]">
          <div>
            <div className="mb-3 flex items-center gap-3">
              <span className="h-px w-10 bg-foreground/30" />
              <span className="eyebrow">01 — 03 · Building blocks</span>
            </div>
            <h2 className="max-w-2xl font-serif text-display-lg font-[440] tracking-tight">
              Three modules,{" "}
              <em className="font-[470]">one</em> integrated story.
            </h2>
          </div>
          <div className="max-w-sm text-sm leading-relaxed text-foreground/70">
            Each card carries a <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-[11px]">Hover&nbsp;for&nbsp;details</span> prompt —
            hover to see methodology, inputs, outputs, and where the module sits in the MITICA architecture.
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <ModuleCard
            number="01"
            icon={<Activity className="h-7 w-7" />}
            title="Macro"
            serifTitle="economic"
            subtitle="SI-002 · Coherent macro & activity proxies"
            description="Produces consistent GDP, population, sectoral GDP and sectoral energy-demand projections — the drivers that ANNALIST and the sectoral modules consume. Three user flows adapt to the amount of projected data you already have."
            href="/modules/macro"
            status="beta"
            accentColor="indigo"
            ctaLabel="Learn more"
            tooltip={
              <div className="space-y-2">
                <p className="font-serif text-sm font-medium">
                  Macroeconomic module <span className="italic">· g_Macro · SI-002</span>
                </p>
                <p className="leading-relaxed">
                  Three-layer semi-structured model: <strong>Layer A</strong> accounting
                  identities (hard), <strong>Layer B</strong> behavioural equations (Bayesian
                  shrinkage toward regional priors), <strong>Layer C</strong> validation with
                  traffic-light tests and touch-up mode.
                </p>
                <p className="leading-relaxed">
                  <span className="font-medium">Inputs</span> — historical GDP, population,
                  sectoral GDP, energy balance, livestock heads · optionally, aspirational
                  projected paths.
                </p>
                <p className="leading-relaxed">
                  <span className="font-medium">Outputs</span> — Year-indexed frames for each
                  ANNALIST proxy: GDP_tot, SGDP_&#123;primary,secondary,tertiary&#125;,
                  SED_&lt;sector&gt;, Heads, GDP_per_cap.
                </p>
                <p className="leading-relaxed">
                  <span className="font-medium">Regions</span> — LAC · SSA · MENA · APAC · EEU ·
                  HIC. Priors are plausible placeholders pending offline panel training on
                  WDI&nbsp;/&nbsp;PWT&nbsp;/&nbsp;FAOSTAT.
                </p>
              </div>
            }
          />

          <ModuleCard
            number="02"
            icon={<Factory className="h-7 w-7" />}
            title="Sectoral"
            subtitle="SI-003 to SI-007 · Tier-2+ physics per sector"
            description="Physics-based bottom-up models for each IPCC sector. Each produces its own WoM baseline plus PAMs, and hands results to the Integration Module. Activate only the sectors you have data for."
            href="/modules/sectoral"
            status="beta"
            accentColor="amber"
            ctaLabel="See sectors"
            tooltip={
              <div className="space-y-2">
                <p className="font-serif text-sm font-medium">Sectoral modules</p>
                <p className="leading-relaxed">
                  Each sector has its own WoM methodology, far beyond IPCC Tier 1. Activating a
                  module replaces ANNALIST for the affected IPCC codes with a bottom-up
                  projection; unaffected codes keep using ANNALIST as before.
                </p>
                <ul className="ml-3 space-y-0.5 text-[11px]">
                  <li>
                    — <strong>Energy industries (SI-003)</strong> · merit-order dispatch of public
                    electricity + heat generation (IPCC 1A1 only)
                  </li>
                  <li>
                    — <strong>F-gases (SI-005)</strong> · bank-based per-equipment, Kigali-aware
                  </li>
                  <li>
                    — <strong>LULUCF (SI-004)</strong> · CBM-simplified C-stock dynamics
                  </li>
                  <li>
                    — <strong>Transport (SI-006)</strong> · COPERT-simplified fleet turnover
                  </li>
                  <li>
                    — <strong>Waste (SI-007)</strong> · IPCC FOD landfill model
                  </li>
                </ul>
              </div>
            }
          />

          <ModuleCard
            number="03"
            icon={<GitMerge className="h-7 w-7" />}
            title="Integration"
            serifTitle="— Mitica v1.0"
            subtitle="The evolved core — works on its own"
            description="The heart of MITICA: upload inventory, run ANNALIST, validate per category, define PAMs from a 93-entry catalog, build WEM / WAM scenarios, set targets, export CRT tables. Falls back to ANNALIST when no optional module is active."
            href="/projects"
            status="ready"
            accentColor="teal"
            primary
            ctaLabel="Open projects"
            tooltip={
              <div className="space-y-2">
                <p className="font-serif text-sm font-medium">
                  Integration Module <span className="italic">— Mitica v1.0</span>
                </p>
                <p className="leading-relaxed">
                  Evolution of the previous desktop MITICA. Per-gas forecasting with{" "}
                  <span className="italic">Σ(gas × GWP) = CO₂-eq</span> constraint (BI-001), IPCC
                  CRT JSON ingest (BI-002), NDC-style targets (BI-003), CRT Excel export
                  (BI-004), reference-year backtest, per-category validation workflow, PAM
                  catalog with safe formula evaluation.
                </p>
                <p className="leading-relaxed">
                  <span className="font-medium">Route</span> — 7-step wizard per project:
                  Upload&nbsp;· Forecast · Validate · PAMs · Scenarios · Targets · Dashboard.
                </p>
                <p className="text-[11px] italic leading-relaxed text-muted-foreground">
                  If you don't activate any optional module, this is the full tool — equivalent
                  to the previous MITICA plus gases, targets, catalog and export improvements.
                </p>
              </div>
            }
          />
        </div>
      </section>

      {/* ─────────────── Flow diagram ─────────────── */}
      <section className="relative border-y border-border/60 bg-muted/30">
        <div className="mx-auto max-w-7xl px-5 py-20">
          <div className="mb-12 max-w-2xl">
            <div className="mb-3 flex items-center gap-3">
              <span className="h-px w-10 bg-foreground/30" />
              <span className="eyebrow">How they fit</span>
            </div>
            <h2 className="mb-4 font-serif text-display-lg font-[440] tracking-tight">
              The Integration Module is{" "}
              <em className="font-[470]">always</em> required. The rest is optional.
            </h2>
            <p className="text-[15px] leading-relaxed text-foreground/75">
              Activate Macro when you want coherence-by-design in your proxies. Activate a
              sectoral module when you have a per-sector bottom-up story to tell. A country can
              start with just Integration, then add modules as its data matures — no rework.
            </p>
          </div>
          <FlowDiagram />
        </div>
      </section>

      {/* ─────────────── Sectoral strip ─────────────── */}
      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="mb-10 flex items-end justify-between gap-4">
          <div>
            <div className="mb-3 flex items-center gap-3">
              <span className="h-px w-10 bg-foreground/30" />
              <span className="eyebrow">Sectoral modules · at a glance</span>
            </div>
            <h2 className="max-w-xl font-serif text-3xl font-[440] tracking-tight md:text-4xl">
              Five sectors, <em className="italic">stackable</em>.
            </h2>
          </div>
          <Link
            href="/modules/sectoral"
            className="group inline-flex items-center gap-1.5 self-end text-sm text-foreground/70 hover:text-foreground"
          >
            Browse all
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </div>

        <div className="grid gap-px overflow-hidden rounded-sm border border-border/80 bg-border/80 md:grid-cols-5">
          <SectorChip icon={<Zap className="h-4 w-4" />} title="Energy industries" code="SI-003" status="beta" />
          <SectorChip
            icon={<Snowflake className="h-4 w-4" />}
            title="F-gases"
            code="SI-005"
            status="beta"
          />
          <SectorChip
            icon={<Leaf className="h-4 w-4" />}
            title="LULUCF"
            code="SI-004"
            status="planned"
          />
          <SectorChip
            icon={<Car className="h-4 w-4" />}
            title="Transport"
            code="SI-006"
            status="planned"
          />
          <SectorChip
            icon={<Recycle className="h-4 w-4" />}
            title="Waste"
            code="SI-007"
            status="planned"
          />
        </div>
      </section>

      {/* ─────────────── Closing strip ─────────────── */}
      <section className="border-t border-border/60 bg-secondary text-secondary-foreground">
        <div className="mx-auto max-w-7xl px-5 py-20">
          <div className="grid items-start gap-10 md:grid-cols-[1.3fr_1fr]">
            <div>
              <div className="mb-3 flex items-center gap-3">
                <span className="h-px w-10 bg-white/40" />
                <span className="font-mono text-[11px] uppercase tracking-[0.15em] text-white/70">
                  Ready to start
                </span>
              </div>
              <h2 className="mb-6 font-serif text-display-lg font-[440] tracking-tight">
                Open the Integration Module and{" "}
                <em className="italic">start a country project.</em>
              </h2>
              <p className="max-w-xl text-[15px] leading-relaxed text-white/75">
                Everything else — macro, sectoral — slots in later when you have the data for
                it. The wizard takes you Upload → Forecast → Validate → PAMs → Scenarios →
                Targets → Dashboard in a single coherent flow.
              </p>
            </div>
            <div className="flex flex-col gap-4">
              <Link
                href="/projects"
                className="group inline-flex items-center justify-between gap-3 rounded-sm bg-primary px-5 py-4 font-medium text-primary-foreground transition-transform hover:-translate-y-0.5"
              >
                <span>Open Integration Module</span>
                <ArrowUpRight className="h-5 w-5 transition-transform group-hover:rotate-12" />
              </Link>
              <Link
                href="/modules/macro"
                className="group inline-flex items-center justify-between gap-3 rounded-sm border border-white/20 bg-transparent px-5 py-4 text-sm font-medium text-white/90 transition-colors hover:border-white/40 hover:text-white"
              >
                <span>Read about the Macro module</span>
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </TooltipProvider>
  );
}

function SectorChip({
  icon,
  title,
  code,
  status,
}: {
  icon: React.ReactNode;
  title: string;
  code: string;
  status: "ready" | "beta" | "planned";
}) {
  const label = status === "ready" ? "Ready" : status === "beta" ? "Beta" : "Planned";
  const dot =
    status === "ready"
      ? "bg-primary"
      : status === "beta"
      ? "bg-amber-600"
      : "bg-muted-foreground/40";
  return (
    <div className="group flex cursor-default flex-col gap-3 bg-card p-5 transition-colors hover:bg-card/70">
      <div className="flex items-center justify-between">
        <span className="text-primary">{icon}</span>
        <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      </div>
      <div>
        <div className="font-serif text-lg font-[450] tracking-tight">{title}</div>
        <div className="mt-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          {code} · {label}
        </div>
      </div>
    </div>
  );
}
