"""Informe técnico español - Parte III: Validación, Sensibilidades,
Implicaciones, Limitaciones, Discusión y apéndices (secciones 7-11 + A-D)."""

from __future__ import annotations

from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, Spacer, PageBreak

from report_common import header_table, fmt_num, fmt_pct, fmt_int


def P(s, sty):
    return Paragraph(s, sty)


def content_part3(S, data):
    out = []

    # 7. VALIDACIÓN EMPÍRICA
    out.append(P("7.&nbsp;&nbsp; Validación empírica", S["H1"]))

    out.append(P("7.1&nbsp; Recovery Monte Carlo", S["H2"]))
    out.append(P("Antes de exponer el estimador a datos reales corremos "
                  "una prueba Monte Carlo de recovery de 200 réplicas. "
                  "El proceso generador es exactamente el modelo log-log "
                  "B2 con coeficientes conocidos. El estimador se corre "
                  "a shrinkage &lambda; &isin; {0, 0,5, 0,9}. Tres "
                  "escenarios:", S["BODY"]))
    out.append(P("&bull; <b>Ideal</b>: n = 25 años por país, &sigma; "
                  "ruido = 0,02, sin colinealidad.", S["BULLET"]))
    out.append(P("&bull; <b>Series cortas</b>: n = 10 años.", S["BULLET"]))
    out.append(P("&bull; <b>Multicolinealidad alta</b>: SInv y GFCF_pub "
                  "con &rho; = 0,85.", S["BULLET"]))
    out.append(header_table([
        ["Métrica",            "Ideal",       "Cortas",      "Multicolineal"],
        ["Sesgo |E[θ - θ*]|",  "&lt; 0,02",   "&lt; 0,05",   "&lt; 0,03"],
        ["RMSE",               "0,05-0,10",   "0,10-0,20",   "0,10-0,20"],
        ["Cobertura IC 95%",   "92-100%",     "92-99%",      "94-100%"],
        ["Acierto de signo",   "&ge; 99%",    "&ge; 92%",    "&ge; 95%"],
    ], col_widths=[4*cm, 4*cm, 3.5*cm, 4*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("El Monte Carlo fue el diagnóstico que descubrió el "
                  "bug v1.1s en la varianza posterior: bajo la fórmula "
                  "rota los IC del 95% tenían 0% de cobertura a "
                  "&lambda; = 0,9. La fórmula corregida restaura la "
                  "cobertura nominal.", S["BODY"]))

    out.append(P("7.2&nbsp; Backtest UE-27 para B2", S["H2"]))
    out.append(P("Backtest fuera de muestra. Ventana de entrenamiento "
                  "1995-2005 (11 años); ventana de test 2006-2024 (19 "
                  "años). El módulo se ajusta solo en entrenamiento. En "
                  "el test el modelo recibe las trayectorias reales de "
                  "drivers (Pop, SInv, iRate) como inputs proyectados "
                  "F2, de modo que cualquier error en SGDP_s proyectado "
                  "es atribuible a (i) sesgo del estimador, (ii) "
                  "misspecification de la forma funcional, o (iii) "
                  "cambio de régimen fuera de la distribución de "
                  "entrenamiento. La tercera fuente domina los "
                  "residuos.", S["BODY"]))
    out.append(P("Descomposición por sub-pool a &lambda; = 0,5:",
                  S["BODY"]))
    out.append(header_table([
        ["Sub-pool", "n", "Forma", "MAPE Prim", "MAPE Sec",
         "MAPE Ter", "Prom"],
        ["HIC mature", "15", "LL",  "11,87", "16,26", "5,14", "11,09"],
        ["HIC mature", "15", "KC",  "12,06", "18,86", "6,05", "12,32"],
        ["HIC mature", "15", "KCQ", "12,75", "16,62", "5,42", "11,60"],
        ["HIC_TRANS",  "10", "LL",  "16,96", "19,91", "17,31", "18,06"],
        ["HIC_TRANS",  "10", "KC",  "16,58", "14,20", "19,22", "16,67"],
        ["HIC_TRANS",  "10", "KCQ", "14,67", "30,79", "23,83", "23,10"],
    ], col_widths=[2.7*cm, 0.8*cm, 1.3*cm, 2.5*cm, 2.5*cm, 2.5*cm, 1.7*cm],
       highlight_cells=[(1, 6)]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("La configuración recomendada para HIC maduro es la "
                  "forma log-log con &zeta; calibrada (MAPE mediano "
                  "5,14% en terciario). Las alternativas estructurales "
                  "(KC, KCQ) producen MAPE terciario <i>peor</i> "
                  "porque el &kappa;_tertiary calibrado en forma de "
                  "nivel es +2,22 &mdash; suficientemente grande para "
                  "que aun con std = 0,50 el ajuste país no pueda "
                  "anularlo, y la proyección resultante sobre-dispara.",
                  S["BODY"]))
    out.append(P("T8 de la Capa C dispara para 10 de los 25 países, "
                  "identificando correctamente los episodios "
                  "documentados de boom-bust: Chipre (colapso del "
                  "sector financiero 2013), Letonia (rescate FMI "
                  "2009), España (burbuja inmobiliaria 2008), Polonia "
                  "(crecimiento post-adhesión UE), Irlanda (Tigre "
                  "Celta), Hungría, Eslovenia, Bulgaria, Lituania, "
                  "Dinamarca. Los 15 países silenciosos son las "
                  "economías OCDE maduras estables.", S["BODY"]))

    out.append(P("7.3&nbsp; Backtest UE-29 para demanda energética "
                  "B5 / B6", S["H2"]))
    out.append(P("Mismas ventanas. Los agregados Eurostat se comparan "
                  "contra las salidas del módulo. MAPE mediano % a "
                  "&lambda; = 0,5:", S["BODY"]))
    out.append(header_table([
        ["Sector",         "HIC LL", "HIC IC", "HIC_TRANS LL",
         "HIC_TRANS IC"],
        ["Primary",        "27,74",  "27,69",  "28,39", "29,30"],
        ["Manufacturing",  "27,42",  "22,57",  "28,88", "23,63"],
        ["Services",       "13,36",  "17,37",  "30,98", "34,88"],
        ["Transport",      "14,40",  "15,47",  "15,56", "14,15"],
        ["Households (B6)","9,68",   "9,68",   "11,26", "11,26"],
    ], col_widths=[3.5*cm, 2.6*cm, 2.6*cm, 3*cm, 2.6*cm],
       highlight_cells=[(2, 2), (2, 4), (4, 4)]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("Resultado titular: <b>la forma de convergencia de "
                  "intensidad reduce el MAPE de energía manufacturera "
                  "en 4,8 puntos porcentuales en HIC maduro y en 5,3 "
                  "puntos en HIC_TRANS</b>. El &psi;_manuf = "
                  "&minus;1,23 calibrado en HIC se traduce en un "
                  "desacoplamiento estructural que la especificación "
                  "log-log legacy no podía capturar. Transporte en "
                  "HIC_TRANS también gana con IC (-1,4 pp).",
                  S["BODY"]))

    out.append(P("7.4&nbsp; Hipótesis testadas en el sprint",
                  S["H2"]))
    out.append(header_table([
        ["Hipótesis", "Resultado"],
        ["Corregir el bug de varianza posterior bayesiana es necesario",
         "CONFIRMADA — los IC v1.1s tenían 0% de cobertura a shrinkage alta."],
        ["La regla de no-síntesis mejora la identificación",
         "CONFIRMADA — coeficientes espuriamente confiables eliminados."],
        ["KC cuadrático captura la joroba Kuznets en secundario",
         "CONFIRMADA — con priors estilizados MAPE 12,6 vs 14,1 (LL)."],
        ["La estratificación HIC revela sub-pools distintas",
         "CONFIRMADA — signo de &kappa;_sec discrepa entre HIC y HIC_TRANS."],
        ["La calibración level-form joint elimina el mismatch share/level",
         "CONFIRMADA — LL con &zeta; calibrado es lo mejor para HIC terciario."],
        ["La estratificación sub-periodo de servicios mejora el MAPE SED",
         "RECHAZADA — restringir a post-2000 empeoró el backtest SED."],
        ["La forma de convergencia de intensidad ayuda a manufactura",
         "CONFIRMADA — &minus;4,8 pp MAPE en HIC, &minus;5,3 pp en HIC_TRANS."],
        ["Bennett logístico recupera (a_B, b_B) sobre datos sintéticos",
         "CONFIRMADA — dentro de tolerancia 0,30 / 0,10 en n=28."],
        ["T8 dispara en episodios boom-bust documentados",
         "CONFIRMADA — 10 de 25 países UE marcados; todos coinciden con literatura."],
    ], col_widths=[8*cm, 8.5*cm]))

    out.append(PageBreak())

    # 8. EJEMPLOS NUMÉRICOS
    out.append(P("8.&nbsp;&nbsp; Ejemplos numéricos de sensibilidad",
                  S["H1"]))
    out.append(P("Tres escenarios operativos ilustran las "
                  "implicaciones cuantitativas de las elecciones "
                  "metodológicas.", S["BODY"]))

    sens = data.get("sensitivities", {})

    s1 = sens.get("sensitivity_1_spain_gdp_growth", {})
    out.append(P("8.1&nbsp; Sensibilidad 1 &mdash; España, trayectoria "
                  "de crecimiento del PIB", S["H2"]))
    out.append(P("<b>Setup.</b> España en flujo F2: el usuario aporta "
                  "una trayectoria de GDP_tot creciendo al 2% o al 3% "
                  "anual desde 2024 hasta 2050, manteniendo la "
                  "población constante al nivel 2023. Los drivers "
                  "(SInv, iRate) están ausentes para el futuro; el "
                  "modelo rellena la composición sectorial desde el "
                  "estimador B2 con forma log-log y &lambda; = 0,5.",
                  S["BODY"]))
    sc_lo = (s1.get("scenarios") or {}).get("GDP_g_2pct", {})
    sc_hi = (s1.get("scenarios") or {}).get("GDP_g_3pct", {})
    diff = s1.get("diff_endpoint_pct", {})
    if sc_lo and sc_hi:
        out.append(P("<b>Valores en el horizonte 2050:</b>", S["BODY"]))
        out.append(header_table([
            ["Variable", "2% crec. (M EUR)", "3% crec. (M EUR)",
             "Δ (3% - 2%)", "Δ %"],
            ["SGDP_primary",
             fmt_int(sc_lo.get("SGDP_primary")),
             fmt_int(sc_hi.get("SGDP_primary")),
             fmt_int(diff.get("SGDP_primary", {}).get("abs")),
             fmt_pct(diff.get("SGDP_primary", {}).get("pct"))],
            ["SGDP_secondary",
             fmt_int(sc_lo.get("SGDP_secondary")),
             fmt_int(sc_hi.get("SGDP_secondary")),
             fmt_int(diff.get("SGDP_secondary", {}).get("abs")),
             fmt_pct(diff.get("SGDP_secondary", {}).get("pct"))],
            ["SGDP_tertiary",
             fmt_int(sc_lo.get("SGDP_tertiary")),
             fmt_int(sc_hi.get("SGDP_tertiary")),
             fmt_int(diff.get("SGDP_tertiary", {}).get("abs")),
             fmt_pct(diff.get("SGDP_tertiary", {}).get("pct"))],
        ], col_widths=[3.5*cm, 3.5*cm, 3.5*cm, 3*cm, 2.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("<b>Lectura.</b> Un punto porcentual más alto en el "
                  "supuesto de crecimiento anual del PIB se traduce "
                  "en un valor añadido sectorial ~30% más alto en "
                  "cada sector en 2050. La escala proporcional es "
                  "la firma del flujo F2 con B2 log-log: el GDP_tot "
                  "del usuario es la restricción operativa y las "
                  "cuotas sectoriales se calculan desde drivers "
                  "(aquí constantes), por lo que cada SGDP_s escala "
                  "idénticamente con GDP_tot. La implicación para "
                  "emisiones: bajo intensidades de emisión por "
                  "sector constantes, un supuesto de crecimiento del "
                  "PIB 1 pp más alto implica emisiones sectoriales "
                  "2050 aproximadamente 30% más altas por categoría "
                  "&mdash; antes de aplicar cualquier política de "
                  "mitigación.", S["BODY"]))

    s2 = sens.get("sensitivity_2_form_choice_germany", {})
    out.append(P("8.2&nbsp; Sensibilidad 2 &mdash; Alemania, log-log "
                  "vs Kuznets-Chenery cuadrático", S["H2"]))
    out.append(P("<b>Setup.</b> Alemania en flujo F3: sin trayectoria "
                  "de PIB aportada; drivers Pop, SInv, iRate "
                  "extendidos a tasas de crecimiento constantes desde "
                  "2024 hasta 2050. Dos corridas: log_log vs "
                  "kuznets_chenery_quad. Región HIC. Priors "
                  "calibrados activos.", S["BODY"]))
    sc_ll = (s2.get("scenarios") or {}).get("log_log", {})
    sc_kcq = (s2.get("scenarios") or {}).get("kuznets_chenery_quad", {})
    diff2 = s2.get("diff_kcq_vs_ll_pct", {})
    if sc_ll and sc_kcq:
        out.append(P("<b>Valores en 2050:</b>", S["BODY"]))
        out.append(header_table([
            ["Variable", "log_log (M EUR)", "KCQ (M EUR)",
             "Δ KCQ - LL", "Δ %"],
            ["SGDP_primary",
             fmt_int(sc_ll.get("SGDP_primary")),
             fmt_int(sc_kcq.get("SGDP_primary")),
             fmt_int(diff2.get("SGDP_primary", {}).get("abs")),
             fmt_pct(diff2.get("SGDP_primary", {}).get("pct"))],
            ["SGDP_secondary",
             fmt_int(sc_ll.get("SGDP_secondary")),
             fmt_int(sc_kcq.get("SGDP_secondary")),
             fmt_int(diff2.get("SGDP_secondary", {}).get("abs")),
             fmt_pct(diff2.get("SGDP_secondary", {}).get("pct"))],
            ["SGDP_tertiary",
             fmt_int(sc_ll.get("SGDP_tertiary")),
             fmt_int(sc_kcq.get("SGDP_tertiary")),
             fmt_int(diff2.get("SGDP_tertiary", {}).get("abs")),
             fmt_pct(diff2.get("SGDP_tertiary", {}).get("pct"))],
            ["GDP_tot",
             fmt_int(sc_ll.get("GDP_tot")),
             fmt_int(sc_kcq.get("GDP_tot")),
             fmt_int(diff2.get("GDP_tot", {}).get("abs")),
             fmt_pct(diff2.get("GDP_tot", {}).get("pct"))],
            ["Cuota terciaria",
             f"{sc_ll.get('share_tertiary', 0):.4f}",
             f"{sc_kcq.get('share_tertiary', 0):.4f}", "", ""],
        ], col_widths=[3.5*cm, 3.5*cm, 3.5*cm, 3*cm, 2.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("<b>Lectura.</b> KCQ predice +17,6% más de SGDP "
                  "terciario en 2050 que el baseline LL, +7,8% más "
                  "secundario y &minus;21,4% menos primario. La "
                  "cuota terciaria sube de 57,7% (LL) a 59,9% (KCQ) "
                  "&mdash; el desplazamiento estructural capturado "
                  "por el shifter de renta. La implicación para "
                  "proyección de emisiones: KCQ proyecta una economía "
                  "alemana más intensiva en servicios en 2050, "
                  "reduciendo el CO2 industrial proyectado si los "
                  "módulos sectoriales aplican factores de emisión "
                  "específicos por categoría.", S["BODY"]))

    s3 = sens.get("sensitivity_3_b5_form_italy", {})
    out.append(P("8.3&nbsp; Sensibilidad 3 &mdash; Italia energía "
                  "industrial, log-log vs convergencia-intensidad",
                  S["H2"]))
    out.append(P("<b>Setup.</b> Italia en la configuración del "
                  "backtest SED (entrenamiento 1995-2005, test "
                  "2006-2023, &lambda; = 0,5, priors HIC). Dos "
                  "corridas: log_log vs intensity_convergence. "
                  "Comparamos el endpoint 2023 de la demanda "
                  "energética industrial (manufactura + construcción).",
                  S["BODY"]))
    sc_ll = (s3.get("scenarios") or {}).get("log_log", {})
    sc_ic = (s3.get("scenarios") or {}).get("intensity_convergence", {})
    diff3 = s3.get("diff_ic_vs_ll_pct", {})
    if sc_ll and sc_ic:
        out.append(P("<b>Valores en 2023 (ktoe):</b>", S["BODY"]))
        out.append(header_table([
            ["Variable", "LL (ktoe)", "IC (ktoe)", "Δ IC - LL", "Δ %"],
            ["SED_manuf + construcción",
             fmt_int(sc_ll.get("SED_manufacturing_plus_construction_ktoe")),
             fmt_int(sc_ic.get("SED_manufacturing_plus_construction_ktoe")),
             fmt_int(diff3.get("SED_manufacturing_plus_construction_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_manufacturing_plus_construction_ktoe", {}).get("pct"))],
            ["SED_services",
             fmt_int(sc_ll.get("SED_services_ktoe")),
             fmt_int(sc_ic.get("SED_services_ktoe")),
             fmt_int(diff3.get("SED_services_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_services_ktoe", {}).get("pct"))],
            ["SED_transport_pass",
             fmt_int(sc_ll.get("SED_transport_pass_ktoe")),
             fmt_int(sc_ic.get("SED_transport_pass_ktoe")),
             fmt_int(diff3.get("SED_transport_pass_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_transport_pass_ktoe", {}).get("pct"))],
            ["SED_transport_freight",
             fmt_int(sc_ll.get("SED_transport_freight_ktoe")),
             fmt_int(sc_ic.get("SED_transport_freight_ktoe")),
             fmt_int(diff3.get("SED_transport_freight_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_transport_freight_ktoe", {}).get("pct"))],
        ], col_widths=[4*cm, 2.7*cm, 2.7*cm, 2.7*cm, 2.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("<b>Lectura.</b> La forma IC proyecta ~4,9% menos "
                  "de energía industrial en Italia 2023 que la forma "
                  "log-log. El mecanismo: el &psi;_manufacturing = "
                  "&minus;1,23 calibrado en HIC introduce un "
                  "desacoplamiento dirigido por renta fuerte que la "
                  "forma log-log no puede representar (tiene "
                  "elasticidad de actividad constante por "
                  "construcción). El diferencial del 4,9%, aplicado "
                  "al CO2 industrial italiano reportado por IEA de "
                  "aproximadamente 60 Mt en 2023, implica "
                  "aproximadamente 3 Mt CO2 menos de emisiones "
                  "industriales en la proyección IC &mdash; magnitud "
                  "comparable a la mitigación inducida por el ETS UE "
                  "en un año individual para un solo Estado miembro.",
                  S["BODY"]))

    out.append(PageBreak())

    # 9. IMPLICACIONES
    out.append(P("9.&nbsp;&nbsp; Implicaciones para las proyecciones "
                  "de emisiones", S["H1"]))

    out.append(P("9.1&nbsp; La transmisión macro &rarr; emisiones",
                  S["H2"]))
    out.append(P("Las salidas del módulo macro alimentan los módulos "
                  "sectoriales de emisión vía un pequeño conjunto de "
                  "drivers de actividad por categoría IPCC. "
                  "Esquemáticamente:", S["BODY"]))
    out.append(header_table([
        ["Categoría IPCC", "Driver primario de actividad",
         "Fuente macro"],
        ["1A1 Industrias energéticas",
         "Generación eléctrica, refinerías",
         "Derivado del desglose SED"],
        ["1A2 Industrias manufactureras",
         "Energía industrial por sub-sector",
         "SED_manufacturing, SED_construction"],
        ["1A3 Transporte", "Pasajero-km, tonelada-km",
         "SED_transport_pass, SED_transport_freight"],
        ["1A4 Otros (residencial, servicios)",
         "Área de suelo, energía hogar", "SED_hh, SED_services"],
        ["1B Emisiones fugitivas",
         "Volúmenes producción/manejo combustibles",
         "Derivado de SED + cuotas combustibles"],
        ["2 IPPU", "Producto industrial (toneladas clinker, etc.)",
         "Proxy via SGDP_secondary"],
        ["3 Agricultura", "Cabezas de ganado, área de cultivo",
         "SGDP_prim_livestock, Heads"],
        ["5 Residuos", "Generación MSW, aguas residuales",
         "Proxy via Pop y GDPpc"],
    ], col_widths=[4.5*cm, 5.5*cm, 6.5*cm]))
    out.append(Spacer(1, 0.3*cm))

    out.append(P("9.2&nbsp; Dónde el módulo marca una diferencia "
                  "material", S["H2"]))
    out.append(P("<b>(i) El cuadrático Kuznets en B2 cambia las cuotas "
                  "sectoriales.</b> La sección 8.2 mostró +2,2 puntos "
                  "porcentuales de cuota terciaria en 2050 en "
                  "Alemania bajo KCQ vs LL. Traducido a través de la "
                  "intensidad de emisión por EUR menor de servicios vs "
                  "manufactura, es una reducción real en el CO2 "
                  "agregado proyectado antes de aplicar política.",
                  S["BULLET"]))
    out.append(P("<b>(ii) La forma de convergencia de intensidad en "
                  "B5 cambia la energía industrial.</b> La sección "
                  "8.3 mostró aproximadamente -5% en energía "
                  "industrial italiana en 2023 bajo IC vs LL. El "
                  "&psi;_manufacturing = &minus;1,23 calibrado se "
                  "compone sobre horizontes multidecadales.",
                  S["BULLET"]))
    out.append(P("<b>(iii) La procedencia honesta cambia la "
                  "interpretación del escenario.</b> Las etiquetas de "
                  "origen identifican qué parámetros son "
                  "<i>calibrated</i>. Para el reporting ETF bajo la "
                  "Decisión 18/CMA.1, la distinción entre parámetros "
                  "derivados del país vs derivados de literatura tiene "
                  "peso en la revisión de expertos técnicos.",
                  S["BULLET"]))

    out.append(P("9.3&nbsp; Con qué no puede ayudar el módulo",
                  S["H2"]))
    out.append(P("<b>(a) Cambio de régimen agudo.</b> La crisis "
                  "financiera de 2008, COVID-19, la crisis energética "
                  "de 2022. T8 dispara para 10 de 25 países UE-27 en "
                  "la ventana de test 2006-2024; ningún modelo de "
                  "elasticidades constantes entrenado en 1995-2005 "
                  "puede predecirlos.", S["BULLET"]))
    out.append(P("<b>(b) Shocks de política que alteran las "
                  "elasticidades.</b> El colapso del precio ETS UE en "
                  "2013 cambió las elasticidades de energía industrial. "
                  "Las directivas UE de eficiencia energética 2018 "
                  "cambiaron las intensidades residenciales. Los "
                  "usuarios con priors fuertes sobre política "
                  "post-entrenamiento deben aportar trayectorias "
                  "explícitas en flujo F1/F2.", S["BULLET"]))
    out.append(P("<b>(c) Daño climático a largo plazo.</b> El módulo "
                  "está mudo sobre la realimentación de daños "
                  "climáticos al PIB. Acoplar MITICA a una función de "
                  "daño es una dirección de investigación interesante "
                  "pero fuera de alcance.", S["BULLET"]))

    out.append(PageBreak())

    # 10. LIMITACIONES
    out.append(P("10.&nbsp;&nbsp; Limitaciones y advertencias", S["H1"]))

    out.append(P("10.1&nbsp; Cobertura de calibración desigual",
                  S["H2"]))
    out.append(P("La calibración B2 usa el panel WDI que cubre los "
                  "217 países. La calibración B5 / B6 usa el panel "
                  "Eurostat que cubre sólo 29 economías europeas. Los "
                  "valores calibrados de &psi; y &gamma;_hh son por "
                  "tanto fiables para HIC y HIC_TRANS pero estilizados "
                  "para LAC, MENA, APAC, SSA, EEU. Hasta integrar un "
                  "panel IEA WEO global, las proyecciones en regiones "
                  "no-UE descansan sobre priors energéticos derivados "
                  "de literatura y deben reportarse con esa advertencia.",
                  S["BODY"]))

    out.append(P("10.2&nbsp; El supuesto de elasticidades constantes",
                  S["H2"]))
    out.append(P("Incluso el Kuznets-Chenery cuadrático es una "
                  "aproximación polinómica: permite que la elasticidad "
                  "dependa suavemente del ingreso pero asume que la "
                  "dependencia se captura por un cuadrático. Las "
                  "elasticidades reales pueden cambiar más bruscamente "
                  "&mdash; por ejemplo cuando una economía cruza un "
                  "umbral estructural (punto de inflexión de "
                  "urbanización, umbral de desarrollo financiero, "
                  "política de transición energética).", S["BODY"]))

    out.append(P("10.3&nbsp; Las ventanas de entrenamiento cortas "
                  "perjudican la identificación", S["H2"]))
    out.append(P("Con 11-25 años de datos de entrenamiento, sólo las "
                  "señales estructurales más fuertes pueden "
                  "identificarse a nivel país. La shrinkage bayesiana "
                  "evita el sobreajuste pero al coste de sesgar el "
                  "estimador hacia el prior regional.", S["BODY"]))

    out.append(P("10.4&nbsp; El backtest de validación es UE-céntrico",
                  S["H2"]))
    out.append(P("Los backtests fuera de muestra cubren UE + UK + NO. "
                  "La experiencia UE 2006-2024 incluye la crisis "
                  "financiera de 2008, la crisis de deuda soberana "
                  "2010-2012, COVID-19 y la crisis energética de 2022 "
                  "&mdash; un conjunto de test particularmente "
                  "turbulento. Los MAPE serían probablemente menores "
                  "en regiones sin shocks comparables.", S["BODY"]))

    out.append(P("10.5&nbsp; El usuario es el filtro último",
                  S["H2"]))
    out.append(P("El módulo es una herramienta, no un oráculo. Los "
                  "modeladores nacionales poseen conocimiento "
                  "específico al contexto (inversiones de "
                  "infraestructura anunciadas, cambios de política "
                  "demográfica, regímenes de tipo de cambio, "
                  "consolidaciones sectoriales) que los priors "
                  "basados en paneles no pueden representar. Los "
                  "flujos F1 y F2 están diseñados precisamente para "
                  "que el usuario inyecte este conocimiento.",
                  S["BODY"]))

    out.append(PageBreak())

    # 11. DISCUSIÓN
    out.append(P("11.&nbsp;&nbsp; Discusión y trabajo pendiente",
                  S["H1"]))

    out.append(P("11.1&nbsp; Dónde queda v2.0", S["H2"]))
    out.append(P("El sprint de mayo de 2026 cierra tres deficiencias "
                  "de la especificación legacy: la actualización "
                  "bayesiana rota, la síntesis de covariables "
                  "faltantes, y la ausencia de alternativas "
                  "estructurales a la forma log-log. Abre dos "
                  "capacidades nuevas: un sistema de priors regionales "
                  "calibrado en WDI con estadísticas de robustez "
                  "validadas por bootstrap, y una capa de validación "
                  "extendida (T7, T8) que aflora a la usuaria los "
                  "riesgos de extrapolación. El Monte Carlo y los "
                  "backtests UE demuestran que el estimador "
                  "recuperado es internamente sano y que las formas "
                  "calibradas entregan ganancias empíricas medibles "
                  "en los sectores donde los canales estructurales son "
                  "más fuertes (energía manufacturera, PIB terciario "
                  "OCDE maduro).", S["BODY"]))

    out.append(P("11.2&nbsp; Trabajo pendiente", S["H2"]))
    out.append(P("<b>1.</b> Calibración energética multirregional. "
                  "Añadir paneles IEA WEO o OECD-CER permitiría "
                  "calibrar &psi;_k para LAC, MENA, APAC, SSA, EEU.",
                  S["BULLET"]))
    out.append(P("<b>2.</b> Calibración FAOSTAT de Bennett. Las "
                  "interceptos a_B de Bennett actualmente se "
                  "resuelven inversamente desde anclas regionales. "
                  "Una regresión panel directa sobre cuotas FAO de "
                  "valor añadido proporcionaría priors bayesianos "
                  "propios.", S["BULLET"]))
    out.append(P("<b>3.</b> Follow-on del test T8. La ventana de scan "
                  "actual está fijada en los primeros 3 años "
                  "proyectados. Un scan adaptable (5 años para "
                  "horizontes largos) capturaría cambios de régimen "
                  "de inicio más lento.", S["BULLET"]))
    out.append(P("<b>4.</b> Validación no-UE. Construir un harness de "
                  "backtest latinoamericano o africano, con los "
                  "paneles de cuentas nacionales relevantes, cerraría "
                  "el bucle de calibración para las regiones no-UE.",
                  S["BULLET"]))
    out.append(P("<b>5.</b> Traducciones documentales. Esta "
                  "especificación viene en inglés y español. Versiones "
                  "en francés, portugués y árabe alinearían con las "
                  "lenguas de trabajo de la CMNUCC.", S["BULLET"]))

    out.append(P("11.3&nbsp; Posición metodológica", S["H2"]))
    out.append(P("El módulo se sitúa en la intersección de tres "
                  "literaturas de investigación: transformación "
                  "estructural (Kuznets-Chenery-Herrendorf), economía "
                  "energética (Bashmakov-Schipper-IEA), y "
                  "econometría bayesiana de datos escasos. Ninguna de "
                  "las elecciones de diseño en v2.0 es novedosa en "
                  "cada literatura individualmente; la contribución "
                  "es la integración en un único pipeline auditable, "
                  "reproducible, dirigido al modelador nacional que "
                  "trabaja bajo el ETF de la CMNUCC.", S["BODY"]))

    out.append(PageBreak())

    # APÉNDICES (abreviados, mismos contenidos que EN)
    out.append(P("Apéndice A.&nbsp;&nbsp; Derivaciones matemáticas",
                  S["H1"]))
    out.append(P("A.1&nbsp; Posterior bayesiano en forma cerrada",
                  S["H2"]))
    out.append(P("Partiendo del modelo (5-1)-(5-2):", S["BODY"]))
    out.append(P("p(y | &theta;, &sigma;&sup2;) &prop; exp[&minus;(y "
                  "&minus; X &theta;)' (y &minus; X &theta;) / (2 "
                  "&sigma;&sup2;)]", S["EQN"]))
    out.append(P("p(&theta;) &prop; exp[&minus;(&theta; &minus; "
                  "&theta;_prior)' &Sigma;_prior,eff&#8315;&sup1; "
                  "(&theta; &minus; &theta;_prior) / 2]", S["EQN"]))
    out.append(P("El posterior p(&theta; | y, &sigma;&sup2;) es "
                  "proporcional al producto. Expandiendo y agrupando "
                  "términos en &theta;:", S["BODY"]))
    out.append(P("&Sigma;_post&#8315;&sup1; = X'X / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1;,&emsp;&theta;_hat = "
                  "&Sigma;_post (X' y / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1; &theta;_prior)",
                  S["EQN"]))

    out.append(P("A.2&nbsp; Estimador within-FE (calibración panel)",
                  S["H2"]))
    out.append(P("La regresión panel con efectos fijos por país:",
                  S["BODY"]))
    out.append(P("y_c,t = &alpha;_c + X_c,t &theta; + &epsilon;_c,t",
                  S["EQN"]))
    out.append(P("Demeaning intra-país elimina &alpha;_c. OLS sobre "
                  "los datos demeaning devuelve &theta;_hat. Errores "
                  "estándar HC1:", S["BODY"]))
    out.append(P("V_HC1 = (n / (n &minus; p)) (X' X)&#8315;&sup1; "
                  "(&Sigma;_i x_i x'_i &epsilon;_i&sup2;) (X' X)"
                  "&#8315;&sup1;", S["EQN"]))

    out.append(P("A.3&nbsp; Función logit para Bennett", S["H2"]))
    out.append(P("logit(p) = log(p / (1 &minus; p)),&emsp;expit(z) = 1 "
                  "/ (1 + exp(&minus; z))", S["EQN"]))

    out.append(P("A.4&nbsp; Inflexión de la forma de saturación",
                  S["H2"]))
    out.append(P("Para B6 cuadrático:", S["BODY"]))
    out.append(P("d(log SED_hh) / d(log GDPpc) = &beta; + 2 &gamma; "
                  "log GDPpc", S["EQN"]))
    out.append(P("que se anula en log(GDPpc)* = &minus; &beta; / (2 "
                  "&gamma;).", S["BODY"]))

    out.append(PageBreak())

    # B. PRIORS ESTILIZADOS
    out.append(P("Apéndice B.&nbsp;&nbsp; Priors regionales estilizados",
                  S["H1"]))
    out.append(P("Estos son los priors hardcodeados en "
                  "<font face='Courier'>g_Macro_Priors.py</font>. Se "
                  "aplican cuando no hay calibración JSON o cuando una "
                  "celda específica (región, parámetro) falta. Para "
                  "HIC y HIC_TRANS los valores calibrados sobreescriben "
                  "estos.", S["BODY"]))
    out.append(P("B.1&nbsp; B2 elasticidades estilizadas", S["H3"]))
    out.append(header_table([
        ["Región", "&beta;_pri", "&beta;_sec", "&beta;_ter",
         "&gamma;_pri", "&gamma;_sec", "&gamma;_ter",
         "&zeta;_pri", "&zeta;_sec", "&zeta;_ter"],
        ["LAC",        "0,30", "0,35", "0,25", "0,10", "0,15", "0,10",
         "0,90", "1,00", "1,10"],
        ["SSA",        "0,30", "0,35", "0,25", "0,15", "0,20", "0,15",
         "0,90", "1,00", "1,10"],
        ["MENA",       "0,30", "0,35", "0,25", "0,10", "0,15", "0,10",
         "0,90", "1,00", "1,10"],
        ["APAC",       "0,35", "0,40", "0,30", "0,10", "0,15", "0,10",
         "0,90", "1,00", "1,10"],
        ["EEU",        "0,30", "0,35", "0,25", "0,10", "0,15", "0,10",
         "0,90", "1,00", "1,10"],
        ["HIC",        "0,30", "0,35", "0,25", "0,05", "0,10", "0,05",
         "0,90", "1,00", "1,10"],
        ["HIC_TRANS",  "0,33", "0,38", "0,28", "0,07", "0,12", "0,07",
         "0,90", "1,00", "1,10"],
    ], col_widths=[2*cm] + [1.4*cm]*9))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.2&nbsp; B2 shifters KC estilizados", S["H3"]))
    out.append(header_table([
        ["Región",     "&kappa;_pri", "&kappa;_sec", "&kappa;_ter"],
        ["LAC, SSA, MENA, APAC", "-0,40", "-0,05", "+0,20"],
        ["EEU",        "-0,30", "-0,05", "+0,15"],
        ["HIC",        "-0,20", "-0,05", "+0,10"],
        ["HIC_TRANS",  "-0,25", " 0,00", "+0,12"],
    ], col_widths=[5.5*cm, 3.5*cm, 3.5*cm, 3.5*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.3&nbsp; B5 psi estilizados", S["H3"]))
    out.append(header_table([
        ["Región", "&psi;_pri", "&psi;_manuf", "&psi;_constr",
         "&psi;_services", "&psi;_tp", "&psi;_tf"],
        ["HIC",        "-0,30", "-0,50", "-0,20", "-0,10", "-0,05", "-0,15"],
        ["HIC_TRANS",  "-0,21", "-0,35", "-0,14", "-0,07", "-0,04", "-0,11"],
        ["EEU/LAC/MENA","-0,15","-0,25", "-0,10", "-0,05", "-0,03", "-0,08"],
        ["APAC",       "-0,10", "+0,10", "+0,05", "-0,05", "+0,10", "+0,10"],
        ["SSA",        "+0,10", "+0,20", "+0,15", " 0,00", "+0,15", "+0,15"],
    ], col_widths=[3*cm, 2*cm, 2.2*cm, 2.2*cm, 2.5*cm, 1.7*cm, 1.7*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.4&nbsp; B6 priors estilizados", S["H3"]))
    out.append(header_table([
        ["&beta;_hh", "&gamma;_hh", "&zeta;_hh",
         "&sigma;_&beta;_hh", "&sigma;_&gamma;_hh", "&sigma;_&zeta;_hh"],
        ["0,70", "-0,04", "1,00", "0,15", "0,02", "0,10"],
    ], col_widths=[2.5*cm]*6))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.5&nbsp; Anclas Bennett estilizadas", S["H3"]))
    out.append(header_table([
        ["Región", "share_crops", "share_livestock", "share_other",
         "ancla log GDPpc", "a_B (back-solved)", "b_B"],
        ["LAC",       "0,55", "0,35", "0,10", "8,5",  "-1,89", "0,15"],
        ["SSA",       "0,60", "0,30", "0,10", "7,0",  "-1,90", "0,15"],
        ["MENA",      "0,50", "0,35", "0,15", "8,5",  "-1,89", "0,15"],
        ["APAC",      "0,65", "0,25", "0,10", "7,5",  "-2,22", "0,15"],
        ["EEU",       "0,55", "0,40", "0,05", "9,0",  "-1,75", "0,15"],
        ["HIC",       "0,50", "0,40", "0,10", "10,5", "-1,98", "0,15"],
        ["HIC_TRANS", "0,52", "0,40", "0,08", "9,5",  "-1,83", "0,15"],
    ], col_widths=[2*cm, 1.8*cm, 2.3*cm, 1.8*cm, 2.3*cm, 2.3*cm, 1.5*cm]))

    out.append(PageBreak())

    # C. GLOSARIO
    out.append(P("Apéndice C.&nbsp;&nbsp; Glosario", S["H1"]))
    out.append(header_table([
        ["Término",    "Definición"],
        ["MITICA",     "Mitigation-Inventory Tool for Integrated Climate Action; herramienta de Gauss / CMNUCC."],
        ["CMNUCC",     "Convención Marco de las Naciones Unidas sobre Cambio Climático."],
        ["ETF",        "Marco de Transparencia Reforzado, Acuerdo de París, Decisión 18/CMA.1."],
        ["BTR",        "Informe Bienal de Transparencia bajo el ETF."],
        ["NDC",        "Contribución Determinada a nivel Nacional al Acuerdo de París."],
        ["IPCC",       "Grupo Intergubernamental de Expertos sobre el Cambio Climático."],
        ["WoM/WEM/WAM","Sin Medidas / Con Medidas Existentes / Con Medidas Adicionales."],
        ["GEI",        "Gases de efecto invernadero (en CO2-eq usando GWPs AR5)."],
        ["PIB / GDPpc","PIB (total) y per cápita (= PIB/Pop)."],
        ["SGDP_s",     "PIB sectorial para el sector económico s (primario, secundario, terciario)."],
        ["SED_k",      "Demanda Energética final Sectorial para el sector k."],
        ["TED",        "Demanda Energética Total = sum_k SED_k + SED_hh."],
        ["SInv_s",     "Inversión sectorial (formación bruta de capital fijo)."],
        ["GFCF_pub_s", "Formación bruta de capital fijo público por sector."],
        ["iRate",      "Tipo de interés efectivo (proxy: rentabilidad bono soberano largo plazo)."],
        ["WDI",        "World Development Indicators del Banco Mundial."],
        ["FAOSTAT",    "Estadísticas FAO; datos panel agrícolas."],
        ["IEA WEO",    "Agencia Internacional de la Energía, World Energy Outlook."],
        ["NACE rev2",  "Clasificación Estadística de Actividades Económicas de la CE (rev. 2)."],
        ["FE / WG",    "Efectos fijos / within-group estimador panel."],
        ["HC1",        "Estimador de varianza consistente con heterocedasticidad, tipo 1."],
        ["VIF",        "Factor de Inflación de la Varianza (diagnóstico de multicolinealidad)."],
        ["MAPE",       "Error porcentual absoluto medio: (1/n) sum |y_hat - y| / |y| × 100."],
        ["Ridge bayesiano", "Posterior conjugado gaussiano-gaussiano en forma cerrada con shrinkage centrado en el prior."],
        ["Bootstrap",  "Remuestreo cluster-robust (por país) para intervalos de confianza."],
        ["KC / KCQ",   "Shifter Kuznets-Chenery lineal / cuadrático sobre log(GDPpc)."],
        ["IC",         "Convergencia de Intensidad (Bashmakov 2007)."],
        ["SAT",        "Forma de Saturación (cuadrático en log GDPpc) para energía residencial."],
        ["BL",         "Forma logística de ley de Bennett para cuota cultivos/ganadería."],
        ["LL",         "Forma log-log (especificación legacy v1.1s)."],
        ["HIC / HIC_TRANS", "Países de ingreso alto (OCDE maduro vs transicionando)."],
        ["LAC / SSA / MENA / APAC / EEU",
         "Macro-regiones MITICA (América Latina y Caribe / África Subsahariana / Oriente Medio y Norte de África / Asia-Pacífico / Europa Oriental y Asia Central)."],
    ], col_widths=[3*cm, 13.5*cm]))

    out.append(PageBreak())

    # D. REFERENCIAS
    out.append(P("Apéndice D.&nbsp;&nbsp; Referencias", S["H1"]))

    out.append(P("D.1&nbsp; Documentación MITICA", S["H3"]))
    out.append(P("&bull; Martín-Ortega, J.L., Almagro Holgado, M., "
                  "Maroño de la Mata, A. y Carbajales, S. (2024). "
                  "MITICA: A Tool for Designing Mitigation Scenarios. "
                  "<i>Sustainability</i> 16(10): 4219. DOI: "
                  "10.3390/su16104219.", S["BULLET"]))
    out.append(P("&bull; Secretaría CMNUCC (2024). <i>Manual de la "
                  "herramienta MITICA</i>, versión 6.", S["BULLET"]))

    out.append(P("D.2&nbsp; Metodología económica", S["H3"]))
    out.append(P("&bull; Bashmakov, I. (2007). Three laws of energy "
                  "transitions. <i>Energy Policy</i> 35(7): 3583-3594.",
                  S["BULLET"]))
    out.append(P("&bull; Bennett, M.K. (1941). Wheat in National "
                  "Diets. <i>Wheat Studies</i> 18(2): 35-76.",
                  S["BULLET"]))
    out.append(P("&bull; Chenery, H.B. y Syrquin, M. (1975). "
                  "<i>Patterns of Development, 1950-1970</i>. Oxford "
                  "University Press para el Banco Mundial.",
                  S["BULLET"]))
    out.append(P("&bull; Chenery, H.B. y Syrquin, M. (1986). "
                  "<i>Industrialization and Growth: A Comparative "
                  "Study</i>. Oxford University Press.", S["BULLET"]))
    out.append(P("&bull; Herrendorf, B., Rogerson, R. y Valentinyi, "
                  "Á. (2014). Growth and Structural Transformation. "
                  "En Aghion y Durlauf (eds.), <i>Handbook of Economic "
                  "Growth</i>, vol. 2B, 855-941. Elsevier.",
                  S["BULLET"]))
    out.append(P("&bull; Kuznets, S. (1957, 1971). Obras sobre la "
                  "estructura del producto y el crecimiento "
                  "económico de las naciones.", S["BULLET"]))
    out.append(P("&bull; Schipper, L. y Meyers, S. (1992). <i>Energy "
                  "Efficiency and Human Activity</i>. Cambridge "
                  "University Press.", S["BULLET"]))

    out.append(P("D.3&nbsp; Estimación y estadística", S["H3"]))
    out.append(P("&bull; Cameron, A.C. y Trivedi, P.K. (2005). "
                  "<i>Microeconometrics: Methods and Applications</i>. "
                  "Cambridge University Press.", S["BULLET"]))
    out.append(P("&bull; Cameron, A.C., Gelbach, J.B. y Miller, D.L. "
                  "(2008). Bootstrap-based improvements for inference "
                  "with clustered errors. <i>Review of Economics and "
                  "Statistics</i> 90(3): 414-427.", S["BULLET"]))
    out.append(P("&bull; Gelman et al. (2013). <i>Bayesian Data "
                  "Analysis</i>, 3ª ed. CRC Press.", S["BULLET"]))

    out.append(P("D.4&nbsp; Fuentes de datos", S["H3"]))
    out.append(P("&bull; Eurostat (2024). Data Browser. CC BY 4.0.",
                  S["BULLET"]))
    out.append(P("&bull; Banco Mundial (2024). World Development "
                  "Indicators. CC BY 4.0.", S["BULLET"]))
    out.append(P("&bull; FAO (2024). FAOSTAT.", S["BULLET"]))
    out.append(P("&bull; IEA (2024). World Energy Outlook 2024.",
                  S["BULLET"]))

    out.append(P("D.5&nbsp; Regulatorio", S["H3"]))
    out.append(P("&bull; CMNUCC (2018). Decisión 18/CMA.1: Modalidades, "
                  "procedimientos y directrices para el marco de "
                  "transparencia bajo el Artículo 13 del Acuerdo de "
                  "París.", S["BULLET"]))
    out.append(P("&bull; IPCC (2006). <i>2006 IPCC Guidelines for "
                  "National Greenhouse Gas Inventories</i>, Vols 1-5.",
                  S["BULLET"]))
    out.append(P("&bull; IPCC (2019). <i>2019 Refinement to the 2006 "
                  "IPCC Guidelines</i>.", S["BULLET"]))

    out.append(Spacer(1, 0.5*cm))
    out.append(P("<i>Fin del informe.</i>", S["NOTE"]))

    return out
