"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Zap,
  Play,
  CheckCircle2,
  Plus,
  Pencil,
  Trash2,
  Check,
  X,
  Download,
  AlertCircle,
  Info,
} from "lucide-react";

import {
  api,
  type EnergyPAM,
  type EnergyPAMInput,
  type EnergyResult,
  type EnergySystem,
  type EnergyUploadResponse,
  type EnergyValidationFlag,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { UploadBox } from "@/components/mitica/UploadBox";

const SCENARIO_COLORS: Record<string, string> = {
  WoM: "#1A2438",
  WM: "#147A6E",
  WAM: "#8a7d5a",
};

export default function EnergyModulePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);

  const [horizon, setHorizon] = useState<string>("");
  const [losses, setLosses] = useState<number>(0);
  // Monte-Carlo iterations (0 = off). 1000 gives stable quartiles; the
  // dissertation (§2.6) default is 10000; the API caps at 20000.
  const [uncIters, setUncIters] = useState<string>("0");

  const system = useQuery<EnergySystem>({
    queryKey: ["energy-system", id],
    queryFn: () => api.getEnergySystem(id),
    retry: false,
  });
  const result = useQuery<EnergyResult>({
    queryKey: ["energy-result", id],
    queryFn: () => api.getEnergyResult(id),
    retry: false,
  });

  const upload = useMutation({
    mutationFn: (file: File) => api.uploadEnergyTemplate(id, file),
    onSuccess: () => system.refetch(),
  });

  const run = useMutation({
    mutationFn: () =>
      api.runEnergy(id, {
        horizon_year: horizon ? Number(horizon) : null,
        losses_pct: losses,
        scenarios: ["WoM", "WM", "WAM"],
        uncertainty_iterations: Math.min(20000, Math.max(0, Math.floor(Number(uncIters) || 0))),
      }),
    onSuccess: () => result.refetch(),
  });

  const sys = system.data;
  const res = run.data ?? result.data;

  return (
    <div className="space-y-8">
      <div>
        <div className="mb-2 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-amber-700">
            <Zap className="h-5 w-5" />
          </div>
          <div>
            <div className="eyebrow">Module · SI-003 · IPCC 1A1</div>
            <h2 className="font-serif text-2xl font-[460]">Energy industries module</h2>
          </div>
        </div>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Projection of <em>public electricity and heat generation</em> (IPCC 1A1a, plus optional
          1A1c autoproducers — not 1A2 manufacturing, not 1A3 transport), faithful to the legacy
          MITICA Excel model: the WoM scales every technology with demand at frozen mix shares,
          and WM/WAM capacity additions displace fossil generation. Upload the legacy Excel
          template{" "}
          <code className="rounded bg-muted px-1 font-mono">templates.xlsx</code> — sheets
          <em> System / Supply / Proyection / PAM_Energia</em> — and the module will freeze
          per-technology factors at the base year, then project WoM, WM and WAM trajectories.
          Activating the module in a project overrides ANNALIST for ONLY its own categories
          (1A1a, plus 1A1c if used). Every other category — 1A2, 1A4 and the rest of the
          inventory — still projects with ANNALIST using your proxies.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">1. Upload the Energy template</CardTitle>
        </CardHeader>
        <CardContent>
          <UploadBox
            label={sys ? "Template uploaded" : "Choose templates.xlsx"}
            description="Legacy Energy module layout (Tecnologia × Data type × year matrix)."
            accept=".xlsx,.xlsm,.xls"
            onUpload={async (file) => {
              await upload.mutateAsync(file);
            }}
            uploaded={Boolean(sys)}
          />
          {upload.error && (
            <p className="mt-2 text-sm text-destructive">{(upload.error as Error).message}</p>
          )}
          {sys && (
            <SystemSummary
              projectId={id}
              system={sys}
              uploadResp={upload.data ?? undefined}
            />
          )}
        </CardContent>
      </Card>

      {sys && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">2. Run the dispatch</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-4">
              <div>
                <Label>Horizon year (optional)</Label>
                <Input
                  type="number"
                  placeholder={`default: ${sys.demand_projection_gwh && Object.keys(sys.demand_projection_gwh).length ? Math.max(...Object.keys(sys.demand_projection_gwh).map(Number)) : ""}`}
                  value={horizon}
                  onChange={(e) => setHorizon(e.target.value)}
                />
              </div>
              <div>
                <Label>
                  Transmission losses:{" "}
                  <span className="font-mono">
                    {losses > 0 ? `${losses.toFixed(1)}%` : "derived from history"}
                  </span>
                </Label>
                <input
                  type="range"
                  min={0}
                  max={20}
                  step={0.5}
                  value={losses}
                  onChange={(e) => setLosses(Number(e.target.value))}
                  className="w-full"
                />
              </div>
              <div>
                <Label>Uncertainty iterations</Label>
                <Input
                  type="number"
                  min={0}
                  max={20000}
                  step={100}
                  value={uncIters}
                  onChange={(e) => setUncIters(e.target.value)}
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  0 = off. Monte-Carlo bands (empirical bootstrap, max 20000).
                </p>
              </div>
              <div className="self-end">
                <Button onClick={() => run.mutate()} disabled={run.isPending}>
                  <Play className="mr-2 h-4 w-4" />
                  {run.isPending ? "Dispatching…" : "Run WoM + WM + WAM"}
                </Button>
              </div>
            </div>
            {run.error && <p className="text-sm text-destructive">{(run.error as Error).message}</p>}
            {run.isSuccess && (
              <p className="inline-flex items-center gap-1.5 text-sm text-primary">
                <CheckCircle2 className="h-4 w-4" /> Dispatch complete — horizon {run.data.horizon_year}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {res && <EnergyResults projectId={id} result={res} />}
    </div>
  );
}

// ----------------------------------------------------------------------------

function SystemSummary({
  projectId,
  system,
  uploadResp,
}: {
  projectId: string;
  system: EnergySystem;
  uploadResp?: EnergyUploadResponse;
}) {
  const techs = system.technologies.map((t) => t.name);
  const histYears = Object.keys(system.demand_history_gwh).map(Number).sort((a, b) => a - b);
  const projYears = Object.keys(system.demand_projection_gwh).map(Number).sort((a, b) => a - b);
  const lastHist = uploadResp?.last_historical_year ?? (histYears.at(-1) ?? 0);

  return (
    <div className="mt-5 space-y-4">
      <div className="flex flex-wrap gap-3">
        <Pill label="Country" value={system.country_code} />
        <Pill label="Techs" value={String(techs.length)} />
        <Pill label="PAMs" value={String(system.pams.length)} />
        <Pill label="Last hist" value={String(lastHist)} />
        {projYears.length > 0 && (
          <Pill label="Projection" value={`${projYears[0]} → ${projYears.at(-1)}`} />
        )}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {techs.map((t) => (
          <code key={t} className="rounded-sm bg-muted px-2 py-0.5 font-mono text-[11px]">
            {t}
          </code>
        ))}
      </div>
      <PAMEditor projectId={projectId} system={system} />
    </div>
  );
}

// Palette for the stacked per-tech charts — deterministic from the tech
// name so the same colour maps across all three charts.
const TECH_PALETTE = [
  "#147A6E", // Gauss teal (primary)
  "#1A2438", // Gauss navy
  "#8a7d5a", // warm earth
  "#5b6dcd", // indigo
  "#c97064", // terracotta
  "#3ea99f", // teal mid
  "#b08a3e", // mustard
  "#6e7aa0", // slate
  "#94634c", // sienna
  "#44756c", // moss
];

function colorForTech(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) | 0;
  }
  return TECH_PALETTE[Math.abs(hash) % TECH_PALETTE.length];
}

function EnergyResults({ projectId, result }: { projectId: string; result: EnergyResult }) {
  const scenarios = Object.keys(result.scenario_totals);
  const years = useMemo(
    () => Array.from(new Set(result.dispatch.map((d) => d.year))).sort((a, b) => a - b),
    [result.dispatch]
  );

  // Engine mode — pre-mode artifacts (no `mode` field) were merit-dispatch runs.
  const mode = result.mode ?? "merit_dispatch";
  const isLegacy = mode === "legacy_excel";
  const modeLabel = isLegacy ? "Legacy Excel (share-scaling)" : "Merit-order dispatch";

  // Selected scenario for the three stacked charts (default first = WoM).
  const [selectedScen, setSelectedScen] = useState<string>(scenarios[0] ?? "WoM");

  // Per-scenario total emissions trajectory (the top chart — always shows all 3).
  const totalTrace = scenarios.map((scen) => {
    const m = result.scenario_totals[scen] || {};
    return {
      x: years,
      y: years.map((y) => m[String(y)] ?? null),
      type: "scatter" as const,
      mode: "lines+markers" as const,
      name: scen,
      line: { color: SCENARIO_COLORS[scen] || "#666", width: 2 },
    };
  });

  // Dispatches for the selected scenario, sorted by year.
  const rowsForScen = useMemo(
    () => result.dispatch.filter((d) => d.scenario === selectedScen).sort((a, b) => a.year - b.year),
    [result.dispatch, selectedScen]
  );

  // Union of tech names in the selected scenario (covers new techs added via PAMs).
  const techs = useMemo(
    () =>
      Array.from(
        new Set(rowsForScen.flatMap((d) => [
          ...Object.keys(d.emissions_kt),
          ...Object.keys(d.generation_gwh),
          ...Object.keys(d.capacity_mw),
        ]))
      ),
    [rowsForScen]
  );

  // Sort techs by merit rank so the stack ordering matches the dispatch order.
  const rankByName = Object.fromEntries(result.characterisation.map((c) => [c.name, c.merit_rank]));
  const orderedTechs = [...techs].sort(
    (a, b) => (rankByName[a] ?? 999) - (rankByName[b] ?? 999)
  );

  function stackedBy(field: "emissions_kt" | "generation_gwh" | "capacity_mw") {
    return orderedTechs.map((t) => ({
      x: rowsForScen.map((d) => d.year),
      y: rowsForScen.map((d) => (d as any)[field][t] ?? 0),
      name: t,
      type: "bar" as const,
      marker: { color: colorForTech(t) },
    }));
  }

  const emisStack = stackedBy("emissions_kt");
  const genStack = stackedBy("generation_gwh");
  const capStack = stackedBy("capacity_mw");

  return (
    <div className="space-y-6">
      {/* Narrative summary at the top — mirrors the macro module's G2
          pattern. Deterministic from the result; no LLM. */}
      <EnergyNarrativeSummary result={result} />

      {/* Plausibility flags from the engine (E1-E5). Replaces the
          previous one-off UnservedNote with the full E* surface. */}
      <EnergyValidationPanel report={result.validation_report ?? []} />

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <CardTitle className="text-base">Scenario comparison — total emissions (kt CO₂-eq)</CardTitle>
            <span
              className="rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 font-mono text-[11px] text-primary"
              title={
                isLegacy
                  ? "Faithful port of the legacy MITICA Excel: WoM scales every technology with demand at frozen mix shares; WM/WAM additions displace fossil generation."
                  : "Per-technology merit-order dispatch (the previous engine behaviour)."
              }
            >
              {modeLabel}
            </span>
          </div>
          <div className="flex gap-2">
            <a
              href={api.energyExportCsvUrl(projectId)}
              className="inline-flex items-center gap-1.5 rounded-sm border border-border bg-card px-3 py-1.5 text-xs font-medium hover:border-foreground/40"
            >
              <Download className="h-3.5 w-3.5" /> CSV
            </a>
            <a
              href={api.energyExportJsonUrl(projectId)}
              className="inline-flex items-center gap-1.5 rounded-sm border border-border bg-card px-3 py-1.5 text-xs font-medium hover:border-foreground/40"
            >
              <Download className="h-3.5 w-3.5" /> JSON
            </a>
          </div>
        </CardHeader>
        <CardContent>
          <PlotlyChart height={340} data={totalTrace} layout={{ yaxis: { title: "kt CO₂-eq" } }} />
        </CardContent>
      </Card>

      {result.uncertainty && result.uncertainty.iterations > 0 && (
        <UncertaintyFanChart uncertainty={result.uncertainty} />
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Per-technology stack — {selectedScen}</CardTitle>
          <div className="flex overflow-hidden rounded-sm border border-border text-xs">
            {scenarios.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSelectedScen(s)}
                className={
                  s === selectedScen
                    ? "bg-primary px-3 py-1 font-medium text-primary-foreground"
                    : "bg-card px-3 py-1 text-muted-foreground hover:bg-muted"
                }
              >
                {s}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <StackedChartBlock
            title="Capacity (MW)"
            note="WoM capacity scales with demand at the frozen technology mix (legacy rule). WM/WAM add cumulative PAM capacity; fossil capacity follows its displaced generation."
            data={capStack}
            unit="MW"
          />
          <StackedChartBlock
            title="Generation (GWh)"
            note="Generation per technology. WoM: frozen mix shares scale with demand. WM/WAM: clean additions serve first, fossil takes the residual."
            data={genStack}
            unit="GWh"
          />
          <StackedChartBlock
            title="Emissions (kt CO₂-eq)"
            note="Generation × emission factor. Renewables contribute 0."
            data={emisStack}
            unit="kt CO₂-eq"
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Technology characterisation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs text-muted-foreground">
                <tr>
                  {/* Rank is merit-order semantics — hidden in legacy mode,
                      where dispatch is share-scaling, not a merit stack. */}
                  {!isLegacy && <th className="px-2 py-1.5 text-left">Rank</th>}
                  <th className="px-2 py-1.5 text-left">Technology</th>
                  <th className="px-2 py-1.5 text-right">EF (kt/GWh)</th>
                  <th className="px-2 py-1.5 text-right">CF</th>
                  <th className="px-2 py-1.5 text-right">Cap (MW)</th>
                </tr>
              </thead>
              <tbody>
                {result.characterisation.map((c) => (
                  <tr key={c.name} className="border-t border-border">
                    {!isLegacy && (
                      <td className="px-2 py-1.5 font-mono text-xs">{c.merit_rank}</td>
                    )}
                    <td className="px-2 py-1.5">
                      <span
                        className="inline-block h-2 w-2 rounded-full align-middle"
                        style={{ backgroundColor: colorForTech(c.name) }}
                      />{" "}
                      <span className="font-mono text-xs">{c.name}</span>
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono text-xs">
                      {c.emission_factor_kt_per_gwh.toFixed(4)}
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono text-xs">
                      {c.capacity_factor.toFixed(3)}
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono text-xs">
                      {c.last_capacity_mw.toFixed(0)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

    </div>
  );
}


// Monte-Carlo fan chart (FE-05): per scenario the median + p25–p75 band +
// min/max whiskers from `uncertainty.bands` (empirical bootstrap over the
// observed historical years, dissertation §2.6; seeded).
function hexToRgba(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function UncertaintyFanChart({
  uncertainty,
}: {
  uncertainty: NonNullable<EnergyResult["uncertainty"]>;
}) {
  const traces: object[] = [];
  for (const scen of Object.keys(uncertainty.bands)) {
    const byYear = uncertainty.bands[scen] ?? {};
    const yrs = Object.keys(byYear).map(Number).sort((a, b) => a - b);
    if (yrs.length === 0) continue;
    const color = SCENARIO_COLORS[scen] ?? "#666";
    const stat = (k: "median" | "p25" | "p75" | "min" | "max") =>
      yrs.map((y) => byYear[String(y)]?.[k] ?? null);
    traces.push(
      // min/max whisker envelope (lighter) …
      {
        x: yrs, y: stat("min"), type: "scatter", mode: "lines",
        line: { width: 0 }, hoverinfo: "skip", showlegend: false, legendgroup: scen,
      },
      {
        x: yrs, y: stat("max"), type: "scatter", mode: "lines",
        line: { width: 0 }, fill: "tonexty", fillcolor: hexToRgba(color, 0.1),
        hoverinfo: "skip", showlegend: false, legendgroup: scen,
      },
      // … then the p25–p75 interquartile band (darker) …
      {
        x: yrs, y: stat("p25"), type: "scatter", mode: "lines",
        line: { width: 0 }, hoverinfo: "skip", showlegend: false, legendgroup: scen,
      },
      {
        x: yrs, y: stat("p75"), type: "scatter", mode: "lines",
        line: { width: 0 }, fill: "tonexty", fillcolor: hexToRgba(color, 0.22),
        hoverinfo: "skip", showlegend: false, legendgroup: scen,
      },
      // … and the median on top.
      {
        x: yrs, y: stat("median"), type: "scatter", mode: "lines",
        line: { color, width: 2 }, name: `${scen} median`, legendgroup: scen,
      },
    );
  }
  if (traces.length === 0) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">
          Uncertainty bands — total emissions (kt CO₂-eq), {uncertainty.iterations} iterations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={340}
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          data={traces as any}
          layout={{ yaxis: { title: "kt CO₂-eq" }, xaxis: { title: "Year" } }}
        />
        <p className="mt-2 text-[11px] text-muted-foreground">
          Method: empirical bootstrap over the observed historical years (dissertation §2.6) —{" "}
          {uncertainty.sampled.length > 0
            ? `resampled per iteration: ${uncertainty.sampled.join(", ")}`
            : "resampled per iteration from the historical record"}
          . Seeded (seed {uncertainty.seed}), so re-runs reproduce the same bands. Darker band =
          p25–p75 interquartile range; lighter envelope = min–max across iterations; solid line =
          median.
        </p>
      </CardContent>
    </Card>
  );
}

// G2 pattern (UX audit, applied to energy): deterministic narrative
// summary so the user immediately knows what the dispatch produced.
// Computes 4 numbers from the result: WoM/WAM emission totals at the
// horizon, abatement %, renewable share trend.
function EnergyNarrativeSummary({ result }: { result: EnergyResult }) {
  const years = Array.from(
    new Set(result.dispatch.map((d) => d.year)),
  ).sort((a, b) => a - b);
  if (years.length === 0) return null;
  const last = years[years.length - 1];
  const first = years[0];

  const totalAtYear = (scen: string, y: number): number => {
    const row = result.dispatch.find(
      (d) => d.scenario === scen && d.year === y,
    );
    return row?.total_emissions_kt ?? 0;
  };

  // Renewable share = generation from zero-EF techs / total generation
  const isRenewable = (techName: string): boolean => {
    const c = result.characterisation.find((c) => c.name === techName);
    return (c?.emission_factor_kt_per_gwh ?? 1) < 0.05;
  };
  const renewShareAt = (scen: string, y: number): number | null => {
    const row = result.dispatch.find(
      (d) => d.scenario === scen && d.year === y,
    );
    if (!row || !row.generation_gwh) return null;
    let renew = 0;
    let total = 0;
    for (const [tech, gen] of Object.entries(row.generation_gwh)) {
      total += gen;
      if (isRenewable(tech)) renew += gen;
    }
    return total > 0 ? renew / total : null;
  };

  const womH = totalAtYear("WoM", last);
  const wamH = totalAtYear("WAM", last);
  const abatement =
    womH > 0 && wamH >= 0 ? (1 - wamH / womH) * 100 : null;

  const renewFirst = renewShareAt("WAM", first) ?? renewShareAt("WoM", first);
  const renewLast = renewShareAt("WAM", last) ?? renewShareAt("WoM", last);

  const scenarios = Array.from(new Set(result.dispatch.map((d) => d.scenario)));
  return (
    <Card>
      <CardContent className="py-3.5">
        <p className="text-sm leading-relaxed text-foreground">
          <span className="font-medium">
            Energy module · IPCC 1A1, dispatch over {scenarios.length}{" "}
            scenario{scenarios.length === 1 ? "" : "s"} ({scenarios.join(", ")}),
            horizon {result.horizon_year}.
          </span>{" "}
          WoM emissions at {last}: <span className="font-mono">{womH.toFixed(0)}</span> kt CO₂-eq.
          {abatement !== null && (
            <>
              {" "}WAM achieves{" "}
              <span className="font-mono">
                {abatement >= 0 ? "−" : "+"}{Math.abs(abatement).toFixed(1)}%
              </span>{" "}
              vs WoM.
            </>
          )}
          {renewFirst !== null && renewLast !== null && (
            <>
              {" "}Renewable generation share moves from{" "}
              <span className="font-mono">{(renewFirst * 100).toFixed(0)}%</span> ({first})
              to <span className="font-mono">{(renewLast * 100).toFixed(0)}%</span> ({last}) under WAM.
            </>
          )}
        </p>
      </CardContent>
    </Card>
  );
}


// E* validation surface — mirrors the macro module's ValidationPanel.
// Always renders (even when empty) so the user knows the engine ran
// the checks and is confident the projection is plausible. Carries
// proposed_action under each flag, same pattern as macro.
function EnergyValidationPanel({ report }: { report: EnergyValidationFlag[] }) {
  const amber = report.filter((f) => f.severity === "amber").length;
  const info = report.filter((f) => f.severity === "info").length;
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">Validation summary</CardTitle>
        <div className="flex gap-2 text-xs">
          <span className="rounded-full border border-amber-600/40 bg-amber-600/10 px-2 py-0.5 text-amber-700">
            {amber} amber
          </span>
          <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
            {info} info
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <p className="mb-3 text-[11px] text-muted-foreground">
          Engine never fires red — it informs, the user decides.{" "}
          <strong>E1</strong> emission-factor sanity per tech ·{" "}
          <strong>E2</strong> capacity-factor sanity ·{" "}
          <strong>E3</strong> unserved demand · <strong>E4</strong>{" "}
          stranded capacity · <strong>E5</strong> mitigation direction
          (WAM should reduce vs WoM) · <strong>E6</strong> unknown technology
          name · <strong>E7</strong> inoperative / out-of-window PAM ·{" "}
          <strong>E8</strong> demand-chain &amp; input integrity.
        </p>
        {report.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No flags raised — all plausibility checks passed.
          </p>
        ) : (
          <ul className="divide-y divide-border text-sm">
            {report.map((f, i) => (
              <li key={i} className="flex items-start gap-3 py-2.5">
                {f.severity === "amber" ? (
                  <AlertCircle
                    className="mt-0.5 h-4 w-4 shrink-0 text-amber-600"
                    aria-hidden
                  />
                ) : (
                  <Info
                    className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground"
                    aria-hidden
                  />
                )}
                <div className="flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="font-mono text-xs text-muted-foreground">
                      {f.test_id}
                    </span>
                    <span className="text-sm font-medium">{f.variable}</span>
                  </div>
                  <p className="whitespace-pre-line text-xs text-muted-foreground">
                    {f.message}
                  </p>
                  {f.proposed_action && (
                    <p className="mt-1.5 text-xs text-foreground/90">
                      <span className="font-medium text-foreground">
                        What to do:{" "}
                      </span>
                      {f.proposed_action}
                    </p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function StackedChartBlock({
  title,
  note,
  data,
  unit,
}: {
  title: string;
  note: string;
  data: unknown[];
  unit: string;
}) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <div className="font-serif text-sm font-medium">{title}</div>
        <div className="text-[11px] text-muted-foreground">{note}</div>
      </div>
      <PlotlyChart
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data={data as any}
        height={280}
        layout={{ barmode: "stack", yaxis: { title: unit }, legend: { orientation: "h", y: -0.25 } }}
      />
    </div>
  );
}

// (UnservedNote removed — superseded by E3 in EnergyValidationPanel.)

function Pill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-sm border border-border bg-card px-3 py-1.5 text-xs">
      <span className="text-muted-foreground">{label}: </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

// ----------------------------------------------------------------------------
// PAM Editor — CRUD without re-uploading the Excel template.
// ----------------------------------------------------------------------------

function PAMEditor({ projectId, system }: { projectId: string; system: EnergySystem }) {
  const qc = useQueryClient();
  const techNames = system.technologies.map((t) => t.name);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const pams = useQuery<EnergyPAM[]>({
    queryKey: ["energy-pams", projectId],
    queryFn: () => api.listEnergyPAMs(projectId),
    initialData: system.pams as EnergyPAM[],
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["energy-pams", projectId] });
    qc.invalidateQueries({ queryKey: ["energy-system", projectId] });
  };

  const create = useMutation({
    mutationFn: (body: EnergyPAMInput) => api.createEnergyPAM(projectId, body),
    onSuccess: () => {
      invalidate();
      setCreating(false);
    },
  });

  const update = useMutation({
    mutationFn: ({ id, body }: { id: string; body: Partial<EnergyPAMInput> }) =>
      api.updateEnergyPAM(projectId, id, body),
    onSuccess: () => {
      invalidate();
      setEditingId(null);
    },
  });

  const del = useMutation({
    mutationFn: (pamId: string) => api.deleteEnergyPAM(projectId, pamId),
    onSuccess: invalidate,
  });

  const rows = pams.data ?? [];
  const sortedTechs = [...new Set([...techNames, ...rows.map((p) => p.technology)])];

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <div className="eyebrow">PAMs by scenario</div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setCreating(true);
            setEditingId(null);
          }}
          disabled={creating}
        >
          <Plus className="mr-1 h-3 w-3" /> Add PAM
        </Button>
      </div>
      <div className="overflow-hidden rounded-sm border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-1.5 text-left">Scenario</th>
              <th className="px-3 py-1.5 text-left">Technology</th>
              <th className="px-3 py-1.5 text-right">Year</th>
              <th className="px-3 py-1.5 text-right">MW added</th>
              <th className="px-3 py-1.5 text-left">Name</th>
              <th className="px-3 py-1.5 text-right"></th>
            </tr>
          </thead>
          <tbody>
            {creating && (
              <PAMRowEditor
                techs={sortedTechs}
                initial={{
                  scenario: "WM",
                  technology: techNames[0] ?? "",
                  year: new Date().getFullYear() + 1,
                  added_mw: 0,
                  name: "",
                  notes: "",
                }}
                onSave={(body) => create.mutate(body)}
                onCancel={() => setCreating(false)}
                saving={create.isPending}
              />
            )}
            {rows.map((p) =>
              editingId === p.id ? (
                <PAMRowEditor
                  key={p.id ?? `${p.scenario}-${p.technology}-${p.year}`}
                  techs={sortedTechs}
                  initial={{
                    scenario: p.scenario,
                    technology: p.technology,
                    year: p.year,
                    added_mw: p.added_mw,
                    name: p.name ?? "",
                    notes: p.notes ?? "",
                  }}
                  onSave={(body) => update.mutate({ id: p.id!, body })}
                  onCancel={() => setEditingId(null)}
                  saving={update.isPending}
                />
              ) : (
                <tr
                  key={p.id ?? `${p.scenario}-${p.technology}-${p.year}`}
                  className="border-t border-border"
                >
                  <td className="px-3 py-1.5">
                    <span
                      className={
                        p.scenario === "WAM"
                          ? "rounded bg-amber-700/10 px-1.5 py-0.5 text-xs text-amber-800"
                          : "rounded bg-primary/10 px-1.5 py-0.5 text-xs text-primary"
                      }
                    >
                      {p.scenario}
                    </span>
                  </td>
                  <td className="px-3 py-1.5 font-mono text-xs">{p.technology}</td>
                  <td className="px-3 py-1.5 text-right font-mono">{p.year}</td>
                  <td className="px-3 py-1.5 text-right font-mono">
                    {p.added_mw.toFixed(0)}
                  </td>
                  <td className="px-3 py-1.5 text-xs text-muted-foreground">{p.name}</td>
                  <td className="px-3 py-1.5 text-right">
                    <div className="flex justify-end gap-1">
                      <button
                        type="button"
                        aria-label="Edit PAM"
                        className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"
                        disabled={!p.id || del.isPending}
                        onClick={() => {
                          setEditingId(p.id ?? null);
                          setCreating(false);
                        }}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label="Delete PAM"
                        className="rounded p-1 text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-50"
                        disabled={!p.id || del.isPending}
                        onClick={() => {
                          if (p.id && confirm(`Delete PAM "${p.name || p.technology}"?`)) {
                            del.mutate(p.id);
                          }
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              )
            )}
            {rows.length === 0 && !creating && (
              <tr>
                <td colSpan={6} className="px-3 py-4 text-center text-xs text-muted-foreground">
                  No PAMs yet. Click "Add PAM" to create one.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {(create.error || update.error || del.error) && (
        <p className="mt-2 text-xs text-destructive">
          {(create.error as Error | null)?.message ??
            (update.error as Error | null)?.message ??
            (del.error as Error | null)?.message}
        </p>
      )}
      <p className="mt-2 text-[11px] text-muted-foreground">
        Adding a PAM here updates <code className="rounded bg-muted px-1 font-mono">system.json</code>{" "}
        immediately. Re-run the dispatch to see it reflected in the charts.
      </p>
    </div>
  );
}

function PAMRowEditor({
  techs,
  initial,
  onSave,
  onCancel,
  saving,
}: {
  techs: string[];
  initial: EnergyPAMInput;
  onSave: (body: EnergyPAMInput) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [scenario, setScenario] = useState(initial.scenario);
  const [technology, setTechnology] = useState(initial.technology);
  const [year, setYear] = useState<number>(initial.year);
  const [mw, setMw] = useState<number>(initial.added_mw);
  const [name, setName] = useState(initial.name ?? "");

  const canSave = technology.trim().length > 0 && mw >= 0 && year > 1990;

  return (
    <tr className="border-t border-border bg-primary/5">
      <td className="px-3 py-1.5">
        <select
          value={scenario}
          onChange={(e) => setScenario(e.target.value)}
          className="h-7 rounded-sm border border-input bg-background px-1 text-xs"
        >
          <option value="WM">WM</option>
          <option value="WAM">WAM</option>
        </select>
      </td>
      <td className="px-3 py-1.5">
        <input
          list="energy-tech-options"
          value={technology}
          onChange={(e) => setTechnology(e.target.value)}
          className="h-7 w-full rounded-sm border border-input bg-background px-2 font-mono text-xs"
          placeholder="e.g. Solar"
        />
        <datalist id="energy-tech-options">
          {techs.map((t) => (
            <option key={t} value={t} />
          ))}
        </datalist>
      </td>
      <td className="px-3 py-1.5 text-right">
        <input
          type="number"
          value={year}
          onChange={(e) => setYear(Number(e.target.value))}
          className="h-7 w-20 rounded-sm border border-input bg-background px-1 text-right font-mono text-xs"
        />
      </td>
      <td className="px-3 py-1.5 text-right">
        <input
          type="number"
          step="any"
          value={mw}
          onChange={(e) => setMw(Number(e.target.value))}
          className="h-7 w-24 rounded-sm border border-input bg-background px-1 text-right font-mono text-xs"
        />
      </td>
      <td className="px-3 py-1.5">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Optional label"
          className="h-7 w-full rounded-sm border border-input bg-background px-2 text-xs"
        />
      </td>
      <td className="px-3 py-1.5 text-right">
        <div className="flex justify-end gap-1">
          <button
            type="button"
            aria-label="Save PAM"
            className="rounded p-1 text-primary hover:bg-primary/10 disabled:opacity-50"
            disabled={!canSave || saving}
            onClick={() =>
              onSave({ scenario, technology: technology.trim(), year, added_mw: mw, name })
            }
          >
            <Check className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Cancel"
            className="rounded p-1 text-muted-foreground hover:bg-muted"
            disabled={saving}
            onClick={onCancel}
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}
