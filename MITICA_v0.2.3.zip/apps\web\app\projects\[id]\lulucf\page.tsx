"use client";

import React, { use, useMemo, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  AlertCircle,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Download,
  Info,
  Lock,
  Play,
  Plus,
  Trash2,
  TreePine,
  Wand2,
} from "lucide-react";

import {
  api,
  type ClimateZone,
  type CrtCategory,
  type LulucfCountryEntry,
  type LulucfFormsCatalog,
  type LulucfPamCatalog,
  type LulucfPamSummaryRow,
  type LulucfProfile,
  type LulucfResult,
  type LulucfRunRequest,
  type LulucfScenarioEntry,
  type LulucfScenarioNetRow,
  type MacroRegion,
  type PamCatalogEntry,
  type PamSpec,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { cn } from "@/lib/utils";

// ============================================================================
// CSV parse helpers — LULUCF uses long-format tables with named columns.
// ============================================================================

// G16 (UX audit): CSV download — serialise an array of records to
// CSV and trigger a browser download. Used by the result panel's
// "Download CSV" buttons.
function recordsToCsv(rows: Array<Record<string, unknown>>): string {
  if (rows.length === 0) return "";
  // Preserve column order from the first row's keys.
  const cols = Object.keys(rows[0]);
  const escape = (v: unknown): string => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    if (/[",\n\r]/.test(s)) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };
  const header = cols.join(",");
  const body = rows
    .map((r) => cols.map((c) => escape(r[c])).join(","))
    .join("\n");
  return `${header}\n${body}\n`;
}

function downloadCsv(filename: string, rows: Array<Record<string, unknown>>) {
  const csv = recordsToCsv(rows);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

// G16 (UX audit): CRT-format Excel export. Lazy-loads SheetJS (same
// pattern as the macro page) so the bundle cost is only paid when the
// user actually exports. Produces a multi-sheet workbook that round-
// trips into the BTR submission shape: per-CRT-category × per-gas ×
// per-year emissions, plus net flux, HWP pool, and a metadata sheet.
async function downloadCrtXlsx(result: LulucfResult, filename: string) {
  const XLSX = await import("xlsx");
  const wb = XLSX.utils.book_new();

  // Sheet 1 — net flux by year
  const net = (result.net_co2eq_by_year ?? []).map((r) => ({
    Year: r.Year,
    "Net LULUCF (kt CO2-eq)": r.Net_LULUCF_CO2eq_kt,
  }));
  XLSX.utils.book_append_sheet(
    wb, XLSX.utils.json_to_sheet(net), "Net flux",
  );

  // Sheet 2 — emissions per CRT category × gas × year (the CRT shape)
  const em = result.emissions.map((r) => ({
    Year: r.Year,
    Category: r.Category,
    "Category label": result.crt_labels?.[r.Category] ?? r.Category,
    Gas: r.Gas,
    "Emissions (kt gas)": r.Emissions_kt,
    "Emissions (kt CO2-eq)": r.Emissions_CO2eq_kt,
  }));
  XLSX.utils.book_append_sheet(
    wb, XLSX.utils.json_to_sheet(em), "Emissions (CRT)",
  );

  // Sheet 3 — HWP pool (4G) per product class
  if ((result.hwp ?? []).length > 0) {
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        result.hwp as unknown as Array<Record<string, unknown>>,
      ),
      "HWP pool",
    );
  }

  // Sheet 4 — metadata / provenance
  const meta = [
    { Field: "Country", Value: result.country ?? "" },
    { Field: "Profile", Value: result.profile_used },
    { Field: "Tier", Value: result.tier_used },
    { Field: "refDB version", Value: result.refdb_version_used },
    { Field: "Inventory vintage", Value: result.inventory_vintage_used ?? "" },
    { Field: "Touch-up applied", Value: result.touchup_applied ? "yes" : "no" },
    { Field: "Red flags", Value: result.n_red_flags },
    { Field: "Amber flags", Value: result.n_amber_flags },
    { Field: "GWP set", Value: "AR4 GWP-100 (CO2=1, CH4=25, N2O=298)" },
    { Field: "Exported", Value: new Date().toISOString() },
  ];
  XLSX.utils.book_append_sheet(
    wb, XLSX.utils.json_to_sheet(meta), "Metadata",
  );

  XLSX.writeFile(wb, filename);
}

// ============================================================================
// G8 (UX audit): parameter-log glossary.
// Plain-language explanation + design-doc section for each parameter
// name the engine surfaces. Pattern-matched so it already covers the
// v1.1 four-θ fit names; in v1.0 the engine only logs the touch-up
// offset, but the others are documented as deferred (θ fixed at 1.0).
// ============================================================================

const CRT_CATEGORY_NAME: Record<string, string> = {
  "4A": "Forest Land",
  "4B": "Cropland",
  "4C": "Grassland",
  "4D": "Wetlands",
  "4E": "Settlements",
  "4F": "Other Land",
  "4G": "Harvested Wood Products",
  "4_total": "Sector-4 total",
};

/**
 * Return a plain-language description (incl. design-doc section) for a
 * parameter-log name, or null if no glossary entry matches.
 */
function paramGlossary(name: string): string | null {
  const touchup = name.match(/^touchup_offset_T0\[(.+)\]$/);
  if (touchup) {
    const cat = touchup[1];
    const label = CRT_CATEGORY_NAME[cat] ?? cat;
    return (
      `Touch-up anchor offset for ${cat} (${label}). This is the gap ` +
      `between your reported inventory and the raw model in the last ` +
      `historical year, applied as an additive correction that fades over ` +
      `a 5-year half-life so the projection starts exactly from your ` +
      `inventory. See LULUCF_v1_DESIGN.md §2.3.2.`
    );
  }
  if (name.startsWith("theta_FL_bio"))
    return (
      "Level-0 calibration scale on forest biomass growth and loss. Part " +
      "of the v1.1 four-θ fit; fixed at 1.0 in v1.0 (touch-up absorbs the " +
      "emission level instead). See LULUCF_v1_DESIGN.md §2.3.1."
    );
  if (name.startsWith("theta_soil"))
    return (
      "Level-0 calibration scale on mineral-soil carbon. v1.1 four-θ fit; " +
      "fixed at 1.0 in v1.0. See LULUCF_v1_DESIGN.md §2.3.1."
    );
  if (name.startsWith("theta_org"))
    return (
      "Level-0 calibration scale on drained organic-soil emissions. v1.1 " +
      "four-θ fit; fixed at 1.0 in v1.0. See LULUCF_v1_DESIGN.md §2.3.1."
    );
  if (name.startsWith("theta_conv"))
    return (
      "Level-0 calibration scale on land-conversion (deforestation) " +
      "carbon loss. v1.1 four-θ fit; fixed at 1.0 in v1.0. See " +
      "LULUCF_v1_DESIGN.md §2.3.1."
    );
  if (name.startsWith("b_max"))
    return (
      "Chapman-Richards asymptotic maximum above-ground biomass density " +
      "for the forest type. See LULUCF_v1_DESIGN.md §2.2 (Layer B2)."
    );
  if (name.startsWith("k_DOM"))
    return (
      "First-order decay constant for dead organic matter (litter + dead " +
      "wood). Temperature-dependent. See LULUCF_v1_DESIGN.md §2.2 (B3)."
    );
  if (name.startsWith("k_SOC"))
    return (
      "Relaxation rate of soil organic carbon toward its land-use " +
      "reference density. See LULUCF_v1_DESIGN.md §2.2 (B4)."
    );
  return null;
}

/**
 * Parse a CSV with a header row to an array of dicts. Values are coerced
 * to numbers if they parse as numeric, else kept as string. Unknown
 * separators (commas, semicolons, tabs, whitespace) are auto-detected.
 */
function parseNamedCsv(text: string): Array<Record<string, unknown>> {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !l.startsWith("#"));
  if (lines.length < 2) return [];
  const sep = /[,;\t]/.test(lines[0]) ? /[,;\t]/ : /\s+/;
  const header = lines[0].split(sep).map((h) => h.trim()).filter(Boolean);
  if (header.length === 0) return [];
  const rows: Array<Record<string, unknown>> = [];
  for (const line of lines.slice(1)) {
    const parts = line.split(sep).map((p) => p.trim()).filter((p) => p.length > 0);
    if (parts.length === 0) continue;
    const row: Record<string, unknown> = {};
    header.forEach((h, i) => {
      const raw = parts[i];
      if (raw === undefined) {
        row[h] = null;
        return;
      }
      const num = Number(raw);
      row[h] = Number.isFinite(num) ? num : raw;
    });
    rows.push(row);
  }
  return rows;
}

// ============================================================================
// CsvField — drop-target upload widget for one named-CSV input
// ============================================================================

interface CsvFieldProps {
  label: string;
  required?: boolean;
  description?: React.ReactNode;
  expectedColumns: string[];
  value: Array<Record<string, unknown>> | null;
  onChange: (rows: Array<Record<string, unknown>> | null) => void;
  // G5 (UX audit): if a refDB-derived default is available for this
  // field, render an "Auto-fill from refDB" button next to "Upload".
  // The builder returns the rows ready to be applied.
  refdbDefault?: {
    label: string;
    build: () => Array<Record<string, unknown>>;
  };
}

function CsvField({
  label,
  required,
  description,
  expectedColumns,
  value,
  onChange,
  refdbDefault,
}: CsvFieldProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const handleFile = async (f: File) => {
    setErr(null);
    try {
      const text = await f.text();
      const rows = parseNamedCsv(text);
      if (rows.length === 0) {
        setErr("Parsed 0 rows — check the file format.");
        onChange(null);
        return;
      }
      const cols = new Set(Object.keys(rows[0]));
      const missing = expectedColumns.filter((c) => !cols.has(c));
      if (missing.length > 0) {
        setErr(`Missing required columns: ${missing.join(", ")}`);
        onChange(null);
        return;
      }
      onChange(rows);
    } catch (e) {
      setErr(`Failed to read file: ${(e as Error).message}`);
      onChange(null);
    }
  };

  const nrows = value?.length ?? 0;

  return (
    <div className="space-y-1">
      <Label className="flex items-center gap-2 text-sm">
        <span className="font-medium">{label}</span>
        {required && <span className="text-red-500">*</span>}
        {nrows > 0 && (
          <span className="ml-auto rounded bg-emerald-50 px-2 py-0.5 text-xs text-emerald-700">
            {nrows} rows
          </span>
        )}
      </Label>
      {description && (
        <p className="text-xs text-muted-foreground">{description}</p>
      )}
      <p className="text-[10px] text-muted-foreground">
        Expected columns:{" "}
        <code className="font-mono">{expectedColumns.join(", ")}</code>
      </p>
      <div className="flex flex-wrap items-center gap-2">
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.tsv,.txt"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
            e.target.value = "";
          }}
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => inputRef.current?.click()}
        >
          {nrows > 0 ? "Replace file" : "Upload CSV"}
        </Button>
        {refdbDefault && nrows === 0 && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setErr(null);
              try {
                onChange(refdbDefault.build());
              } catch (e) {
                setErr(`Auto-fill failed: ${(e as Error).message}`);
              }
            }}
            title={refdbDefault.label}
          >
            <Wand2 className="mr-1 h-3 w-3" />
            Auto-fill from refDB
          </Button>
        )}
        {nrows > 0 && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              onChange(null);
              setErr(null);
            }}
          >
            Clear
          </Button>
        )}
      </div>
      {err && (
        <p className="text-xs text-red-600">{err}</p>
      )}
    </div>
  );
}

// ============================================================================
// Severity helpers (mirror the macro page)
// ============================================================================

function isBlockingTest(testId: string): boolean {
  return testId === "T1" || testId === "T2" || testId === "T5";
}

function SeverityIcon({ severity, blocking }: { severity: string; blocking?: boolean }) {
  if (severity === "red") {
    return blocking ? (
      <Lock className="h-4 w-4 text-red-600" />
    ) : (
      <AlertCircle className="h-4 w-4 text-red-600" />
    );
  }
  if (severity === "amber") return <AlertCircle className="h-4 w-4 text-amber-600" />;
  return <Info className="h-4 w-4 text-sky-600" />;
}

// ============================================================================
// formatRunError — UX audit G10 fix (plain-language errors)
// ============================================================================

/**
 * Convert a Pydantic / API error into a plain-language message the
 * user can act on. Falls back to the raw error message when no
 * pattern matches.
 */
function formatRunError(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  // Pydantic v2 list-too-long. Match the stable error type ("too_long"
  // / "list_too_long", carried through by stringifyDetail) as well as
  // the human wording ("at most 5000 items"), so this fires even if the
  // Pydantic message text drifts in a future upgrade.
  if (/too_long|at most \d+ items|max_length/i.test(msg)) {
    return (
      "Your input has more rows than the API accepts (max 5,000 per " +
      "list). Aggregate to national level (or per-category if you " +
      "had sub-regional rows), or split by sub-region and run each " +
      "as a separate project."
    );
  }
  if (/Missing required columns/.test(msg)) {
    return (
      `${msg} (one of your CSV files is missing a required column ` +
      "header; check the 'Expected columns' line in each upload widget)."
    );
  }
  if (/ISO3/i.test(msg)) {
    return (
      "Country must be a 3-letter ISO code (e.g. CRI, FIN, JPN). " +
      "Use the dropdown or type the ISO3."
    );
  }
  if (/no overlap/i.test(msg)) {
    return (
      "Macro inputs (SGDP_primary, heads) do not overlap with the " +
      "historical inventory years. Run the macro module first, then " +
      "feed its result years through here."
    );
  }
  return msg;
}

// ============================================================================
// ProfileMismatchHint — UX audit G7 fix
// ============================================================================

/**
 * Detect which LULUCF profile the engine would infer from the supplied
 * PAM/projected inputs. Mirrors `ProjectedLULUCF.detect_profile()` in
 * `g_LULUCF_Schemas.py`.
 */
function detectImpliedProfile(args: {
  hasProjLandAreas: boolean;
  hasProjTransitions: boolean;
  hasNationalEfs: boolean;
  hasFullInventoryProjection: boolean;
}): LulucfProfile {
  if (args.hasFullInventoryProjection) return "L-E";
  if (args.hasNationalEfs) return "L-D";
  if (args.hasProjTransitions) return "L-C";
  if (args.hasProjLandAreas) return "L-B";
  return "L-A";
}

function ProfileMismatchHint(props: {
  profile: LulucfProfile;
  hasProjLandAreas: boolean;
  hasProjTransitions: boolean;
  hasNationalEfs: boolean;
  hasFullInventoryProjection: boolean;
  onPickProfile: (p: LulucfProfile) => void;
}) {
  const implied = detectImpliedProfile(props);
  if (implied === props.profile) {
    return (
      <div className="flex items-center gap-2 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">
        <CheckCircle2 className="h-4 w-4" />
        <span>
          Profile <strong>{props.profile}</strong> matches the inputs
          you&apos;ve supplied.
        </span>
      </div>
    );
  }
  // Mismatch: the user picked a profile that needs more inputs than
  // they've supplied, OR they've supplied more inputs than the profile
  // uses.
  const requirements: Record<LulucfProfile, string> = {
    "L-A": "no future inputs needed",
    "L-B": "projected land areas",
    "L-C": "projected transition matrix (plus L-B inputs)",
    "L-D": "national emission factors (plus L-C inputs)",
    "L-E": "full inventory projection",
  };
  const sevClass =
    implied === "L-A"
      ? "bg-amber-50 text-amber-800"
      : "bg-sky-50 text-sky-800";
  return (
    <div
      className={cn(
        "flex items-start gap-2 rounded-md px-3 py-2 text-xs",
        sevClass,
      )}
    >
      <Info className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="flex-1">
        <p>
          You picked profile <strong>{props.profile}</strong> (
          {requirements[props.profile]}), but your inputs match{" "}
          <strong>{implied}</strong>.{" "}
          {implied === "L-A" && props.profile !== "L-A" && (
            <>
              The engine will run as L-A — supply the required inputs
              for {props.profile} or accept the auto-detected profile.
            </>
          )}
          {implied !== "L-A" && (
            <>The engine will auto-detect and run as {implied}.</>
          )}
        </p>
        <button
          type="button"
          className="mt-1 text-xs font-medium underline hover:no-underline"
          onClick={() => props.onPickProfile(implied)}
        >
          Use profile {implied}
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// Section 5 — catalog-formula PAM builder (DESIGN §2.4.2)
// ============================================================================

/**
 * A client-side draft of a catalog PAM. Variable values are kept as
 * strings so partially-typed numbers (e.g. "-", "1.") don't fight the
 * input; they are coerced to numbers only at submit time. `uid` is a
 * stable React list key, never sent to the server.
 */
interface PamDraft {
  uid: string;
  catalog_id: string;
  category: string;
  scenario: "WEM" | "WAM";
  variables: Record<string, string>;
  time_distribution: "constant" | "variable";
  t0: string;
  t1: string;
  t2: string;
}

let _pamUidSeq = 0;
function nextPamUid(): string {
  _pamUidSeq += 1;
  return `pam-${_pamUidSeq}-${Math.random().toString(36).slice(2, 7)}`;
}

/** Build a fresh draft for a catalog entry, pre-filling variable defaults. */
function newPamDraft(entry: PamCatalogEntry, defaultT0: number): PamDraft {
  const variables: Record<string, string> = {};
  for (const v of entry.variables) {
    variables[v.alias] = v.default != null ? String(v.default) : "";
  }
  return {
    uid: nextPamUid(),
    catalog_id: entry.catalog_id,
    category: entry.categories[0] ?? "",
    scenario: "WEM",
    variables,
    time_distribution: "constant",
    t0: String(defaultT0),
    t1: "",
    t2: "",
  };
}

/** Is this draft complete enough to submit? (all variables filled, t0 set) */
function pamDraftReady(draft: PamDraft, entry: PamCatalogEntry | undefined): boolean {
  if (!entry) return false;
  if (draft.t0.trim() === "" || !Number.isFinite(Number(draft.t0))) return false;
  for (const v of entry.variables) {
    const raw = draft.variables[v.alias];
    if (raw == null || raw.trim() === "" || !Number.isFinite(Number(raw))) {
      return false;
    }
  }
  if (draft.time_distribution === "variable") {
    // t1/t2 optional (engine infers), but if given they must be numbers.
    for (const k of ["t1", "t2"] as const) {
      const raw = draft[k];
      if (raw.trim() !== "" && !Number.isFinite(Number(raw))) return false;
    }
  }
  return true;
}

/** Convert the UI drafts into the API PamSpec[] payload (or null if empty). */
function draftsToPamSpecs(drafts: PamDraft[]): PamSpec[] | null {
  if (drafts.length === 0) return null;
  const specs: PamSpec[] = drafts.map((d) => {
    const variables: Record<string, number> = {};
    for (const [alias, raw] of Object.entries(d.variables)) {
      if (raw != null && raw.trim() !== "" && Number.isFinite(Number(raw))) {
        variables[alias] = Number(raw);
      }
    }
    const t1 = d.t1.trim() !== "" ? Number(d.t1) : null;
    const t2 = d.t2.trim() !== "" ? Number(d.t2) : null;
    return {
      catalog_id: d.catalog_id,
      category: d.category,
      scenario: d.scenario,
      variables,
      time_distribution: d.time_distribution,
      t0: Number(d.t0),
      t1: d.time_distribution === "variable" ? t1 : null,
      t2: d.time_distribution === "variable" ? t2 : null,
    };
  });
  return specs;
}

// ----------------------------------------------------------------------------
// PamBuilder — add / edit / remove catalog PAMs (DESIGN §2.4.2)
// ----------------------------------------------------------------------------

interface PamBuilderProps {
  catalog: LulucfPamCatalog | undefined;
  isLoading: boolean;
  isError: boolean;
  drafts: PamDraft[];
  onChange: (drafts: PamDraft[]) => void;
  /** Sensible default start year for a fresh measure (the run horizon). */
  defaultT0: number;
}

function PamBuilder({
  catalog,
  isLoading,
  isError,
  drafts,
  onChange,
  defaultT0,
}: PamBuilderProps) {
  // Flat catalog_id → entry map for editor lookups.
  const entryById = useMemo(() => {
    const m = new Map<string, PamCatalogEntry>();
    if (catalog) {
      for (const entries of Object.values(catalog.subsectors)) {
        for (const e of entries) m.set(e.catalog_id, e);
      }
    }
    return m;
  }, [catalog]);

  // Controlled "add" selector — holds the catalog_id queued to add.
  const [pendingId, setPendingId] = useState<string>("");

  const addPam = () => {
    const entry = entryById.get(pendingId);
    if (!entry) return;
    onChange([...drafts, newPamDraft(entry, defaultT0)]);
    setPendingId("");
  };

  const patchDraft = (uid: string, patch: Partial<PamDraft>) => {
    onChange(drafts.map((d) => (d.uid === uid ? { ...d, ...patch } : d)));
  };

  const patchVariable = (uid: string, alias: string, value: string) => {
    onChange(
      drafts.map((d) =>
        d.uid === uid
          ? { ...d, variables: { ...d.variables, [alias]: value } }
          : d,
      ),
    );
  };

  const removeDraft = (uid: string) => {
    onChange(drafts.filter((d) => d.uid !== uid));
  };

  if (isLoading) {
    return (
      <p className="text-sm text-muted-foreground">Loading PAM catalog…</p>
    );
  }
  if (isError || !catalog) {
    return (
      <p className="text-sm text-red-600">
        Could not load the PAM catalog. Reload the page and try again.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Each measure is evaluated from its IPCC catalog formula to a kt CO₂-eq/yr
        reduction and subtracted from the WoM baseline to build the WEM and WAM
        scenarios. A measure targets one CRT category and rolls out from its
        start year (constant, or a logistic ramp to a 100%-year).
      </p>

      {/* Add-PAM row */}
      <div className="flex flex-wrap items-end gap-2 rounded-md border border-dashed bg-muted/30 p-3">
        <div className="min-w-[260px] flex-1">
          <Label className="text-xs">Add a measure from the catalog</Label>
          <select
            className="mt-1 w-full rounded border bg-background px-3 py-2 text-sm"
            value={pendingId}
            onChange={(e) => setPendingId(e.target.value)}
          >
            <option value="">— select a measure —</option>
            {Object.entries(catalog.subsectors).map(([subsector, entries]) => (
              <optgroup key={subsector} label={subsector}>
                {entries.map((e) => (
                  <option key={e.catalog_id} value={e.catalog_id}>
                    {e.name}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>
        <Button type="button" size="sm" onClick={addPam} disabled={pendingId === ""}>
          <Plus className="mr-1 h-4 w-4" /> Add
        </Button>
      </div>

      {/* Draft list */}
      {drafts.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No measures added — the run will produce a WoM baseline only.
        </p>
      ) : (
        <div className="space-y-3">
          {drafts.map((draft) => (
            <PamDraftCard
              key={draft.uid}
              draft={draft}
              entry={entryById.get(draft.catalog_id)}
              ready={pamDraftReady(draft, entryById.get(draft.catalog_id))}
              crtLabels={catalog.crt_labels}
              onPatch={(patch) => patchDraft(draft.uid, patch)}
              onVariable={(alias, value) => patchVariable(draft.uid, alias, value)}
              onRemove={() => removeDraft(draft.uid)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface PamDraftCardProps {
  draft: PamDraft;
  entry: PamCatalogEntry | undefined;
  ready: boolean;
  crtLabels: Record<string, string>;
  onPatch: (patch: Partial<PamDraft>) => void;
  onVariable: (alias: string, value: string) => void;
  onRemove: () => void;
}

function PamDraftCard({
  draft,
  entry,
  ready,
  crtLabels,
  onPatch,
  onVariable,
  onRemove,
}: PamDraftCardProps) {
  if (!entry) {
    return (
      <div className="flex items-center justify-between rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
        <span>
          Unknown catalog entry{" "}
          <span className="font-mono">{draft.catalog_id}</span>.
        </span>
        <button type="button" onClick={onRemove} className="underline">
          remove
        </button>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "space-y-3 rounded-md border p-3",
        ready
          ? "border-emerald-200 bg-emerald-50/30"
          : "border-amber-200 bg-amber-50/30",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-sm font-medium">{entry.name}</p>
          <p className="font-mono text-xs text-muted-foreground">
            {entry.formula}
          </p>
        </div>
        <button
          type="button"
          onClick={onRemove}
          className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-red-600"
          title="Remove this measure"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      {/* Category · scenario · roll-out · start-year */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <div>
          <Label className="text-xs">CRT category</Label>
          <select
            className="mt-1 w-full rounded border bg-background px-2 py-1.5 text-sm"
            value={draft.category}
            onChange={(e) => onPatch({ category: e.target.value })}
          >
            {entry.categories.map((c) => (
              <option key={c} value={c}>
                {c} · {crtLabels[c] ?? c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label className="text-xs">Scenario</Label>
          <select
            className="mt-1 w-full rounded border bg-background px-2 py-1.5 text-sm"
            value={draft.scenario}
            onChange={(e) =>
              onPatch({ scenario: e.target.value as "WEM" | "WAM" })
            }
          >
            <option value="WEM">WEM (existing)</option>
            <option value="WAM">WAM (additional)</option>
          </select>
        </div>
        <div>
          <Label className="text-xs">Roll-out</Label>
          <select
            className="mt-1 w-full rounded border bg-background px-2 py-1.5 text-sm"
            value={draft.time_distribution}
            onChange={(e) =>
              onPatch({
                time_distribution: e.target.value as "constant" | "variable",
              })
            }
          >
            <option value="constant">Constant from t0</option>
            <option value="variable">Logistic ramp</option>
          </select>
        </div>
        <div>
          <Label className="text-xs">Start year (t0)</Label>
          <Input
            type="number"
            className="mt-1"
            value={draft.t0}
            onChange={(e) => onPatch({ t0: e.target.value })}
          />
        </div>
      </div>

      {/* Logistic ramp years (only when ramping) */}
      {draft.time_distribution === "variable" && (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <div>
            <Label className="text-xs">50%-year (t1, optional)</Label>
            <Input
              type="number"
              className="mt-1"
              value={draft.t1}
              placeholder="auto"
              onChange={(e) => onPatch({ t1: e.target.value })}
            />
          </div>
          <div>
            <Label className="text-xs">100%-year (t2, optional)</Label>
            <Input
              type="number"
              className="mt-1"
              value={draft.t2}
              placeholder="auto"
              onChange={(e) => onPatch({ t2: e.target.value })}
            />
          </div>
        </div>
      )}

      {/* Formula inputs */}
      <div>
        <Label className="text-xs">Formula inputs</Label>
        <div className="mt-1 grid grid-cols-2 gap-3 md:grid-cols-3">
          {entry.variables.map((v) => (
            <div key={v.alias}>
              <label
                className="text-xs text-muted-foreground"
                title={v.name}
              >
                <span className="font-mono">{v.alias}</span>
                {v.unit ? ` · ${v.unit}` : ""}
              </label>
              <Input
                type="number"
                className="mt-0.5"
                value={draft.variables[v.alias] ?? ""}
                onChange={(e) => onVariable(v.alias, e.target.value)}
              />
            </div>
          ))}
        </div>
      </div>

      {!ready && (
        <p className="text-xs text-amber-700">
          Fill every formula input and a valid start year to include this
          measure in the run.
        </p>
      )}
    </div>
  );
}

// ============================================================================
// Main page
// ============================================================================

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function LulucfPage({ params }: PageProps) {
  const { id: projectId } = use(params);

  // --- Config state ---
  const [country, setCountry] = useState<string>("CRI");
  const [countryMode, setCountryMode] = useState<"refdb" | "custom">("refdb");
  const [region, setRegion] = useState<MacroRegion>("LAC");
  const [horizon, setHorizon] = useState<number>(2050);
  const [climateZone, setClimateZone] = useState<ClimateZone>("tropical");
  const [tier, setTier] = useState<0 | 1 | 2>(0);
  const [profile, setProfile] = useState<LulucfProfile>("L-A");
  const [touchupEnabled, setTouchupEnabled] = useState<boolean>(true);
  // G13: the touch-up trigger threshold is the one calibration lever that
  // is genuinely meaningful in v1.0 (the four θ-scales are fixed at 1.0
  // until the v1.1 Bayesian-ridge fit lands — see UX audit §7). Exposed
  // for power-user sensitivity testing; default 0.15 (±15%).
  const [touchupThreshold, setTouchupThreshold] = useState<number>(0.15);

  // G14: when the user picks a country from the refDB list, auto-derive
  // climate_zone + region. The user can still override either field.
  const applyCountryFromRefdb = (entry: LulucfCountryEntry) => {
    setCountry(entry.iso3);
    if (entry.region) setRegion(entry.region);
    if (entry.climate_zone) setClimateZone(entry.climate_zone);
  };

  // --- Mandatory historical ---
  const [inventoryEmissions, setInventoryEmissions] = useState<Array<Record<string, unknown>> | null>(null);
  const [landAreas, setLandAreas] = useState<Array<Record<string, unknown>> | null>(null);

  // --- Optional activity drivers (L3 sources) ---
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [macroHeads, setMacroHeads] = useState<Array<Record<string, unknown>> | null>(null);
  const [macroSgdpPrimary, setMacroSgdpPrimary] = useState<Array<Record<string, unknown>> | null>(null);
  const [limeApplied, setLimeApplied] = useState<Array<Record<string, unknown>> | null>(null);
  const [ureaApplied, setUreaApplied] = useState<Array<Record<string, unknown>> | null>(null);
  const [nFertApplied, setNFertApplied] = useState<Array<Record<string, unknown>> | null>(null);
  const [riceArea, setRiceArea] = useState<Array<Record<string, unknown>> | null>(null);
  const [burnedArea, setBurnedArea] = useState<Array<Record<string, unknown>> | null>(null);
  const [organicSoilArea, setOrganicSoilArea] = useState<Array<Record<string, unknown>> | null>(null);
  const [harvestVolume, setHarvestVolume] = useState<Array<Record<string, unknown>> | null>(null);
  const [pestArea, setPestArea] = useState<Array<Record<string, unknown>> | null>(null);
  const [windThrowArea, setWindThrowArea] = useState<Array<Record<string, unknown>> | null>(null);

  // --- Scenario assumptions + PAMs (UX audit G1 fix; §2.4.1 split:
  // scenario-defining inputs vs mitigation measures) ---
  const [showScenario, setShowScenario] = useState(false);
  const [showPams, setShowPams] = useState(false);
  const [projLandAreas, setProjLandAreas] = useState<Array<Record<string, unknown>> | null>(null);
  const [projTransitionMatrix, setProjTransitionMatrix] = useState<Array<Record<string, unknown>> | null>(null);
  const [projBurnedArea, setProjBurnedArea] = useState<Array<Record<string, unknown>> | null>(null);
  const [afforestationSchedule, setAfforestationSchedule] = useState<Array<Record<string, unknown>> | null>(null);
  const [deforestationPath, setDeforestationPath] = useState<Array<Record<string, unknown>> | null>(null);
  const [harvestSchedule, setHarvestSchedule] = useState<Array<Record<string, unknown>> | null>(null);
  const [rewettingSchedule, setRewettingSchedule] = useState<Array<Record<string, unknown>> | null>(null);
  const [nationalEfs, setNationalEfs] = useState<Array<Record<string, unknown>> | null>(null);
  const [fullInventoryProjection, setFullInventoryProjection] = useState<Array<Record<string, unknown>> | null>(null);

  // --- G2: scenario state ---
  const [scenarioName, setScenarioName] = useState<string>("WoM");

  // --- Section 5: catalog-formula PAM builder (DESIGN §2.4.2) ---
  const [pamDrafts, setPamDrafts] = useState<PamDraft[]>([]);

  // --- Catalog query (static) ---
  const catalogQuery = useQuery<LulucfFormsCatalog>({
    queryKey: ["lulucf-forms-catalog"],
    queryFn: () => api.getLulucfFormsCatalog(),
  });

  // --- PAM catalog query (static): the LULUCF slice of the MITICA
  //     Policies & Measures catalog drives the Section 5 builder. ---
  const pamCatalogQuery = useQuery<LulucfPamCatalog>({
    queryKey: ["lulucf-pam-catalog"],
    queryFn: () => api.getLulucfPamCatalog(),
  });

  // --- Scenarios list ---
  const scenariosQuery = useQuery<{ scenarios: LulucfScenarioEntry[] }>({
    queryKey: ["lulucf-scenarios", projectId],
    queryFn: () => api.listLulucfScenarios(projectId),
    refetchOnWindowFocus: false,
  });

  // --- Existing result for active scenario ---
  const resultQuery = useQuery<LulucfResult | null>({
    queryKey: ["lulucf-result", projectId, scenarioName],
    queryFn: async () => {
      try {
        return await api.getLulucfResult(projectId, scenarioName);
      } catch (e) {
        return null;
      }
    },
    refetchOnWindowFocus: false,
  });

  // --- Run mutation ---
  const runMutation = useMutation<LulucfResult, Error, void>({
    mutationFn: async () => {
      if (!inventoryEmissions || !landAreas) {
        throw new Error("Inventory and land areas are required.");
      }
      const req: LulucfRunRequest = {
        country,
        region,
        horizon_year: horizon,
        climate_zone: climateZone,
        tier,
        profile,
        touchup_enabled: touchupEnabled,
        touchup_residual_threshold: touchupThreshold,
        inventory_emissions: inventoryEmissions,
        land_areas: landAreas,
        macro_heads: macroHeads,
        macro_sgdp_primary: macroSgdpPrimary,
        lime_applied: limeApplied,
        urea_applied: ureaApplied,
        n_fertilizer_applied: nFertApplied,
        rice_cultivated_area: riceArea,
        burned_area: burnedArea,
        organic_soil_area: organicSoilArea,
        harvest_volume: harvestVolume,
        pest_area: pestArea,
        wind_throw_area: windThrowArea,
        // PAM / projected inputs (G1 fix)
        proj_land_areas: projLandAreas,
        proj_transition_matrix: projTransitionMatrix,
        proj_burned_area: projBurnedArea,
        afforestation_schedule: afforestationSchedule,
        deforestation_path: deforestationPath,
        harvest_schedule: harvestSchedule,
        rewetting_schedule: rewettingSchedule,
        national_efs: nationalEfs,
        full_inventory_projection: fullInventoryProjection,
        // Section 5 — catalog-formula PAMs (WEM/WAM scenarios, §2.4.2)
        pams: draftsToPamSpecs(pamDrafts),
      };
      return api.runLulucf(projectId, req, scenarioName);
    },
    onSuccess: () => {
      resultQuery.refetch();
      scenariosQuery.refetch();
    },
  });

  const result = runMutation.data ?? resultQuery.data;
  const canRun = inventoryEmissions != null && landAreas != null && !runMutation.isPending;

  // G5: refDB profile for the selected country (used by Auto-fill
  // buttons on the activity-driver CsvFields).
  const refdbCountry = useMemo(() => {
    return catalogQuery.data?.countries.find((c) => c.iso3 === country) ?? null;
  }, [catalogQuery.data, country]);

  // Anchor year for refDB auto-fill: prefer the latest year in the
  // user-supplied inventory; fall back to the current year - 2.
  const anchorYearForAutofill = useMemo(() => {
    if (inventoryEmissions && inventoryEmissions.length > 0) {
      const years = inventoryEmissions
        .map((r) => Number(r.Year))
        .filter((y) => Number.isFinite(y));
      if (years.length > 0) return Math.max(...years);
    }
    return new Date().getFullYear() - 2;
  }, [inventoryEmissions]);

  return (
    // `lulucf-root` anchors the G16 print stylesheet (styles/globals.css):
    // on window.print() everything here is hidden except `.lulucf-print`.
    <div className="lulucf-root space-y-6 p-6">
      <div className="flex items-center gap-3">
        <TreePine className="h-7 w-7 text-emerald-600" />
        <div className="flex-1">
          <h1 className="text-2xl font-semibold">LULUCF module</h1>
          <p className="text-sm text-muted-foreground">
            Sector 4 projection (CRT 4A-4G). Opt-in sectoral module
            feeding MITICA Core via SI-008. Activating it overrides ANNALIST
            for ONLY its own categories (CRT-4: 4A–4G); every other category in
            the inventory still projects with ANNALIST using your proxies.
          </p>
        </div>
        {/* G12: Methodology link */}
        <a
          href="https://github.com/JChornetGauss/MITICA-2.0/blob/feature/refinements-bi001-modules-rebrand/docs/LULUCF_v1_DESIGN.md"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 rounded-md border bg-background px-3 py-1.5 text-xs hover:bg-muted"
          title="Open LULUCF_v1_DESIGN.md (full methodology + equations + decisions)"
        >
          <BookOpen className="h-3.5 w-3.5" />
          Methodology
        </a>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>1 · Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
            <div className="md:col-span-3">
              <Label htmlFor="country">Country</Label>
              {countryMode === "refdb" ? (
                <div className="flex items-center gap-2">
                  <select
                    id="country"
                    value={country}
                    onChange={(e) => {
                      const iso3 = e.target.value;
                      const entry = catalogQuery.data?.countries.find(
                        (c) => c.iso3 === iso3,
                      );
                      if (entry) {
                        applyCountryFromRefdb(entry);
                      } else {
                        setCountry(iso3);
                      }
                    }}
                    className="flex-1 rounded border bg-background px-3 py-2 text-sm"
                  >
                    {(catalogQuery.data?.countries ?? []).map((c) => (
                      <option key={c.iso3} value={c.iso3}>
                        {c.name} ({c.iso3}) — {c.climate_zone ?? "?"}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className="text-xs underline text-muted-foreground hover:no-underline"
                    onClick={() => setCountryMode("custom")}
                  >
                    Other (type ISO3)
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Input
                    id="country"
                    value={country}
                    maxLength={3}
                    onChange={(e) => setCountry(e.target.value.toUpperCase())}
                    placeholder="ISO3 (e.g. CRI)"
                  />
                  <button
                    type="button"
                    className="text-xs underline text-muted-foreground hover:no-underline"
                    onClick={() => setCountryMode("refdb")}
                  >
                    Pick from refDB
                  </button>
                </div>
              )}
              {countryMode === "refdb" && (
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Region and climate zone auto-fill from refDB
                  {catalogQuery.data?.refdb_metadata?.version
                    ? ` (${catalogQuery.data.refdb_metadata.version})`
                    : ""}
                  . Edit either below to override.
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="region">Region</Label>
              <select
                id="region"
                value={region}
                onChange={(e) => setRegion(e.target.value as MacroRegion)}
                className="w-full rounded border bg-background px-3 py-2 text-sm"
              >
                {(["LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS"] as const).map(
                  (r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ),
                )}
              </select>
            </div>
            <div>
              <Label htmlFor="climate">Climate zone</Label>
              <select
                id="climate"
                value={climateZone}
                onChange={(e) => setClimateZone(e.target.value as ClimateZone)}
                className="w-full rounded border bg-background px-3 py-2 text-sm"
              >
                <option value="tropical">tropical</option>
                <option value="temperate">temperate</option>
                <option value="boreal">boreal</option>
              </select>
            </div>
            <div>
              <Label htmlFor="horizon">Horizon year</Label>
              <Input
                id="horizon"
                type="number"
                value={horizon}
                min={2025}
                max={2100}
                onChange={(e) => setHorizon(Number(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="tier">Tier</Label>
              <select
                id="tier"
                value={tier}
                onChange={(e) => setTier(Number(e.target.value) as 0 | 1 | 2)}
                className="w-full rounded border bg-background px-3 py-2 text-sm"
              >
                <option value={0}>0 — inventory + country only</option>
                <option value={1}>1 — + historical areas / burned area</option>
                <option value={2}>2 — + national forest inventory</option>
              </select>
              {/* G19: tier auto-suggest */}
              <TierAutoSuggest
                currentTier={tier}
                hasBurnedArea={burnedArea != null}
                hasOrganicSoilArea={organicSoilArea != null}
                hasNationalEfs={nationalEfs != null}
                onSuggest={setTier}
              />
            </div>
            <div>
              <Label htmlFor="profile">Profile</Label>
              <select
                id="profile"
                value={profile}
                onChange={(e) => setProfile(e.target.value as LulucfProfile)}
                className="w-full rounded border bg-background px-3 py-2 text-sm"
              >
                {(["L-A", "L-B", "L-C", "L-D", "L-E"] as const).map((p) => (
                  <option key={p} value={p}>
                    {p}
                    {catalogQuery.data
                      ? ` — ${catalogQuery.data.profile_descriptions[p]}`
                      : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={touchupEnabled}
              onChange={(e) => setTouchupEnabled(e.target.checked)}
            />
            Touch-up enabled (anchor projection to reported inventory)
          </label>
          {touchupEnabled && (
            <div className="flex flex-wrap items-center gap-2 pl-6 text-xs text-muted-foreground">
              <Label htmlFor="touchup-threshold" className="text-xs">
                Trigger threshold
              </Label>
              <Input
                id="touchup-threshold"
                type="number"
                min={0.01}
                max={0.99}
                step={0.01}
                value={touchupThreshold}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  if (Number.isFinite(v) && v > 0 && v < 1) {
                    setTouchupThreshold(v);
                  }
                }}
                className="h-7 w-20 text-xs"
              />
              <span>
                fraction (default 0.15 = ±15%). Touch-up fires only when the
                model misses your inventory by more than this. Lower it to
                anchor more aggressively; raise it to let the physical model
                stand. The four θ-scales are fixed at 1.0 in v1.0 (see
                Methodology §2.3).
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>2 · Mandatory inputs</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <CsvField
            label="Inventory emissions (calibration target)"
            required
            description={
              <>
                Reported LULUCF inventory in kt of the native gas. The
                engine will reproduce this at the last historical year
                via touch-up. Category in <code>4A..4G</code>, OR the
                sentinel <code>4_total</code> if your country only
                reports the aggregate Sector-4 total (e.g. some
                Non-Annex I BURs) — that triggers the 4→2 parameter
                collapse path described in LULUCF_v1_DESIGN.md §2.3.
              </>
            }
            expectedColumns={["Year", "Category", "Gas", "Emissions"]}
            value={inventoryEmissions}
            onChange={setInventoryEmissions}
          />
          <CsvField
            label="Land areas (per CRT category)"
            required
            description={
              <>
                Historical land area per CRT category (4A-4F). Sum
                across categories must equal the constant national
                area.{" "}
                {refdbCountry?.total_area_kha
                  ? `For ${refdbCountry.name}, refDB has total area = ${refdbCountry.total_area_kha.toLocaleString()} kha.`
                  : ""}
              </>
            }
            expectedColumns={["Year", "Category", "Area_kha"]}
            value={landAreas}
            onChange={setLandAreas}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <button
            type="button"
            className="flex w-full items-center justify-between text-left"
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            <CardTitle>3 · Activity drivers (optional)</CardTitle>
            {showAdvanced ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </button>
        </CardHeader>
        {showAdvanced && (
          <CardContent className="space-y-5">
            <p className="text-xs text-muted-foreground">
              All optional. When missing, the source contributes zero in
              v1.0 (Phase L8 will load FAOSTAT defaults). Macro outputs
              (heads, SGDP_primary) are read from the project&apos;s saved
              macro result at solver time when not supplied here.
            </p>
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <CsvField
                label="Macro: livestock heads"
                description="From the macro module's out.heads (drives manure N2O on 4B/4C)."
                expectedColumns={["Year", "Heads"]}
                value={macroHeads}
                onChange={setMacroHeads}
              />
              <CsvField
                label="Macro: SGDP primary"
                description="Primary value added (drives L_agric internally)."
                expectedColumns={["Year", "SGDP_primary"]}
                value={macroSgdpPrimary}
                onChange={setMacroSgdpPrimary}
              />
              <CsvField
                label="Lime applied"
                description="CO2 from agricultural lime → 4B."
                expectedColumns={["Year", "Lime_kt"]}
                value={limeApplied}
                onChange={setLimeApplied}
              />
              <CsvField
                label="Urea applied"
                description="CO2 from urea hydrolysis → 4B."
                expectedColumns={["Year", "Urea_kt"]}
                value={ureaApplied}
                onChange={setUreaApplied}
              />
              <CsvField
                label="N fertiliser applied"
                description="N2O direct + indirect (4B 70% / 4C 30%)."
                expectedColumns={["Year", "N_kt"]}
                value={nFertApplied}
                onChange={setNFertApplied}
              />
              <CsvField
                label="Rice cultivated area"
                description="CH4 from rice → 4B."
                expectedColumns={["Year", "Area_kha"]}
                value={riceArea}
                onChange={setRiceArea}
              />
              <CsvField
                label="Burned area (per category)"
                description="Wildfire CH4 / N2O on 4A; CO2 from B6 combustion."
                expectedColumns={["Year", "Category", "BurnedArea_kha"]}
                value={burnedArea}
                onChange={setBurnedArea}
                refdbDefault={
                  refdbCountry?.burned_area_kha_mean
                    ? {
                        label: `Use refDB mean: ${refdbCountry.burned_area_kha_mean} kha/yr on 4A`,
                        build: () => [
                          {
                            Year: anchorYearForAutofill,
                            Category: "4A",
                            BurnedArea_kha: refdbCountry.burned_area_kha_mean!,
                          },
                        ],
                      }
                    : undefined
                }
              />
              <CsvField
                label="Drained organic-soil area"
                description="CO2 + N2O + CH4 (4B/4C/4D) per Wetlands Supplement EFs."
                expectedColumns={["Year", "Category", "DrainedArea_kha"]}
                value={organicSoilArea}
                onChange={setOrganicSoilArea}
                refdbDefault={
                  refdbCountry?.organic_soil_area_kha
                    ? {
                        label: `Use refDB total: ${refdbCountry.organic_soil_area_kha} kha split 50/30/20 across 4B/4C/4D`,
                        build: () => {
                          const total = refdbCountry.organic_soil_area_kha!;
                          return [
                            {
                              Year: anchorYearForAutofill,
                              Category: "4B",
                              DrainedArea_kha: total * 0.5,
                            },
                            {
                              Year: anchorYearForAutofill,
                              Category: "4C",
                              DrainedArea_kha: total * 0.3,
                            },
                            {
                              Year: anchorYearForAutofill,
                              Category: "4D",
                              DrainedArea_kha: total * 0.2,
                            },
                          ];
                        },
                      }
                    : undefined
                }
              />
              <CsvField
                label="Harvest volume"
                description="m³ of industrial roundwood — feeds B7 HWP first-order decay."
                expectedColumns={["Year", "Volume_m3"]}
                value={harvestVolume}
                onChange={setHarvestVolume}
                refdbDefault={
                  refdbCountry?.wood_removals_m3_per_year
                    ? {
                        label: `Use refDB FAOSTAT removals: ${refdbCountry.wood_removals_m3_per_year.toLocaleString()} m³/yr`,
                        build: () => [
                          {
                            Year: anchorYearForAutofill,
                            Volume_m3: refdbCountry.wood_removals_m3_per_year!,
                          },
                        ],
                      }
                    : undefined
                }
              />
              <CsvField
                label="Pest-affected area (4A)"
                description="Forest area affected by pest events. Feeds B6 partial-mortality flux to DOM (no atmospheric flux)."
                expectedColumns={["Year", "Category", "Area_kha"]}
                value={pestArea}
                onChange={setPestArea}
              />
              <CsvField
                label="Wind throw area (4A)"
                description="Forest area affected by wind throw events. Feeds B6 biomass to DOM."
                expectedColumns={["Year", "Category", "Area_kha"]}
                value={windThrowArea}
                onChange={setWindThrowArea}
              />
            </div>
          </CardContent>
        )}
      </Card>

      {/* Section 4 — Scenario assumptions: inputs that DEFINE the
          baseline/scenario trajectory (profile-unlockers + activity
          paths). NOT mitigation measures. See DESIGN §2.4.1. */}
      <Card>
        <CardHeader>
          <button
            type="button"
            className="flex w-full items-center justify-between text-left"
            onClick={() => setShowScenario(!showScenario)}
          >
            <CardTitle>4 · Scenario assumptions</CardTitle>
            {showScenario ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </button>
        </CardHeader>
        {showScenario && (
          <CardContent className="space-y-5">
            <p className="text-xs text-muted-foreground">
              All optional. These inputs <strong>define the scenario
              trajectory itself</strong> (the WoM baseline, or any named
              scenario) — what the country&apos;s land use and activity
              look like absent any single measure. They unlock the higher
              LULUCF profiles (L-B through L-E). They are{" "}
              <strong>not</strong> mitigation measures: changing them moves
              the whole baseline. Mitigation levers go in section 5. See
              LULUCF_v1_DESIGN.md §2.4 / §2.4.1.
            </p>
            <ProfileMismatchHint
              profile={profile}
              hasProjLandAreas={projLandAreas != null}
              hasProjTransitions={projTransitionMatrix != null}
              hasNationalEfs={nationalEfs != null}
              hasFullInventoryProjection={fullInventoryProjection != null}
              onPickProfile={setProfile}
            />
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <CsvField
                label="Projected land areas (profile L-B)"
                description="Future per-CRT-category area path. Triggers profile L-B at minimum."
                expectedColumns={["Year", "Category", "Area_kha"]}
                value={projLandAreas}
                onChange={setProjLandAreas}
              />
              <CsvField
                label="Projected transition matrix (profile L-C)"
                description="Future bilateral land-use transitions. Required for profile L-C."
                expectedColumns={["Year", "From", "To", "Area_kha"]}
                value={projTransitionMatrix}
                onChange={setProjTransitionMatrix}
              />
              <CsvField
                label="National emission factors (profile L-D, Tier 2)"
                description="Country-specific EFs override IPCC defaults. Required for profile L-D."
                expectedColumns={["Category", "Gas", "EF", "Unit"]}
                value={nationalEfs}
                onChange={setNationalEfs}
              />
              <CsvField
                label="Full inventory projection (profile L-E)"
                description="Pre-computed full inventory time series. Engine only does cascade + CRT mapping. Required for profile L-E."
                expectedColumns={["Year", "Category", "Gas", "Emissions"]}
                value={fullInventoryProjection}
                onChange={setFullInventoryProjection}
              />
              <CsvField
                label="Harvest schedule (activity path)"
                description="Future industrial roundwood removals (m³) — the harvest trajectory that drives the HWP pool (B7). Overrides the historical hold-constant default. An activity assumption, not a PAM."
                expectedColumns={["Year", "Volume_m3"]}
                value={harvestSchedule}
                onChange={setHarvestSchedule}
              />
              <CsvField
                label="Projected burned area (fire regime)"
                description="Future fire regime: overrides the flat-mean (refDB) projection with an explicit per-year path. A scenario assumption — only a measure that REDUCES it vs this baseline would be a PAM."
                expectedColumns={["Year", "Category", "BurnedArea_kha"]}
                value={projBurnedArea}
                onChange={setProjBurnedArea}
              />
            </div>

            {/* Tier-2 physical realisation of the 3 forestry/wetland
                measures. These move the BASELINE physically (a new k=0
                cohort, a capped transition, an EF-class move) and unfold
                over decades. Use these OR the equivalent Section-5
                catalog PAM (afforestation / reducing deforestation /
                wetland restoration) — not both, to avoid double-counting.
                See LULUCF_v1_DESIGN.md §2.4.2 (tiering table). */}
            <div className="space-y-3 rounded-md border border-dashed border-emerald-300/60 bg-emerald-50/40 p-4">
              <div>
                <p className="text-sm font-medium text-emerald-900">
                  Tier-2 baseline activity paths (physical realisation)
                </p>
                <p className="text-xs text-muted-foreground">
                  Optional, advanced. These realise three measures{" "}
                  <strong>physically in the process model</strong> rather
                  than as a flat catalog formula — yielding a realistic
                  multi-decade sink response. Use one of these{" "}
                  <strong>or</strong> the equivalent Section-5 catalog PAM,
                  not both (double-counting). See §2.4.2.
                </p>
              </div>
              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                <CsvField
                  label="Afforestation / reforestation (Tier 2)"
                  description="Annual area moved from cropland/grassland to forest. Creates a new 4A cohort at age 0 whose sink unfolds over decades (B1/B2). Catalog: Afforestation and reforestation."
                  expectedColumns={["Year", "Area_kha"]}
                  value={afforestationSchedule}
                  onChange={setAfforestationSchedule}
                />
                <CsvField
                  label="Reducing deforestation — cap (Tier 2)"
                  description="Annual cap on 4A → 4B/4C outflows. Scales down the macro-driven deforestation. Catalog: Reducing deforestation."
                  expectedColumns={["Year", "Area_kha"]}
                  value={deforestationPath}
                  onChange={setDeforestationPath}
                />
                <CsvField
                  label="Wetland restoration / rewetting (Tier 2)"
                  description="Annual organic-soil area moved from drained to rewetted; the area shifts to lower-EF classes (B5). Catalog: Wetland conservation/restoration + Management of organic/peaty soils."
                  expectedColumns={["Year", "Category", "Area_kha"]}
                  value={rewettingSchedule}
                  onChange={setRewettingSchedule}
                />
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Section 5 — PAMs: catalog-formula mitigation levers applied ON
          TOP of the baseline to build WEM/WAM. Each is a MITICA-catalog
          LULUCF entry whose IPCC formula is evaluated to a kt CO2-eq/yr
          mitigation and distributed over time. See DESIGN §2.4.2. */}
      <Card>
        <CardHeader>
          <button
            type="button"
            className="flex w-full items-center justify-between text-left"
            onClick={() => setShowPams(!showPams)}
          >
            <CardTitle>
              5 · PAMs (mitigation measures)
              {pamDrafts.length > 0 ? ` · ${pamDrafts.length}` : ""}
            </CardTitle>
            {showPams ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </button>
        </CardHeader>
        {showPams && (
          <CardContent className="space-y-5">
            <PamBuilder
              catalog={pamCatalogQuery.data}
              isLoading={pamCatalogQuery.isLoading}
              isError={pamCatalogQuery.isError}
              drafts={pamDrafts}
              onChange={setPamDrafts}
              defaultT0={Math.min(new Date().getFullYear(), horizon)}
            />
          </CardContent>
        )}
      </Card>

      {/* G2: scenario picker + Run button */}
      <ScenarioPicker
        active={scenarioName}
        scenarios={scenariosQuery.data?.scenarios ?? []}
        onPick={setScenarioName}
      />

      <div className="flex items-center gap-4">
        <Button onClick={() => runMutation.mutate()} disabled={!canRun} size="lg">
          <Play className="mr-2 h-4 w-4" />
          {runMutation.isPending
            ? `Running ${scenarioName}…`
            : `Run scenario "${scenarioName}"`}
        </Button>
        {!canRun && !runMutation.isPending && (
          <p className="text-sm text-muted-foreground">
            Upload inventory + land areas to enable the run button.
          </p>
        )}
        {runMutation.isError && (
          <p className="text-sm text-red-600">
            {formatRunError(runMutation.error)}
          </p>
        )}
      </div>

      {result && <ResultsPanel result={result} />}
    </div>
  );
}

// ============================================================================
// Results panel
// ============================================================================

function ResultsPanel({ result }: { result: LulucfResult }) {
  const netByYear = result.net_co2eq_by_year ?? [];
  const firstYear = netByYear[0]?.Year ?? null;
  const lastYear = netByYear[netByYear.length - 1]?.Year ?? null;
  const firstNet = netByYear[0]?.Net_LULUCF_CO2eq_kt ?? null;
  const lastNet = netByYear[netByYear.length - 1]?.Net_LULUCF_CO2eq_kt ?? null;

  // G17 (UX audit): surface the largest touchup offset magnitude in
  // the summary card.
  const maxTouchupAbs = useMemo(() => {
    const offs = result.parameter_log
      .filter((p) => p.origin === "touchup")
      .map((p) => Math.abs(p.value));
    return offs.length > 0 ? Math.max(...offs) : null;
  }, [result.parameter_log]);

  // G16: filename prefix for downloads
  const countryTag = (result.country ?? "lulucf").toLowerCase();

  const emissionsAtHorizon = useMemo(() => {
    if (!lastYear) return [];
    return result.emissions.filter((r) => r.Year === lastYear);
  }, [result.emissions, lastYear]);

  const emissionsByCat = useMemo(() => {
    const grouped = new Map<CrtCategory, number>();
    for (const row of emissionsAtHorizon) {
      grouped.set(row.Category, (grouped.get(row.Category) ?? 0) + row.Emissions_CO2eq_kt);
    }
    return Array.from(grouped.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [emissionsAtHorizon]);

  const extrapolated = Object.entries(result.extrapolated_inputs).filter(([, v]) => v);

  return (
    // `lulucf-print` is the only subtree that survives window.print()
    // (G16 print stylesheet in styles/globals.css).
    <div className="lulucf-print space-y-6">
      {/* G15: plain-language narrative summary */}
      <NarrativeSummary result={result} />

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            Result summary
          </CardTitle>
          {/* G16: CRT XLSX + PDF report exports for BTR submission */}
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                downloadCrtXlsx(
                  result,
                  `MITICA_LULUCF_CRT_${countryTag}.xlsx`,
                ).catch((e) =>
                  alert(
                    `Could not build the Excel file: ${
                      (e as Error).message
                    }. Use the per-table CSV buttons instead.`,
                  ),
                )
              }
              title="Download a CRT-shaped Excel workbook (net flux, per-category × gas × year emissions, HWP, metadata) for your BTR submission"
            >
              <Download className="mr-1 h-3 w-3" /> CRT XLSX
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => window.print()}
              title="Open the browser print dialog — choose 'Save as PDF' to export this results page as a report"
            >
              <Download className="mr-1 h-3 w-3" /> PDF report
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm md:grid-cols-4">
            <Stat label="Profile" value={result.profile_used} />
            <Stat label="Tier" value={String(result.tier_used)} />
            <Stat label="refDB" value={result.refdb_version_used} />
            <Stat label="Touch-up" value={result.touchup_applied ? "applied" : "—"} />
            {maxTouchupAbs !== null && (
              <Stat
                label="Max touch-up offset"
                value={`${maxTouchupAbs.toLocaleString(undefined, {
                  maximumFractionDigits: 0,
                })} kt CO₂-eq`}
              />
            )}
            {firstYear !== null && firstNet !== null && (
              <Stat
                label={`Net flux ${firstYear}`}
                value={`${firstNet >= 0 ? "+" : ""}${firstNet.toFixed(1)} kt CO₂-eq`}
              />
            )}
            {lastYear !== null && lastNet !== null && (
              <Stat
                label={`Net flux ${lastYear}`}
                value={`${lastNet >= 0 ? "+" : ""}${lastNet.toFixed(1)} kt CO₂-eq`}
              />
            )}
            <Stat label="Red flags" value={String(result.n_red_flags)} />
            <Stat label="Amber flags" value={String(result.n_amber_flags)} />
          </div>
        </CardContent>
      </Card>

      {/* G3: Plotly net-flux trajectory */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>Net LULUCF CO₂-eq trajectory (kt)</CardTitle>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() =>
              downloadCsv(
                `lulucf_${countryTag}_net_co2eq.csv`,
                netByYear as unknown as Array<Record<string, unknown>>,
              )
            }
            disabled={netByYear.length === 0}
          >
            <Download className="mr-1 h-3 w-3" /> CSV
          </Button>
        </CardHeader>
        <CardContent>
          <NetFluxChart rows={netByYear} />
        </CardContent>
      </Card>

      {/* Catalog-PAM scenarios (DESIGN §2.4.2): WoM/WEM/WAM net trajectory
          + per-measure ranking. Present only when the run carried PAMs. */}
      {result.scenario_net && result.scenario_net.length > 0 && (
        <Card className="border-emerald-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle>Scenario comparison — WoM / WEM / WAM net (kt CO₂-eq)</CardTitle>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                downloadCsv(
                  `lulucf_${countryTag}_scenario_net.csv`,
                  result.scenario_net as unknown as Array<Record<string, unknown>>,
                )
              }
            >
              <Download className="mr-1 h-3 w-3" /> CSV
            </Button>
          </CardHeader>
          <CardContent>
            <ScenarioNetChart rows={result.scenario_net} />
          </CardContent>
        </Card>
      )}

      {result.pam_summary && result.pam_summary.length > 0 && (
        <Card className="border-emerald-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle>PAM ranking — by total mitigation</CardTitle>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                downloadCsv(
                  `lulucf_${countryTag}_pam_summary.csv`,
                  result.pam_summary as unknown as Array<Record<string, unknown>>,
                )
              }
            >
              <Download className="mr-1 h-3 w-3" /> CSV
            </Button>
          </CardHeader>
          <CardContent>
            <PamRankingTable
              rows={result.pam_summary}
              crtLabels={result.crt_labels ?? {}}
            />
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Net LULUCF CO₂-eq — sparse table</CardTitle>
        </CardHeader>
        <CardContent>
          <NetFluxTable rows={netByYear} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>Emissions at horizon ({lastYear}) — per CRT category</CardTitle>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() =>
              downloadCsv(
                `lulucf_${countryTag}_emissions.csv`,
                result.emissions as unknown as Array<Record<string, unknown>>,
              )
            }
            disabled={result.emissions.length === 0}
          >
            <Download className="mr-1 h-3 w-3" /> Full CSV
          </Button>
        </CardHeader>
        <CardContent>
          {emissionsByCat.length === 0 ? (
            <p className="text-sm text-muted-foreground">No data.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="px-2 py-1 text-left">Category</th>
                  <th className="px-2 py-1 text-left">Label</th>
                  <th className="px-2 py-1 text-right">CO₂-eq (kt)</th>
                </tr>
              </thead>
              <tbody>
                {emissionsByCat.map(([cat, val]) => (
                  <tr key={cat} className="border-b">
                    <td className="px-2 py-1 font-mono">{cat}</td>
                    <td className="px-2 py-1 text-muted-foreground">
                      {result.crt_labels?.[cat] ?? cat}
                    </td>
                    <td className={cn("px-2 py-1 text-right tabular-nums",
                      val < 0 ? "text-emerald-600" : "text-red-600")}>
                      {val >= 0 ? "+" : ""}
                      {val.toFixed(1)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>HWP pool (4G) — kt C by product class</CardTitle>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() =>
              downloadCsv(
                `lulucf_${countryTag}_hwp.csv`,
                (result.hwp ?? []) as unknown as Array<Record<string, unknown>>,
              )
            }
            disabled={(result.hwp ?? []).length === 0}
          >
            <Download className="mr-1 h-3 w-3" /> CSV
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* G18: HWP pool line chart per product class */}
          <HwpPoolChart rows={result.hwp ?? []} />
          <HwpTable rows={result.hwp ?? []} />
        </CardContent>
      </Card>

      {extrapolated.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-amber-700">
              ⚠ Extrapolated inputs (no country data supplied)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-2 text-sm">
              These series were extrapolated from regional defaults — your
              country did not supply historical data. Numbers in the
              output that depend on them should not be published without
              additional verification.
            </p>
            <div className="flex flex-wrap gap-2">
              {extrapolated.map(([field]) => (
                <span
                  key={field}
                  className="rounded bg-amber-50 px-2 py-1 text-xs font-mono text-amber-800"
                >
                  {field}
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {result.validation_report.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Validation report</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {result.validation_report.map((f, i) => (
                <li
                  key={i}
                  className={cn(
                    "rounded border-l-4 p-3 text-sm",
                    f.severity === "red" && "border-red-500 bg-red-50",
                    f.severity === "amber" && "border-amber-500 bg-amber-50",
                    f.severity === "info" && "border-sky-500 bg-sky-50",
                  )}
                >
                  <div className="flex items-start gap-2">
                    <SeverityIcon
                      severity={f.severity}
                      blocking={f.severity === "red" && isBlockingTest(f.test_id)}
                    />
                    <div className="flex-1">
                      <p className="font-medium">
                        {f.test_id} · {f.variable}
                        {f.severity === "red" && isBlockingTest(f.test_id) && (
                          <span className="ml-2 rounded bg-red-100 px-2 py-0.5 text-xs text-red-700">
                            Blocks projection
                          </span>
                        )}
                      </p>
                      <p className="whitespace-pre-wrap text-muted-foreground">
                        {f.message}
                      </p>
                      {f.proposed_action && (
                        <p className="mt-1 text-xs">
                          <span className="font-medium">What to do:</span>{" "}
                          {f.proposed_action}
                        </p>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {result.parameter_log.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Parameter log</CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="px-2 py-1 text-left">Name</th>
                  <th className="px-2 py-1 text-right">Value</th>
                  <th className="px-2 py-1 text-left">Origin</th>
                  <th className="px-2 py-1 text-left">Note</th>
                </tr>
              </thead>
              <tbody>
                {result.parameter_log.map((p, i) => {
                  const glossary = paramGlossary(p.name);
                  return (
                  <tr key={i} className="border-b">
                    <td className="px-2 py-1 font-mono text-xs">
                      {glossary ? (
                        <span
                          className="inline-flex cursor-help items-center gap-1 underline decoration-dotted underline-offset-2"
                          title={glossary}
                        >
                          {p.name}
                          <Info className="h-3 w-3 text-muted-foreground" />
                        </span>
                      ) : (
                        p.name
                      )}
                    </td>
                    <td className="px-2 py-1 text-right tabular-nums">
                      {p.value.toFixed(3)}
                    </td>
                    <td className="px-2 py-1">
                      <span className="rounded bg-muted px-2 py-0.5 text-xs">
                        {p.origin}
                      </span>
                    </td>
                    <td className="px-2 py-1 text-xs text-muted-foreground">
                      {p.note ?? ""}
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border bg-background p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-medium tabular-nums">{value}</p>
    </div>
  );
}

// ============================================================================
// NarrativeSummary — UX audit G15 fix
// ============================================================================

/**
 * Deterministic 2-3 sentence summary of the result. Generated locally
 * from the result dict; no LLM. Mirrors the macro page's narrative
 * panel.
 */
function NarrativeSummary({ result }: { result: LulucfResult }) {
  const net = result.net_co2eq_by_year ?? [];
  if (net.length === 0) {
    return null;
  }
  const first = net[0];
  const last = net[net.length - 1];
  const country = result.country ?? "the country";

  // Net flux description: sink or source
  const fluxKind = (v: number) =>
    v < 0 ? "net sink" : v > 0 ? "net source" : "net-neutral";
  const startKind = fluxKind(first.Net_LULUCF_CO2eq_kt);
  const endKind = fluxKind(last.Net_LULUCF_CO2eq_kt);

  // Trajectory direction
  const delta = last.Net_LULUCF_CO2eq_kt - first.Net_LULUCF_CO2eq_kt;
  let trajectory: string;
  if (Math.abs(delta) < Math.abs(first.Net_LULUCF_CO2eq_kt) * 0.05) {
    trajectory = "stays roughly flat";
  } else if (delta < 0 && first.Net_LULUCF_CO2eq_kt < 0) {
    trajectory = "deepens the sink";
  } else if (delta > 0 && first.Net_LULUCF_CO2eq_kt < 0) {
    trajectory = "weakens the sink";
  } else if (delta > 0 && first.Net_LULUCF_CO2eq_kt > 0) {
    trajectory = "grows as a source";
  } else if (delta < 0 && first.Net_LULUCF_CO2eq_kt > 0) {
    trajectory = "shrinks toward neutral";
  } else {
    trajectory = "evolves";
  }

  const profileDescription: Record<LulucfProfile, string> = {
    "L-A": "minimum-input baseline",
    "L-B": "user-supplied area path",
    "L-C": "observed transition matrix",
    "L-D": "national emission factors (Tier 2)",
    "L-E": "full-inventory cascade",
  };

  // Touchup magnitude — already accessible via the parameter_log;
  // surface the largest absolute offset if any.
  const touchupOffsets = result.parameter_log
    .filter((p) => p.origin === "touchup")
    .map((p) => p.value);
  const maxTouchupAbs = touchupOffsets.length
    ? Math.max(...touchupOffsets.map(Math.abs))
    : 0;

  const flagBlurb = (() => {
    const n_red = result.n_red_flags;
    const n_amb = result.n_amber_flags;
    if (n_red === 0 && n_amb === 0) return "No validation flags fired.";
    const parts = [];
    if (n_red > 0) parts.push(`${n_red} red`);
    if (n_amb > 0) parts.push(`${n_amb} amber`);
    return `${parts.join(", ")} validation flag${
      n_red + n_amb === 1 ? "" : "s"
    } fired — review below.`;
  })();

  return (
    <Card className="border-emerald-200 bg-emerald-50/30">
      <CardContent className="space-y-2 pt-5 text-sm">
        <p>
          Your <strong>{result.profile_used}</strong> run (
          {profileDescription[result.profile_used]}) projected{" "}
          <strong>{country}</strong>&apos;s LULUCF net flux from{" "}
          <strong className={cn(
            first.Net_LULUCF_CO2eq_kt < 0 ? "text-emerald-700" : "text-red-700",
          )}>
            {first.Net_LULUCF_CO2eq_kt >= 0 ? "+" : ""}
            {first.Net_LULUCF_CO2eq_kt.toLocaleString(undefined, {
              maximumFractionDigits: 0,
            })} kt CO₂-eq
          </strong>{" "}
          ({startKind}) in {first.Year} to{" "}
          <strong className={cn(
            last.Net_LULUCF_CO2eq_kt < 0 ? "text-emerald-700" : "text-red-700",
          )}>
            {last.Net_LULUCF_CO2eq_kt >= 0 ? "+" : ""}
            {last.Net_LULUCF_CO2eq_kt.toLocaleString(undefined, {
              maximumFractionDigits: 0,
            })} kt CO₂-eq
          </strong>{" "}
          ({endKind}) in {last.Year} — trajectory {trajectory}.
        </p>
        {result.touchup_applied && maxTouchupAbs > 0 && (
          <p className="text-muted-foreground">
            Touch-up calibration applied: the unfitted model differed
            from the reported inventory at the anchor year by up to{" "}
            <strong>
              {maxTouchupAbs.toLocaleString(undefined, {
                maximumFractionDigits: 0,
              })} kt CO₂-eq
            </strong>{" "}
            (per category); the offset fades over a 5-year half-life
            into the projection.
          </p>
        )}
        <p className="text-muted-foreground">{flagBlurb}</p>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// ScenarioPicker — UX audit G2 fix
// ============================================================================

const SCENARIO_NAME_PATTERN = /^[A-Za-z][A-Za-z0-9_-]{0,31}$/;
const SUGGESTED_SCENARIOS = ["WoM", "WEM", "WAM"];

function ScenarioPicker({
  active,
  scenarios,
  onPick,
}: {
  active: string;
  scenarios: LulucfScenarioEntry[];
  onPick: (name: string) => void;
}) {
  // Union of saved + suggested + active, deduped + preserving order.
  const tabs = useMemo(() => {
    const out: string[] = [];
    const seen = new Set<string>();
    for (const name of [
      ...SUGGESTED_SCENARIOS,
      ...scenarios.map((s) => s.name),
      active,
    ]) {
      if (!seen.has(name)) {
        seen.add(name);
        out.push(name);
      }
    }
    return out;
  }, [scenarios, active]);

  const handleNew = () => {
    const raw = window.prompt(
      "New scenario name (1-32 chars; starts with a letter; A-Z, 0-9, '_', '-' allowed):",
      "Custom_v1",
    );
    if (!raw) return;
    if (!SCENARIO_NAME_PATTERN.test(raw)) {
      window.alert(
        `Invalid scenario name '${raw}'. Use 1-32 chars starting with a ` +
          "letter; allowed chars: A-Z, 0-9, '_', '-'.",
      );
      return;
    }
    onPick(raw);
  };

  return (
    <Card>
      <CardContent className="flex flex-wrap items-center gap-2 pt-5 text-sm">
        <span className="text-muted-foreground">Scenario:</span>
        {tabs.map((name) => {
          const saved = scenarios.some((s) => s.name === name);
          const isActive = name === active;
          return (
            <button
              key={name}
              type="button"
              onClick={() => onPick(name)}
              className={cn(
                "rounded-md border px-3 py-1 text-xs transition-colors",
                isActive
                  ? "border-primary bg-primary/10 font-medium"
                  : "border-border bg-background hover:bg-muted",
              )}
              title={saved ? "Saved result available" : "Not yet run"}
            >
              {name}
              {saved && <span className="ml-1 text-emerald-600">●</span>}
            </button>
          );
        })}
        <button
          type="button"
          onClick={handleNew}
          className="rounded-md border border-dashed border-border bg-background px-3 py-1 text-xs text-muted-foreground hover:bg-muted"
        >
          + New scenario
        </button>
        <p className="ml-auto text-[11px] text-muted-foreground">
          Run multiple scenarios (e.g. WoM, WEM, WAM) and switch tabs to
          compare. Each scenario has its own persisted result.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// TierAutoSuggest — UX audit G19 fix
// ============================================================================

function TierAutoSuggest({
  currentTier,
  hasBurnedArea,
  hasOrganicSoilArea,
  hasNationalEfs,
  onSuggest,
}: {
  currentTier: 0 | 1 | 2;
  hasBurnedArea: boolean;
  hasOrganicSoilArea: boolean;
  hasNationalEfs: boolean;
  onSuggest: (t: 0 | 1 | 2) => void;
}) {
  let implied: 0 | 1 | 2 = 0;
  if (hasNationalEfs) implied = 2;
  else if (hasBurnedArea || hasOrganicSoilArea) implied = 1;
  if (implied === currentTier) return null;
  if (implied < currentTier) {
    return (
      <p className="mt-1 text-[11px] text-amber-700">
        You picked Tier {currentTier} but supplied no Tier-{currentTier}
        -specific data. Consider Tier {implied}.{" "}
        <button
          type="button"
          className="underline hover:no-underline"
          onClick={() => onSuggest(implied)}
        >
          Use Tier {implied}
        </button>
      </p>
    );
  }
  return (
    <p className="mt-1 text-[11px] text-sky-700">
      You&apos;ve supplied data consistent with Tier {implied} — your
      Tier {currentTier} selection won&apos;t use it.{" "}
      <button
        type="button"
        className="underline hover:no-underline"
        onClick={() => onSuggest(implied)}
      >
        Upgrade to Tier {implied}
      </button>
    </p>
  );
}

// ============================================================================
// NetFluxChart — UX audit G3 fix
// ============================================================================

function NetFluxChart({
  rows,
}: {
  rows: { Year: number; Net_LULUCF_CO2eq_kt: number }[];
}) {
  if (rows.length === 0) {
    return <p className="text-sm text-muted-foreground">No data.</p>;
  }
  // Split into sink (negative) and source (positive) markers for
  // visual encoding. Line is single, markers coloured by sign.
  const years = rows.map((r) => r.Year);
  const values = rows.map((r) => r.Net_LULUCF_CO2eq_kt);
  const colours = values.map((v) =>
    v < 0 ? "rgb(16, 185, 129)" : "rgb(220, 38, 38)",
  );

  return (
    <PlotlyChart
      data={[
        {
          x: years,
          y: values,
          type: "scatter",
          mode: "lines+markers",
          name: "Net LULUCF",
          line: { color: "rgb(75, 85, 99)", width: 2 },
          marker: { color: colours, size: 7 },
          hovertemplate:
            "%{x}: <b>%{y:+,.0f}</b> kt CO₂-eq<extra></extra>",
        },
        // Zero reference line
        {
          x: [years[0], years[years.length - 1]],
          y: [0, 0],
          type: "scatter",
          mode: "lines",
          name: "net-neutral",
          line: { color: "rgba(150,150,150,0.6)", width: 1, dash: "dot" },
          hoverinfo: "skip",
          showlegend: false,
        },
      ]}
      layout={{
        xaxis: { title: { text: "Year" }, tickformat: "d" },
        yaxis: {
          title: { text: "Net LULUCF CO₂-eq (kt)" },
          tickformat: ",d",
          zeroline: false,
        },
      }}
      height={360}
    />
  );
}

function NetFluxTable({
  rows,
}: {
  rows: { Year: number; Net_LULUCF_CO2eq_kt: number }[];
}) {
  if (rows.length === 0) {
    return <p className="text-sm text-muted-foreground">No data.</p>;
  }
  // Sparse-by-default: show first, last, and every ~5 years in between.
  const filtered = rows.filter(
    (r, i) =>
      i === 0 ||
      i === rows.length - 1 ||
      r.Year % 5 === 0,
  );
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b">
          <th className="px-2 py-1 text-left">Year</th>
          <th className="px-2 py-1 text-right">Net (kt CO₂-eq)</th>
        </tr>
      </thead>
      <tbody>
        {filtered.map((r) => (
          <tr key={r.Year} className="border-b">
            <td className="px-2 py-1 tabular-nums">{r.Year}</td>
            <td
              className={cn(
                "px-2 py-1 text-right tabular-nums",
                r.Net_LULUCF_CO2eq_kt < 0 ? "text-emerald-600" : "text-red-600",
              )}
            >
              {r.Net_LULUCF_CO2eq_kt >= 0 ? "+" : ""}
              {r.Net_LULUCF_CO2eq_kt.toFixed(1)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ============================================================================
// ScenarioNetChart + PamRankingTable — catalog-PAM scenarios (DESIGN §2.4.2)
// ============================================================================

/**
 * WoM / WEM / WAM net trajectory. The backend emits per-category rows; we
 * aggregate to a national net per scenario per year (sum across CRT
 * categories) so the three scenarios overlay on one axis.
 */
function ScenarioNetChart({ rows }: { rows: LulucfScenarioNetRow[] }) {
  const traces = useMemo(() => {
    const order: Array<LulucfScenarioNetRow["Scenario"]> = ["WoM", "WEM", "WAM"];
    const colour: Record<string, string> = {
      WoM: "rgb(75, 85, 99)", // grey baseline
      WEM: "rgb(37, 99, 235)", // blue
      WAM: "rgb(16, 185, 129)", // emerald (deepest mitigation)
    };
    return order
      .map((scn) => {
        const byYear = new Map<number, number>();
        for (const r of rows) {
          if (r.Scenario !== scn) continue;
          byYear.set(r.Year, (byYear.get(r.Year) ?? 0) + r.Net_CO2eq_kt);
        }
        const years = Array.from(byYear.keys()).sort((a, b) => a - b);
        if (years.length === 0) return null;
        return {
          x: years,
          y: years.map((y) => byYear.get(y) ?? 0),
          type: "scatter" as const,
          mode: "lines" as const,
          name: scn,
          line: {
            color: colour[scn],
            width: 2,
            dash: scn === "WoM" ? ("dot" as const) : ("solid" as const),
          },
          hovertemplate: `${scn} %{x}: <b>%{y:+,.0f}</b> kt CO₂-eq<extra></extra>`,
        };
      })
      .filter((t): t is NonNullable<typeof t> => t !== null);
  }, [rows]);

  if (traces.length === 0) {
    return <p className="text-sm text-muted-foreground">No scenario data.</p>;
  }
  return (
    <PlotlyChart
      data={traces}
      layout={{
        xaxis: { title: { text: "Year" }, tickformat: "d" },
        yaxis: {
          title: { text: "Net LULUCF CO₂-eq (kt)" },
          tickformat: ",d",
          zeroline: true,
          zerolinecolor: "rgba(150,150,150,0.6)",
        },
        legend: { orientation: "h" },
      }}
      height={360}
    />
  );
}

/**
 * Per-measure ranking by total mitigation over the projection, with each
 * measure's cumulative share of the total. Mirrors the macro page's
 * driver-ranking table.
 */
function PamRankingTable({
  rows,
  crtLabels,
}: {
  rows: LulucfPamSummaryRow[];
  crtLabels: Record<string, string>;
}) {
  if (rows.length === 0) {
    return <p className="text-sm text-muted-foreground">No measures.</p>;
  }
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b">
          <th className="px-2 py-1 text-left">#</th>
          <th className="px-2 py-1 text-left">Measure</th>
          <th className="px-2 py-1 text-left">Category</th>
          <th className="px-2 py-1 text-center">Scenario</th>
          <th className="px-2 py-1 text-right">Total mitigation (kt CO₂-eq)</th>
          <th className="px-2 py-1 text-right">Cumulative share</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={`${r.PamId}-${i}`} className="border-b">
            <td className="px-2 py-1 tabular-nums text-muted-foreground">{i + 1}</td>
            <td className="px-2 py-1">{r.PamName}</td>
            <td className="px-2 py-1 font-mono text-xs" title={crtLabels[r.Category] ?? ""}>
              {r.Category}
            </td>
            <td className="px-2 py-1 text-center">
              <span className="rounded bg-muted px-2 py-0.5 text-xs">{r.Scenario}</span>
            </td>
            <td className="px-2 py-1 text-right tabular-nums text-emerald-700">
              {r.Total_Mitigation_CO2eq_kt.toLocaleString(undefined, {
                maximumFractionDigits: 1,
              })}
            </td>
            <td className="px-2 py-1 text-right tabular-nums text-muted-foreground">
              {(r.CumulativeShare * 100).toFixed(1)}%
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ============================================================================
// HwpPoolChart — UX audit G18 fix
// ============================================================================

function HwpPoolChart({
  rows,
}: {
  rows: { Year: number; ProductClass: string; Pool_ktC: number }[];
}) {
  if (rows.length === 0) {
    return null;
  }
  const classes = Array.from(new Set(rows.map((r) => r.ProductClass)));
  const colourMap: Record<string, string> = {
    sawnwood: "rgb(120, 53, 15)",   // brown
    panels:   "rgb(180, 83, 9)",    // amber
    paper:    "rgb(245, 158, 11)",  // light amber
  };
  const traces = classes.map((cls) => {
    const sub = rows
      .filter((r) => r.ProductClass === cls)
      .sort((a, b) => a.Year - b.Year);
    return {
      x: sub.map((r) => r.Year),
      y: sub.map((r) => r.Pool_ktC),
      type: "scatter" as const,
      mode: "lines" as const,
      name: cls,
      line: { color: colourMap[cls] ?? "rgb(75, 85, 99)", width: 2 },
      stackgroup: "one",
      hovertemplate: `${cls}: <b>%{y:,.1f}</b> kt C in %{x}<extra></extra>`,
    };
  });
  return (
    <PlotlyChart
      data={traces}
      layout={{
        xaxis: { title: { text: "Year" }, tickformat: "d" },
        yaxis: { title: { text: "HWP pool (kt C, stacked)" }, tickformat: ",d" },
      }}
      height={280}
    />
  );
}

function HwpTable({
  rows,
}: {
  rows: { Year: number; ProductClass: string; Pool_ktC: number }[];
}) {
  if (rows.length === 0) {
    return <p className="text-sm text-muted-foreground">No HWP data.</p>;
  }
  const years = Array.from(new Set(rows.map((r) => r.Year))).sort((a, b) => a - b);
  const classes = Array.from(new Set(rows.map((r) => r.ProductClass)));
  const sampleYears = [
    years[0],
    years[Math.floor(years.length / 2)],
    years[years.length - 1],
  ];
  const lookup = new Map<string, number>();
  for (const r of rows) {
    lookup.set(`${r.Year}|${r.ProductClass}`, r.Pool_ktC);
  }
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b">
          <th className="px-2 py-1 text-left">Year</th>
          {classes.map((c) => (
            <th key={c} className="px-2 py-1 text-right">
              {c}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {sampleYears.map((y) => (
          <tr key={y} className="border-b">
            <td className="px-2 py-1 tabular-nums">{y}</td>
            {classes.map((c) => (
              <td key={c} className="px-2 py-1 text-right tabular-nums">
                {(lookup.get(`${y}|${c}`) ?? 0).toFixed(1)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
