"""Probe the BTR CRT zips: list sheets matching Table5 / Summary, dump the layout
of the sector-5 table for one country so we can write a robust parser.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

import openpyxl

D = ROOTBTR = (Path(__file__).resolve().parents[2] / "scripts" / "energy_validation"
               / "data" / "btr")
ISOS = ["BRA", "CHL", "COL", "EGY", "GEO", "IDN", "KAZ", "TUR"]


def main() -> None:
    for iso in ISOS:
        z = zipfile.ZipFile(D / f"{iso}_CRT.zip")
        members = sorted(n for n in z.namelist()
                         if n.lower().endswith(".xlsx") and "~$" not in n)
        # open the first workbook, list candidate sheets
        wb = openpyxl.load_workbook(io.BytesIO(z.read(members[0])),
                                    read_only=True, data_only=True)
        t5 = [s for s in wb.sheetnames if "table5" in s.lower().replace(" ", "")]
        summ = [s for s in wb.sheetnames if "summary" in s.lower()]
        print(f"{iso}: {len(members)} workbooks; first={members[0]}")
        print(f"   Table5 sheets: {t5}")
        print(f"   Summary sheets: {summ}")
        wb.close()
        if iso == "BRA":  # dump a Table5 layout
            target = t5[0] if t5 else (summ[0] if summ else None)
            if target:
                wb = openpyxl.load_workbook(io.BytesIO(z.read(members[0])),
                                            read_only=True, data_only=True)
                ws = wb[target]
                print(f"\n--- {iso} sheet '{target}' first 40 rows x 8 cols ---")
                for i, r in enumerate(ws.iter_rows(max_row=40, max_col=8)):
                    vals = [getattr(c, "value", None) for c in r]
                    if any(v is not None for v in vals):
                        print(i, vals)
                wb.close()


if __name__ == "__main__":
    main()
