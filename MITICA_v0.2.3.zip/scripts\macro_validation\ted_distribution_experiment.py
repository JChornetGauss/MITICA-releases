"""Experiment: how to distribute the TED wedge (pinned − bottom-up) across
sectors. Compares three rules offline, scored against observed 2020-2024 SED.

  S1 proportional      : SED_k = bottom_up_k × (TED_pin / TED_WoM)  [current engine]
  S2 volatility-tilted : wedge allocated ∝ level × historical SED log-growth
                         volatility (inelastic sectors absorb less)
  S3 intensity-tilted  : wedge allocated ∝ level × historical intensity
                         (SED/driver) log-growth volatility

All preserve Σ = TED_pin exactly; non-negativity floored + residual redistributed.
The bottom-up is taken from the engine's own WoM run (observed macro), so the
only thing changing is the distribution rule.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)
from mitica_core.modules.macro.g_Macro_LayerB5_B6 import (  # noqa: E402
    _convergence_drivers,
)

DATA = Path(__file__).resolve().parent / "data"
TRAIN_START, TRAIN_END, TEST_END = 1995, 2019, 2024
EU = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "FI", "FR", "DE", "EL", "HU",
      "IE", "IT", "LV", "LT", "LU", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE"]
REGION = {c: ("HIC_TRANS" if c in {"BG", "HR", "CZ", "HU", "LV", "LT", "PL",
                                    "PT", "RO", "SK", "SI"} else "HIC") for c in EU}
SECT6 = ["SED_primary", "SED_manufacturing", "SED_construction", "SED_services",
         "SED_transport_pass", "SED_transport_freight"]
COMPS = SECT6 + ["SED_hh"]
TEST = list(range(TRAIN_END + 1, TEST_END + 1))


def _six(sed_raw):
    o = pd.DataFrame({"Year": sed_raw["Year"]})
    o["SED_primary"] = sed_raw["SED_primary"]
    o["SED_manufacturing"] = sed_raw["SED_manufacturing"] * 0.70
    o["SED_construction"] = sed_raw["SED_manufacturing"] * 0.30
    o["SED_services"] = sed_raw["SED_services"]
    o["SED_transport_pass"] = sed_raw["SED_transport"] * 0.65
    o["SED_transport_freight"] = sed_raw["SED_transport"] * 0.35
    return o


def _logvol(series: pd.Series) -> float:
    """Std of year-on-year log-growth (removes the linear log trend)."""
    v = series.dropna().to_numpy(dtype=float)
    v = v[v > 0]
    if len(v) < 4:
        return 0.0
    g = np.diff(np.log(v))
    return float(np.std(g, ddof=1))


def _distribute(bottom_up: dict, ted_pin: float, weights: dict) -> dict:
    """Allocate the wedge (ted_pin − Σ bottom_up) across components by `weights`
    (need not sum to 1), with a non-negativity floor and residual redistribution."""
    keys = list(bottom_up.keys())
    wom = sum(bottom_up.values())
    wedge = ted_pin - wom
    wsum = sum(weights[k] for k in keys)
    if wsum <= 0:
        wsum = 1.0
        weights = {k: bottom_up[k] for k in keys}
        wsum = sum(weights.values()) or 1.0
    out = {k: bottom_up[k] + wedge * weights[k] / wsum for k in keys}
    # floor negatives at 0, redistribute the deficit among positive components
    # proportional to their current value, iterated until clean
    for _ in range(10):
        neg = {k: v for k, v in out.items() if v < 0}
        if not neg:
            break
        deficit = -sum(neg.values())
        for k in neg:
            out[k] = 0.0
        pos = {k: v for k, v in out.items() if v > 0}
        ps = sum(pos.values()) or 1.0
        for k in pos:
            out[k] -= deficit * out[k] / ps
    # renormalise to hit ted_pin exactly (correct tiny float drift)
    tot = sum(out.values())
    if tot > 0:
        out = {k: v * ted_pin / tot for k, v in out.items()}
    return out


def run_country(cc):
    g = pd.read_csv(DATA / f"{cc}_gdp_pop.csv")
    sg = pd.read_csv(DATA / f"{cc}_sgdp.csv")
    sed_raw = pd.read_csv(DATA / f"{cc}_sed.csv")
    for df in (g, sg, sed_raw):
        ys = set(df["Year"].astype(int))
        if not all(y in ys for y in range(TRAIN_START, TEST_END + 1)):
            return None
    sed6 = _six(sed_raw)
    sed_hh = sed_raw[["Year", "SED_households"]].rename(columns={"SED_households": "SED_hh"})
    gdp = sg.assign(GDP_tot=sg.SGDP_primary + sg.SGDP_secondary + sg.SGDP_tertiary)[["Year", "GDP_tot"]]

    def slc(df, a, b):
        return df[(df.Year >= a) & (df.Year <= b)].reset_index(drop=True)

    hist = HistoricalData(
        gdp_tot=slc(gdp, TRAIN_START, TRAIN_END),
        population=slc(g[["Year", "Pop"]], TRAIN_START, TRAIN_END),
        sgdp=slc(sg, TRAIN_START, TRAIN_END),
        sed=slc(sed6, TRAIN_START, TRAIN_END), sed_hh=slc(sed_hh, TRAIN_START, TRAIN_END))
    cfg = MacroConfig(region=REGION[cc], dev_group="H", horizon_year=TEST_END,
                      validate_historical=False)
    # WoM bottom-up with observed macro (so the split is the only thing tested)
    out = run_macro_module(hist, ProjectedInputs(
        gdp_tot=slc(gdp, TRAIN_END + 1, TEST_END),
        population=slc(g[["Year", "Pop"]], TRAIN_END + 1, TEST_END),
        sgdp=slc(sg, TRAIN_END + 1, TEST_END)), cfg)
    bu_sed = out.sed.set_index("Year")
    bu_hh = out.sed_hh.set_index("Year")
    macro_full = (out.gdp_tot.merge(out.population, on="Year").merge(out.sgdp, on="Year"))

    # weights
    vol_sed = {c: _logvol(slc(sed6, TRAIN_START, TRAIN_END)[c]) for c in SECT6}
    vol_sed["SED_hh"] = _logvol(slc(sed_hh, TRAIN_START, TRAIN_END)["SED_hh"])
    mean_vol = np.mean([v for v in vol_sed.values()]) or 1.0
    # intensity volatility (SED/driver) over history
    int_vol = {}
    hist_sed6 = slc(sed6, TRAIN_START, TRAIN_END).set_index("Year")
    for k in ("primary", "manufacturing", "construction", "services",
              "transport_pass", "transport_freight"):
        scale, _gpc = _convergence_drivers(k, slc(macro_full, TRAIN_START, TRAIN_END))
        inten = hist_sed6[f"SED_{k}"] / scale.reindex(hist_sed6.index)
        int_vol[f"SED_{k}"] = _logvol(inten)
    int_vol["SED_hh"] = _logvol(
        slc(sed_hh, TRAIN_START, TRAIN_END).set_index("Year")["SED_hh"]
        / slc(g[["Year", "Pop"]], TRAIN_START, TRAIN_END).set_index("Year")["Pop"])
    mean_ivol = np.mean([v for v in int_vol.values()]) or 1.0

    ted_obs = sed_raw.assign(TED=sed_raw[["SED_primary", "SED_manufacturing",
                             "SED_services", "SED_transport", "SED_households"]].sum(axis=1)
                             ).set_index("Year")["TED"]
    obs = sed_raw.set_index("Year")

    def agg5(d):  # 6-comp dict -> 5 Eurostat bins
        return {"primary": d["SED_primary"],
                "manufacturing": d["SED_manufacturing"] + d["SED_construction"],
                "services": d["SED_services"],
                "transport": d["SED_transport_pass"] + d["SED_transport_freight"],
                "households": d["SED_hh"]}

    obs_col = {"primary": "SED_primary", "manufacturing": "SED_manufacturing",
               "services": "SED_services", "transport": "SED_transport",
               "households": "SED_households"}

    # cyclical beta of each component to the aggregate TED (co-movement), from
    # history: how much sector k's energy moves when the total moves.
    h6 = slc(sed6, TRAIN_START, TRAIN_END).set_index("Year")
    hhh = slc(sed_hh, TRAIN_START, TRAIN_END).set_index("Year")["SED_hh"]
    ted_hist = h6[SECT6].sum(axis=1) + hhh
    g_ted = np.diff(np.log(ted_hist.to_numpy(dtype=float)))
    var_ted = float(np.var(g_ted, ddof=1)) or 1.0
    beta = {}
    for c in SECT6:
        gk = np.diff(np.log(h6[c].to_numpy(dtype=float)))
        beta[c] = float(np.cov(gk, g_ted, ddof=1)[0, 1] / var_ted)
    gk = np.diff(np.log(hhh.to_numpy(dtype=float)))
    beta["SED_hh"] = float(np.cov(gk, g_ted, ddof=1)[0, 1] / var_ted)

    schemes = {"S1_prop": {}, "S2_volSED": {}, "S3_volIntensity": {}, "S4_beta": {}}
    err = {s: {b: [] for b in obs_col} for s in schemes}
    prim_share = []
    for y in TEST:
        bottom_up = {c: float(bu_sed.at[y, c]) for c in SECT6}
        bottom_up["SED_hh"] = float(bu_hh.at[y, "SED_hh"])
        tp = float(ted_obs.at[y])
        prim_share.append(float(obs.at[y, "SED_primary"]) / tp)
        w1 = {c: bottom_up[c] for c in COMPS}                                   # proportional
        w2 = {c: bottom_up[c] * (vol_sed[c] / mean_vol) for c in COMPS}         # SED vol tilt
        w3 = {c: bottom_up[c] * (int_vol[c] / mean_ivol) for c in COMPS}        # intensity vol tilt
        w4 = {c: bottom_up[c] * max(beta[c], 0.05) for c in COMPS}              # cyclical beta tilt
        for s, w in (("S1_prop", w1), ("S2_volSED", w2),
                     ("S3_volIntensity", w3), ("S4_beta", w4)):
            d = _distribute(bottom_up, tp, w)
            a = agg5(d)
            for b in obs_col:
                err[s][b].append(abs(a[b] - float(obs.at[y, obs_col[b]])) / float(obs.at[y, obs_col[b]]))
    row = {"cc": cc, "region": REGION[cc], "primary_share": float(np.mean(prim_share))}
    for s in schemes:
        for b in obs_col:
            row[f"{s}_{b}"] = float(np.mean(err[s][b]))
        row[f"{s}_mean"] = float(np.mean([row[f"{s}_{b}"] for b in obs_col]))
    return row


def main():
    rows = [r for cc in EU if (r := run_country(cc)) is not None]
    df = pd.DataFrame(rows)
    bins = ["primary", "manufacturing", "services", "transport", "households", "mean"]
    print("=== TED wedge distribution rules — median sectoral MAPE across "
          f"{len(df)} EU countries (project 2020-2024) ===\n")
    cols = ("S1_prop", "S2_volSED", "S3_volIntensity", "S4_beta")
    hdr = f"  {'bin':<14}" + "".join(f"{s:>16}" for s in cols)
    print(hdr)
    for b in bins:
        line = f"  {b:<14}"
        for s in cols:
            line += f"{df[f'{s}_{b}'].median():>16.1%}"
        print(line)
    print("\n  (p90 of the 5-bin mean)")
    for s in cols:
        print(f"    {s:<16} {df[f'{s}_mean'].quantile(.9):.1%}")
    print(f"\n  primary share of TED: median={df['primary_share'].median():.1%} "
          f"p90={df['primary_share'].quantile(.9):.1%} max={df['primary_share'].max():.1%}")


if __name__ == "__main__":
    main()
