"use client";

import { use } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowRight,
  Upload,
  Zap,
  CheckSquare,
  Lightbulb,
  LineChart,
  Download,
  Activity,
  Power,
  AlertCircle,
  Globe2,
  Trees,
  Snowflake,
  Car,
  Trash2,
  type LucideIcon,
} from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Project, ProjectUpdate } from "@/lib/types";

const STEP_CARDS = [
  {
    slug: "upload",
    title: "1. Upload data",
    description:
      "Upload your IPCC inventory (Excel or CRT JSON) and proxy CSVs (GDP, Population, sectoral drivers).",
    icon: Upload,
  },
  {
    slug: "macro",
    title: "· Macroeconomic module",
    description:
      "Optional SI-002 — generates consistent GDP / Population / SGDP / energy-demand proxies for ANNALIST.",
    icon: Activity,
    optional: true,
  },
  {
    slug: "energy",
    title: "· Energy industries module",
    description:
      "Optional SI-003 (IPCC 1A1a + 1A1c) — scales generation technologies with electricity + heat demand at frozen mix shares. WoM + WM + WAM.",
    icon: Zap,
    optional: true,
  },
  {
    slug: "forecast",
    title: "2. Run the baseline forecast",
    description:
      "Pick a horizon year + method (ANNALIST, AG, LINREG). The backend runs per-category in a background job.",
    icon: Zap,
  },
  {
    slug: "validate",
    title: "3. Validate per category",
    description:
      "Review each IPCC category's historical + forecast, apply modifiers (avoid-negative, smooth, anchor target, …).",
    icon: CheckSquare,
  },
  {
    slug: "pams",
    title: "4. Define Policies & Measures",
    description:
      "Write a formula with variables, pick a time distribution, attach a cost. Safe AST evaluator — no eval().",
    icon: Lightbulb,
  },
  {
    slug: "scenarios",
    title: "5. Compare scenarios",
    description: "Auto-aggregated WOM / WEM / WAM by sector and by category.",
    icon: LineChart,
  },
  {
    slug: "dashboard",
    title: "6. Dashboard & CRT export",
    description:
      "MACC curve + downloadable CRT-shaped Excel for BTR/BUR submission.",
    icon: Download,
  },
];

export default function ProjectOverviewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const { data: project } = useQuery({
    queryKey: ["project", id],
    queryFn: () => api.getProject(id),
  });

  return (
    <div className="space-y-6">
      {project && <CountryIncomeCard project={project} />}
      {project && <ModuleActivationPanel project={project} />}

      <div className="grid gap-4 md:grid-cols-2">
        {STEP_CARDS.map((s) => {
          const Icon = s.icon;
          const isOptional = "optional" in s && s.optional;
          const moduleActive =
            (s.slug === "macro" && project?.use_macro_module) ||
            (s.slug === "energy" && project?.use_energy_module);
          return (
            <Card
              key={s.slug}
              className={`flex flex-col ${isOptional ? "border-dashed bg-muted/20" : ""} ${
                moduleActive ? "ring-1 ring-primary/40" : ""
              }`}
            >
              <CardHeader className="flex-1">
                <div className="mb-2 flex items-start justify-between gap-2">
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-md ${
                      isOptional
                        ? s.slug === "macro"
                          ? "bg-indigo-600/10 text-indigo-600"
                          : "bg-amber-700/10 text-amber-700"
                        : "bg-primary/10 text-primary"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  {moduleActive && (
                    <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary">
                      Active · feeds forecast
                    </span>
                  )}
                </div>
                <CardTitle className="text-base">{s.title}</CardTitle>
                <CardDescription>{s.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="outline" size="sm">
                  <Link href={`/projects/${id}/${s.slug}`}>
                    Open <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {project && (
        <div className="rounded-lg border bg-card p-4 text-sm text-muted-foreground">
          Project <code className="rounded bg-muted px-1">{project.id}</code> — the
          underlying artifacts (inventory, forecast, PAMs) are stored under{" "}
          <code className="rounded bg-muted px-1">data/</code> and indexed in SQLite.
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Country & income group (GUY-09/GUY-17): single project-level setting the
// sectoral modules consume instead of each re-deriving it from GDP per capita.
// ----------------------------------------------------------------------------

const INCOME_GROUP_LABELS: Record<string, string> = {
  L: "L · Low income",
  LM: "LM · Lower-middle income",
  UM: "UM · Upper-middle income",
  H: "H · High income",
};

function CountryIncomeCard({ project }: { project: Project }) {
  const qc = useQueryClient();
  const patch = useMutation({
    mutationFn: (data: ProjectUpdate) => api.patchProject(project.id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["project", project.id] }),
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Globe2 className="h-4 w-4 text-primary" />
          <CardTitle className="text-sm">Country &amp; income group</CardTitle>
        </div>
        <CardDescription>
          The transport and waste modules use the income group to pick their
          priors. Auto-filled from the World Bank classification when the
          country code resolves; override it here if needed.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap items-end gap-4">
        <div>
          <div className="mb-1 text-xs font-medium text-muted-foreground">Country code</div>
          <code className="rounded bg-muted px-2 py-1 text-sm">
            {project.country_code || "UNK"}
          </code>
        </div>
        <div>
          <label
            htmlFor="project-income-group"
            className="mb-1 block text-xs font-medium text-muted-foreground"
          >
            Income group
          </label>
          <select
            id="project-income-group"
            className="h-9 rounded-md border border-input bg-background px-2 text-sm"
            value={project.income_group ?? ""}
            disabled={patch.isPending}
            onChange={(e) =>
              patch.mutate({ income_group: e.target.value === "" ? null : e.target.value })
            }
          >
            <option value="">Not set — modules infer from GDP per capita</option>
            {Object.keys(INCOME_GROUP_LABELS).map((g) => (
              <option key={g} value={g}>
                {INCOME_GROUP_LABELS[g]}
              </option>
            ))}
          </select>
          <p className="mt-1 text-[11px] text-muted-foreground">
            from World Bank classification
          </p>
        </div>
        {patch.error && (
          <p className="text-xs text-destructive">{(patch.error as Error).message}</p>
        )}
      </CardContent>
    </Card>
  );
}

// ----------------------------------------------------------------------------
// SI-008 hand-off: module activation panel
// ----------------------------------------------------------------------------

type ModuleColor = "indigo" | "amber" | "emerald" | "sky" | "rose" | "stone";

const MODULES: {
  slug: string;
  flag:
    | "use_macro_module"
    | "use_energy_module"
    | "use_lulucf_module"
    | "use_fgases_module"
    | "use_transport_module"
    | "use_waste_module";
  result:
    | "has_macro_result"
    | "has_energy_result"
    | "has_lulucf_result"
    | "has_fgases_result"
    | "has_transport_result"
    | "has_waste_result";
  label: string;
  sublabel: string;
  color: ModuleColor;
  icon: LucideIcon;
}[] = [
  {
    slug: "macro",
    flag: "use_macro_module",
    result: "has_macro_result",
    label: "Macroeconomic module",
    sublabel: "Replaces user proxies with SI-002's coherent set",
    color: "indigo",
    icon: Activity,
  },
  {
    slug: "energy",
    flag: "use_energy_module",
    result: "has_energy_result",
    label: "Energy industries module",
    sublabel: "Overrides 1A1a+1A1c WoM — scales technologies with demand at frozen mix shares",
    color: "amber",
    icon: Zap,
  },
  {
    slug: "lulucf",
    flag: "use_lulucf_module",
    result: "has_lulucf_result",
    label: "LULUCF module",
    sublabel: "Overrides sector 4 WoM with the land-representation carbon model",
    color: "emerald",
    icon: Trees,
  },
  {
    slug: "fgases",
    flag: "use_fgases_module",
    result: "has_fgases_result",
    label: "F-gases module",
    sublabel: "Overrides 2F WoM with the refrigerant cohort engine; Kigali wedge as PAMs",
    color: "sky",
    icon: Snowflake,
  },
  {
    slug: "transport",
    flag: "use_transport_module",
    result: "has_transport_result",
    label: "Transport module",
    sublabel: "Overrides road 1A3b WoM with the ASIF fleet model; PAMs as mini-scenarios",
    color: "rose",
    icon: Car,
  },
  {
    slug: "waste",
    flag: "use_waste_module",
    result: "has_waste_result",
    label: "Waste module",
    sublabel: "Overrides sector 5 WoM with the IPCC FOD model; PAMs as mini-scenarios",
    color: "stone",
    icon: Trash2,
  },
];

function ModuleActivationPanel({ project }: { project: Project }) {
  const qc = useQueryClient();

  const patch = useMutation({
    mutationFn: (data: ProjectUpdate) => api.patchProject(project.id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["project", project.id] }),
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Power className="h-4 w-4 text-primary" />
          <CardTitle className="text-sm">Modular ecosystem · SI-008 hand-off</CardTitle>
        </div>
        <CardDescription>
          When a module is active the Integration forecast uses its outputs instead of
          ANNALIST for the categories it covers. Per-project — toggle off to fall back.
          A module only overrides its own IPCC categories: every other category in the
          inventory still projects with ANNALIST using the project&apos;s proxies
          (mandatory GDP / Population plus any optional sectoral proxies you uploaded).
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-3 md:grid-cols-2">
        {MODULES.map((m) => {
          const Icon = m.icon;
          return (
            <ModuleToggle
              key={m.slug}
              projectId={project.id}
              label={m.label}
              sublabel={m.sublabel}
              color={m.color}
              icon={<Icon className="h-4 w-4" />}
              enabled={project[m.flag]}
              resultAvailable={project[m.result]}
              missingHref={`/projects/${project.id}/${m.slug}`}
              onToggle={(v) => patch.mutate({ [m.flag]: v } as ProjectUpdate)}
              isPending={patch.isPending}
            />
          );
        })}
        {patch.error && (
          <p className="md:col-span-2 text-xs text-destructive">
            {(patch.error as Error).message}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function ModuleToggle({
  label,
  sublabel,
  color,
  icon,
  enabled,
  resultAvailable,
  missingHref,
  onToggle,
  isPending,
}: {
  projectId: string;
  label: string;
  sublabel: string;
  color: ModuleColor;
  icon: React.ReactNode;
  enabled: boolean;
  resultAvailable: boolean;
  missingHref: string;
  onToggle: (v: boolean) => void;
  isPending: boolean;
}) {
  const disabled = !resultAvailable;
  const ACCENTS: Record<ModuleColor, string> = {
    indigo: "bg-indigo-600/10 text-indigo-700",
    amber: "bg-amber-700/10 text-amber-800",
    emerald: "bg-emerald-600/10 text-emerald-700",
    sky: "bg-sky-600/10 text-sky-700",
    rose: "bg-rose-600/10 text-rose-700",
    stone: "bg-stone-600/10 text-stone-700",
  };
  const accentBg = ACCENTS[color];
  return (
    <div
      className={`flex items-start gap-3 rounded-md border p-3 transition-colors ${
        enabled ? "border-primary/40 bg-primary/5" : "border-border"
      } ${disabled ? "opacity-70" : ""}`}
    >
      <div className={`mt-0.5 flex h-8 w-8 items-center justify-center rounded ${accentBg}`}>
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm font-medium">{label}</div>
            <div className="truncate text-xs text-muted-foreground">{sublabel}</div>
          </div>
          <button
            type="button"
            aria-label={`${enabled ? "Disable" : "Enable"} ${label}`}
            disabled={disabled || isPending}
            onClick={() => onToggle(!enabled)}
            className={`relative inline-flex h-5 w-9 shrink-0 rounded-full transition-colors ${
              enabled ? "bg-primary" : "bg-muted"
            } ${disabled ? "cursor-not-allowed" : ""}`}
          >
            <span
              className={`absolute top-0.5 h-4 w-4 rounded-full bg-background shadow transition-transform ${
                enabled ? "translate-x-4" : "translate-x-0.5"
              }`}
            />
          </button>
        </div>
        {disabled && (
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-700">
            <AlertCircle className="h-3 w-3" />
            <Link href={missingHref} className="underline underline-offset-2">
              Run this module first
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
