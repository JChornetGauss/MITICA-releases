#!/usr/bin/env python
"""MITICA local orchestrator — start / stop / status / restart / logs.

Usage
-----
    python scripts/mitica.py start              # start backend + frontend
    python scripts/mitica.py stop               # kill both
    python scripts/mitica.py status             # show what's running
    python scripts/mitica.py restart            # stop + start
    python scripts/mitica.py logs backend       # tail backend log
    python scripts/mitica.py logs frontend      # tail frontend log

Cross-platform (Windows / macOS / Linux). Uses stdlib only — no
external dependencies. Two-step boot: backend first (health-check on
:8000/api/v1/health), then frontend on :3000. Auto-opens the browser
when both are ready.

Stale-port handling: if something already owns 8000 or 3000, the
script kills it before binding (Windows uses ``taskkill``, unix uses
``kill`` + ``lsof``).

Logs land in ``.mitica/`` next to the project root; PIDs in
``.mitica/pids.json``. Pass ``--no-browser`` to skip the auto-open.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).resolve().parents[1]           # mitica_next/
WEB_DIR = REPO_ROOT / "apps" / "web"
STATE_DIR = REPO_ROOT / ".mitica"
STATE_DIR.mkdir(exist_ok=True)
PID_FILE = STATE_DIR / "pids.json"
BACKEND_LOG = STATE_DIR / "backend.log"
FRONTEND_LOG = STATE_DIR / "frontend.log"

BACKEND_HOST = "127.0.0.1"
BACKEND_PORT = 8000
FRONTEND_PORT = 3000
HEALTH_URL = f"http://{BACKEND_HOST}:{BACKEND_PORT}/api/v1/health"
FRONTEND_URL = f"http://localhost:{FRONTEND_PORT}/"

IS_WINDOWS = platform.system() == "Windows"


# ---------------------------------------------------------------------------
# Logging helpers (ASCII-only — works in cmd.exe without UTF-8 mode)
# ---------------------------------------------------------------------------


def say(msg: str) -> None:
    print(f"[mitica] {msg}", flush=True)


def warn(msg: str) -> None:
    print(f"[mitica] WARN: {msg}", flush=True)


def die(msg: str, code: int = 1) -> None:
    print(f"[mitica] ERROR: {msg}", flush=True)
    sys.exit(code)


# ---------------------------------------------------------------------------
# Port + process management
# ---------------------------------------------------------------------------


def port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """True if ``host:port`` is currently accepting connections."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        try:
            s.connect((host, port))
            return True
        except (ConnectionRefusedError, socket.timeout, OSError):
            return False


def find_pids_on_port(port: int) -> list[int]:
    """Return the PIDs owning ``port``. Cross-platform best-effort."""
    pids: list[int] = []
    try:
        if IS_WINDOWS:
            out = subprocess.run(
                ["netstat", "-ano", "-p", "TCP"],
                capture_output=True, text=True, timeout=10,
            ).stdout
            for line in out.splitlines():
                parts = line.split()
                if len(parts) < 5:
                    continue
                local = parts[1]
                state = parts[3]
                if state != "LISTENING":
                    continue
                if local.endswith(f":{port}"):
                    try:
                        pids.append(int(parts[4]))
                    except ValueError:
                        continue
        else:
            # Try lsof first; fallback to ss
            lsof = shutil.which("lsof")
            if lsof:
                out = subprocess.run(
                    [lsof, "-iTCP", f"-i:{port}", "-sTCP:LISTEN", "-t"],
                    capture_output=True, text=True, timeout=10,
                ).stdout
                pids.extend(int(p) for p in out.split() if p.isdigit())
            else:
                ss = shutil.which("ss")
                if ss:
                    out = subprocess.run(
                        [ss, "-ltnp", f"sport = :{port}"],
                        capture_output=True, text=True, timeout=10,
                    ).stdout
                    for line in out.splitlines():
                        if "pid=" in line:
                            chunk = line.split("pid=", 1)[1]
                            pid_str = chunk.split(",")[0]
                            if pid_str.isdigit():
                                pids.append(int(pid_str))
    except Exception as e:
        warn(f"could not enumerate PIDs on port {port}: {e}")
    return list(dict.fromkeys(pids))   # de-dupe, preserve order


def kill_pid(pid: int) -> bool:
    """Terminate a process by PID. True if it died."""
    try:
        if IS_WINDOWS:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                capture_output=True, timeout=10,
            )
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
            try:
                os.kill(pid, 0)   # still alive?
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        return True
    except Exception as e:
        warn(f"failed to kill PID {pid}: {e}")
        return False


def free_port(port: int) -> None:
    """Kill anything listening on ``port``."""
    pids = find_pids_on_port(port)
    if not pids:
        return
    say(f"port {port} busy (PIDs {pids}); freeing...")
    for pid in pids:
        kill_pid(pid)
    time.sleep(1.0)


# ---------------------------------------------------------------------------
# Health-check loops
# ---------------------------------------------------------------------------


def wait_for_url(url: str, timeout: float = 60.0, label: str = "service") -> bool:
    """Poll ``url`` every 0.5s until HTTP 200 or timeout."""
    start = time.time()
    last_err: str = ""
    while time.time() - start < timeout:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "mitica/1.0"})
            with urllib.request.urlopen(req, timeout=2) as resp:
                if 200 <= resp.status < 400:
                    return True
        except urllib.error.URLError as e:
            last_err = str(e.reason)
        except Exception as e:
            last_err = str(e)
        time.sleep(0.5)
    warn(f"{label} did not become ready in {timeout:.0f}s (last error: {last_err})")
    return False


def wait_for_port(port: int, timeout: float = 60.0, label: str = "service") -> bool:
    """Poll TCP connect every 0.5s until success or timeout."""
    start = time.time()
    while time.time() - start < timeout:
        if port_in_use(port):
            return True
        time.sleep(0.5)
    warn(f"{label} port {port} did not open in {timeout:.0f}s")
    return False


# ---------------------------------------------------------------------------
# PID file
# ---------------------------------------------------------------------------


def load_pids() -> dict[str, int]:
    if PID_FILE.exists():
        try:
            return json.loads(PID_FILE.read_text())
        except json.JSONDecodeError:
            return {}
    return {}


def save_pids(pids: dict[str, int]) -> None:
    PID_FILE.write_text(json.dumps(pids, indent=2))


# ---------------------------------------------------------------------------
# Dependency checks
# ---------------------------------------------------------------------------


def check_deps() -> None:
    """Verify python imports + pnpm + node_modules. Hard-fail with a
    clear message if anything is missing — better than a cryptic
    subprocess error later."""
    # Python: mitica_api importable
    try:
        subprocess.run(
            [sys.executable, "-c", "import mitica_api.main"],
            capture_output=True, check=True, text=True, timeout=15,
            cwd=str(REPO_ROOT),
        )
    except subprocess.CalledProcessError as e:
        die(
            "mitica_api is not importable. Install with:\n"
            "    pip install -e packages/core packages/api\n\n"
            f"stderr: {e.stderr.strip()[:400]}"
        )
    # pnpm exists
    if not shutil.which("pnpm"):
        die("pnpm not found on PATH. Install: https://pnpm.io/installation")
    # node_modules installed
    if not (WEB_DIR / "node_modules" / ".bin" / "next").exists() and \
       not (WEB_DIR / "node_modules" / ".bin" / "next.cmd").exists():
        say("node_modules missing — running 'pnpm install' (one-time, ~2 min)...")
        subprocess.run(["pnpm", "install"], cwd=str(WEB_DIR), check=True)


# ---------------------------------------------------------------------------
# Start / stop / status
# ---------------------------------------------------------------------------


def spawn_detached(
    cmd: list[str],
    cwd: Path,
    log_path: Path,
    env: dict[str, str] | None = None,
) -> int:
    """Launch ``cmd`` detached, redirecting stdout + stderr to ``log_path``.
    Returns the child PID."""
    log_path.parent.mkdir(exist_ok=True)
    log_fh = open(log_path, "wb")
    kwargs: dict = dict(
        cwd=str(cwd),
        stdout=log_fh, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
        env={**os.environ, **(env or {})},
    )
    if IS_WINDOWS:
        # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP — survives parent exit
        kwargs["creationflags"] = 0x00000008 | 0x00000200   # type: ignore[arg-type]
    else:
        kwargs["start_new_session"] = True
    proc = subprocess.Popen(cmd, **kwargs)
    return proc.pid


def cmd_start(args: argparse.Namespace) -> int:
    check_deps()

    # Free ports of any zombies (with confirmation when the PID file
    # already says a server is running we own — kill our own children
    # first via cmd_stop logic).
    existing = load_pids()
    if existing:
        say("found existing PID file — stopping previous servers first...")
        cmd_stop(args)

    free_port(BACKEND_PORT)
    free_port(FRONTEND_PORT)

    # --- Start backend (uvicorn) ---
    say(f"starting backend on http://{BACKEND_HOST}:{BACKEND_PORT}/ ...")
    backend_cmd = [
        sys.executable, "-m", "uvicorn",
        "mitica_api.main:app",
        "--host", BACKEND_HOST,
        "--port", str(BACKEND_PORT),
    ]
    backend_pid = spawn_detached(backend_cmd, REPO_ROOT, BACKEND_LOG)
    say(f"  backend PID {backend_pid}  log: {BACKEND_LOG}")
    if not wait_for_url(HEALTH_URL, timeout=30, label="backend"):
        say(f"  backend log tail:")
        try:
            print(BACKEND_LOG.read_text(encoding="utf-8", errors="replace")[-2000:])
        except Exception:
            pass
        die("backend failed to start — see log above")
    say(f"  backend healthy")

    # --- Start frontend (Next.js dev) ---
    say(f"starting frontend on {FRONTEND_URL} ...")
    pnpm_exe = shutil.which("pnpm") or "pnpm"
    frontend_cmd = [pnpm_exe, "dev"]
    frontend_env = {"NEXT_TELEMETRY_DISABLED": "1"}
    frontend_pid = spawn_detached(frontend_cmd, WEB_DIR, FRONTEND_LOG, frontend_env)
    say(f"  frontend PID {frontend_pid}  log: {FRONTEND_LOG}")
    if not wait_for_port(FRONTEND_PORT, timeout=90, label="frontend"):
        say(f"  frontend log tail:")
        try:
            print(FRONTEND_LOG.read_text(encoding="utf-8", errors="replace")[-2000:])
        except Exception:
            pass
        die("frontend failed to start — see log above")
    say(f"  frontend ready")

    save_pids({"backend": backend_pid, "frontend": frontend_pid})

    # --- Auto-open browser ---
    if not args.no_browser:
        say(f"opening {FRONTEND_URL} in your browser...")
        try:
            webbrowser.open(FRONTEND_URL)
        except Exception:
            pass

    say("MITICA is up.")
    say(f"  frontend: {FRONTEND_URL}")
    say(f"  backend:  http://{BACKEND_HOST}:{BACKEND_PORT}/docs   (FastAPI Swagger)")
    say(f"  stop with: python scripts/mitica.py stop")
    return 0


def cmd_stop(args: argparse.Namespace) -> int:
    pids = load_pids()
    killed: list[int] = []
    for label, pid in pids.items():
        say(f"stopping {label} (PID {pid})")
        if kill_pid(pid):
            killed.append(pid)
    # Belt-and-suspenders: also kill anything still on the ports
    for port in (FRONTEND_PORT, BACKEND_PORT):
        for pid in find_pids_on_port(port):
            if pid not in killed:
                say(f"freeing port {port} (PID {pid})")
                kill_pid(pid)
                killed.append(pid)
    PID_FILE.unlink(missing_ok=True)
    if killed:
        say(f"stopped {len(killed)} process(es)")
    else:
        say("nothing to stop")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    pids = load_pids()
    rows: list[tuple[str, str, str, str]] = []
    for label, port in (("backend", BACKEND_PORT), ("frontend", FRONTEND_PORT)):
        listening = port_in_use(port)
        pid_str = str(pids.get(label, "?")) if pids.get(label) else "-"
        port_owners = find_pids_on_port(port)
        owners_str = ",".join(str(p) for p in port_owners) if port_owners else "-"
        status = "UP" if listening else "DOWN"
        rows.append((label, str(port), status, f"pid_file={pid_str} listening={owners_str}"))
    width = max(len(r[0]) for r in rows)
    say(f"{'service'.ljust(width)}  port   status  detail")
    for r in rows:
        print(f"           {r[0].ljust(width)}  {r[1]:<5s}  {r[2]:<6s}  {r[3]}")
    return 0


def cmd_restart(args: argparse.Namespace) -> int:
    cmd_stop(args)
    time.sleep(1.0)
    return cmd_start(args)


def cmd_logs(args: argparse.Namespace) -> int:
    target = args.which
    path = BACKEND_LOG if target == "backend" else FRONTEND_LOG
    if not path.exists():
        die(f"no log at {path} — did you start the {target}?")
    say(f"tailing {path} (Ctrl+C to stop)")
    # Simple tail -f
    with open(path, "rb") as f:
        f.seek(0, 2)
        try:
            while True:
                line = f.readline()
                if not line:
                    time.sleep(0.3)
                    continue
                sys.stdout.write(line.decode("utf-8", errors="replace"))
                sys.stdout.flush()
        except KeyboardInterrupt:
            pass
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        description="MITICA local-dev orchestrator. Starts backend + frontend.",
    )
    # Top-level --no-browser also accepted on the start / restart
    # subcommands so users can put it after the command name.
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="do not auto-open the browser after start",
    )
    sub = parser.add_subparsers(dest="cmd")

    start_p = sub.add_parser("start", help="start backend + frontend (default)")
    start_p.add_argument("--no-browser", action="store_true", dest="no_browser_sub")
    sub.add_parser("stop", help="kill backend + frontend")
    sub.add_parser("status", help="show what is running")
    restart_p = sub.add_parser("restart", help="stop + start")
    restart_p.add_argument("--no-browser", action="store_true", dest="no_browser_sub")
    logs_p = sub.add_parser("logs", help="tail backend or frontend logs")
    logs_p.add_argument("which", choices=["backend", "frontend"])

    args = parser.parse_args()
    cmd = args.cmd or "start"
    # Merge top-level --no-browser with subcommand --no-browser
    args.no_browser = (
        getattr(args, "no_browser", False)
        or getattr(args, "no_browser_sub", False)
    )
    dispatch = {
        "start": cmd_start,
        "stop": cmd_stop,
        "status": cmd_status,
        "restart": cmd_restart,
        "logs": cmd_logs,
    }
    return dispatch[cmd](args)


if __name__ == "__main__":
    sys.exit(main())
