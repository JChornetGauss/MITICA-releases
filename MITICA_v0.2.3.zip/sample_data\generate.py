"""Generate a toy inventory + GDP + population for smoke-testing MITICA Next.

Run: `python sample_data/generate.py`

Writes the inventory in the v1.1s MITICA Excel layout:
    Row 1 (iloc[0, *]): freeform metadata. Country code at col C (iloc[0,2]),
                         unit at col E (iloc[0,4]).
    Row 2: header — "ipcc_code" | <year> | <year> | ...
    Row 3+: category rows (e.g. "1A1a") with per-year emissions.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import openpyxl

HERE = Path(__file__).resolve().parent


CATEGORIES = {
    "1A1a": ("Public Electricity and Heat Production", 8000.0, 0.02),
    "1A3b": ("Road Transportation", 3000.0, 0.015),
    "2A1": ("Cement Production", 400.0, 0.01),
    "2B": ("Chemical Industry", 300.0, 0.008),
    "3A1": ("Enteric Fermentation — Cattle", 2000.0, 0.005),
    "4A": ("Forest Land (net sink)", -500.0, 0.0),
    "5A1": ("Managed Waste Disposal", 600.0, 0.012),
}

YEARS = list(range(2000, 2023))


def make_inventory(path: Path) -> Path:
    rng = np.random.default_rng(42)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Inventory"

    # Row 1 — freeform metadata.
    #   col A: freeform title     col C: country_code (read via iloc[0,2])
    #   col E: unit (read via iloc[0,4])
    ws.cell(row=1, column=1, value="MITICA Next — Smoke-Test Inventory")
    ws.cell(row=1, column=3, value="TST")
    ws.cell(row=1, column=5, value="kt CO2 eq")

    # Row 2 — header
    ws.cell(row=2, column=1, value="ipcc_code")
    for i, y in enumerate(YEARS, start=2):
        ws.cell(row=2, column=i, value=y)

    # Rows 3+ — data
    for row_i, (code, (_desc, base, growth)) in enumerate(CATEGORIES.items(), start=3):
        ws.cell(row=row_i, column=1, value=code)
        val = float(base)
        for col_i, _y in enumerate(YEARS, start=2):
            val *= 1.0 + growth + 0.015 * rng.standard_normal()
            ws.cell(row=row_i, column=col_i, value=float(val))

    wb.save(path)
    return path


def make_csv(path: Path, col: str, values: list[float]) -> Path:
    lines = ["Year," + col]
    for y, v in zip(YEARS, values, strict=True):
        lines.append(f"{y},{v}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def main():
    inv = make_inventory(HERE / "inventory.xlsx")
    gdp = make_csv(
        HERE / "gdp.csv",
        "gdp",
        [1000.0 * (1.03**i) for i in range(len(YEARS))],
    )
    pop = make_csv(
        HERE / "population.csv",
        "pop",
        [10_000_000 + 120_000 * i for i in range(len(YEARS))],
    )
    print(f"[OK] {inv}")
    print(f"[OK] {gdp}")
    print(f"[OK] {pop}")


if __name__ == "__main__":
    main()
