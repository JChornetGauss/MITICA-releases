"""EU-27 TED-as-input backtest (Eurostat panel).

Per JL (2026-06-09): train on history 1995–2018, project 2019–2024, feeding the
OBSERVED TED 2019–2024 back as the country's *projected* TED input (plus the
historical series). Score the projection against reality; report cross-country
patterns; emit the exact inputs used + the results.

Configurations per country (all trained on 1995/2000..2018):
  MAIN  TED-F3  : historical series + projected TED only. Macro (GDP/Pop/SGDP)
                  self-projected by the engine (flow F3). <- what JL asked for.
  base  WoM-F3  : historical series only, NO TED. The model's free energy WoM
                  (same self-projected macro) — the baseline the TED input beats.
  ref   TED-ISO : observed macro 2019–2024 + projected TED. Isolates the split
                  skill from the engine's own macro-projection error.

Data: scripts/macro_validation/data/<CC>_{gdp_pop,sgdp,sed}.csv (Eurostat —
GDP/Pop/sectoral GVA in constant EUR million / persons; final energy by sector
in ktoe). Eurostat lumps industry (manuf+constr) and transport (pass+freight);
the engine splits them internally 70/30 and 65/35 — the within-bin split does not
affect the bin comparison. TED = Σ of the 5 Eurostat final-energy sectors.

Outputs (results/ted_eu27/):
  inputs_all.csv          — every series fed to the engine, per country/year.
  results_by_year.csv     — observed vs projected, per country/year/variable.
  summary_by_country.csv  — per-country metrics.
  MITICA_TED_EU27_backtest.xlsx — the same, as a workbook (README + 3 sheets).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA = Path(__file__).resolve().parent / "data"
OUTDIR = Path(__file__).resolve().parent / "results" / "ted_eu27"

HIST_START_PREF, TRAIN_END, PROJ_END = 1995, 2018, 2024
PROJ_YEARS = list(range(TRAIN_END + 1, PROJ_END + 1))   # 2019..2024
MIN_TRAIN = 12

EU27 = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL",
        "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
        "SI", "ES", "SE"]
NAME = {
    "AT": "Austria", "BE": "Belgium", "BG": "Bulgaria", "HR": "Croatia",
    "CY": "Cyprus", "CZ": "Czechia", "DK": "Denmark", "EE": "Estonia",
    "FI": "Finland", "FR": "France", "DE": "Germany", "EL": "Greece",
    "HU": "Hungary", "IE": "Ireland", "IT": "Italy", "LV": "Latvia",
    "LT": "Lithuania", "LU": "Luxembourg", "MT": "Malta", "NL": "Netherlands",
    "PL": "Poland", "PT": "Portugal", "RO": "Romania", "SK": "Slovakia",
    "SI": "Slovenia", "ES": "Spain", "SE": "Sweden",
}
HIC_TRANS = {"BG", "HR", "CZ", "EE", "HU", "LV", "LT", "MT", "PL", "PT", "RO",
             "SK", "SI"}
REGION = {c: ("HIC_TRANS" if c in HIC_TRANS else "HIC") for c in EU27}

EUROSTAT_SED = ["SED_primary", "SED_manufacturing", "SED_services",
                "SED_transport", "SED_households"]
BIN_AGG = {  # engine 6-sector -> Eurostat 5-bin
    "primary":       lambda s: s["SED_primary"],
    "manufacturing": lambda s: s["SED_manufacturing"] + s["SED_construction"],
    "services":      lambda s: s["SED_services"],
    "transport":     lambda s: s["SED_transport_pass"] + s["SED_transport_freight"],
}
BIN_OBS = {"primary": "SED_primary", "manufacturing": "SED_manufacturing",
           "services": "SED_services", "transport": "SED_transport",
           "households": "SED_households"}
BINS5 = list(BIN_OBS)


def _six(sed_raw):
    o = pd.DataFrame({"Year": sed_raw["Year"]})
    o["SED_primary"] = sed_raw["SED_primary"]
    o["SED_manufacturing"] = sed_raw["SED_manufacturing"] * 0.70
    o["SED_construction"] = sed_raw["SED_manufacturing"] * 0.30
    o["SED_services"] = sed_raw["SED_services"]
    o["SED_transport_pass"] = sed_raw["SED_transport"] * 0.65
    o["SED_transport_freight"] = sed_raw["SED_transport"] * 0.35
    return o


def _slc(df, a, b):
    out = df[(df["Year"] >= a) & (df["Year"] <= b)].sort_values("Year").reset_index(drop=True)
    return out if not out.empty else None


def _mape(p, o):
    p, o = np.asarray(p, float), np.asarray(o, float)
    return float(np.mean(np.abs((p - o) / o)))


def _bias(p, o):
    p, o = np.asarray(p, float), np.asarray(o, float)
    return float(np.mean((p - o) / o))


def _cagr(end, start, n):
    if start <= 0 or end <= 0:
        return float("nan")
    return (end / start) ** (1.0 / n) - 1.0


def run_country(cc):
    try:
        gp = pd.read_csv(DATA / f"{cc}_gdp_pop.csv")
        sg = pd.read_csv(DATA / f"{cc}_sgdp.csv")
        sed_raw = pd.read_csv(DATA / f"{cc}_sed.csv")
    except FileNotFoundError:
        return None, [], []
    common = (set(gp.Year.astype(int)) & set(sg.Year.astype(int))
              & set(sed_raw.Year.astype(int)))
    if not all(y in common for y in PROJ_YEARS):
        return {"cc": cc, "error": "missing observed 2019-2024"}, [], []
    hist_start = max(HIST_START_PREF, min(common))
    train_years = [y for y in range(hist_start, TRAIN_END + 1) if y in common]
    if len(train_years) < MIN_TRAIN:
        return {"cc": cc, "error": f"only {len(train_years)} train years"}, [], []

    sed6 = _six(sed_raw)
    sed_hh = sed_raw[["Year", "SED_households"]].rename(columns={"SED_households": "SED_hh"})
    gdp = sg.assign(GDP_tot=sg.SGDP_primary + sg.SGDP_secondary + sg.SGDP_tertiary)[["Year", "GDP_tot"]]
    ted_obs = sed_raw.assign(TED=sed_raw[EUROSTAT_SED].sum(axis=1))[["Year", "TED"]]

    hist = HistoricalData(
        gdp_tot=_slc(gdp, hist_start, TRAIN_END),
        population=_slc(gp[["Year", "Pop"]], hist_start, TRAIN_END),
        sgdp=_slc(sg, hist_start, TRAIN_END),
        sed=_slc(sed6, hist_start, TRAIN_END),
        sed_hh=_slc(sed_hh, hist_start, TRAIN_END))
    ted_pin = _slc(ted_obs, TRAIN_END + 1, PROJ_END)
    gdp_f = _slc(gdp, TRAIN_END + 1, PROJ_END)
    pop_f = _slc(gp[["Year", "Pop"]], TRAIN_END + 1, PROJ_END)
    sg_f = _slc(sg, TRAIN_END + 1, PROJ_END)
    cfg = MacroConfig(region=REGION[cc], dev_group="H", horizon_year=PROJ_END,
                      validate_historical=False, verbose=False)

    configs = {
        "TEDf3": ProjectedInputs(ted=ted_pin),                       # MAIN (JL)
        "WoMf3": ProjectedInputs(),                                  # baseline
        "TEDiso": ProjectedInputs(gdp_tot=gdp_f, population=pop_f,    # split-skill ref
                                  sgdp=sg_f, ted=ted_pin),
    }
    obs = sed_raw.set_index("Year")
    gobs = gp.set_index("Year")["Pop"]
    gdpobs = gdp.set_index("Year")["GDP_tot"]
    tedobs_i = ted_obs.set_index("Year")["TED"]

    summ = {"cc": cc, "name": NAME[cc], "region": REGION[cc],
            "hist_start": hist_start, "n_train": len(train_years)}
    res_rows, outs = [], {}
    for tag, proj in configs.items():
        out = run_macro_module(hist, proj, cfg)
        outs[tag] = out
        s = out.sed.set_index("Year"); h = out.sed_hh.set_index("Year")
        der = out.derived.set_index("Year")
        gdp_p = out.gdp_tot.set_index("Year")["GDP_tot"]
        pop_p = out.population.set_index("Year")["Pop"]
        # sectoral bins
        bin_mape = {}
        proj_bin = {b: [] for b in BINS5}
        obs_bin = {b: [] for b in BINS5}
        for b in BINS5:
            if b == "households":
                pv = [float(h.at[y, "SED_hh"]) for y in PROJ_YEARS]
            else:
                pv = [float(BIN_AGG[b](s.loc[y])) for y in PROJ_YEARS]
            ov = [float(obs.at[y, BIN_OBS[b]]) for y in PROJ_YEARS]
            proj_bin[b], obs_bin[b] = pv, ov
            bin_mape[b] = _mape(pv, ov)
            summ[f"{tag}_mape_{b}"] = bin_mape[b]
            if tag == "TEDf3":
                for y, p_, o_ in zip(PROJ_YEARS, pv, ov):
                    res_rows.append({"cc": cc, "Year": y, "config": tag,
                                     "variable": f"SED_{b}", "observed": o_,
                                     "projected": p_, "ape": abs(p_ - o_) / o_})
        summ[f"{tag}_mape_sectoral"] = float(np.mean([bin_mape[b] for b in BINS5]))
        # TED-size-weighted sectoral MAPE (down-weights the tiny primary bin)
        wts = np.array([np.mean(obs_bin[b]) for b in BINS5])
        wts = wts / wts.sum()
        summ[f"{tag}_wmape_sectoral"] = float(np.sum(
            [wts[i] * bin_mape[b] for i, b in enumerate(BINS5)]))
        # energy MIS-ALLOCATED as % of TED: mean_y Σ_bin|proj-obs| / mean_y TED_obs
        ted_o_yr = np.array([float(tedobs_i.at[y]) for y in PROJ_YEARS])
        l1 = np.array([sum(abs(proj_bin[b][k] - obs_bin[b][k]) for b in BINS5)
                       for k in range(len(PROJ_YEARS))])
        summ[f"{tag}_sed_misalloc"] = float(np.mean(l1) / np.mean(ted_o_yr))
        # TED total + macro
        ted_p = [float(der.at[y, "TED"]) for y in PROJ_YEARS]
        ted_o = [float(tedobs_i.at[y]) for y in PROJ_YEARS]
        summ[f"{tag}_mape_TED"] = _mape(ted_p, ted_o)
        summ[f"{tag}_bias_TED"] = _bias(ted_p, ted_o)
        gdp_pv = [float(gdp_p.at[y]) for y in PROJ_YEARS]
        gdp_ov = [float(gdpobs.at[y]) for y in PROJ_YEARS]
        pop_pv = [float(pop_p.at[y]) for y in PROJ_YEARS]
        pop_ov = [float(gobs.at[y]) for y in PROJ_YEARS]
        summ[f"{tag}_mape_GDP"] = _mape(gdp_pv, gdp_ov)
        summ[f"{tag}_mape_Pop"] = _mape(pop_pv, pop_ov)
        u3 = [f for f in out.validation_report if f.test_id == "U3"]
        summ[f"{tag}_u3"] = u3[0].severity if u3 else ""
        if tag == "TEDf3":
            for y in PROJ_YEARS:
                res_rows.append({"cc": cc, "Year": y, "config": tag, "variable": "TED",
                                 "observed": float(tedobs_i.at[y]), "projected": float(der.at[y, "TED"]),
                                 "ape": abs(der.at[y, "TED"] - tedobs_i.at[y]) / tedobs_i.at[y]})
                res_rows.append({"cc": cc, "Year": y, "config": tag, "variable": "GDP_tot",
                                 "observed": float(gdpobs.at[y]), "projected": float(gdp_p.at[y]),
                                 "ape": abs(gdp_p.at[y] - gdpobs.at[y]) / gdpobs.at[y]})

    # observed vs WoM-model energy-intensity decline (TED/GDP), real units
    n = len(PROJ_YEARS)
    ei_obs0 = float(tedobs_i.at[TRAIN_END]) / float(gdpobs.at[TRAIN_END])
    ei_obsH = float(tedobs_i.at[PROJ_END]) / float(gdpobs.at[PROJ_END])
    wom_der = outs["WoMf3"].derived.set_index("Year")
    ei_wom0 = float(wom_der.at[TRAIN_END, "TED"]) / float(wom_der.at[TRAIN_END, "GDP_tot"]) \
        if TRAIN_END in wom_der.index else float("nan")
    ei_womH = float(wom_der.at[PROJ_END, "TED"]) / float(wom_der.at[PROJ_END, "GDP_tot"])
    summ["intensity_decline_obs_pctyr"] = -_cagr(ei_obsH, ei_obs0, n) * 100
    summ["intensity_decline_modelWoM_pctyr"] = -_cagr(ei_womH, ei_wom0, n) * 100
    summ["primary_share_TED"] = float(np.mean(
        [float(obs.at[y, "SED_primary"]) / float(tedobs_i.at[y]) for y in PROJ_YEARS]))

    # inputs dump (exactly what's fed): historical series + the projected TED
    inp_rows = []
    hgdp = gdp.set_index("Year"); hpop = gp.set_index("Year"); hsg = sg.set_index("Year")
    for y in train_years:
        row = {"cc": cc, "Year": y, "role": "historical",
               "GDP_tot": float(hgdp.at[y, "GDP_tot"]), "Pop": float(hpop.at[y, "Pop"]),
               "SGDP_primary": float(hsg.at[y, "SGDP_primary"]),
               "SGDP_secondary": float(hsg.at[y, "SGDP_secondary"]),
               "SGDP_tertiary": float(hsg.at[y, "SGDP_tertiary"]),
               **{c: float(obs.at[y, c]) for c in EUROSTAT_SED},
               "TED_input": ""}
        inp_rows.append(row)
    for y in PROJ_YEARS:
        inp_rows.append({"cc": cc, "Year": y, "role": "projected_input",
                         "GDP_tot": "", "Pop": "", "SGDP_primary": "",
                         "SGDP_secondary": "", "SGDP_tertiary": "",
                         **{c: "" for c in EUROSTAT_SED},
                         "TED_input": float(tedobs_i.at[y])})
    return summ, res_rows, inp_rows


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    summaries, results, inputs, errs = [], [], [], []
    for cc in EU27:
        summ, res, inp = run_country(cc)
        if summ is None:
            errs.append((cc, "no data")); continue
        if "error" in summ:
            errs.append((cc, summ["error"])); continue
        summaries.append(summ); results += res; inputs += inp

    sdf = pd.DataFrame(summaries)
    rdf = pd.DataFrame(results)
    idf = pd.DataFrame(inputs)
    sdf.to_csv(OUTDIR / "summary_by_country.csv", index=False)
    rdf.to_csv(OUTDIR / "results_by_year.csv", index=False)
    idf.to_csv(OUTDIR / "inputs_all.csv", index=False)

    # Excel workbook
    readme = pd.DataFrame({"MITICA — TED-as-input backtest, EU-27 (Eurostat)": [
        "Train 1995-2018 (Malta 2000-2018, Estonia from 1995 with one gap);",
        "project 2019-2024 feeding the OBSERVED TED back as the projected TED input.",
        "",
        "MAIN config TEDf3: historical series + projected TED; macro self-projected (flow F3).",
        "baseline WoMf3: historical only, no TED (the free energy WoM, same macro).",
        "ref TEDiso: observed macro 2019-2024 + projected TED (isolates the split skill).",
        "",
        "Data: Eurostat. GDP/sectoral GVA in constant EUR million; population in persons;",
        "final energy by sector in ktoe. TED = sum of the 5 Eurostat final-energy sectors.",
        "Industry (manuf+constr) and transport (pass+freight) split internally 70/30, 65/35.",
        "",
        "Sheets: Inputs (series fed), Results_by_year (observed vs projected, MAIN config),",
        "Summary_by_country (per-country metrics). MAPE = mean abs % error over 2019-2024.",
    ]})
    with pd.ExcelWriter(OUTDIR / "MITICA_TED_EU27_backtest.xlsx", engine="openpyxl") as xw:
        readme.to_excel(xw, sheet_name="README", index=False)
        idf.to_excel(xw, sheet_name="Inputs", index=False)
        rdf.to_excel(xw, sheet_name="Results_by_year", index=False)
        sdf.to_excel(xw, sheet_name="Summary_by_country", index=False)

    # ---- console summary ----
    def med(col):
        return sdf[col].median()

    def p90(col):
        return sdf[col].quantile(.9)

    print(f"=== EU-27 TED-as-input backtest (train -2018, project 2019-2024) ===")
    print(f"  scored {len(sdf)}/27   skipped: {errs}\n")
    print("--- Realistic flow (macro self-projected): does pinning TED help? ---")
    print(f"  {'metric':<34}{'WoM-F3':>12}{'TED-F3':>12}")
    print(f"  {'TED total MAPE (med)':<34}{med('WoMf3_mape_TED'):>11.1%}{med('TEDf3_mape_TED'):>12.1%}")
    print(f"  {'TED total bias (med)':<34}{med('WoMf3_bias_TED'):>+11.1%}{med('TEDf3_bias_TED'):>+12.1%}")
    print(f"  {'sectoral MAPE eq-wt (med)':<34}{med('WoMf3_mape_sectoral'):>11.1%}{med('TEDf3_mape_sectoral'):>12.1%}")
    print(f"  {'sectoral MAPE size-wt (med)':<34}{med('WoMf3_wmape_sectoral'):>11.1%}{med('TEDf3_wmape_sectoral'):>12.1%}")
    print(f"  {'energy mis-allocated %TED (med)':<34}{med('WoMf3_sed_misalloc'):>11.1%}{med('TEDf3_sed_misalloc'):>12.1%}")
    print(f"  {'energy mis-allocated %TED (p90)':<34}{p90('WoMf3_sed_misalloc'):>11.1%}{p90('TEDf3_sed_misalloc'):>12.1%}")
    print(f"  {'GDP self-proj MAPE (med)':<34}{med('WoMf3_mape_GDP'):>11.1%}{med('TEDf3_mape_GDP'):>12.1%}")
    print(f"  {'Pop self-proj MAPE (med)':<34}{med('WoMf3_mape_Pop'):>11.1%}{med('TEDf3_mape_Pop'):>12.1%}")

    print("\n--- Split skill isolated (TED-ISO, observed macro) vs realistic (TED-F3) ---")
    print(f"  sectoral MAPE med: TED-ISO {med('TEDiso_mape_sectoral'):.1%}  |  TED-F3 {med('TEDf3_mape_sectoral'):.1%}")

    print("\n--- Per-bin sectoral MAPE (median): WoM-F3 -> TED-F3 ---")
    for b in BINS5:
        a, bb = med(f"WoMf3_mape_{b}"), med(f"TEDf3_mape_{b}")
        print(f"  {b:<16}{a:>8.1%}  ->  {bb:>7.1%}   (Δ {bb-a:+.1%})")

    print("\n--- By region (sectoral MAPE med, TED-F3) ---")
    for reg in ("HIC", "HIC_TRANS"):
        sub = sdf[sdf.region == reg]
        if len(sub):
            print(f"  {reg:<11} n={len(sub):<2}  WoM {sub['WoMf3_mape_sectoral'].median():.1%}"
                  f"  ->  TED {sub['TEDf3_mape_sectoral'].median():.1%}")

    print("\n--- Energy-intensity decline 2018->2024 (%/yr): observed vs model WoM ---")
    print(f"  observed: med {med('intensity_decline_obs_pctyr'):+.1f}%/yr  "
          f"[{sdf['intensity_decline_obs_pctyr'].min():+.1f}, {sdf['intensity_decline_obs_pctyr'].max():+.1f}]")
    print(f"  model WoM: med {med('intensity_decline_modelWoM_pctyr'):+.1f}%/yr")
    print(f"  U3 verdict (TED-F3): {sdf['TEDf3_u3'].value_counts().to_dict()}")

    print("\n--- Best / worst countries by TED-F3 energy mis-allocation (%TED) ---")
    rank = sdf.sort_values("TEDf3_sed_misalloc")[
        ["cc", "name", "region", "TEDf3_sed_misalloc", "WoMf3_sed_misalloc",
         "TEDf3_mape_sectoral"]]
    for _, r in pd.concat([rank.head(6), rank.tail(6)]).iterrows():
        print(f"  {r['cc']} {r['name']:<12} {r['region']:<10} "
              f"misalloc {r['TEDf3_sed_misalloc']:5.1%} (WoM {r['WoMf3_sed_misalloc']:5.1%})"
              f"  eq-wt MAPE {r['TEDf3_mape_sectoral']:.1%}")

    print(f"\nWrote inputs_all.csv, results_by_year.csv, summary_by_country.csv,"
          f" MITICA_TED_EU27_backtest.xlsx to {OUTDIR}")


if __name__ == "__main__":
    main()
