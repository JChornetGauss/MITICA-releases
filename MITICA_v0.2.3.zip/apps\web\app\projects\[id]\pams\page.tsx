"use client";

import { use, useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Lightbulb, BookOpen, Edit3 } from "lucide-react";

import { api } from "@/lib/api";
import type {
  PAM,
  PAMCatalogEntry,
  PAMTimeDistribution,
  ScenarioKind,
} from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { formatNumber, cn } from "@/lib/utils";

type Mode = "catalog" | "custom";

// Extract A-Z variable aliases (single uppercase char, word-boundary) from a formula
function extractVariables(formula: string): string[] {
  const matches = formula.match(/\b[A-Z]\b/g) ?? [];
  return [...new Set(matches)];
}

export default function PAMsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();

  const { data: forecast } = useQuery({
    queryKey: ["forecast", id],
    queryFn: () => api.getForecast(id),
    retry: false,
  });
  const { data: pams } = useQuery({ queryKey: ["pams", id], queryFn: () => api.listPAMs(id) });
  const { data: catalog } = useQuery({
    queryKey: ["pam-catalog"],
    queryFn: () => api.pamCatalog(),
    staleTime: Infinity,
  });

  const availableCategories = useMemo(() => {
    return forecast?.categories.map((c) => c.ipcc_code).sort() ?? [];
  }, [forecast]);

  const [mode, setMode] = useState<Mode>("catalog");

  // ---- Catalog mode state
  const [sector, setSector] = useState<string>("");
  const [subsector, setSubsector] = useState<string>("");
  const [catalogId, setCatalogId] = useState<string>("");

  // Initialise catalog state once the catalog loads
  useEffect(() => {
    if (!catalog || sector) return;
    const firstSector = Object.keys(catalog)[0];
    if (!firstSector) return;
    setSector(firstSector);
    const firstSub = Object.keys(catalog[firstSector])[0] ?? "";
    setSubsector(firstSub);
    const firstPam = catalog[firstSector][firstSub]?.[0];
    if (firstPam) setCatalogId(firstPam.catalog_id);
  }, [catalog, sector]);

  // When sector changes, pick first subsector + first PAM
  useEffect(() => {
    if (!catalog || !sector) return;
    if (!catalog[sector]) return;
    if (catalog[sector][subsector]) return;
    const firstSub = Object.keys(catalog[sector])[0] ?? "";
    setSubsector(firstSub);
    setCatalogId(catalog[sector][firstSub]?.[0]?.catalog_id ?? "");
  }, [sector, catalog, subsector]);

  // When subsector changes, pick first PAM in it
  useEffect(() => {
    if (!catalog || !sector || !subsector) return;
    const current = catalog[sector]?.[subsector] ?? [];
    if (!current.find((p) => p.catalog_id === catalogId)) {
      setCatalogId(current[0]?.catalog_id ?? "");
    }
  }, [subsector, catalog, sector, catalogId]);

  const selectedEntry: PAMCatalogEntry | null = useMemo(() => {
    if (!catalog || !sector || !subsector) return null;
    return catalog[sector]?.[subsector]?.find((p) => p.catalog_id === catalogId) ?? null;
  }, [catalog, sector, subsector, catalogId]);

  // ---- Common fields (both modes)
  const [name, setName] = useState("");
  const [scenario, setScenario] = useState<ScenarioKind>("WEM");
  const [category, setCategory] = useState("");
  const [cost, setCost] = useState("");
  const [t0, setT0] = useState<number>(2028);
  const [t1, setT1] = useState<string>("");
  const [t2, setT2] = useState<string>("");
  const [distribution, setDistribution] = useState<PAMTimeDistribution>("CONSTANT");
  const [notes, setNotes] = useState("");

  // ---- Custom mode state
  const [customFormula, setCustomFormula] = useState("A * B / 100");

  // ---- Variable values (shared)
  const [varValues, setVarValues] = useState<Record<string, number>>({});

  // Auto-populate state when the selected catalog entry changes
  useEffect(() => {
    if (mode !== "catalog" || !selectedEntry) return;
    setName(selectedEntry.name);
    // Pick a category that exists in the loaded forecast, else the first catalog category
    const match = selectedEntry.categories.find((c) => availableCategories.includes(c));
    setCategory(match ?? selectedEntry.categories[0] ?? availableCategories[0] ?? "");
    const values: Record<string, number> = {};
    for (const v of selectedEntry.variables) {
      values[v.alias] = typeof v.default === "number" ? v.default : 0;
    }
    setVarValues(values);
  }, [selectedEntry, mode, availableCategories]);

  const activeFormula = mode === "catalog" ? selectedEntry?.formula ?? "" : customFormula;
  const activeVariables =
    mode === "catalog"
      ? selectedEntry?.variables ?? []
      : extractVariables(customFormula).map((alias) => ({
          alias,
          name: alias,
          unit: null,
          default: null,
        }));

  const create = useMutation({
    mutationFn: async () => {
      if (!category) throw new Error("Pick a category");
      const pam: PAM = {
        id: `pam_${Date.now()}`,
        name: name.trim() || "Unnamed PAM",
        category,
        scenario,
        formula: activeFormula,
        variables: activeVariables.map((v) => ({
          alias: v.alias,
          name: v.name,
          unit: v.unit ?? null,
          value: varValues[v.alias] ?? 0,
        })),
        cost_usd_per_ton: cost ? Number(cost) : null,
        time_distribution: distribution,
        t0,
        t1: t1 ? Number(t1) : null,
        t2: t2 ? Number(t2) : null,
        annual_mitigation_kt: null,
        dynamic: false,
        notes: notes.trim() || null,
      };
      return api.createPAM(id, pam);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pams", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const del = useMutation({
    mutationFn: (pamId: string) => api.deletePAM(id, pamId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pams", id] }),
  });

  return (
    <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-primary" /> Define a Policy or Measure
          </CardTitle>
          <CardDescription>
            Pick from the <strong>catalog</strong> of {catalog ? countEntries(catalog) : "…"} PAM
            templates (ported from MITICA v1.1s, with formulas & units preset), or write your own.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Tabs value={mode} onValueChange={(v) => setMode(v as Mode)}>
            <TabsList>
              <TabsTrigger value="catalog" className="gap-2">
                <BookOpen className="h-4 w-4" /> From catalog
              </TabsTrigger>
              <TabsTrigger value="custom" className="gap-2">
                <Edit3 className="h-4 w-4" /> Custom formula
              </TabsTrigger>
            </TabsList>

            <TabsContent value="catalog" className="space-y-4 pt-2">
              {!catalog ? (
                <p className="text-sm text-muted-foreground">Loading catalog…</p>
              ) : (
                <>
                  <div className="grid gap-3 md:grid-cols-3">
                    <div>
                      <Label>Sector</Label>
                      <select
                        className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                        value={sector}
                        onChange={(e) => setSector(e.target.value)}
                      >
                        {Object.keys(catalog).map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label>Subsector</Label>
                      <select
                        className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                        value={subsector}
                        onChange={(e) => setSubsector(e.target.value)}
                      >
                        {Object.keys(catalog[sector] ?? {}).map((s) => (
                          <option key={s} value={s}>
                            {s} ({catalog[sector][s].length})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label>PAM template</Label>
                      <select
                        className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                        value={catalogId}
                        onChange={(e) => setCatalogId(e.target.value)}
                      >
                        {(catalog[sector]?.[subsector] ?? []).map((p) => (
                          <option key={p.catalog_id} value={p.catalog_id}>
                            {p.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {selectedEntry && (
                    <div className="rounded-md border bg-muted/40 p-3 text-sm">
                      <p className="font-medium">{selectedEntry.name}</p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Targets IPCC {selectedEntry.categories.join(", ")}
                      </p>
                      <p className="mt-2 font-mono text-xs">= {selectedEntry.formula}</p>
                    </div>
                  )}
                </>
              )}
            </TabsContent>

            <TabsContent value="custom" className="space-y-4 pt-2">
              <div>
                <Label>Formula</Label>
                <Input
                  className="font-mono"
                  value={customFormula}
                  onChange={(e) => setCustomFormula(e.target.value)}
                />
                <p className="mt-1 text-xs text-muted-foreground">
                  Single-letter variables (A, B, …). Allowed: + − * / ** abs sqrt exp log min max round.
                </p>
              </div>
            </TabsContent>
          </Tabs>

          {/* ---- Shared fields ---- */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. 100 MW Solar PV" />
            </div>
            <div>
              <Label>Scenario</Label>
              <select
                className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={scenario}
                onChange={(e) => setScenario(e.target.value as ScenarioKind)}
              >
                <option value="WEM">WEM (already-decided)</option>
                <option value="WAM">WAM (additional)</option>
              </select>
            </div>
            <div>
              <Label>IPCC category</Label>
              <select
                className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                <option value="">— pick a category —</option>
                {availableCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                    {selectedEntry?.categories.includes(c) ? "  ✓" : ""}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Cost (USD / tCO₂eq)</Label>
              <Input type="number" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="e.g. 20" />
            </div>
          </div>

          {activeVariables.length > 0 && (
            <div className="rounded-md border bg-muted/20 p-3">
              <p className="mb-2 text-xs font-medium">Formula variables</p>
              <div className="grid gap-2 md:grid-cols-2">
                {activeVariables.map((v) => (
                  <div key={v.alias} className="grid grid-cols-[auto_1fr] items-center gap-2">
                    <code className="rounded bg-primary/10 px-2 py-1 text-sm font-mono text-primary">
                      {v.alias}
                    </code>
                    <div className="flex-1">
                      <Input
                        type="number"
                        value={varValues[v.alias] ?? ""}
                        onChange={(e) =>
                          setVarValues({ ...varValues, [v.alias]: Number(e.target.value) })
                        }
                      />
                      <p className="mt-0.5 truncate text-[10px] text-muted-foreground">
                        {v.name}
                        {v.unit ? <> — <span className="font-mono">{v.unit}</span></> : null}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>t₀ (start year)</Label>
              <Input type="number" value={t0} onChange={(e) => setT0(Number(e.target.value))} />
            </div>
            <div>
              <Label>Distribution</Label>
              <select
                className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={distribution}
                onChange={(e) => setDistribution(e.target.value as PAMTimeDistribution)}
              >
                <option value="CONSTANT">Constant</option>
                <option value="VARIABLE">Logistic ramp</option>
              </select>
            </div>
            {distribution === "VARIABLE" && (
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>t₁ (50 %)</Label>
                  <Input type="number" value={t1} onChange={(e) => setT1(e.target.value)} />
                </div>
                <div>
                  <Label>t₂ (100 %)</Label>
                  <Input type="number" value={t2} onChange={(e) => setT2(e.target.value)} />
                </div>
              </div>
            )}
          </div>

          <div>
            <Label>Notes (optional)</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Any context" />
          </div>

          <Button onClick={() => create.mutate()} disabled={create.isPending || !category}>
            <Plus className="mr-2 h-4 w-4" />
            {create.isPending ? "Saving…" : "Save PAM"}
          </Button>
          {create.error && (
            <p className="text-xs text-destructive">{(create.error as Error).message}</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Existing PAMs</CardTitle>
          <CardDescription>{pams?.length ?? 0} defined</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Cat</TableHead>
                <TableHead>Scen</TableHead>
                <TableHead className="text-right">kt/yr</TableHead>
                <TableHead className="text-right">$/t</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {(pams ?? []).map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="max-w-[180px]">
                    <div className="truncate font-medium">{p.name}</div>
                    {p.notes && (
                      <div className="truncate text-[10px] text-muted-foreground">{p.notes}</div>
                    )}
                  </TableCell>
                  <TableCell className="font-mono text-xs">{p.category}</TableCell>
                  <TableCell>
                    <Badge variant={p.scenario === "WEM" ? "secondary" : "default"}>
                      {p.scenario}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    {formatNumber(p.annual_mitigation_kt, 2)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatNumber(p.cost_usd_per_ton, 1)}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => del.mutate(p.id)}
                      aria-label="Delete PAM"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {(!pams || pams.length === 0) && (
                <TableRow>
                  <TableCell colSpan={6} className="py-6 text-center text-sm text-muted-foreground">
                    No PAMs defined yet.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function countEntries(cat: Record<string, Record<string, unknown[]>>): number {
  let n = 0;
  for (const sector of Object.values(cat)) {
    for (const sub of Object.values(sector)) {
      n += sub.length;
    }
  }
  return n;
}
