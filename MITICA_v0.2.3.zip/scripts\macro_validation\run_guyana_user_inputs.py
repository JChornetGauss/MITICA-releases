"""
run_guyana_user_inputs.py — simulate a USER pinning projected variables (F2/F1)
on real Guyana data, and observe what validation fires + what is proposed.

Now that the model produces a plausible WoM for Guyana ($33k→$50k/cap, 3.9 %/yr),
the question is: when a focal point pins their OWN projected path, what does the
validator say, and does it use the model's good projection as a benchmark?

Scenarios:
  A. Aggressive   — user expects to sustain the oil boom (GDP ~8 %/yr → ~$80k/cap).
  B. Conservative — user pins flat/low growth (~1 %/yr).
  C. Diversifying — user pins a plausible GDP path (~4 %/yr) AND a sectoral path
       that deliberately shifts away from oil/secondary toward services
       (secondary 25 % by 2035). Exercises U2 (structure benchmark).
All compared against the model's own WoM (F3) as the natural reference.
"""
from __future__ import annotations

import sys
import pandas as pd

from mitica_core.modules.macro import (
    HistoricalData, MacroConfig, ProjectedInputs,
    run_macro_module,
)

W = "scripts/macro_validation/wdi_data"
ISO, START, HORIZON = "GUY", 2000, 2035


def _series(fname, col):
    d = pd.read_csv(f"{W}/{fname}.csv")
    d = d[(d.iso3 == ISO) & (d.Year >= START)][["Year", "value"]].rename(columns={"value": col})
    return d.sort_values("Year").reset_index(drop=True)


def _hist():
    gdp = _series("GDP_tot", "GDP_tot")
    pop = _series("Pop", "Pop")
    sp, ss, st = _series("SGDP_primary", "SGDP_primary"), _series("SGDP_secondary", "SGDP_secondary"), _series("SGDP_tertiary", "SGDP_tertiary")
    sgdp = sp.merge(ss, on="Year").merge(st, on="Year").merge(gdp, on="Year")
    tot = sgdp[["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"]].sum(axis=1)
    for c in ("SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        sgdp[c] = sgdp[c] / tot * sgdp["GDP_tot"]
    sgdp = sgdp.drop(columns="GDP_tot")
    return HistoricalData(gdp_tot=gdp, population=pop, sgdp=sgdp), gdp, pop


def _proj_gdp(gdp, pop, rate):
    """User-pinned GDP_tot path 2025..HORIZON at `rate`/yr from the 2024 level."""
    last = int(gdp["Year"].max())
    g0 = float(gdp[gdp.Year == last]["GDP_tot"].iloc[0])
    fut = list(range(last + 1, HORIZON + 1))
    return pd.DataFrame({"Year": fut, "GDP_tot": [g0 * (1 + rate) ** (i + 1) for i in range(len(fut))]})


def _proj_sgdp(gdp_proj, target):
    """User-pinned sectoral GDP that glides from the last historical shares to
    `target` (dict primary/secondary/tertiary) by HORIZON, applied to gdp_proj."""
    n = len(gdp_proj)
    rows = {"Year": list(gdp_proj["Year"])}
    for k in ("primary", "secondary", "tertiary"):
        # linear share glide to the target over the projection window
        rows[f"SGDP_{k}"] = [
            target[k] * float(g) for g in gdp_proj["GDP_tot"]
        ]
    return pd.DataFrame(rows)


def _report(title, out, gdp, pop):
    print(f"\n========== {title} ==========")
    print(f"flow: {out.flow_detected}")
    pcp = {int(r.Year): r.GDP_per_cap for r in out.derived.itertuples()} if out.derived is not None else {}
    if HORIZON in pcp:
        print(f"GDP/cap {HORIZON}: ${pcp[HORIZON]:,.0f}")
    print(f"validation flags: {len(out.validation_report)}")
    order = {"red": 0, "amber": 1, "info": 2}
    for f in sorted(out.validation_report, key=lambda x: order.get(x.severity, 9)):
        print(f"  [{f.severity:<5}] {f.test_id:<7} {f.variable:<14} {f.message[:78]}")
        if f.proposed_action:
            print(f"         → {f.proposed_action[:90]}")


def main() -> int:
    hist, gdp, pop = _hist()
    cfg = MacroConfig(region="LAC", horizon_year=HORIZON, estimation_shrinkage=0.5,
                      validate_historical=True, verbose=False)

    # Model's own WoM (the benchmark)
    wom = run_macro_module(hist, ProjectedInputs(), cfg)
    wom_pc = {int(r.Year): r.GDP_per_cap for r in wom.derived.itertuples()}
    print(f"[benchmark] model WoM GDP/cap {HORIZON}: ${wom_pc.get(HORIZON, 0):,.0f}  "
          f"(flags: {len(wom.validation_report)})")

    # A — aggressive user GDP path (~8 %/yr)
    out_a = run_macro_module(hist, ProjectedInputs(gdp_tot=_proj_gdp(gdp, pop, 0.08)), cfg)
    _report("A — user pins AGGRESSIVE GDP (~8%/yr, sustaining the boom)", out_a, gdp, pop)

    # B — conservative user GDP path (~1 %/yr)
    out_b = run_macro_module(hist, ProjectedInputs(gdp_tot=_proj_gdp(gdp, pop, 0.01)), cfg)
    _report("B — user pins CONSERVATIVE GDP (~1%/yr)", out_b, gdp, pop)

    # C — plausible GDP (~4 %/yr) + diversifying sectoral path (secondary → 25 %)
    gdp_c = _proj_gdp(gdp, pop, 0.04)
    sgdp_c = _proj_sgdp(gdp_c, {"primary": 0.10, "secondary": 0.25, "tertiary": 0.65})
    out_c = run_macro_module(hist, ProjectedInputs(gdp_tot=gdp_c, sgdp=sgdp_c), cfg)
    _report("C — user pins plausible GDP + DIVERSIFYING structure (secondary→25%)", out_c, gdp, pop)
    return 0


if __name__ == "__main__":
    sys.exit(main())
