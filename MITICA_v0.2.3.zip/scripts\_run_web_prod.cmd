@echo off
rem Helper invoked by start.cmd — runs the Next frontend in PRODUCTION mode.
rem
rem Requires that scripts\install.cmd has already done `pnpm build` so that
rem apps\web\.next\BUILD_ID is present.

set ROOT=%~dp0..
cd /d "%ROOT%\apps\web"
title MITICA Web (production)

if not exist ".next\BUILD_ID" (
    echo.
    echo [MITICA Web] ERROR: no production build found at apps\web\.next.
    echo              Run scripts\install.cmd  (or  cd apps\web ^&^& pnpm build^).
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA Web] starting Next.js (production) on http://localhost:3000 ...
echo.

call pnpm start

echo.
echo [MITICA Web] server exited. Press any key to close this window.
pause >nul
