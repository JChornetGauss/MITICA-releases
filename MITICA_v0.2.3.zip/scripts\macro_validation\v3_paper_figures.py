"""
Generate the figures for the v3 methodological paper.

Produces three PNGs in ``docs/figures/`` ready for inclusion in the paper:

  fig1_eu27_mape.png     Per-country GDP MAPE, v2.0 (log_log) vs v3.0
                          (compositional + Solow), with the 1:1 reference
                          line.
  fig2_b2_priors.png      Regional compositional B2 priors heatmap
                          (β, γ, μ, ν per non-reference sector).
  fig3_solow_bands.png    Regional Solow TFP growth bands: point + p5/p95
                          whiskers per region.

Inputs:
  scripts/macro_validation/results/v3_eu_backtest.csv
  scripts/macro_validation/wdi_data/calibrated_b2_compositional_priors.json
  scripts/macro_validation/wdi_data/calibrated_solow_priors.json
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

FIG_DIR = Path("docs/figures")
DATA_DIR = Path("scripts/macro_validation")
BACKTEST = DATA_DIR / "results" / "v3_eu_backtest.csv"
B2_PRIORS = DATA_DIR / "wdi_data" / "calibrated_b2_compositional_priors.json"
SOLOW_PRIORS = DATA_DIR / "wdi_data" / "calibrated_solow_priors.json"

REGIONS = ("HIC", "HIC_TRANS", "EEU", "APAC", "LAC", "MENA", "SSA")
SECTORS = ("primary", "secondary")
B2_COEFS = ("beta", "gamma", "mu", "nu")


# ---------------------------------------------------------------------------


def fig1_eu27_mape() -> None:
    """Per-country GDP MAPE scatter, v2.0 vs v3.0."""
    if not BACKTEST.exists():
        print(f"  [skip] {BACKTEST} missing")
        return
    df = pd.read_csv(BACKTEST)
    if "mape_gdp" not in df.columns:
        print("  [skip] backtest CSV missing mape_gdp column")
        return
    # Pivot: one row per country, columns for each b2_form
    piv = df.pivot_table(
        index="country", columns="b2_form", values="mape_gdp",
    ).dropna(subset=["log_log", "compositional"])
    if piv.empty:
        print("  [skip] no countries with both v2 and v3 MAPE")
        return

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(piv["log_log"] * 100, piv["compositional"] * 100,
               s=40, alpha=0.7, edgecolor="black", linewidth=0.5)
    for country, row in piv.iterrows():
        ax.annotate(country,
                     (row["log_log"] * 100, row["compositional"] * 100),
                     fontsize=7, alpha=0.85,
                     xytext=(3, 3), textcoords="offset points")
    lim = max(piv["log_log"].max(), piv["compositional"].max()) * 100 * 1.05
    ax.plot([0, lim], [0, lim], "--", color="gray", linewidth=0.8,
            label="1:1 reference")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    ax.set_xlabel("v2.0 log_log MAPE on GDP (%)", fontsize=11)
    ax.set_ylabel("v3.0 compositional + Solow MAPE (%)", fontsize=11)
    ax.set_title(
        "EU-27 backtest: per-country GDP MAPE\n"
        "train 1995-2014, project 2015-2024, Profile A",
        fontsize=11,
    )
    ax.legend(loc="upper left", fontsize=9)
    ax.grid(True, alpha=0.3)
    # Annotation summarising the headline
    n = len(piv)
    below_diag = int(((piv["compositional"] < piv["log_log"]).sum()))
    ax.text(0.95, 0.05,
             f"n = {n} countries\n"
             f"{below_diag}/{n} below the diagonal (v3 better)\n"
             f"Median MAPE: "
             f"{piv['log_log'].median()*100:.1f}% -> "
             f"{piv['compositional'].median()*100:.1f}%\n"
             f"P90 MAPE: "
             f"{piv['log_log'].quantile(0.9)*100:.1f}% -> "
             f"{piv['compositional'].quantile(0.9)*100:.1f}%",
             transform=ax.transAxes, fontsize=9,
             ha="right", va="bottom",
             bbox=dict(boxstyle="round,pad=0.4", facecolor="white",
                        edgecolor="gray", alpha=0.9))
    fig.tight_layout()
    out = FIG_DIR / "fig1_eu27_mape.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"  wrote {out}")


# ---------------------------------------------------------------------------


def fig2_b2_priors() -> None:
    """Heatmap of compositional B2 calibrated coefficients."""
    if not B2_PRIORS.exists():
        print(f"  [skip] {B2_PRIORS} missing")
        return
    payload = json.loads(B2_PRIORS.read_text())
    fig, axes = plt.subplots(1, len(B2_COEFS), figsize=(14, 4),
                              gridspec_kw={"wspace": 0.4})
    for ax, coef in zip(axes, B2_COEFS):
        data = payload.get(coef, {})
        M = np.full((len(REGIONS), len(SECTORS)), np.nan)
        for i, r in enumerate(REGIONS):
            for j, s in enumerate(SECTORS):
                v = data.get(r, {}).get(s)
                if v is not None:
                    M[i, j] = float(v)
        max_abs = float(np.nanmax(np.abs(M))) or 1.0
        im = ax.imshow(M, cmap="RdBu_r", vmin=-max_abs, vmax=max_abs,
                        aspect="auto")
        ax.set_xticks(range(len(SECTORS)))
        ax.set_xticklabels(SECTORS, fontsize=9)
        ax.set_yticks(range(len(REGIONS)))
        ax.set_yticklabels(REGIONS, fontsize=9)
        ax.set_title(coef, fontsize=11)
        for i in range(len(REGIONS)):
            for j in range(len(SECTORS)):
                v = M[i, j]
                if np.isnan(v):
                    ax.text(j, i, "n/a", ha="center", va="center",
                             fontsize=8, color="black")
                else:
                    txt_color = "white" if abs(v) > max_abs * 0.55 else "black"
                    ax.text(j, i, f"{v:+.2f}", ha="center", va="center",
                             fontsize=8, color=txt_color)
        fig.colorbar(im, ax=ax, shrink=0.85)
    fig.suptitle(
        "Compositional B2 priors (WDI panel 1960-2024, 197 countries)\n"
        "Within-FE for beta + nu; pooled-OLS with country clustering for gamma + mu",
        fontsize=12, y=1.04,
    )
    out = FIG_DIR / "fig2_b2_priors.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  wrote {out}")


# ---------------------------------------------------------------------------


def fig3_solow_bands() -> None:
    """Regional Solow TFP growth band: point + p5/p95 whiskers."""
    if not SOLOW_PRIORS.exists():
        print(f"  [skip] {SOLOW_PRIORS} missing")
        return
    payload = json.loads(SOLOW_PRIORS.read_text())
    regions_data = payload.get("regions", {})
    fig, ax = plt.subplots(figsize=(9, 5))
    xs, means, lows, highs, labels = [], [], [], [], []
    for i, r in enumerate(REGIONS):
        d = regions_data.get(r)
        if d is None:
            continue
        m = d.get("tfp_growth_mean")
        lo = d.get("tfp_growth_min")
        hi = d.get("tfp_growth_max")
        if m is None:
            continue
        xs.append(i)
        means.append(m * 100)
        lows.append((m - (lo or m)) * 100)
        highs.append(((hi or m) - m) * 100)
        labels.append(r)
    ax.errorbar(xs, means, yerr=[lows, highs], fmt="o",
                 markersize=8, capsize=6, linewidth=1.5,
                 color="#3a6ea5", ecolor="#3a6ea5", alpha=0.9,
                 label="median +/- (p5, p95)")
    ax.axhline(0, color="gray", linewidth=0.6, alpha=0.7)
    ax.set_xticks(xs)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("Solow TFP growth (%/yr)", fontsize=11)
    ax.set_title(
        "Regional TFP growth bands (WDI 1960-2024 Solow accounting)\n"
        "Cobb-Douglas with alpha = 1/3, delta = 5%, K via perpetual inventory",
        fontsize=11,
    )
    ax.grid(True, alpha=0.3, axis="y")
    ax.legend(loc="upper left", fontsize=9)
    # Annotate counts
    for i, r in enumerate(labels):
        d = regions_data.get(r) or {}
        n = d.get("n_countries", 0)
        ax.annotate(f"n={n}", (xs[i], means[i]),
                     fontsize=8, xytext=(8, -3),
                     textcoords="offset points", color="gray")
    fig.tight_layout()
    out = FIG_DIR / "fig3_solow_bands.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"  wrote {out}")


# ---------------------------------------------------------------------------


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    print("=== MITICA v3 paper figures ===\n")
    fig1_eu27_mape()
    fig2_b2_priors()
    fig3_solow_bands()
    print(f"\nFigures saved under {FIG_DIR.resolve()}/")


if __name__ == "__main__":
    main()
