"""English technical report - Part I: Executive summary, Introduction,
Theoretical framework. Exposed as content_part1(styles, data) -> list[Flowable]."""

from __future__ import annotations

from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, Spacer, PageBreak

from report_common import header_table


def P(s, sty):
    return Paragraph(s, sty)


def content_part1(S, data):
    """Return Story flowables for cover + Part I (sections 0-3)."""
    out = []

    # ============================================================
    # COVER
    # ============================================================
    out.append(Spacer(1, 2.5*cm))
    out.append(P("MITICA Macroeconomic Module", S["TITLE"]))
    out.append(P("Methodological Specification, Calibration, and Empirical "
                  "Validation", S["SUB"]))
    out.append(Spacer(1, 0.5*cm))
    out.append(P("Technical Report &mdash; Version 2.0", S["SUB"]))
    out.append(P("May 2026", S["SUB"]))
    out.append(Spacer(1, 1.5*cm))
    out.append(P("Gauss", S["AUTHOR"]))
    out.append(P("prepared for the UNFCCC Secretariat", S["AUTHOR"]))
    out.append(Spacer(1, 0.8*cm))
    out.append(P(
        "<b>Abstract.</b> This report presents the methodological "
        "specification, calibration strategy, and empirical validation of "
        "the macroeconomic module of MITICA (Mitigation-Inventory Tool for "
        "Integrated Climate Action). The module provides the macroeconomic "
        "drivers &mdash; GDP, population, sectoral value added, sectoral "
        "energy demand &mdash; that feed the sectoral emissions projection "
        "pipeline. The new specification departs from the v1.1s legacy in "
        "three material respects. First, it replaces a defective ridge "
        "regression with a closed-form Gaussian-Gaussian Bayesian update "
        "that respects the prior covariance structure and produces "
        "calibrated credible intervals. Second, it forbids the synthesis of "
        "missing covariates, exposing instead a transparent provenance tag "
        "on every estimated parameter. Third, it introduces four optional "
        "alternative functional forms motivated by structural economic "
        "theory (Kuznets-Chenery, Bashmakov, Bennett) which the user can "
        "select per block to match the regional regime. A regional prior "
        "system is calibrated against the World Bank's WDI panel of 217 "
        "countries and Eurostat's nrg_bal_c energy panel of 29 European "
        "economies. We report a 200-replicate Monte Carlo coverage study, a "
        "25-country EU-27 out-of-sample backtest for sectoral GDP, and a "
        "29-country EU-29 out-of-sample backtest for sectoral energy "
        "demand. The validated default configuration produces a 5.14% "
        "median absolute percentage error on tertiary GDP and a 22.6% MAPE "
        "on manufacturing energy in mature high-income economies over a "
        "19-year out-of-sample window, an improvement of 4.8 percentage "
        "points on manufacturing energy over the legacy specification. "
        "Three numerical sensitivity examples illustrate the operational "
        "implications for emissions scenarios.",
        S["ABSTRACT"],
    ))

    out.append(PageBreak())

    # ============================================================
    # TABLE OF CONTENTS (manual; ReportLab TOC requires multi-pass)
    # ============================================================
    out.append(P("Contents", S["H1"]))
    toc_items = [
        ("1.",  "Executive Summary"),
        ("2.",  "Introduction and Scope"),
        ("3.",  "Theoretical Framework"),
        ("4.",  "Model Specification"),
        ("5.",  "Estimation Strategy"),
        ("6.",  "Data and Calibration"),
        ("7.",  "Empirical Validation"),
        ("8.",  "Numerical Sensitivity Examples"),
        ("9.",  "Implications for Emissions Projections"),
        ("10.", "Limitations and Caveats"),
        ("11.", "Discussion and Outstanding Work"),
        ("A.",  "Mathematical Derivations"),
        ("B.",  "Stylised Regional Priors"),
        ("C.",  "Glossary"),
        ("D.",  "References"),
    ]
    rows = [[num, title] for num, title in toc_items]
    out.append(header_table([["", "Section"]] + rows,
                              col_widths=[1.5*cm, 14*cm]))
    out.append(PageBreak())

    # ============================================================
    # 1. EXECUTIVE SUMMARY
    # ============================================================
    out.append(P("1.&nbsp;&nbsp; Executive Summary", S["H1"]))

    out.append(P("1.1&nbsp; Motivation", S["H2"]))
    out.append(P(
        "Long-horizon greenhouse-gas projections rest on macroeconomic "
        "trajectories: total output, demographic dynamics, the sectoral "
        "composition of value added, and the energy intensity of each "
        "productive activity. The MITICA macro module produces these "
        "drivers for every year of the projection horizon and hands them "
        "off to the sectoral emissions modules (Energy, LULUCF, F-gases, "
        "Transport, Waste). The v1.1s implementation of the module relied "
        "on a constant-elasticity log-log specification estimated by "
        "penalised least squares with a flawed posterior-variance formula. "
        "Three structural problems motivated the present revision: (i) the "
        "v1.1s estimator collapsed the credible intervals at high "
        "shrinkage, producing overconfident parameter values; (ii) when "
        "the user did not supply sectoral investment or public capital "
        "data, the module synthesised the missing covariates as fixed "
        "fractions of sectoral GDP, generating a design matrix linearly "
        "dependent on the target; (iii) the constant-elasticity form fails "
        "to capture three well-documented structural patterns in long-"
        "horizon data: the Kuznets-Chenery hump in the secondary share, "
        "the income-driven decline in energy intensity (Bashmakov), and "
        "the dietary shift toward animal protein with rising income "
        "(Bennett). The present specification addresses these three "
        "issues.", S["BODY"]))

    out.append(P("1.2&nbsp; Headline Findings", S["H2"]))
    out.append(P("<b>1.</b> The Bayesian estimator passes a Monte Carlo "
                  "recovery test with 92-100% credible-interval coverage at "
                  "all shrinkage levels.", S["BULLET"]))
    out.append(P("<b>2.</b> On an out-of-sample backtest of 25 EU-27 "
                  "countries (training 1995-2005, test 2006-2024) the "
                  "recommended configuration achieves a median absolute "
                  "percentage error of <b>5.14%</b> on tertiary GDP at the "
                  "horizon, the best result across all functional-form "
                  "combinations tested.", S["BULLET"]))
    out.append(P("<b>3.</b> On the energy side, calibrating the intensity-"
                  "convergence form against the Eurostat nrg_bal_c panel "
                  "yields an income elasticity of manufacturing energy "
                  "intensity of <b>-1.23</b> in mature OECD economies, 2.5 "
                  "times stronger than the literature-derived stylised "
                  "prior. The calibrated form reduces the manufacturing "
                  "energy MAPE by 4.8 percentage points relative to the "
                  "legacy log-log baseline.", S["BULLET"]))
    out.append(P("<b>4.</b> Country-clustered bootstrap analysis on the "
                  "calibrated priors reveals that the Pop elasticities "
                  "(&zeta;_s) are precisely identified by the global panel, "
                  "while the income shifters (&kappa;, &kappa;&sup2;) are "
                  "mostly NOT statistically distinguishable from zero at "
                  "the regional level. The methodological consequence: the "
                  "country-level Bayesian update has wide enough priors on "
                  "&kappa; that local data carries the identification.",
                  S["BULLET"]))
    out.append(P("<b>5.</b> A new validation test (T8, structural-break "
                  "detector) correctly flags 10 of 25 EU-27 countries "
                  "where the post-2008 trajectory diverges from the "
                  "1995-2005 training distribution &mdash; including all "
                  "the documented bust countries (Spain housing, Cyprus "
                  "financial sector, Ireland Celtic Tiger, Latvia IMF "
                  "rescue).", S["BULLET"]))

    out.append(P("1.3&nbsp; What is New Relative to v1.1s", S["H2"]))
    out.append(header_table([
        ["Block",              "v1.1s",
         "v2.0 (this report)"],
        ["Estimator",          "Ridge with bug in posterior variance",
         "Closed-form Bayesian; bootstrap CIs"],
        ["Missing drivers",    "Synthesised as fixed fraction of SGDP",
         "Excluded; coefficient stays at prior (tagged 'calibrated')"],
        ["B2 (sectoral GDP) forms", "log-log",
         "log-log, Kuznets-Chenery, KC quadratic"],
        ["B3 (crops/livestock) forms", "Constant share",
         "Constant or Bennett logistic"],
        ["B5 (sectoral energy) forms", "log-log",
         "log-log or intensity convergence"],
        ["B6 (residential) forms", "log-log",
         "log-log or saturation (quadratic)"],
        ["Regional priors",    "Hand-coded stylised",
         "WDI + Eurostat calibrated; bootstrap-validated"],
        ["Region taxonomy",    "6 regions",
         "7 (HIC split into mature and transitioning)"],
        ["Validation tests",   "T1-T6",
         "T1-T8 (added plausibility test T7, structural break T8)"],
        ["Unit tests in core", "0 dedicated",
         "46 macro tests; 138 across the whole core library"],
    ], col_widths=[3.5*cm, 5.5*cm, 7.5*cm]))
    out.append(Spacer(1, 0.4*cm))

    out.append(P("1.4&nbsp; Report Structure", S["H2"]))
    out.append(P(
        "Sections 2 and 3 establish the scope of the module and the "
        "economic theory that motivates each functional form. Section 4 "
        "specifies the model layer by layer, with the equations stated in "
        "their working form. Section 5 derives the Bayesian estimator. "
        "Section 6 documents the data sources and the calibration "
        "pipeline. Section 7 reports the Monte Carlo and EU backtests. "
        "Section 8 presents three numerical sensitivity examples in "
        "operational scenarios. Section 9 connects the macro outputs to "
        "the emissions projection downstream. Section 10 enumerates the "
        "limitations honestly. Section 11 discusses outstanding work. "
        "Four appendices give the formal derivations, the stylised priors "
        "for regions without calibration, a glossary, and the references. "
        "Code references in monospace point to the Python source under "
        "<font face='Courier'>packages/core/src/mitica_core/modules/macro/"
        "</font>; the calibration scripts live under "
        "<font face='Courier'>scripts/macro_validation/</font>.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 2. INTRODUCTION AND SCOPE
    # ============================================================
    out.append(P("2.&nbsp;&nbsp; Introduction and Scope", S["H1"]))

    out.append(P("2.1&nbsp; Position in MITICA", S["H2"]))
    out.append(P(
        "MITICA is a Python desktop / web application that supports Parties "
        "to the Paris Agreement in constructing greenhouse-gas emission "
        "scenarios consistent with their national inventory. The tool was "
        "introduced in Mart&iacute;n-Ortega et al. (2024) and distributed "
        "through the UNFCCC Secretariat. The application produces three "
        "scenarios &mdash; Without Measures (WoM), With Existing Measures "
        "(WEM), and With Additional Measures (WAM) &mdash; for every IPCC "
        "category of the national inventory, anchored on a baseline "
        "projection of macroeconomic activity.", S["BODY"]))
    out.append(P(
        "The macroeconomic module supplies the activity drivers for the "
        "WoM baseline. Concretely, for every projection year t &isin; "
        "[T+1, H] the module produces:", S["BODY"]))
    out.append(P("&bull; total GDP, GDP_tot;", S["BULLET"]))
    out.append(P("&bull; total population, Pop;", S["BULLET"]))
    out.append(P("&bull; sectoral value added split into primary, "
                  "secondary and tertiary, SGDP_s;", S["BULLET"]))
    out.append(P("&bull; sectoral final energy demand for six energy "
                  "sectors, SED_k;", S["BULLET"]))
    out.append(P("&bull; residential final energy demand, SED_hh;",
                  S["BULLET"]))
    out.append(P("&bull; livestock heads and crop / livestock value-added "
                  "split;", S["BULLET"]))
    out.append(P("&bull; total energy demand (TED) by identity.",
                  S["BULLET"]))
    out.append(P(
        "These drivers feed the sectoral modules (Energy, IPPU, Agriculture, "
        "LULUCF, Waste) which produce emission projections per IPCC "
        "category. The macro module does NOT compute emissions directly; "
        "it computes the activity variables that the downstream emission "
        "factors are applied to. The accounting identity TED = sum SED_k "
        "+ SED_hh is enforced by Layer A.", S["BODY"]))

    out.append(P("2.2&nbsp; Design Constraints", S["H2"]))
    out.append(P(
        "The module is calibrated to the empirical regularities of small-"
        "data, long-horizon macroeconomic forecasting. National inventories "
        "typically contain 15-25 years of historical data; the projection "
        "horizon is 25-30 years. The estimator must therefore: (a) extract "
        "useful information from short series without overfitting, (b) "
        "remain transparent and auditable for national modellers operating "
        "under UNFCCC's Enhanced Transparency Framework (ETF), (c) refuse "
        "to invent data the user did not supply, and (d) flag situations "
        "where it is extrapolating beyond the regime captured by the "
        "training window. Bayesian shrinkage with regional priors meets "
        "the first three criteria; the validation layer (T7, T8) addresses "
        "the fourth.", S["BODY"]))

    out.append(P("2.3&nbsp; User Flows", S["H2"]))
    out.append(P(
        "Three user-input flows are recognised by the module:", S["BODY"]))
    out.append(P("<b>F1 (full path).</b> The user supplies GDP_tot, Pop, "
                  "and SGDP for the full horizon. Common in NDC "
                  "submissions where the national modeller has an exogenous "
                  "GDP projection from the finance ministry. The module "
                  "respects the user's paths verbatim and runs plausibility "
                  "test T7 to flag inconsistencies between the user's "
                  "trajectory and the model's data-driven prediction.",
                  S["BULLET"]))
    out.append(P("<b>F2 (partial path).</b> At least one of GDP_tot, Pop, "
                  "SGDP is supplied. The module fills the others from the "
                  "estimator. The typical case is GDP_tot supplied (often "
                  "with an aspirational growth target) and the sectoral "
                  "composition computed.", S["BULLET"]))
    out.append(P("<b>F3 (priors only).</b> Nothing is supplied for the "
                  "future. The module relies entirely on the regional "
                  "priors and the user's historical data. Useful for "
                  "scoping exercises where the country has no formal "
                  "macroeconomic scenario.", S["BULLET"]))
    out.append(P(
        "In all flows the module maintains a parallel <i>model-only</i> "
        "trajectory (ignoring any user override) which is consumed by the "
        "validation tests T7 (plausibility) and T8 (structural break).",
        S["BODY"]))

    out.append(P("2.4&nbsp; Origin tagging as the transparency interface",
                  S["H2"]))
    out.append(P(
        "Every estimated parameter carries one of three origin tags: "
        "<i>estimated</i> (the country data dominated), <i>adjusted</i> "
        "(data and prior contributed roughly equally), and <i>calibrated</i> "
        "(the regional prior dominates, typically because the country "
        "lacked the historical series needed to identify the coefficient). "
        "The tag is part of the module's output contract and is intended "
        "to be displayed to the user in the wizard interface. The "
        "epistemic interpretation: when a parameter is <i>calibrated</i>, "
        "the projection's behaviour along that axis reflects regional "
        "literature rather than the country's own experience, and should "
        "be reported as such in any methodology annex submitted under the "
        "ETF.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 3. THEORETICAL FRAMEWORK
    # ============================================================
    out.append(P("3.&nbsp;&nbsp; Theoretical Framework", S["H1"]))
    out.append(P(
        "The four alternative functional forms in v2.0 are not arbitrary "
        "specification choices: each corresponds to a well-documented "
        "empirical regularity in the structural transformation literature. "
        "This section summarises the theory and reviews the most relevant "
        "references; the actual estimating equations are stated in "
        "Section 4 and derived in Appendix A.", S["BODY"]))

    out.append(P("3.1&nbsp; The constant-elasticity baseline", S["H2"]))
    out.append(P(
        "The log-log specification:", S["BODY"]))
    out.append(P("log SGDP_s,t = &alpha;_s + &beta;_s log SInv_s,t "
                  "+ &gamma;_s log GFCF_pub_s,t + &zeta;_s log Pop_t "
                  "+ &delta;_s iRate_t + &epsilon;_s,t", S["EQN"]))
    out.append(P(
        "is the workhorse of small-data macroeconometric forecasting. It "
        "is theoretically grounded in a Cobb-Douglas production function "
        "where capital, labour and productivity enter multiplicatively, "
        "and empirically attractive because it is identified by ordinary "
        "least squares on short series. Its principal limitation is the "
        "imposition of <b>constant</b> elasticities throughout the income "
        "range: at high income an extra unit of investment is assumed to "
        "have the same proportional effect on output as at low income, "
        "and the share of each sector is implicitly held constant. Both "
        "assumptions are violated in the data over the multi-decade "
        "horizon relevant to climate scenarios.", S["BODY"]))

    out.append(P("3.2&nbsp; Structural transformation: Kuznets and Chenery",
                  S["H2"]))
    out.append(P(
        "Kuznets (1957, 1971) documented that as income per capita rises, "
        "the share of agriculture in total output falls monotonically, "
        "the share of industry rises and then falls (an inverse-U), and "
        "the share of services rises monotonically. Chenery and Syrquin "
        "(1975, 1986) and later Herrendorf, Rogerson and Valentinyi "
        "(2014) confirmed the pattern on long-panel cross-country data: "
        "in the developing-to-middle-income transition, primary share "
        "falls by 10-20 percentage points per doubling of GDP per capita, "
        "secondary share rises by 5-15 percentage points before peaking, "
        "and tertiary share rises monotonically.", S["BODY"]))
    out.append(P(
        "The simplest way to embed this pattern in a log-log specification "
        "is to add an income shifter:", S["BODY"]))
    out.append(P("log SGDP_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1}",
                  S["EQN"]))
    out.append(P(
        "with &kappa;_primary &lt; 0, &kappa;_tertiary &gt; 0 and "
        "&kappa;_secondary &asymp; 0 in steady state. The lag is critical "
        "for projection: at t the model knows GDP/Pop_{t-1}, so the "
        "regressor is exogenous in the projection loop and no fixed-point "
        "iteration is needed. We refer to this as the Kuznets-Chenery "
        "linear form (KC).", S["BODY"]))
    out.append(P(
        "The inverse-U in secondary is non-monotonic and is therefore "
        "imperfectly captured by the linear shifter. Adding a quadratic "
        "term in log GDP per capita:", S["BODY"]))
    out.append(P("log SGDP_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1} "
                  "+ &kappa;&sup2;_s [log(GDP/Pop)_{t-1}]&sup2;", S["EQN"]))
    out.append(P(
        "with &kappa;&sup2;_secondary &lt; 0 produces the hump shape with "
        "peak at log(GDP/Pop)* = &minus; &kappa; / (2 &kappa;&sup2;). We "
        "refer to this as the Kuznets-Chenery quadratic form (KCQ). The "
        "calibrated peak for the EU mature pool falls at log(GDP/Pop) "
        "&asymp; 17.6 in the share-form regression and at &asymp; 9.45 in "
        "the level form (Section 6), consistent with the empirical "
        "observation that the Western European economies have moved past "
        "the industrial peak in the past three decades.", S["BODY"]))

    out.append(P("3.3&nbsp; Energy intensity and the Bashmakov law", S["H2"]))
    out.append(P(
        "Bashmakov (2007) formulated the empirical regularity that "
        "sectoral energy intensity (energy use per unit of output) "
        "declines with income in mature economies. The mechanism is "
        "compound: efficiency improvements in capital stock, structural "
        "shifts toward less energy-intensive activities, and the diffusion "
        "of best-available technologies. In the developing phase of "
        "industrialisation, intensity often <b>rises</b> before peaking, "
        "as the energy-intensive activities (mining, heavy industry) grow "
        "faster than the energy-extensive ones. The intensity-convergence "
        "form encodes this:", S["BODY"]))
    out.append(P("log(SED_k / scale_k) = &phi;_k + &psi;_k log(GDP/Pop)",
                  S["EQN"]))
    out.append(P(
        "where scale_k is the natural activity driver for sector k (e.g. "
        "SGDP_secondary for manufacturing) and &psi;_k is the income "
        "elasticity of intensity. The choice of <b>intensity</b> rather "
        "than <b>level</b> as the dependent variable pins the activity "
        "elasticity to unity (a proportional response to scale) and "
        "isolates the income-driven decoupling in &psi;_k. For mature "
        "OECD economies the Schipper-Meyers (1992) panels and the IEA "
        "World Energy Outlook (annually) report &psi;_manufacturing on "
        "the order of -0.5 to -1.0 over multi-decade windows; we recover "
        "&psi;_manufacturing = -1.23 on the Eurostat panel (Section 6.3), "
        "stronger than the literature consensus but consistent with the "
        "additional drivers (ETS pricing, energy-efficiency directives) "
        "in the European policy environment.", S["BODY"]))

    out.append(P("3.4&nbsp; Bennett's law in primary value added", S["H2"]))
    out.append(P(
        "Bennett (1941) documented that the consumption mix shifts from "
        "starches toward animal protein as income rises. The implication "
        "for the value-added composition of agriculture: the livestock "
        "share grows with income while the crops share falls. The "
        "MITICA module decomposes primary sector value added into crops, "
        "livestock and other; the Bennett-logistic form encodes the "
        "income response on the livestock share:", S["BODY"]))
    out.append(P("logit(share_livestock_t) = a_B + b_B log(GDP/Pop_t)",
                  S["EQN"]))
    out.append(P(
        "where logit(p) = log(p / (1 &minus; p)) keeps the implied share "
        "bounded in (0, 1) by construction. b_B &gt; 0 is Bennett's law. "
        "The share of crops is the residual 1 &minus; share_livestock "
        "&minus; share_other, with share_other held at the regional "
        "default. The form is statistically equivalent to a binomial "
        "logistic regression but applied to value-added shares rather "
        "than counts. Recovery testing on synthetic data confirms the "
        "estimator returns a_B and b_B within tolerance under reasonable "
        "noise (Section 7).", S["BODY"]))

    out.append(P("3.5&nbsp; Saturation in residential energy", S["H2"]))
    out.append(P(
        "Per-capita residential energy demand rises rapidly in the "
        "developing phase of an economy as appliances diffuse, then "
        "plateaus as saturation is approached. The plateau is reached at "
        "different income thresholds in different climates, but is a "
        "robust feature of the IEA cross-country data. We capture this "
        "with a quadratic in log GDP per capita:", S["BODY"]))
    out.append(P("log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) "
                  "+ &gamma;_hh [log(GDP/Pop_t)]&sup2; "
                  "+ &zeta;_hh log Pop_t", S["EQN"]))
    out.append(P(
        "with &gamma;_hh &lt; 0. The inflection where the marginal income "
        "response is zero falls at log(GDP/Pop)* = &minus; &beta;_hh / "
        "(2 &gamma;_hh). The form is mathematically convenient (linear in "
        "parameters under Bayesian ridge) and avoids the explicit logistic "
        "asymptote. The calibrated inflection for the EU mature pool "
        "coincides with the sample mean log GDP per capita, consistent "
        "with appliance saturation in mature OECD economies.", S["BODY"]))

    out.append(P("3.6&nbsp; Where structural-form choice matters less",
                  S["H2"]))
    out.append(P(
        "Two observations qualify the case for the alternative forms. "
        "First, when the user supplies the full GDP and SGDP path (flow "
        "F1), the module respects that path and the choice of B2 form "
        "affects only the model-only plausibility trajectory used by T7. "
        "Second, when the projection horizon contains a regime change "
        "that is not in the training window (the 2008 financial crisis, "
        "COVID-19, an energy transition policy), no constant-elasticity "
        "or polynomial-in-log-GDP form can predict it from prior data. "
        "The role of the alternative forms is to extract the structural "
        "signal embedded in the training window, not to anticipate "
        "unforecastable breaks. Layer C test T8 is designed to flag these "
        "breaks when they show up in the projection.", S["BODY"]))

    out.append(PageBreak())

    return out
