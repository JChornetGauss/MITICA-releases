"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export type ModuleStatus = "ready" | "beta" | "coming_soon" | "planned";

interface ModuleCardProps {
  number: string; // "01", "02", "03" — editorial numbering
  icon: ReactNode;
  title: string;
  serifTitle?: string; // An italic serif word inside the title, e.g. "Macro*economic*"
  subtitle: string;
  description: string;
  tooltip: ReactNode;
  href: string;
  status?: ModuleStatus;
  accentColor?: "teal" | "indigo" | "amber";
  primary?: boolean;
  ctaLabel?: string;
  disabled?: boolean;
}

const STATUS_LABEL: Record<ModuleStatus, { label: string; color: string }> = {
  ready: { label: "Ready", color: "bg-primary text-primary-foreground" },
  beta: { label: "Beta", color: "bg-amber-600/10 text-amber-700 border border-amber-600/30" },
  coming_soon: {
    label: "Soon",
    color: "bg-muted text-muted-foreground border border-border",
  },
  planned: { label: "Planned", color: "bg-muted text-muted-foreground border border-border" },
};

const ACCENT_CLASSES: Record<
  NonNullable<ModuleCardProps["accentColor"]>,
  { rule: string; icon: string; glow: string }
> = {
  teal: {
    rule: "from-[hsl(var(--primary))]",
    icon: "text-[hsl(var(--primary))]",
    glow: "bg-[hsl(var(--primary))]/8",
  },
  indigo: {
    rule: "from-indigo-600",
    icon: "text-indigo-600",
    glow: "bg-indigo-600/5",
  },
  amber: {
    rule: "from-amber-700",
    icon: "text-amber-700",
    glow: "bg-amber-700/5",
  },
};

export function ModuleCard({
  number,
  icon,
  title,
  serifTitle,
  subtitle,
  description,
  tooltip,
  href,
  status = "ready",
  accentColor = "teal",
  primary = false,
  ctaLabel = "Open",
  disabled = false,
}: ModuleCardProps) {
  const statusCfg = STATUS_LABEL[status];
  const accent = ACCENT_CLASSES[accentColor];

  const Inner = (
    <article
      className={cn(
        "group relative flex h-full flex-col overflow-hidden rounded-sm border border-border/80 bg-card transition-all duration-300",
        !disabled &&
          "hover:-translate-y-0.5 hover:border-foreground/20 hover:shadow-[0_24px_40px_-24px_rgba(20,25,35,0.15)]",
        disabled && "opacity-55",
        primary && "ring-1 ring-primary/15",
      )}
    >
      {/* Glow on hover */}
      <div
        aria-hidden
        className={cn(
          "pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100",
          accent.glow,
        )}
      />

      {/* Top accent rule */}
      <div
        aria-hidden
        className={cn("h-[3px] bg-gradient-to-r to-transparent", accent.rule)}
      />

      <div className="relative flex flex-1 flex-col p-8">
        {/* Header row: number + status */}
        <div className="mb-7 flex items-start justify-between">
          <div className="flex items-baseline gap-3">
            <span className="font-serif text-xl italic text-foreground/30">{number}</span>
            <span className="eyebrow">Module</span>
          </div>
          <span
            className={cn(
              "rounded-full px-2.5 py-0.5 text-[10px] font-medium tracking-wide",
              statusCfg.color,
            )}
          >
            {statusCfg.label}
          </span>
        </div>

        {/* Icon + title */}
        <div className="mb-6 flex items-start gap-4">
          <div className={cn("mt-1 shrink-0", accent.icon)}>{icon}</div>
          <div>
            <h3 className="font-serif text-[28px] leading-[1.08] tracking-tight">
              {title}
              {serifTitle && (
                <span className="italic text-foreground/85"> {serifTitle}</span>
              )}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
          </div>
        </div>

        <p className="mb-8 flex-1 text-[15px] leading-relaxed text-foreground/80">
          {description}
        </p>

        <div className="flex items-center justify-between border-t border-border/60 pt-5">
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
                onClick={(e) => e.preventDefault()}
              >
                <span className="h-1 w-1 rounded-full bg-current" />
                Hover for details
              </button>
            </TooltipTrigger>
            <TooltipContent
              side="bottom"
              align="start"
              className="max-w-md rounded-sm border-border/80 text-left font-sans"
            >
              {tooltip}
            </TooltipContent>
          </Tooltip>
          <span
            className={cn(
              "inline-flex items-center gap-1.5 text-sm font-medium transition-transform duration-300",
              !disabled && "group-hover:translate-x-0.5",
              accent.icon,
            )}
          >
            {ctaLabel}
            <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
      </div>
    </article>
  );

  if (disabled) return <div>{Inner}</div>;
  return <Link href={href}>{Inner}</Link>;
}
