"use client";

import { useState } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, FileWarning, Trash2, Folder, ArrowLeft } from "lucide-react";

import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate } from "@/lib/utils";
import type { Project } from "@/lib/types";

export default function ProjectsPage() {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", country_code: "", description: "" });

  const { data: projects, isLoading, error } = useQuery<Project[]>({
    queryKey: ["projects"],
    queryFn: api.listProjects,
  });

  const create = useMutation({
    mutationFn: () =>
      api.createProject({
        name: form.name.trim(),
        country_code: form.country_code.trim() || "UNK",
        description: form.description.trim(),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      setShowForm(false);
      setForm({ name: "", country_code: "", description: "" });
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => api.deleteProject(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <Link
        href="/"
        className="mb-3 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3 w-3" /> Home
      </Link>

      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Integration Module — projects</h1>
          <p className="text-sm text-muted-foreground">
            Each project = one country × one BTR / NDC cycle. Start by creating one.
          </p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>
          <Plus className="mr-2 h-4 w-4" />
          New project
        </Button>
      </div>

      {showForm && (
        <Card className="mb-8 border-primary/30">
          <CardHeader>
            <CardTitle>Create a project</CardTitle>
            <CardDescription>Name, ISO-3 country code, and a short description.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="p-name">Name</Label>
              <Input
                id="p-name"
                placeholder="e.g. NDC-2030-SLV"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="p-cc">ISO-3 country code</Label>
                <Input
                  id="p-cc"
                  maxLength={3}
                  placeholder="SLV"
                  value={form.country_code}
                  onChange={(e) => setForm({ ...form, country_code: e.target.value.toUpperCase() })}
                />
              </div>
              <div>
                <Label htmlFor="p-desc">Description</Label>
                <Input
                  id="p-desc"
                  placeholder="Optional"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={() => create.mutate()}
                disabled={!form.name.trim() || create.isPending}
              >
                {create.isPending ? "Creating…" : "Create"}
              </Button>
              <Button variant="ghost" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              {create.error && (
                <span className="text-sm text-destructive">
                  {(create.error as Error).message}
                </span>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-44" />
          ))}
        </div>
      )}

      {error && (
        <Card className="border-destructive/40">
          <CardContent className="flex items-center gap-3 py-6">
            <FileWarning className="h-5 w-5 text-destructive" />
            <div>
              <p className="font-medium">Could not load projects.</p>
              <p className="text-sm text-muted-foreground">
                Is the API running at <code>:8000</code>?
              </p>
              <p className="mt-2 text-xs text-destructive">{(error as Error).message}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {projects && projects.length === 0 && !showForm && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Folder className="mb-3 h-10 w-10 text-muted-foreground" />
            <p className="mb-2 font-medium">No projects yet</p>
            <p className="mb-4 text-sm text-muted-foreground">
              Click "New project" to get started.
            </p>
          </CardContent>
        </Card>
      )}

      {projects && projects.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Card key={p.id} className="flex flex-col">
              <CardHeader className="flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-base">{p.name}</CardTitle>
                    <CardDescription className="mt-1">
                      {p.country_code} · updated {formatDate(p.updated_at)}
                    </CardDescription>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => {
                      if (confirm(`Delete "${p.name}"?`)) del.mutate(p.id);
                    }}
                    aria-label="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {p.description && (
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                    {p.description}
                  </p>
                )}
              </CardHeader>
              <CardContent className="flex items-center justify-between">
                <div className="flex flex-wrap gap-1">
                  <Badge variant={p.has_inventory ? "success" : "outline"}>
                    {p.has_inventory ? "1" : "0"} inv
                  </Badge>
                  <Badge variant={p.has_forecast ? "success" : "outline"}>
                    {p.has_forecast ? "fc" : "no fc"}
                  </Badge>
                  <Badge variant={p.pam_count > 0 ? "default" : "outline"}>
                    {p.pam_count} PAM
                  </Badge>
                  {p.use_macro_module && (
                    <Badge
                      variant="outline"
                      className="border-indigo-600/40 bg-indigo-600/10 text-indigo-700"
                    >
                      macro
                    </Badge>
                  )}
                  {p.use_energy_module && (
                    <Badge
                      variant="outline"
                      className="border-amber-700/40 bg-amber-700/10 text-amber-800"
                    >
                      energy
                    </Badge>
                  )}
                </div>
                <Button asChild size="sm">
                  <Link href={`/projects/${p.id}`}>Open →</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
