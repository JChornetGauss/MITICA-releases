r"""PHASE F — cross-module ACCEPTANCE test (MITICA NEXT v1).

One real country (Kazakhstan, BTR-1 CRT submission), several modules active,
the FULL product pipeline end-to-end through the REAL FastAPI app (in-process
ASGI — the same pattern as packages/api/tests/test_modules_http.py; fresh
SQLite DB + data dir in a tempdir, nothing touches ./data).

Pipeline exercised:
  project -> inventory Excel upload (real CRT AR4 series, 11 categories)
  -> macro run (real WDI GDP/pop/SGDP, flow F1, horizon 2035) -> flag ON
  -> transport run (auto-pulls macro drivers + 1A3b history) + 2 PAMs -> flag ON
  -> waste run (auto-pulls; 5A-5D history) + 2 PAMs -> flag ON
  -> forecast (ANNALIST, horizon 2035, async job polled)
  -> /scenarios (+ by_level3), target (PCT_FROM_BASE_YEAR), /targets/evaluation
  -> /exports/crt.xlsx

Modules NOT exercised (honest notes, see docs/ACCEPTANCE_F_2026-06-10.md):
  - Energy (SI-003): the router's only input path is the legacy Excel template
    upload (no JSON system builder) — fabricating a KAZ EnergySystem workbook
    would violate data-honesty. 1A1a stays under ANNALIST.
  - F-gases (SI-005): the cohort engine needs per-subsector sales/stock units;
    the CRT only carries aggregate 2F1 emissions. 2F1 stays under ANNALIST.
  - LULUCF (SI-004): needs land areas + activity data beyond this harness's
    scope; CRT-4 stays under ANNALIST (KAZ LULUCF is a net source).

Acceptance checks (each printed PASS/FAIL, exit 1 on any FAIL):
  A. Override provenance      (metadata.source per category)
  B. History continuity       (forecast == uploaded inventory for y <= last)
  C. Module PAMs + wedge      (tpam-*/wpam-* with mitigation_series; WEM<=WoM;
                               per-category wedge == sum of module series)
  D. Identity                 (totals == sum categories; by_level3 == detail)
  E. No silent drops          (failed_categories empty; dropped_pams guard)
  F. Plausibility             (finite series; WoM@2035 within +-60% of 2022)

Run (from mitica_next/):
  .venv\Scripts\python.exe scripts\acceptance_f\run_acceptance.py

The BTR extraction is cached in scripts/acceptance_f/data/KAZ_inventory_ar4.csv
(delete it, or run btr_extract.py KAZ, to re-parse the zip from scratch).
"""
from __future__ import annotations

import asyncio
import io
import math
import os
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

ISO = "KAZ"
MACRO_HIST_START = 1995   # post-Soviet structural break; transition collapse
                          # years (1990-94, GDP -9%/yr) excluded from the fit
HORIZON = 2035
WASTE_CLIMATE = "boreal_dry"   # KAZ: cold semi-arid steppe (IPCC collapsed zones)
MACRO_REGION = "EEU"
MACRO_DEV_GROUP = "UM"         # WB income class for Kazakhstan

# --- env BEFORE importing the app (same trick as the API conftest) ----------
_TMP = Path(tempfile.mkdtemp(prefix="mitica-acceptance-f-"))
os.environ["MITICA_DATA_DIR"] = str(_TMP)
os.environ["MITICA_DATABASE_URL"] = f"sqlite+aiosqlite:///{_TMP / 'acceptance.db'}"
os.environ["MITICA_ENV"] = "test"

sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))
sys.path.insert(0, str(ROOT / "packages" / "api" / "src"))

import httpx  # noqa: E402
import pandas as pd  # noqa: E402

RESULTS: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str) -> None:
    RESULTS.append((name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}: {detail}")


# ----------------------------------------------------------------------------
# Data prep (all numbers from raw files on disk)
# ----------------------------------------------------------------------------


def load_inventory_series() -> dict[tuple[str, int], float]:
    """(code, year) -> kt CO2-eq AR4, parsed from the KAZ CRT zip."""
    cache = HERE / "data" / f"{ISO}_inventory_ar4.csv"
    if not cache.exists():
        print(f"-- extraction cache missing; parsing {ISO}_CRT.zip (slow) --")
        sys.path.insert(0, str(HERE))
        import btr_extract
        records, problems, _ = btr_extract.parse_country(ISO)
        cache.parent.mkdir(parents=True, exist_ok=True)
        with open(cache, "w", newline="") as f:
            f.write("ipcc_code,year,co2eq_ar4_kt\n")
            for c, y, v in sorted(records):
                f.write(f"{c},{y},{v!r}\n")
        if problems:
            print(f"   extraction problems ({len(problems)}):")
            for p in problems:
                print(f"     - {p}")
    df = pd.read_csv(cache)
    return {(r.ipcc_code, int(r.year)): float(r.co2eq_ar4_kt)
            for r in df.itertuples()}


def build_inventory_excel(series: dict[tuple[str, int], float]) -> bytes:
    """'Simple inventory layout' workbook: ipcc_code | 1990 | ... | 2022."""
    codes = sorted({c for c, _ in series})
    years = sorted({y for _, y in series})
    data = {"ipcc_code": codes}
    for y in years:
        data[str(y)] = [series.get((c, y)) for c in codes]
    df = pd.DataFrame(data)
    buf = io.BytesIO()
    df.to_excel(buf, index=False, sheet_name="Hoja1")
    return buf.getvalue()


def load_wdi_macro() -> dict[str, list[dict]]:
    """Real WB-WDI history rows for the macro run (constant-USD, persons)."""
    wdi = ROOT / "scripts" / "macro_validation" / "wdi_data"

    def _series(fname: str) -> dict[int, float]:
        df = pd.read_csv(wdi / fname)
        df = df[(df.iso3 == ISO) & (df.Year >= MACRO_HIST_START)].dropna()
        return {int(r.Year): float(r.value) for r in df.itertuples()}

    gdp = _series("GDP_tot.csv")
    pop = _series("Pop.csv")
    s1 = _series("SGDP_primary.csv")
    s2 = _series("SGDP_secondary.csv")
    s3 = _series("SGDP_tertiary.csv")
    years = sorted(set(gdp) & set(pop) & set(s1) & set(s2) & set(s3))
    if not years:
        raise RuntimeError("No overlapping WDI years for the macro history")
    return {
        "gdp_tot": [{"year": y, "value": gdp[y]} for y in years],
        "population": [{"year": y, "value": pop[y]} for y in years],
        "sgdp": [{"year": y, "primary": s1[y], "secondary": s2[y],
                  "tertiary": s3[y]} for y in years],
    }


# ----------------------------------------------------------------------------
# The pipeline + checks
# ----------------------------------------------------------------------------


async def main() -> int:
    inv = load_inventory_series()
    inv_years = sorted({y for _, y in inv})
    last_inv_year = max(inv_years)
    codes = sorted({c for c, _ in inv})
    total_last = sum(inv.get((c, last_inv_year), 0.0) for c in codes)
    print(f"Inventory: {ISO}, {len(codes)} categories {codes}, "
          f"{inv_years[0]}-{last_inv_year}, total {last_inv_year} = "
          f"{total_last:,.1f} kt CO2-eq (AR4)")

    from mitica_api.db import init_db
    from mitica_api.main import app

    await init_db()
    transport = httpx.ASGITransport(app=app, raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://t",
                                 timeout=300.0) as c:
        # -- 1. project + inventory ------------------------------------------
        r = await c.post("/api/v1/projects",
                         json={"name": "acceptance-f-kaz", "country_code": ISO})
        assert r.status_code == 201, r.text
        pid = r.json()["id"]

        xlsx = build_inventory_excel(inv)
        r = await c.post(
            f"/api/v1/projects/{pid}/inventory/excel",
            files={"file": ("kaz_inventory.xlsx", xlsx,
                            "application/vnd.openxmlformats-officedocument"
                            ".spreadsheetml.sheet")})
        assert r.status_code == 200, r.text
        up = r.json()
        got_codes = sorted(up["categories"])
        assert got_codes == codes, f"upload categories {got_codes} != {codes}"
        assert up["rows"] == len(inv), f"{up['rows']} rows != {len(inv)}"
        print(f"Inventory uploaded: {up['rows']} rows, {len(got_codes)} categories")

        # The inventory AS THE PRODUCT PARSED IT — the baseline for check B.
        # (xlsx serialises doubles to ~15 significant digits, so the parsed
        # values can differ from the pre-Excel doubles by ~1 ulp; that
        # serialisation gap is asserted separately below.)
        r = await c.get(f"/api/v1/projects/{pid}/inventory")
        assert r.status_code == 200, r.text
        inv_parsed = {(row["ipcc_code"], int(row["year"])): float(row["value"])
                      for row in r.json()["rows"]}
        ser_worst = max(
            abs(inv_parsed[k] - inv[k]) / max(1.0, abs(inv[k]))
            for k in inv
        )
        assert set(inv_parsed) == set(inv), "parsed inventory key mismatch"
        assert ser_worst < 1e-12, f"xlsx serialisation gap too large: {ser_worst}"
        print(f"Inventory parse fidelity: max rel diff vs raw doubles = {ser_worst:.2e}")

        # -- 2. macro (flow F1: no pinned projections) -------------------------
        macro_payload = {
            "region": MACRO_REGION,
            "dev_group": MACRO_DEV_GROUP,
            "horizon_year": HORIZON,
            **load_wdi_macro(),
        }
        r = await c.post(f"/api/v1/projects/{pid}/macro/run", json=macro_payload)
        assert r.status_code == 200, r.text
        macro = r.json()
        n_red = sum(1 for f in macro["validation_report"]
                    if f.get("severity") == "red")
        print(f"Macro: flow={macro['flow_detected']} dev_group={macro['dev_group']} "
              f"phi={macro['phi']:.3f} flags(red)={n_red} "
              f"proxies={macro['annalist_proxies_index']}")
        # No pinned projections -> the engine's fully-model-driven flow.
        # (Engine vocabulary: F3 = nothing pinned; F2 = GDP pinned; F1 = full
        # user projections — the brief's "flow F1 (no pinned projections)"
        # corresponds to F3 here.)
        assert macro["flow_detected"] == "F3", macro["flow_detected"]
        r = await c.patch(f"/api/v1/projects/{pid}",
                          json={"use_macro_module": True})
        assert r.status_code == 200, r.text

        # -- 3a. transport: 2 PAMs + run + flag --------------------------------
        for pam in (
            {"name": "EV sales push 30pct by 2032", "scenario": "WEM",
             "lever": "ev_sales_push", "segment": "passenger_cars",
             "start_year": 2026, "target_year": 2032,
             "ev_target_sales_share": 0.30},
            {"name": "Heavy fleet renewal", "scenario": "WAM",
             "lever": "fleet_renewal", "segment": "freight_heavy_bus",
             "start_year": 2027, "target_year": 2035,
             "efficiency_gain_pct": 12.0, "affected_fleet_share": 0.35},
        ):
            r = await c.post(f"/api/v1/projects/{pid}/transport/pams", json=pam)
            assert r.status_code == 200, r.text
        r = await c.post(f"/api/v1/projects/{pid}/transport/run",
                         json={"horizon_year": HORIZON})
        assert r.status_code == 200, r.text
        tr = r.json()
        print(f"Transport: tier={tr['tier']} codes={sorted(tr['scenario_totals_by_code'])} "
              f"pam_mit scenarios={sorted((tr.get('pam_mitigation') or {}).keys())}")
        r = await c.patch(f"/api/v1/projects/{pid}",
                          json={"use_transport_module": True})
        assert r.status_code == 200, r.text

        # -- 3b. waste: 2 PAMs + run + flag ------------------------------------
        for pam in (
            {"name": "Landfill gas recovery 40pct", "scenario": "WEM",
             "lever": "gas_recovery", "start_year": 2026, "target_year": 2033,
             "recovery_target": 0.40},
            {"name": "Organics diversion 30pct", "scenario": "WAM",
             "lever": "diversion", "start_year": 2027, "target_year": 2035,
             "diversion_frac": 0.30},
        ):
            r = await c.post(f"/api/v1/projects/{pid}/waste/pams", json=pam)
            assert r.status_code == 200, r.text
        r = await c.post(f"/api/v1/projects/{pid}/waste/run",
                         json={"horizon_year": HORIZON,
                               "climate_zone": WASTE_CLIMATE})
        assert r.status_code == 200, r.text
        wa = r.json()
        print(f"Waste: income_group={wa['income_group']} tier={wa['tier']} "
              f"codes={sorted(wa['scenario_totals_by_code'])} "
              f"pam_mit scenarios={sorted((wa.get('pam_mitigation') or {}).keys())}")
        r = await c.patch(f"/api/v1/projects/{pid}",
                          json={"use_waste_module": True})
        assert r.status_code == 200, r.text

        # -- 4. forecast (ANNALIST, async job) ---------------------------------
        r = await c.post(f"/api/v1/projects/{pid}/forecasts/run",
                         json={"horizon_year": HORIZON, "method": "ANNALIST",
                               "seed": 42})
        assert r.status_code == 200, r.text
        job = r.json()
        print(f"Forecast job {job['id']}: {job.get('message') or '(no notes)'}")
        t0 = time.time()
        while True:
            r = await c.get(f"/api/v1/projects/{pid}/forecasts/jobs/{job['id']}")
            st = r.json()
            if st["status"] in ("done", "error"):
                break
            if time.time() - t0 > 900:
                raise TimeoutError(f"forecast job stuck: {st}")
            await asyncio.sleep(1.0)
        assert st["status"] == "done", f"forecast job failed:\n{st['message']}"
        print(f"Forecast done in {time.time() - t0:.1f}s")

        r = await c.get(f"/api/v1/projects/{pid}/forecast")
        assert r.status_code == 200, r.text
        fc = r.json()
        by_code = {cat["ipcc_code"]: cat for cat in fc["categories"]}
        assert int(fc["last_inventory_year"]) == last_inv_year

        # -- 5. scenarios + target + CRT export --------------------------------
        r = await c.get(f"/api/v1/projects/{pid}/scenarios")
        assert r.status_code == 200, r.text
        sc = r.json()
        years_sc = sc["years"]

        target = {"id": "", "name": "NDC-style -15pct vs 1990",
                  "type": "PCT_FROM_BASE_YEAR", "base_year": 1990,
                  "target_year": 2030, "pct": -15.0, "scope": "all"}
        r = await c.post(f"/api/v1/projects/{pid}/targets", json=target)
        assert r.status_code == 200, r.text
        r = await c.get(f"/api/v1/projects/{pid}/targets/evaluation")
        assert r.status_code == 200, r.text
        tev = r.json()["targets"]
        assert len(tev) == 1 and tev[0]["evaluation"], tev
        ev = tev[0]["evaluation"]
        print(f"Target: threshold={ev['threshold_kt']:,.1f} kt; "
              + "; ".join(f"{k} {v['value_kt']:,.0f} kt "
                          f"({'OK' if v['achieved'] else 'MISS'})"
                          for k, v in ev["scenarios"].items()))

        r = await c.get(f"/api/v1/projects/{pid}/exports/crt.xlsx")
        crt_ok = r.status_code == 200 and len(r.content) > 1000
        if crt_ok:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(r.content), read_only=True)
            crt_sheets = wb.sheetnames
            wb.close()
            print(f"CRT export: {len(r.content):,} bytes, sheets={crt_sheets}")
        else:
            print(f"CRT export FAILED: {r.status_code} {r.text[:200]}")

        r = await c.get(f"/api/v1/projects/{pid}/pams")
        assert r.status_code == 200, r.text
        pams = r.json()

        # Diagnostic: per-category WoM at the last inventory year vs horizon
        # (context for check F — which categories drive the trajectory).
        i_last = years_sc.index(last_inv_year)
        i_hz = years_sc.index(HORIZON)
        print(f"\nPer-category WoM, {last_inv_year} -> {HORIZON} (kt CO2-eq AR4):")
        collapsed: list[str] = []
        for code in codes:
            v0 = sc["by_category"]["WOM"][code][i_last]
            v1 = sc["by_category"]["WOM"][code][i_hz]
            src = (by_code.get(code, {}).get("metadata") or {}).get("source") or "ANNALIST"
            print(f"  {code:5s} {v0:12,.1f} -> {v1:12,.1f}  "
                  f"({(v1 / v0 - 1) * 100 if v0 else float('nan'):+6.1f}%)  [{src}]")
            if v1 == 0.0 and v0 > 1000.0:
                collapsed.append(code)
        if collapsed:
            print(f"  !! WARNING (non-gating): {collapsed} projected to EXACTLY 0 "
                  f"at {HORIZON} — the avoid_negative auto-modifier lifting a "
                  "negative ANNALIST path (see docs/ACCEPTANCE_F_2026-06-10.md, "
                  "finding 1).")

        # ======================= ACCEPTANCE CHECKS ===========================
        print("\n--- ACCEPTANCE CHECKS " + "-" * 50)

        # The categories each module override should own (KAZ inventory carries
        # 1A3b for road and the full 5A-5D split):
        transport_owned = {"1A3b"}
        waste_owned = {"5A", "5B", "5C", "5D"}
        annalist_only = set(codes) - transport_owned - waste_owned

        # -- A. override provenance -------------------------------------------
        bad: list[str] = []
        for code in transport_owned:
            src = (by_code.get(code, {}).get("metadata") or {}).get("source")
            if src != "transport_module":
                bad.append(f"{code}: source={src!r} (want transport_module)")
        for code in waste_owned:
            src = (by_code.get(code, {}).get("metadata") or {}).get("source")
            if src != "waste_module":
                bad.append(f"{code}: source={src!r} (want waste_module)")
        for code in sorted(annalist_only):
            src = (by_code.get(code, {}).get("metadata") or {}).get("source")
            if src is not None:
                bad.append(f"{code}: unexpectedly tagged source={src!r}")
        check("A provenance", not bad,
              ("1A3b=transport_module, 5A-5D=waste_module, "
               f"{len(annalist_only)} ANNALIST categories untagged")
              if not bad else "; ".join(bad))

        # -- B. history continuity --------------------------------------------
        # Baseline = the uploaded inventory as the product parsed it
        # (GET /inventory) — bit-exact equality required all the way through
        # forecast + module overrides.
        worst = 0.0
        n_pts = 0
        mismatches: list[str] = []
        for code in codes:
            cat = by_code.get(code)
            if cat is None:
                mismatches.append(f"{code}: MISSING from forecast")
                continue
            merged = [f if f is not None else h
                      for f, h in zip(cat["forecast"], cat["historical"])]
            for y, v in zip(cat["years"], merged):
                if y > last_inv_year or (code, y) not in inv_parsed:
                    continue
                n_pts += 1
                d = abs((v if v is not None else float("nan"))
                        - inv_parsed[(code, y)])
                if not (d == 0.0):
                    worst = max(worst, d if not math.isnan(d) else float("inf"))
                    if len(mismatches) < 5:
                        mismatches.append(
                            f"{code}@{y}: {v} != {inv_parsed[(code, y)]}")
        check("B history continuity", not mismatches and n_pts > 300,
              f"{n_pts} historical points bit-exact vs uploaded inventory "
              f"(xlsx serialisation gap vs raw doubles: {ser_worst:.2e} rel)"
              if not mismatches else
              f"max|diff|={worst:g}; " + "; ".join(mismatches))

        # -- C. module PAMs + wedge -------------------------------------------
        tpams = [p for p in pams if str(p.get("id", "")).startswith("tpam-")]
        wpams = [p for p in pams if str(p.get("id", "")).startswith("wpam-")]
        mod_ok = (
            len(tpams) >= 1 and len(wpams) >= 1
            and all(p.get("mitigation_series") for p in tpams + wpams)
            and all(p.get("source_module") in ("transport_module", "waste_module")
                    for p in tpams + wpams)
        )
        detail = (f"{len(tpams)} tpam-* + {len(wpams)} wpam-* with "
                  f"mitigation_series; user PAMs: "
                  f"{len(pams) - len(tpams) - len(wpams)}")
        check("C1 module PAMs present", mod_ok, detail)

        wom_c = sc["by_category"]["WOM"]
        wem_c = sc["by_category"]["WEM"]
        wam_c = sc["by_category"]["WAM"]

        # ordering: WEM <= WoM and WAM <= WEM per year (totals)
        viol = []
        for i, y in enumerate(years_sc):
            if sc["totals"]["WEM"][i] > sc["totals"]["WOM"][i] + 1e-9:
                viol.append(f"WEM>WoM@{y}")
            if sc["totals"]["WAM"][i] > sc["totals"]["WEM"][i] + 1e-9:
                viol.append(f"WAM>WEM@{y}")
        check("C2 scenario ordering", not viol,
              "WEM <= WoM and WAM <= WEM at every year"
              if not viol else "; ".join(viol[:6]))

        # wedge: WoM - scenario == sum of module PAM series per category-year
        def pam_sum(cat: str, year: int, scens: tuple[str, ...]) -> float:
            s = 0.0
            for p in pams:
                if p.get("category") != cat or p.get("scenario") not in scens:
                    continue
                ms = p.get("mitigation_series") or {}
                s += float(ms.get(str(year), ms.get(year, 0.0)))
            return s

        worst_wedge = 0.0
        wedge_cats = sorted({p["category"] for p in tpams + wpams})
        for cat in wedge_cats:
            for i, y in enumerate(years_sc):
                d_wem = (wom_c[cat][i] - wem_c[cat][i]) - pam_sum(cat, y, ("WEM",))
                d_wam = (wom_c[cat][i] - wam_c[cat][i]) - pam_sum(cat, y, ("WEM", "WAM"))
                worst_wedge = max(worst_wedge, abs(d_wem), abs(d_wam))
        check("C3 wedge == module series", worst_wedge <= 1e-6,
              f"max |wedge - sum(mitigation_series)| = {worst_wedge:.3e} kt "
              f"on {wedge_cats}")

        # -- D. identity --------------------------------------------------------
        worst_tot = 0.0
        for scen in ("WOM", "WEM", "WAM"):
            cats = sc["by_category"][scen]
            l3 = sc["by_level3"][scen]
            for i, y in enumerate(years_sc):
                s_cat = sum(cats[k][i] for k in cats)
                s_l3 = sum(l3[k][i] for k in l3)
                tot = sc["totals"][scen][i]
                scale = max(1.0, abs(tot))
                worst_tot = max(worst_tot, abs(s_cat - tot) / scale,
                                abs(s_l3 - tot) / scale)
        check("D identity", worst_tot <= 1e-9,
              f"max rel gap totals vs sum(categories) vs sum(by_level3) = "
              f"{worst_tot:.3e}")

        # -- E. no silent drops --------------------------------------------------
        failed = fc.get("failed_categories") or {}
        extrap = fc.get("extrapolated_proxies") or {}
        dropped = sc.get("dropped_pams")  # field may not exist yet — guard
        check("E no silent drops", not failed,
              f"failed_categories={failed or '{}'}; "
              f"extrapolated_proxies={extrap or '{}'}; "
              f"dropped_pams={'(field absent)' if dropped is None else dropped}")

        # -- F. plausibility -------------------------------------------------------
        finite = all(
            math.isfinite(v)
            for scen in ("WOM", "WEM", "WAM")
            for k in sc["by_category"][scen]
            for v in sc["by_category"][scen][k]
        ) and all(math.isfinite(v) for s in ("WOM", "WEM", "WAM")
                  for v in sc["totals"][s])
        i_h = years_sc.index(HORIZON)
        wom_h = sc["totals"]["WOM"][i_h]
        ratio = wom_h / total_last
        check("F plausibility", finite and 0.4 <= ratio <= 1.6,
              f"all series finite={finite}; WoM@{HORIZON} = {wom_h:,.0f} kt = "
              f"{ratio:.2f}x the {last_inv_year} inventory total")

        # CRT export folded into the deliverables check
        check("CRT export", crt_ok, "GET /exports/crt.xlsx -> 200, valid xlsx"
              if crt_ok else "export failed")

    n_fail = sum(1 for _, ok, _ in RESULTS if not ok)
    print("\n" + "=" * 72)
    print(f"PHASE F ACCEPTANCE: {len(RESULTS) - n_fail}/{len(RESULTS)} checks passed"
          + (f" — {n_fail} FAILED" if n_fail else " — ALL GREEN"))
    print(f"(tempdir: {_TMP})")
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
