@echo off
rem MITICA Next — stop whatever is on :8000 and :3000.
pushd "%~dp0.."
node scripts\stop.mjs
popd
