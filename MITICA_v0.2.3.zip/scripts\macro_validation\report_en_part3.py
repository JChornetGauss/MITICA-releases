"""English technical report - Part III: Validation, Sensitivities, Emissions
implications, Limitations, Discussion, Appendices (sections 7-11 + A-D).
Exposed as content_part3(S, data)."""

from __future__ import annotations

from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, Spacer, PageBreak

from report_common import header_table, fmt_num, fmt_pct, fmt_int


def P(s, sty):
    return Paragraph(s, sty)


def content_part3(S, data):
    """Sections 7-11 + appendices A-D."""
    out = []

    # ============================================================
    # 7. EMPIRICAL VALIDATION
    # ============================================================
    out.append(P("7.&nbsp;&nbsp; Empirical Validation", S["H1"]))

    out.append(P("7.1&nbsp; Monte Carlo recovery", S["H2"]))
    out.append(P("Before exposing the estimator to real data we run a "
                  "200-replicate Monte Carlo recovery test. The data-"
                  "generating process is exactly the log-log B2 model "
                  "with known coefficients drawn from plausible developing-"
                  "country values. The estimator is then run at shrinkage "
                  "&lambda; &isin; {0, 0.5, 0.9} and the recovered "
                  "&theta;_hat compared against the truth. Three "
                  "scenarios:", S["BODY"]))
    out.append(P("&bull; <b>Ideal</b>: n = 25 years per country, "
                  "&sigma;_noise = 0.02, no driver collinearity.",
                  S["BULLET"]))
    out.append(P("&bull; <b>Short series</b>: n = 10 years.", S["BULLET"]))
    out.append(P("&bull; <b>High multicollinearity</b>: SInv and "
                  "GFCF_pub drawn from a joint distribution with "
                  "&rho; = 0.85.", S["BULLET"]))
    out.append(header_table([
        ["Metric",            "Ideal",       "Short",       "Multicollinear"],
        ["Bias |E[θ - θ*]|",  "&lt; 0.02",   "&lt; 0.05",   "&lt; 0.03"],
        ["RMSE",              "0.05-0.10",   "0.10-0.20",   "0.10-0.20"],
        ["95% CI coverage",   "92-100%",     "92-99%",      "94-100%"],
        ["Sign correctness",  "&ge; 99%",    "&ge; 92%",    "&ge; 95%"],
    ], col_widths=[4*cm, 4*cm, 3.5*cm, 4*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("The Monte Carlo was the diagnostic that surfaced the "
                  "v1.1s posterior-variance bug: under the broken formula "
                  "the 95% credible intervals had 0% coverage at &lambda; "
                  "= 0.9 (the intervals collapsed to zero width). The "
                  "corrected formula (5-3) restores nominal coverage. "
                  "Script: <font face='Courier'>b2_recovery.py</font>.",
                  S["BODY"]))

    out.append(P("7.2&nbsp; EU-27 backtest for B2", S["H2"]))
    out.append(P("Out-of-sample backtest. Training window 1995-2005 (11 "
                  "years); test window 2006-2024 (19 years). The macro "
                  "module is fit on the training window only. In the "
                  "test window the model receives the actual driver "
                  "paths (Pop, SInv, iRate) supplied as F2 projected "
                  "inputs, so any error in projected SGDP_s is "
                  "attributable to one of: (i) estimator bias, (ii) "
                  "functional-form misspecification, or (iii) out-of-"
                  "distribution regime change. The third source dominates "
                  "the residuals.", S["BODY"]))
    out.append(P("25 of 29 EU + UK + NO + CH countries pass the data-"
                  "quality filter. The four exclusions (BG, EE, UK, MT) "
                  "are dropped because their Pop or SInv series have gaps "
                  "in the test window or fewer than 10 training years. "
                  "The 25-country sample is the operational benchmark.",
                  S["BODY"]))
    out.append(P("Sub-pool decomposition at shrinkage &lambda; = 0.5:",
                  S["BODY"]))
    out.append(header_table([
        ["Sub-pool", "n", "Form", "Primary MAPE", "Secondary MAPE",
         "Tertiary MAPE", "Avg"],
        ["HIC mature",  "15", "LL",   "11.87", "16.26", "5.14", "11.09"],
        ["HIC mature",  "15", "KC",   "12.06", "18.86", "6.05", "12.32"],
        ["HIC mature",  "15", "KCQ",  "12.75", "16.62", "5.42", "11.60"],
        ["HIC_TRANS",   "10", "LL",   "16.96", "19.91", "17.31", "18.06"],
        ["HIC_TRANS",   "10", "KC",   "16.58", "14.20", "19.22", "16.67"],
        ["HIC_TRANS",   "10", "KCQ",  "14.67", "30.79", "23.83", "23.10"],
    ], col_widths=[2.7*cm, 0.8*cm, 1.3*cm, 2.5*cm, 2.6*cm, 2.5*cm, 1.5*cm],
       highlight_cells=[(1, 6)]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("The recommended configuration for mature HIC is the "
                  "log-log form with calibrated &zeta; (median tertiary "
                  "MAPE 5.14%). The structural alternatives (KC, KCQ) "
                  "produce <i>worse</i> tertiary MAPE because the "
                  "calibrated &kappa;_tertiary in level form is +2.22 &mdash; "
                  "large enough that even with std = 0.50 the country fit "
                  "cannot fully override the prior, and the resulting "
                  "projection over-shoots. For HIC_TRANS the linear KC "
                  "form wins on secondary, consistent with the still-"
                  "industrialising regime of EE accession states.",
                  S["BODY"]))
    out.append(P("Layer C T8 fires for 10 of the 25 countries, "
                  "correctly identifying the documented boom-bust "
                  "episodes: Cyprus (financial sector collapse 2013), "
                  "Latvia (IMF bailout 2009), Spain (housing bubble "
                  "2008), Poland (EU-accession growth surge), Ireland "
                  "(Celtic Tiger), Hungary, Slovenia, Bulgaria, "
                  "Lithuania, Denmark. The 15 quiet countries are the "
                  "stable mature OECD economies. The test does its job: "
                  "it informs the user that the projection extrapolates "
                  "into territory the training window did not cover, "
                  "without claiming to predict the break itself.",
                  S["BODY"]))

    out.append(P("7.3&nbsp; EU-29 backtest for B5 / B6 energy demand",
                  S["H2"]))
    out.append(P("Same windows. Eurostat aggregates are compared against "
                  "module outputs (the module&apos;s manuf + construction "
                  "summed for the industry comparison; pass + freight "
                  "summed for transport). Median MAPE % across countries "
                  "at &lambda; = 0.5:", S["BODY"]))
    out.append(header_table([
        ["Sector",         "HIC LL", "HIC IC", "HIC_TRANS LL",
         "HIC_TRANS IC"],
        ["Primary",        "27.74",  "27.69",  "28.39", "29.30"],
        ["Manufacturing",  "27.42",  "22.57",  "28.88", "23.63"],
        ["Services",       "13.36",  "17.37",  "30.98", "34.88"],
        ["Transport",      "14.40",  "15.47",  "15.56", "14.15"],
        ["Households (B6)","9.68",   "9.68",   "11.26", "11.26"],
    ], col_widths=[3.5*cm, 2.6*cm, 2.6*cm, 3*cm, 2.6*cm],
       highlight_cells=[(2, 2), (2, 4), (4, 4)]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("The headline empirical result: <b>the intensity-"
                  "convergence form (IC) reduces manufacturing energy "
                  "MAPE by 4.8 percentage points in mature HIC and 5.3 "
                  "points in HIC_TRANS</b>. The calibrated &psi;_manuf "
                  "= &minus;1.23 in HIC translates into a structural "
                  "decoupling that the legacy log-log specification "
                  "could not capture. Transport in HIC_TRANS also gains "
                  "from IC (-1.4 pp), consistent with the rebound effect "
                  "documented in EU mobility data. Services and "
                  "households are roughly tied between the two forms.",
                  S["BODY"]))

    out.append(P("7.4&nbsp; Hypotheses tested in the calibration sprint",
                  S["H2"]))
    out.append(header_table([
        ["Hypothesis", "Result"],
        ["Bayesian posterior-variance bug correction is needed",
         "CONFIRMED — v1.1s CIs had 0% coverage at high shrinkage."],
        ["No-synthesis rule improves identification",
         "CONFIRMED — spurious confident coefficients eliminated."],
        ["KC quadratic captures the Kuznets hump in secondary",
         "CONFIRMED — with stylised priors avg MAPE 12.6 vs 14.1 (LL)."],
        ["HIC stratification reveals structurally distinct sub-pools",
         "CONFIRMED — &kappa;_secondary sign disagrees between HIC and HIC_TRANS."],
        ["Level-form joint calibration eliminates share/level mismatch",
         "CONFIRMED — LL with calibrated &zeta; is best for HIC tertiary."],
        ["Sub-period stratification of services calibration improves SED MAPE",
         "REJECTED — restricting to post-2000 made the SED backtest worse."],
        ["Intensity-convergence form helps manufacturing",
         "CONFIRMED — &minus;4.8 pp MAPE in HIC, &minus;5.3 pp in HIC_TRANS."],
        ["Bennett logistic recovers (a_B, b_B) on synthetic data",
         "CONFIRMED — within tolerance 0.30 / 0.10 on n=28."],
        ["T8 detector fires on documented boom-bust episodes",
         "CONFIRMED — 10 of 25 EU countries flagged; all matched the literature."],
    ], col_widths=[8*cm, 8.5*cm]))

    out.append(PageBreak())

    # ============================================================
    # 8. NUMERICAL SENSITIVITY EXAMPLES
    # ============================================================
    out.append(P("8.&nbsp;&nbsp; Numerical Sensitivity Examples", S["H1"]))
    out.append(P("Three operational scenarios illustrate the "
                  "quantitative implications of the methodological "
                  "choices. The examples use the live module on the "
                  "calibrated priors; the input data are the real "
                  "Eurostat 1995-2023 panels for Spain, Germany and "
                  "Italy. Reproducible from "
                  "<font face='Courier'>scripts/macro_validation/"
                  "run_sensitivities.py</font>.", S["BODY"]))

    sens = data.get("sensitivities", {})

    # ---- Sensitivity 1: Spain GDP growth ----
    s1 = sens.get("sensitivity_1_spain_gdp_growth", {})
    out.append(P("8.1&nbsp; Sensitivity 1 &mdash; Spain GDP growth path",
                  S["H2"]))
    out.append(P("<b>Setup.</b> Spain in flow F2: the user supplies a "
                  "GDP_tot path growing at either 2% or 3% per year from "
                  "2024 to 2050, holding population constant at the 2023 "
                  "level. Drivers (SInv, iRate) are absent for the "
                  "future; the model fills the sectoral composition "
                  "from the B2 estimator with log-log form and "
                  "&lambda; = 0.5.", S["BODY"]))
    sc_lo = (s1.get("scenarios") or {}).get("GDP_g_2pct", {})
    sc_hi = (s1.get("scenarios") or {}).get("GDP_g_3pct", {})
    diff = s1.get("diff_endpoint_pct", {})
    if sc_lo and sc_hi:
        out.append(P("<b>Endpoint values in 2050:</b>", S["BODY"]))
        out.append(header_table([
            ["Variable", "2% growth (M EUR)", "3% growth (M EUR)",
             "Δ (3% - 2%)", "Δ %"],
            ["SGDP_primary",
             fmt_int(sc_lo.get("SGDP_primary")),
             fmt_int(sc_hi.get("SGDP_primary")),
             fmt_int(diff.get("SGDP_primary", {}).get("abs")),
             fmt_pct(diff.get("SGDP_primary", {}).get("pct"))],
            ["SGDP_secondary",
             fmt_int(sc_lo.get("SGDP_secondary")),
             fmt_int(sc_hi.get("SGDP_secondary")),
             fmt_int(diff.get("SGDP_secondary", {}).get("abs")),
             fmt_pct(diff.get("SGDP_secondary", {}).get("pct"))],
            ["SGDP_tertiary",
             fmt_int(sc_lo.get("SGDP_tertiary")),
             fmt_int(sc_hi.get("SGDP_tertiary")),
             fmt_int(diff.get("SGDP_tertiary", {}).get("abs")),
             fmt_pct(diff.get("SGDP_tertiary", {}).get("pct"))],
        ], col_widths=[3.5*cm, 3.5*cm, 3.5*cm, 3*cm, 2.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("<b>Reading.</b> A one-percentage-point higher annual "
                  "GDP growth assumption translates into a ~30% higher "
                  "sectoral value added in every sector at the 2050 "
                  "horizon. The proportional scaling across sectors is "
                  "the signature of F2 flow with log-log B2: the user-"
                  "supplied GDP_tot is the binding constraint and the "
                  "sectoral shares are computed from drivers (here held "
                  "constant), so each SGDP_s scales identically with "
                  "GDP_tot. The implication for emissions: under "
                  "constant per-sector emission intensities, a 1 pp "
                  "higher GDP growth assumption implies roughly 30% "
                  "higher 2050 sectoral emissions per category &mdash; "
                  "before any mitigation policy is layered on. The "
                  "macro module makes this dependency explicit; the "
                  "sectoral modules then translate the activity "
                  "differences into emission differences via their "
                  "respective emission factors.", S["BODY"]))

    # ---- Sensitivity 2: Germany LL vs KCQ ----
    s2 = sens.get("sensitivity_2_form_choice_germany", {})
    out.append(P("8.2&nbsp; Sensitivity 2 &mdash; Germany, log-log vs "
                  "Kuznets-Chenery quadratic", S["H2"]))
    out.append(P("<b>Setup.</b> Germany in flow F3: no GDP path "
                  "supplied; drivers Pop, SInv, iRate extended at "
                  "constant growth rates (1.5% real for SInv, 0.1% for "
                  "Pop, iRate held constant) from 2024 to 2050. Two "
                  "runs: <font face='Courier'>b2_form = 'log_log'</font> "
                  "vs <font face='Courier'>b2_form = "
                  "'kuznets_chenery_quad'</font>. Region HIC. Calibrated "
                  "priors active.", S["BODY"]))
    sc_ll = (s2.get("scenarios") or {}).get("log_log", {})
    sc_kcq = (s2.get("scenarios") or {}).get("kuznets_chenery_quad", {})
    diff2 = s2.get("diff_kcq_vs_ll_pct", {})
    if sc_ll and sc_kcq:
        out.append(P("<b>Endpoint values in 2050:</b>", S["BODY"]))
        out.append(header_table([
            ["Variable", "log_log (M EUR)", "KCQ (M EUR)",
             "Δ KCQ - LL", "Δ %"],
            ["SGDP_primary",
             fmt_int(sc_ll.get("SGDP_primary")),
             fmt_int(sc_kcq.get("SGDP_primary")),
             fmt_int(diff2.get("SGDP_primary", {}).get("abs")),
             fmt_pct(diff2.get("SGDP_primary", {}).get("pct"))],
            ["SGDP_secondary",
             fmt_int(sc_ll.get("SGDP_secondary")),
             fmt_int(sc_kcq.get("SGDP_secondary")),
             fmt_int(diff2.get("SGDP_secondary", {}).get("abs")),
             fmt_pct(diff2.get("SGDP_secondary", {}).get("pct"))],
            ["SGDP_tertiary",
             fmt_int(sc_ll.get("SGDP_tertiary")),
             fmt_int(sc_kcq.get("SGDP_tertiary")),
             fmt_int(diff2.get("SGDP_tertiary", {}).get("abs")),
             fmt_pct(diff2.get("SGDP_tertiary", {}).get("pct"))],
            ["GDP_tot",
             fmt_int(sc_ll.get("GDP_tot")),
             fmt_int(sc_kcq.get("GDP_tot")),
             fmt_int(diff2.get("GDP_tot", {}).get("abs")),
             fmt_pct(diff2.get("GDP_tot", {}).get("pct"))],
            ["Tertiary share",
             f"{sc_ll.get('share_tertiary', 0):.4f}",
             f"{sc_kcq.get('share_tertiary', 0):.4f}",
             "",
             ""],
        ], col_widths=[3.5*cm, 3.5*cm, 3.5*cm, 3*cm, 2.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("<b>Reading.</b> The KCQ form predicts +17.6% higher "
                  "tertiary SGDP at 2050 than the LL baseline, "
                  "+7.8% higher secondary and &minus;21.4% lower "
                  "primary. The tertiary share rises from 57.7% (LL) to "
                  "59.9% (KCQ) &mdash; the structural drift captured "
                  "by the income shifter. The aggregate GDP_tot is "
                  "+13.3% higher under KCQ because the sectoral "
                  "predictions accumulate; this is the trade-off of F3 "
                  "flow without an exogenous GDP anchor. The implication "
                  "for emissions projection: KCQ projects a more service-"
                  "intensive German economy in 2050, which in turn lowers "
                  "the projected industrial CO2 if downstream sectoral "
                  "modules apply category-specific emission factors. "
                  "Methodological caveat: the KCQ form here uses the "
                  "calibrated &kappa;_tertiary = +2.22, which is large; "
                  "the empirical backtest (Section 7) suggests LL with "
                  "calibrated &zeta; is the better-validated default "
                  "for mature HIC. KCQ is included in the menu for "
                  "users who explicitly want the Kuznets-Chenery channel.",
                  S["BODY"]))

    # ---- Sensitivity 3: Italy LL vs IC ----
    s3 = sens.get("sensitivity_3_b5_form_italy", {})
    out.append(P("8.3&nbsp; Sensitivity 3 &mdash; Italy industrial "
                  "energy, log-log vs intensity-convergence", S["H2"]))
    out.append(P("<b>Setup.</b> Italy on the SED backtest configuration "
                  "(train 1995-2005, test 2006-2023, &lambda; = 0.5, "
                  "HIC priors). Two runs: <font face='Courier'>b5_form = "
                  "'log_log'</font> vs <font face='Courier'>b5_form = "
                  "'intensity_convergence'</font>. We compare the 2023 "
                  "endpoint of industrial energy demand (manufacturing + "
                  "construction).", S["BODY"]))
    sc_ll = (s3.get("scenarios") or {}).get("log_log", {})
    sc_ic = (s3.get("scenarios") or {}).get("intensity_convergence", {})
    diff3 = s3.get("diff_ic_vs_ll_pct", {})
    if sc_ll and sc_ic:
        out.append(P("<b>Endpoint values in 2023 (ktoe):</b>", S["BODY"]))
        out.append(header_table([
            ["Variable", "LL (ktoe)", "IC (ktoe)", "Δ IC - LL", "Δ %"],
            ["SED_manuf + construction",
             fmt_int(sc_ll.get("SED_manufacturing_plus_construction_ktoe")),
             fmt_int(sc_ic.get("SED_manufacturing_plus_construction_ktoe")),
             fmt_int(diff3.get("SED_manufacturing_plus_construction_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_manufacturing_plus_construction_ktoe", {}).get("pct"))],
            ["SED_services",
             fmt_int(sc_ll.get("SED_services_ktoe")),
             fmt_int(sc_ic.get("SED_services_ktoe")),
             fmt_int(diff3.get("SED_services_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_services_ktoe", {}).get("pct"))],
            ["SED_transport_pass",
             fmt_int(sc_ll.get("SED_transport_pass_ktoe")),
             fmt_int(sc_ic.get("SED_transport_pass_ktoe")),
             fmt_int(diff3.get("SED_transport_pass_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_transport_pass_ktoe", {}).get("pct"))],
            ["SED_transport_freight",
             fmt_int(sc_ll.get("SED_transport_freight_ktoe")),
             fmt_int(sc_ic.get("SED_transport_freight_ktoe")),
             fmt_int(diff3.get("SED_transport_freight_ktoe", {}).get("abs")),
             fmt_pct(diff3.get("SED_transport_freight_ktoe", {}).get("pct"))],
        ], col_widths=[4*cm, 2.7*cm, 2.7*cm, 2.7*cm, 2.5*cm]))
    out.append(Spacer(1, 0.2*cm))
    out.append(P("<b>Reading.</b> The intensity-convergence form "
                  "projects ~4.9% lower industrial energy in Italy at "
                  "2023 than the log-log form. The mechanism: the "
                  "calibrated &psi;_manufacturing = &minus;1.23 in HIC "
                  "introduces a strong income-driven decoupling that "
                  "the log-log form cannot represent (it has constant "
                  "activity elasticity by construction). The 4.9% "
                  "differential, applied to the IEA-reported Italian "
                  "industrial CO2 of approximately 60 Mt in 2023, "
                  "implies roughly 3 Mt CO2 lower industrial emissions "
                  "in the IC projection &mdash; a magnitude "
                  "comparable to the EU ETS-induced abatement in a "
                  "single year for a single member state. For long-"
                  "horizon NDC modelling, the cumulative effect over "
                  "25 years is substantial. The empirical backtest "
                  "validates IC as the preferred form for the "
                  "manufacturing sub-sector in HIC. Note that for "
                  "services the IC form has not been validated and the "
                  "calibrated &psi;_services is statistically noisy "
                  "(Section 6.5); the default for services remains "
                  "log-log.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 9. IMPLICATIONS FOR EMISSIONS PROJECTIONS
    # ============================================================
    out.append(P("9.&nbsp;&nbsp; Implications for Emissions Projections",
                  S["H1"]))
    out.append(P("9.1&nbsp; The macro &rarr; emissions transmission",
                  S["H2"]))
    out.append(P("The macro module&apos;s outputs feed the sectoral "
                  "emission modules through a small set of activity "
                  "drivers per IPCC category. Schematically:", S["BODY"]))
    out.append(header_table([
        ["IPCC category", "Primary activity driver", "Macro source"],
        ["1A1 Energy industries", "Electricity generation, refineries",
         "Derived from SED breakdown"],
        ["1A2 Manufacturing industries", "Industrial energy by sub-sector",
         "SED_manufacturing, SED_construction"],
        ["1A3 Transport", "Passenger-km, ton-km",
         "SED_transport_pass, SED_transport_freight"],
        ["1A4 Other (residential, services)",
         "Floor area, household energy use",
         "SED_hh, SED_services"],
        ["1B Fugitive emissions", "Fuel production/handling volumes",
         "Derived from SED + fuel shares"],
        ["2 IPPU", "Industrial output (tonnes of clinker, steel, etc.)",
         "Proxy through SGDP_secondary"],
        ["3 Agriculture", "Heads of livestock, crop area",
         "SGDP_prim_livestock, Heads"],
        ["5 Waste", "MSW generation, wastewater",
         "Proxy through Pop and GDPpc"],
    ], col_widths=[4.5*cm, 5.5*cm, 6.5*cm]))
    out.append(Spacer(1, 0.3*cm))

    out.append(P("9.2&nbsp; Where the macro module makes a material "
                  "difference", S["H2"]))
    out.append(P("Three channels through which the v2.0 specification "
                  "alters projected emissions relative to v1.1s:",
                  S["BODY"]))
    out.append(P("<b>(i) The Kuznets quadratic in B2 changes sectoral "
                  "shares.</b> Section 8.2 showed +2.2 percentage points "
                  "of tertiary share at 2050 in Germany under KCQ vs LL. "
                  "Translated through the lower per-EUR emission "
                  "intensity of services vs manufacturing, this is a "
                  "real reduction in projected aggregate CO2 even before "
                  "any policy is added.", S["BULLET"]))
    out.append(P("<b>(ii) The intensity-convergence form in B5 changes "
                  "industrial energy.</b> Section 8.3 showed approximately "
                  "-5% on Italian industrial energy in 2023 under IC vs "
                  "LL. The calibrated &psi;_manufacturing = &minus;1.23 "
                  "compounds over multi-decade horizons; for a 25-year "
                  "projection the cumulative gap can exceed 20% on "
                  "industrial CO2 for an OECD economy with rising GDPpc.",
                  S["BULLET"]))
    out.append(P("<b>(iii) Honest provenance changes scenario "
                  "interpretation.</b> Origin tags identify which "
                  "parameters are <i>calibrated</i> (i.e., the country "
                  "lacked the relevant series and the regional literature "
                  "is the source). For ETF reporting under Decision "
                  "18/CMA.1, the distinction between country-derived and "
                  "literature-derived parameters carries weight in the "
                  "technical expert review; the v1.1s synthesis of "
                  "missing covariates obscured this and is now made "
                  "explicit.", S["BULLET"]))

    out.append(P("9.3&nbsp; What the module cannot help with", S["H2"]))
    out.append(P("Three classes of phenomenon lie structurally outside "
                  "what any constant-elasticity or polynomial-in-log "
                  "specification can deliver. The macro module flags "
                  "them rather than predicting them.", S["BODY"]))
    out.append(P("<b>(a) Sharp regime change.</b> The 2008 financial "
                  "crisis, COVID-19, the 2022 energy crisis. These "
                  "appear in the test data as multi-sigma growth-rate "
                  "deviations from the training distribution. Test T8 "
                  "fires for 10 of 25 EU-27 countries in the 2006-2024 "
                  "test window; no constant-elasticity model trained on "
                  "1995-2005 can predict them.", S["BULLET"]))
    out.append(P("<b>(b) Policy shocks that alter the elasticities.</b> "
                  "The EU ETS price collapse of 2013 changed industrial "
                  "energy elasticities. The 2018 EU energy-efficiency "
                  "directives changed residential intensities. The "
                  "module&apos;s elasticities are estimated on the "
                  "average of the training window; if a policy shock "
                  "structurally changed the elasticity after the "
                  "training window ended, the projection is biased. "
                  "Users with strong priors about post-training policy "
                  "should supply explicit paths in flow F1/F2 rather "
                  "than letting the priors do the extrapolation.",
                  S["BULLET"]))
    out.append(P("<b>(c) Long-run climate-induced damage.</b> The "
                  "module is silent on the feedback from climate-related "
                  "damages back to GDP. Coupling MITICA to a damage "
                  "function (Burke-Hsiang-Miguel, Kalkuhl-Wenz, etc.) "
                  "is an interesting research direction but out of scope "
                  "for the current spec.", S["BULLET"]))

    out.append(PageBreak())

    # ============================================================
    # 10. LIMITATIONS AND CAVEATS
    # ============================================================
    out.append(P("10.&nbsp;&nbsp; Limitations and Caveats", S["H1"]))
    out.append(P("Honesty about uncertainty is a methodological principle "
                  "of the v2.0 specification. This section enumerates "
                  "the limitations explicitly so users do not over-"
                  "interpret the outputs.", S["BODY"]))

    out.append(P("10.1&nbsp; Calibration coverage is uneven", S["H2"]))
    out.append(P("The B2 calibration uses the WDI panel which covers "
                  "all 217 countries. The B5 / B6 calibration uses the "
                  "Eurostat panel which covers 29 European economies "
                  "only. Calibrated &psi; and &gamma;_hh values are "
                  "therefore reliable for HIC and HIC_TRANS but "
                  "stylised for LAC, MENA, APAC, SSA, EEU. Until an IEA "
                  "WEO or comparable global energy-balance panel is "
                  "integrated, projections in non-EU regions rely on "
                  "literature-derived energy priors and should be "
                  "reported with that caveat.", S["BODY"]))

    out.append(P("10.2&nbsp; The constant-elasticity assumption", S["H2"]))
    out.append(P("Even the Kuznets-Chenery quadratic is a polynomial "
                  "approximation: it allows the elasticity to depend "
                  "smoothly on income but assumes the dependence is "
                  "captured by a quadratic. True elasticities can shift "
                  "more sharply &mdash; for example, when an economy "
                  "crosses a structural threshold (urbanisation tipping "
                  "point, financial development threshold, energy "
                  "transition policy). The module cannot anticipate "
                  "these; the Layer C tests flag them ex post.",
                  S["BODY"]))

    out.append(P("10.3&nbsp; Short training windows hurt identification",
                  S["H2"]))
    out.append(P("With 11-25 years of training data, only the strongest "
                  "structural signals can be identified at the country "
                  "level. The Bayesian shrinkage prevents overfitting "
                  "but at the cost of biasing the estimator toward the "
                  "regional prior. Users should report the origin tag "
                  "for each coefficient and treat <i>calibrated</i> "
                  "parameters as carrying regional rather than country-"
                  "specific information.", S["BODY"]))

    out.append(P("10.4&nbsp; The validation backtest is EU-centric",
                  S["H2"]))
    out.append(P("The out-of-sample backtests cover EU + UK + NO. The "
                  "EU experience over 2006-2024 includes the 2008 "
                  "financial crisis, the 2010-2012 sovereign debt "
                  "crisis, COVID-19, and the 2022 energy crisis &mdash; "
                  "a particularly turbulent test set. MAPE figures "
                  "would likely be lower in regions that did not "
                  "experience comparable shocks, and could be higher in "
                  "regions with even sharper political or "
                  "macroeconomic events. The methodology is not "
                  "EU-specific; the validation evidence is.", S["BODY"]))

    out.append(P("10.5&nbsp; The user is the ultimate filter", S["H2"]))
    out.append(P("The module is a tool, not an oracle. National "
                  "modellers possess context-specific knowledge "
                  "(announced infrastructure investments, demographic "
                  "policy changes, foreign-exchange regimes, sector "
                  "consolidations) that the panel-based priors cannot "
                  "represent. Flows F1 and F2 are designed precisely "
                  "to let the user inject this knowledge. The module&apos;s "
                  "comparative advantage is in turning sparse historical "
                  "data into a coherent baseline; it cannot replace "
                  "domain expertise.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 11. DISCUSSION AND OUTSTANDING WORK
    # ============================================================
    out.append(P("11.&nbsp;&nbsp; Discussion and Outstanding Work",
                  S["H1"]))

    out.append(P("11.1&nbsp; Where v2.0 lands", S["H2"]))
    out.append(P("The May 2026 sprint closes three deficiencies of the "
                  "legacy specification: the broken Bayesian update, "
                  "the synthesis of missing covariates, and the "
                  "absence of structural alternatives to the log-log "
                  "form. It opens up two new capabilities: a "
                  "WDI-calibrated regional prior system with bootstrap-"
                  "validated robustness statistics, and an extended "
                  "validation layer (T7, T8) that surfaces extrapolation "
                  "risks to the user. The Monte Carlo and the EU "
                  "backtests demonstrate that the recovered estimator "
                  "is internally sound and that the calibrated forms "
                  "deliver measurable empirical gains on the sectors "
                  "where the structural channels are strongest "
                  "(manufacturing energy, mature-OECD tertiary GDP).",
                  S["BODY"]))

    out.append(P("11.2&nbsp; Outstanding work", S["H2"]))
    out.append(P("<b>1.</b> Multi-region energy calibration. Adding "
                  "IEA WEO or OECD-CER global energy panels would let "
                  "us calibrate &psi;_k for LAC, MENA, APAC, SSA, EEU. "
                  "Until then those regions rely on literature-derived "
                  "stylised priors.", S["BULLET"]))
    out.append(P("<b>2.</b> FAOSTAT calibration of Bennett. The "
                  "Bennett-logistic intercepts a_B are currently back-"
                  "solved from FAOSTAT-style regional anchors. A direct "
                  "panel regression on crop/livestock value-added "
                  "shares would provide proper Bayesian priors with "
                  "bootstrap CIs.", S["BULLET"]))
    out.append(P("<b>3.</b> Test T8 follow-on. The current scan window "
                  "is fixed at the first 3 projected years. An adaptive "
                  "scan (5 years for long horizons) would catch slower-"
                  "onset regime changes. The touch-up proposal could be "
                  "based on driver re-estimation rather than on the "
                  "suspect model projection.", S["BULLET"]))
    out.append(P("<b>4.</b> Non-EU validation. Constructing a "
                  "Latin-American or African backtest harness, with "
                  "the relevant national-accounts panels, would close "
                  "the calibration loop for the non-EU regions.",
                  S["BULLET"]))
    out.append(P("<b>5.</b> Documentation translations. The current "
                  "specification ships in English and Spanish. French, "
                  "Portuguese, and Arabic versions would align with "
                  "the UNFCCC&apos;s working languages.", S["BULLET"]))

    out.append(P("11.3&nbsp; Methodological position", S["H2"]))
    out.append(P("The module sits at the intersection of three "
                  "research literatures: structural transformation "
                  "(Kuznets-Chenery-Herrendorf), energy economics "
                  "(Bashmakov-Schipper-IEA), and Bayesian small-data "
                  "econometrics. None of the design choices in v2.0 is "
                  "novel in any of these literatures individually; the "
                  "contribution is the integration into a single, "
                  "auditable, reproducible pipeline aimed at the "
                  "national modeller working under the UNFCCC ETF. "
                  "The empirical validation on EU data is the test of "
                  "that integration, and the results &mdash; 5.14% "
                  "MAPE on EU tertiary GDP at 19-year horizon, "
                  "-4.8 percentage points on manufacturing energy under "
                  "the intensity-convergence form &mdash; are "
                  "operationally meaningful magnitudes for emission "
                  "projections.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # APPENDIX A — DERIVATIONS
    # ============================================================
    out.append(P("Appendix A.&nbsp;&nbsp; Mathematical Derivations",
                  S["H1"]))

    out.append(P("A.1&nbsp; Closed-form Bayesian posterior", S["H2"]))
    out.append(P("Starting from the model (5-1)-(5-2):", S["BODY"]))
    out.append(P("p(y | &theta;, &sigma;&sup2;) &prop; exp[&minus;(y &minus; "
                  "X &theta;)' (y &minus; X &theta;) / (2 &sigma;&sup2;)]",
                  S["EQN"]))
    out.append(P("p(&theta;) &prop; exp[&minus;(&theta; &minus; "
                  "&theta;_prior)' &Sigma;_prior,eff&#8315;&sup1; (&theta; "
                  "&minus; &theta;_prior) / 2]", S["EQN"]))
    out.append(P("The posterior p(&theta; | y, &sigma;&sup2;) is "
                  "proportional to the product. Expanding the two "
                  "quadratic forms and collecting terms in &theta; "
                  "yields a quadratic in &theta;:", S["BODY"]))
    out.append(P("&minus; (1/2) [&theta;' (X'X / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1;) &theta; &minus; 2 "
                  "&theta;' (X' y / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1; &theta;_prior) + const]",
                  S["EQN"]))
    out.append(P("Identifying with the Gaussian form &minus; (1/2) "
                  "(&theta; &minus; &theta;_hat)' "
                  "&Sigma;_post&#8315;&sup1; (&theta; &minus; &theta;_hat), "
                  "the posterior precision and mean are:", S["BODY"]))
    out.append(P("&Sigma;_post&#8315;&sup1; = X'X / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1;,&emsp;&theta;_hat = "
                  "&Sigma;_post (X' y / &sigma;&sup2; + "
                  "&Sigma;_prior,eff&#8315;&sup1; &theta;_prior)", S["EQN"]))
    out.append(P("This is (5-3)-(5-4) in Section 5. Note that the "
                  "posterior variance &Sigma;_post depends on the data "
                  "noise &sigma;&sup2;; the v1.1s formulation omitted "
                  "this dependence and produced credible intervals "
                  "that collapsed at high shrinkage.", S["BODY"]))

    out.append(P("A.2&nbsp; Within-FE estimator (panel calibration)",
                  S["H2"]))
    out.append(P("The panel regression with country fixed effects:",
                  S["BODY"]))
    out.append(P("y_c,t = &alpha;_c + X_c,t &theta; + &epsilon;_c,t",
                  S["EQN"]))
    out.append(P("Demeaning within country (subtracting the country "
                  "mean of each variable) eliminates &alpha;_c:",
                  S["BODY"]))
    out.append(P("y_c,t &minus; y_c. = (X_c,t &minus; X_c.) &theta; + "
                  "(&epsilon;_c,t &minus; &epsilon;_c.)", S["EQN"]))
    out.append(P("OLS on the demeaned data returns &theta;_hat. HC1 "
                  "robust standard errors:", S["BODY"]))
    out.append(P("V_HC1 = (n / (n &minus; p)) (X' X)&#8315;&sup1; "
                  "(&Sigma;_i x_i x'_i &epsilon;_i&sup2;) "
                  "(X' X)&#8315;&sup1;", S["EQN"]))
    out.append(P("For the country-clustered bootstrap we resample "
                  "whole countries with replacement (B = 200 "
                  "replicates), rerun the within-FE estimator on each "
                  "bootstrap sample, and report the standard deviation "
                  "of the recovered coefficients as the empirical SE. "
                  "This preserves the within-country serial correlation "
                  "structure that HC1 ignores.", S["BODY"]))

    out.append(P("A.3&nbsp; Logit link for Bennett's law", S["H2"]))
    out.append(P("Given share_livestock &isin; (0, 1), the logit "
                  "transformation maps to R:", S["BODY"]))
    out.append(P("logit(p) = log(p / (1 &minus; p))", S["EQN"]))
    out.append(P("Inverse (logistic / expit):", S["BODY"]))
    out.append(P("expit(z) = 1 / (1 + exp(&minus; z))", S["EQN"]))
    out.append(P("Composing with the linear model a + b log GDPpc gives "
                  "the share form:", S["BODY"]))
    out.append(P("share_livestock_t = 1 / (1 + exp(&minus; (a + b log "
                  "GDPpc_t)))", S["EQN"]))
    out.append(P("which is bounded in (0, 1) by construction and "
                  "approaches 1 as GDPpc &rarr; &infin; (Bennett&apos;s "
                  "limit) when b &gt; 0.", S["BODY"]))

    out.append(P("A.4&nbsp; Inflection of the saturation form", S["H2"]))
    out.append(P("For the B6 quadratic:", S["BODY"]))
    out.append(P("log SED_hh = &alpha; + &beta; log GDPpc + &gamma; "
                  "(log GDPpc)&sup2; + &zeta; log Pop", S["EQN"]))
    out.append(P("the partial elasticity with respect to GDPpc is:",
                  S["BODY"]))
    out.append(P("d(log SED_hh) / d(log GDPpc) = &beta; + 2 &gamma; log "
                  "GDPpc", S["EQN"]))
    out.append(P("which vanishes at log(GDPpc)* = &minus; &beta; / "
                  "(2 &gamma;). For &gamma; &lt; 0 this is the income "
                  "level at which the marginal energy response to "
                  "further income growth is zero &mdash; the appliance "
                  "saturation point.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # APPENDIX B — STYLISED PRIORS
    # ============================================================
    out.append(P("Appendix B.&nbsp;&nbsp; Stylised Regional Priors "
                  "(fallback)", S["H1"]))
    out.append(P("These are the priors hard-coded in "
                  "<font face='Courier'>g_Macro_Priors.py</font>. They "
                  "apply when no JSON calibration is loaded or when a "
                  "(region, parameter) cell is missing from the "
                  "calibration. For HIC and HIC_TRANS the calibrated "
                  "values supersede these.", S["BODY"]))

    out.append(P("B.1&nbsp; B2 stylised elasticities", S["H3"]))
    out.append(header_table([
        ["Region", "&beta;_pri", "&beta;_sec", "&beta;_ter",
         "&gamma;_pri", "&gamma;_sec", "&gamma;_ter",
         "&zeta;_pri", "&zeta;_sec", "&zeta;_ter"],
        ["LAC",        "0.30", "0.35", "0.25", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10"],
        ["SSA",        "0.30", "0.35", "0.25", "0.15", "0.20", "0.15",
         "0.90", "1.00", "1.10"],
        ["MENA",       "0.30", "0.35", "0.25", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10"],
        ["APAC",       "0.35", "0.40", "0.30", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10"],
        ["EEU",        "0.30", "0.35", "0.25", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10"],
        ["HIC",        "0.30", "0.35", "0.25", "0.05", "0.10", "0.05",
         "0.90", "1.00", "1.10"],
        ["HIC_TRANS",  "0.33", "0.38", "0.28", "0.07", "0.12", "0.07",
         "0.90", "1.00", "1.10"],
    ], col_widths=[2*cm] + [1.4*cm]*9))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.2&nbsp; B2 stylised KC shifters", S["H3"]))
    out.append(header_table([
        ["Region",     "&kappa;_pri", "&kappa;_sec", "&kappa;_ter"],
        ["LAC, SSA, MENA, APAC",  "-0.40", "-0.05", "+0.20"],
        ["EEU",        "-0.30", "-0.05", "+0.15"],
        ["HIC",        "-0.20", "-0.05", "+0.10"],
        ["HIC_TRANS",  "-0.25", " 0.00", "+0.12"],
    ], col_widths=[5.5*cm, 3.5*cm, 3.5*cm, 3.5*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.3&nbsp; B5 stylised psi (all regions)", S["H3"]))
    out.append(header_table([
        ["Region", "&psi;_pri", "&psi;_manuf", "&psi;_constr",
         "&psi;_services", "&psi;_tp", "&psi;_tf"],
        ["HIC",        "-0.30", "-0.50", "-0.20", "-0.10", "-0.05", "-0.15"],
        ["HIC_TRANS",  "-0.21", "-0.35", "-0.14", "-0.07", "-0.04", "-0.11"],
        ["EEU/LAC/MENA","-0.15","-0.25", "-0.10", "-0.05", "-0.03", "-0.08"],
        ["APAC",       "-0.10", "+0.10", "+0.05", "-0.05", "+0.10", "+0.10"],
        ["SSA",        "+0.10", "+0.20", "+0.15", " 0.00", "+0.15", "+0.15"],
    ], col_widths=[3*cm, 2*cm, 2.2*cm, 2.2*cm, 2.5*cm, 1.7*cm, 1.7*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.4&nbsp; B6 stylised priors (uniform across regions)",
                  S["H3"]))
    out.append(header_table([
        ["&beta;_hh", "&gamma;_hh", "&zeta;_hh",
         "&sigma;_&beta;_hh", "&sigma;_&gamma;_hh", "&sigma;_&zeta;_hh"],
        ["0.70", "-0.04", "1.00", "0.15", "0.02", "0.10"],
    ], col_widths=[2.5*cm]*6))
    out.append(Spacer(1, 0.2*cm))

    out.append(P("B.5&nbsp; B3 stylised Bennett anchors", S["H3"]))
    out.append(header_table([
        ["Region", "share_crops", "share_livestock", "share_other",
         "log GDPpc anchor", "a_B (back-solved)", "b_B"],
        ["LAC",       "0.55", "0.35", "0.10", "8.5",  "-1.89", "0.15"],
        ["SSA",       "0.60", "0.30", "0.10", "7.0",  "-1.90", "0.15"],
        ["MENA",      "0.50", "0.35", "0.15", "8.5",  "-1.89", "0.15"],
        ["APAC",      "0.65", "0.25", "0.10", "7.5",  "-2.22", "0.15"],
        ["EEU",       "0.55", "0.40", "0.05", "9.0",  "-1.75", "0.15"],
        ["HIC",       "0.50", "0.40", "0.10", "10.5", "-1.98", "0.15"],
        ["HIC_TRANS", "0.52", "0.40", "0.08", "9.5",  "-1.83", "0.15"],
    ], col_widths=[2*cm, 1.8*cm, 2.3*cm, 1.8*cm, 2.3*cm, 2.3*cm, 1.5*cm]))
    out.append(Spacer(1, 0.2*cm))

    out.append(PageBreak())

    # ============================================================
    # APPENDIX C — GLOSSARY
    # ============================================================
    out.append(P("Appendix C.&nbsp;&nbsp; Glossary", S["H1"]))
    out.append(header_table([
        ["Term",       "Definition"],
        ["MITICA",     "Mitigation-Inventory Tool for Integrated Climate Action; the Gauss / UNFCCC GHG projection tool."],
        ["UNFCCC",     "United Nations Framework Convention on Climate Change."],
        ["ETF",        "Enhanced Transparency Framework, Paris Agreement Decision 18/CMA.1."],
        ["BTR",        "Biennial Transparency Report submitted under the ETF."],
        ["NDC",        "Nationally Determined Contribution to the Paris Agreement."],
        ["IPCC",       "Intergovernmental Panel on Climate Change."],
        ["WoM/WEM/WAM","Without Measures / With Existing Measures / With Additional Measures emission scenarios."],
        ["GHG",        "Greenhouse gas; in CO2-eq using IPCC AR5 GWPs."],
        ["GDP / GDPpc","Gross Domestic Product (total) and per capita (= GDP/Pop)."],
        ["SGDP_s",     "Sectoral GDP for economic sector s (primary, secondary, tertiary)."],
        ["SED_k",      "Sectoral final Energy Demand for energy sector k."],
        ["TED",        "Total Energy Demand = sum_k SED_k + SED_hh."],
        ["SInv_s",     "Sectoral Investment (gross fixed capital formation)."],
        ["GFCF_pub_s", "Public Gross Fixed Capital Formation per sector."],
        ["iRate",      "Effective interest rate (long-term sovereign bond yield as proxy)."],
        ["WDI",        "World Bank World Development Indicators."],
        ["FAOSTAT",    "FAO Statistics; agricultural panel data."],
        ["IEA WEO",    "International Energy Agency, World Energy Outlook."],
        ["NACE rev2",  "Statistical Classification of Economic Activities in the European Community (rev. 2)."],
        ["FE / WG",    "Fixed effects / within-group panel estimator."],
        ["HC1",        "Heteroskedasticity-Consistent variance estimator, type 1."],
        ["VIF",        "Variance Inflation Factor (multicollinearity diagnostic)."],
        ["MAPE",       "Mean Absolute Percentage Error: (1/n) sum |y_hat - y| / |y| × 100."],
        ["Bayesian ridge", "Closed-form Gaussian-Gaussian conjugate posterior with prior-centered shrinkage."],
        ["Bootstrap",  "Cluster-robust resampling (by country) for confidence intervals."],
        ["KC / KCQ",   "Kuznets-Chenery linear / quadratic shifter on log(GDPpc)."],
        ["IC",         "Intensity Convergence (Bashmakov 2007); energy intensity decays with income."],
        ["SAT",        "Saturation form (quadratic in log GDPpc) for residential energy."],
        ["BL",         "Bennett's law logistic form for crop / livestock share."],
        ["LL",         "log-log form (the v1.1s legacy specification)."],
        ["HIC / HIC_TRANS", "High-income countries (mature OECD vs transitioning)."],
        ["LAC / SSA / MENA / APAC / EEU", "MITICA macro-regions (Latin America & Caribbean / Sub-Saharan Africa / Middle East & North Africa / Asia-Pacific / Eastern Europe & Central Asia)."],
    ], col_widths=[3*cm, 13.5*cm]))

    out.append(PageBreak())

    # ============================================================
    # APPENDIX D — REFERENCES
    # ============================================================
    out.append(P("Appendix D.&nbsp;&nbsp; References", S["H1"]))

    out.append(P("D.1&nbsp; MITICA documentation", S["H3"]))
    out.append(P("&bull; Mart&iacute;n-Ortega, J.L., Almagro Holgado, "
                  "M., Maro&ntilde;o de la Mata, A. and Carbajales, S. "
                  "(2024). MITICA: A Tool for Designing Mitigation "
                  "Scenarios. <i>Sustainability</i> 16(10): 4219. "
                  "DOI: 10.3390/su16104219.", S["BULLET"]))
    out.append(P("&bull; UNFCCC Secretariat (2024). <i>Manual of the "
                  "MITICA tool</i>, version 6. Available at "
                  "<font face='Courier'>unfccc.int/sites/default/files/"
                  "resource/Manual_draft_Mitigation_toolrev_v6.pdf</font>.",
                  S["BULLET"]))

    out.append(P("D.2&nbsp; Economic methodology", S["H3"]))
    out.append(P("&bull; Bashmakov, I. (2007). Three laws of energy "
                  "transitions. <i>Energy Policy</i> 35(7): 3583-3594.",
                  S["BULLET"]))
    out.append(P("&bull; Bennett, M.K. (1941). Wheat in National Diets. "
                  "<i>Wheat Studies of the Food Research Institute</i> "
                  "18(2): 35-76.", S["BULLET"]))
    out.append(P("&bull; Chenery, H.B. and Syrquin, M. (1975). "
                  "<i>Patterns of Development, 1950-1970</i>. Oxford "
                  "University Press for the World Bank.", S["BULLET"]))
    out.append(P("&bull; Chenery, H.B. and Syrquin, M. (1986). "
                  "<i>Industrialization and Growth: A Comparative "
                  "Study</i>. Oxford University Press.", S["BULLET"]))
    out.append(P("&bull; Herrendorf, B., Rogerson, R. and Valentinyi, "
                  "&Aacute;. (2014). Growth and Structural Transformation. "
                  "In Aghion, P. and Durlauf, S.N. (eds.), <i>Handbook "
                  "of Economic Growth</i>, vol. 2B, 855-941. Elsevier.",
                  S["BULLET"]))
    out.append(P("&bull; Kuznets, S. (1957). Quantitative Aspects of "
                  "the Economic Growth of Nations: II. Industrial "
                  "Distribution of National Product and Labor Force. "
                  "<i>Economic Development and Cultural Change</i> "
                  "5(4 Suppl.): 1-111.", S["BULLET"]))
    out.append(P("&bull; Kuznets, S. (1971). <i>Economic Growth of "
                  "Nations: Total Output and Production Structure</i>. "
                  "Belknap Press of Harvard University Press.",
                  S["BULLET"]))
    out.append(P("&bull; Schipper, L. and Meyers, S. (1992). <i>Energy "
                  "Efficiency and Human Activity: Past Trends, Future "
                  "Prospects</i>. Cambridge University Press.",
                  S["BULLET"]))

    out.append(P("D.3&nbsp; Estimation and statistics", S["H3"]))
    out.append(P("&bull; Cameron, A.C. and Trivedi, P.K. (2005). "
                  "<i>Microeconometrics: Methods and Applications</i>. "
                  "Cambridge University Press. (HC1 robust SE, panel FE).",
                  S["BULLET"]))
    out.append(P("&bull; Cameron, A.C., Gelbach, J.B. and Miller, D.L. "
                  "(2008). Bootstrap-based improvements for inference "
                  "with clustered errors. <i>Review of Economics and "
                  "Statistics</i> 90(3): 414-427.", S["BULLET"]))
    out.append(P("&bull; Gelman, A., Carlin, J.B., Stern, H.S., Dunson, "
                  "D.B., Vehtari, A. and Rubin, D.B. (2013). <i>Bayesian "
                  "Data Analysis</i>, 3rd ed. CRC Press. (Conjugate "
                  "Gaussian-Gaussian posterior, Chapter 3).", S["BULLET"]))

    out.append(P("D.4&nbsp; Data sources", S["H3"]))
    out.append(P("&bull; Eurostat (2024). Data Browser. "
                  "<font face='Courier'>ec.europa.eu/eurostat/data/database"
                  "</font>. Licence: CC BY 4.0.", S["BULLET"]))
    out.append(P("&bull; World Bank (2024). World Development "
                  "Indicators. <font face='Courier'>data.worldbank.org"
                  "</font>. Licence: CC BY 4.0.", S["BULLET"]))
    out.append(P("&bull; FAO (2024). FAOSTAT. "
                  "<font face='Courier'>fao.org/faostat</font>.",
                  S["BULLET"]))
    out.append(P("&bull; IEA (2024). World Energy Outlook 2024. "
                  "<font face='Courier'>iea.org/reports/world-energy-"
                  "outlook-2024</font>.", S["BULLET"]))

    out.append(P("D.5&nbsp; Regulatory", S["H3"]))
    out.append(P("&bull; UNFCCC (2018). Decision 18/CMA.1: Modalities, "
                  "procedures and guidelines for the transparency "
                  "framework for action and support referred to in "
                  "Article 13 of the Paris Agreement.", S["BULLET"]))
    out.append(P("&bull; IPCC (2006). <i>2006 IPCC Guidelines for "
                  "National Greenhouse Gas Inventories</i>, Volumes "
                  "1-5. Eggleston, H.S. et al. (eds.). Institute for "
                  "Global Environmental Strategies, Japan.", S["BULLET"]))
    out.append(P("&bull; IPCC (2019). <i>2019 Refinement to the 2006 "
                  "IPCC Guidelines for National Greenhouse Gas "
                  "Inventories</i>. Calvo Buendia, E. et al. (eds.). "
                  "IPCC, Switzerland.", S["BULLET"]))

    out.append(Spacer(1, 0.5*cm))
    out.append(P("<i>End of report.</i>", S["NOTE"]))

    return out
