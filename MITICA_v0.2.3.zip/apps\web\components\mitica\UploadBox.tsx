"use client";

import { useRef, useState } from "react";
import { CloudUpload, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface UploadBoxProps {
  label: string;
  description?: string;
  accept?: string;
  onUpload: (file: File) => Promise<void>;
  uploaded?: boolean;
}

export function UploadBox({ label, description, accept, onUpload, uploaded }: UploadBoxProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [status, setStatus] = useState<"idle" | "uploading" | "done" | "error">(
    uploaded ? "done" : "idle"
  );
  const [error, setError] = useState<string | null>(null);
  const [filename, setFilename] = useState<string | null>(null);

  async function handle(file: File) {
    setStatus("uploading");
    setError(null);
    setFilename(file.name);
    try {
      await onUpload(file);
      setStatus("done");
    } catch (e) {
      setStatus("error");
      setError((e as Error).message);
    }
  }

  return (
    <div
      className={cn(
        "relative rounded-lg border-2 border-dashed p-6 transition-colors",
        isDragging
          ? "border-primary bg-primary/5"
          : status === "done"
          ? "border-emerald-500/40 bg-emerald-500/5"
          : status === "error"
          ? "border-destructive/40 bg-destructive/5"
          : "border-border"
      )}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file) void handle(file);
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void handle(file);
        }}
      />

      <div className="flex items-start gap-4">
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-md",
            status === "done"
              ? "bg-emerald-500/20 text-emerald-700"
              : status === "error"
              ? "bg-destructive/20 text-destructive"
              : "bg-primary/10 text-primary"
          )}
        >
          {status === "done" ? (
            <CheckCircle2 className="h-5 w-5" />
          ) : status === "error" ? (
            <XCircle className="h-5 w-5" />
          ) : (
            <CloudUpload className="h-5 w-5" />
          )}
        </div>
        <div className="flex-1">
          <p className="font-medium">{label}</p>
          {description && (
            <p className="text-xs text-muted-foreground">{description}</p>
          )}
          {filename && (
            <p className="mt-1 text-xs">
              <span className="text-muted-foreground">File:</span>{" "}
              <code className="rounded bg-muted px-1">{filename}</code>
            </p>
          )}
          {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
        </div>
        <Button
          size="sm"
          variant={status === "done" ? "outline" : "default"}
          disabled={status === "uploading"}
          onClick={() => inputRef.current?.click()}
        >
          {status === "uploading" ? "Uploading…" : status === "done" ? "Replace" : "Choose file"}
        </Button>
      </div>
    </div>
  );
}
