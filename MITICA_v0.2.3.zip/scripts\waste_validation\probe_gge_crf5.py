"""Probe: which CRF5* codes does the raw env_air_gge bulk download carry?

DATA-HONESTY: reads the raw bulk-API gz already on disk (downloaded by the
energy harness) and enumerates the waste-sector (CRF5*) codes with pandas. No
LLM-extracted numbers.
"""
from __future__ import annotations

import gzip
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
RAW = (ROOT / "scripts" / "energy_validation" / "data" / "eurostat" / "raw"
       / "env_air_gge.tsv.gz")


def main() -> None:
    with gzip.open(RAW, "rt", encoding="utf-8") as fh:
        df = pd.read_csv(fh, sep="\t", dtype=str)
    first = df.columns[0]
    dims = first.split("\\")[0].split(",")
    df[dims] = df[first].str.split(",", expand=True)
    crf5 = sorted(c for c in df["src_crf"].dropna().unique()
                  if str(c).startswith("CRF5"))
    print("dims:", dims)
    print("CRF5* codes:", crf5)
    print("units:", sorted(df["unit"].dropna().unique()))
    print("airpol:", sorted(df["airpol"].dropna().unique()))
    print("geo n:", df["geo"].nunique())


if __name__ == "__main__":
    main()
