"""Hand spot-checks for the T4 gate (independent of module_backtest.py):

1. Raw-data checks: panel.csv values vs the raw OWID csv for ESP / IND (parsed
   directly with pandas — no LLM extraction).
2. Math check: ESP module 2023 WoM recomputed step by step (floor from the
   shipped priors JSON parsed directly, scaleP1, P2 fit, shrinkage) and compared
   to the production module's output.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

HERE = Path(__file__).resolve().parent
panel = pd.read_csv(HERE / "data" / "panel.csv")
raw = pd.read_csv(HERE / "data" / "owid_ghg_by_sector.csv")

print("--- spot 1+2: panel vs raw OWID (tonnes) ---")
for c, yrs in [("ESP", (2012, 2023)), ("IND", (2012, 2023))]:
    for y in yrs:
        pv = panel[(panel.iso3 == c) & (panel.Year == y)].transport_co2e_t.iloc[0]
        rv = raw[(raw.Code == c) & (raw.Year == y)]["Transport"].iloc[0]
        print(f"{c} {y}: panel {pv:,.0f} t | OWID raw {rv:,.0f} t | match={abs(pv-rv)<0.5}")

print("\n--- spot 3: ESP module 2023 WoM, recomputed by hand ---")
pri = json.loads((HERE / "data" / "transport_priors.json").read_text())
sub = panel[panel.iso3 == "ESP"].sort_values("Year")
hist = sub[sub.Year <= 2012]
fut = sub[(sub.Year > 2012) & (sub.Year <= 2023)]
grp = "H"  # ESP calib-mean gdp_pc is high income

def log_co2pc(curve, gdp_pc, year):
    return (curve["lng"] + curve["a"] * np.exp(curve["b"] * gdp_pc / 1000.0)
            - curve["d"] * (year - 2000.0))

# H group curve is null in the shipped JSON -> pure global curve
g = pri["global"]
floor_h = np.exp(log_co2pc(g, hist.gdp_pc.to_numpy(), hist.Year.to_numpy())) * hist["pop"].to_numpy()
floor_f = np.exp(log_co2pc(g, fut.gdp_pc.to_numpy(), fut.Year.to_numpy())) * fut["pop"].to_numpy()
co2_h_kt = hist.transport_co2e_t.to_numpy() / 1e3
scaleP1 = float(np.median(co2_h_kt / floor_h))

def f(X, lnscale, ddelta):
    base, yy = X
    return np.log(base) + lnscale - ddelta * (yy - 2000.0)

popt, _ = curve_fit(f, (floor_h, hist.Year.to_numpy().astype(float)),
                    np.log(co2_h_kt), p0=[0.0, 0.0], maxfev=20000)
yr_f = fut.Year.to_numpy().astype(float)
country_f = np.exp(np.log(floor_f) + popt[0] - popt[1] * (yr_f - 2000.0))
floorP1_f = scaleP1 * floor_f
w = len(hist) / (len(hist) + 18.0)  # K_P2
pred_kt = np.exp(w * np.log(country_f) + (1 - w) * np.log(floorP1_f))
hand_2023 = pred_kt[-1]
print(f"hand P2 ESP 2023: {hand_2023:,.1f} kt (w={w:.3f}, scaleP1={scaleP1:.3e})")

from mitica_core.modules.transport import TransportConfig, TransportInputs, run_transport_module
inp = TransportInputs(
    country_code="ESP",
    gdp_pc={int(r.Year): float(r.gdp_pc) for r in sub.itertuples()},
    population={int(r.Year): float(r.pop) for r in sub.itertuples()},
    road_co2_history={int(r.Year): float(r.transport_co2e_t) / 1e3 for r in hist.itertuples()},
)
out = run_transport_module(inp, TransportConfig(horizon_year=2023, dev_group=grp, scenarios=("WoM",)))
mod_2023 = [r.total_kt_co2eq() for r in out.rows if r.scenario == "WoM" and r.year == 2023][0]
obs_2023 = fut[fut.Year == 2023].transport_co2e_t.iloc[0] / 1e3
print(f"module ESP 2023:  {mod_2023:,.1f} kt | tier={out.tier}")
print(f"observed ESP 2023: {obs_2023:,.1f} kt")
print(f"hand vs module rel diff: {abs(hand_2023-mod_2023)/mod_2023:.2e}")
