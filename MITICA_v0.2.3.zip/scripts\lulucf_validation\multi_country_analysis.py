"""
multi_country_analysis.py
=========================

Run the LULUCF model against the REAL submitted inventories of several
structurally different Parties, to map (a) what each country actually reports
(the data-availability "casuistry") and (b) how the WoM baseline compares to
the reported inventory.

Data is read straight from the submission Excel files via crt_lulucf_reader
(validated: per-category sum == reported Total LULUCF, exactly). No download,
no interpolation, no synthetic split — these are the genuine tables.

Sources used (whatever is present locally under the user's BTR Review folder):
  - Canada  CRF 2023  (Annex I, 32 yrs)
  - Canada  CRT 2024  (Annex I, 33 yrs, new BTR1 format)
  - China   CRT 2024  (large developing, only 2005/2020/2021)
  - Greece  CRT 2024  (EU, 33 yrs)

Output: MITICA_LULUCF_multicountry_casuistry.xlsx in the MITICA_project root.
"""

from __future__ import annotations

import glob
import os
import sys
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_PROJECT_ROOT = _REPO_ROOT.parent
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS)):
    if p not in sys.path:
        sys.path.insert(0, p)

import crt_lulucf_reader as rdr  # noqa: E402
import v1_country_backtest as bt  # noqa: E402
from mitica_core.modules.lulucf import (  # noqa: E402
    HistoricalLULUCF, LULUCFConfig, ProjectedLULUCF, run_lulucf_module,
)

_BTR = r"C:\Users\juanl\Desktop\Importante\BTR Review"
_CANCRF = str(_SCRIPTS / "_can_crf")
_BTRCRT = str(_SCRIPTS / "_btr_crt")
_CHN = os.path.join(_BTR, "China_25",
                    "CHN-CRT-2024-V0.11-2005-2020-2021-20241231-141557_started")

OUT = _PROJECT_ROOT / "MITICA_LULUCF_multicountry_casuistry.xlsx"

# tag -> (iso3, list of xlsx file paths)
SOURCES = {
    "Canada (CRF 2023)": ("CAN", sorted(glob.glob(os.path.join(_CANCRF, "*.xlsx")))),
    "Canada (CRT 2024)": ("CAN", sorted(glob.glob(os.path.join(_BTRCRT, "CAN_CRT", "**", "*.xlsx"), recursive=True))),
    "China (CRT 2024)":  ("CHN", sorted(glob.glob(os.path.join(_CHN, "*.xlsx")))),
    "Greece (CRT 2024)": ("GRC", sorted(glob.glob(os.path.join(_BTRCRT, "GRC", "**", "*.xlsx"), recursive=True))),
}

CATS_STD = ["4A", "4B", "4C", "4D", "4E", "4F", "4G"]


def _p(s: str = "") -> None:
    sys.stdout.buffer.write((s + "\n").encode("ascii", "replace"))


def load_country(files: list[str]) -> dict[int, dict[str, float]]:
    """{year: {cat: co2eq_kt}} from a country's per-year submission files."""
    out: dict[int, dict[str, float]] = {}
    for f in files:
        try:
            r = rdr.read_table4(f)
        except Exception:
            continue
        if not r or r["year"] is None:
            continue
        out[r["year"]] = {c: rdr.co2eq(g) for c, g in r["categories"].items()}
    return out


def availability_row(tag: str, iso: str, series: dict[int, dict[str, float]]) -> dict:
    years = sorted(series)
    last = years[-1]
    cats_present = set()
    has_4h = False
    for y in years:
        for c, v in series[y].items():
            if abs(v) > 1:
                cats_present.add(c)
            if c == "4H":
                has_4h = True
    net_last = sum(series[last].values())
    net_std_last = sum(series[last].get(c, 0.0) for c in CATS_STD)
    return {
        "Source": tag,
        "ISO": iso,
        "Years": f"{years[0]}-{last}",
        "N years": len(years),
        "Contiguous?": "yes" if len(years) == (last - years[0] + 1) else "NO (gaps)",
        "Categories reported": ",".join(sorted(cats_present)),
        "Has 4H 'Other'?": "YES" if has_4h else "no",
        f"Net @ {last} (all cats, kt)": round(net_last, 0),
        f"Net @ {last} (4A-4G only)": round(net_std_last, 0),
        "4H lost (kt)": round(net_last - net_std_last, 0),
        "in MITICA refDB?": "yes" if bt.get_country_profile(bt.load_refdb(), iso) else "NO",
    }


def run_model(iso: str, series: dict[int, dict[str, float]]):
    """Feed 4A-4G to MITICA (refDB land auto-fill), return (wom_net_last,
    reported_std_last, reported_all_last, err%, flag) or None."""
    refdb = bt.load_refdb()
    profile = bt.get_country_profile(refdb, iso)
    if profile is None:
        return None
    years = sorted(series)
    inv_rows = []
    for y in years:
        for c in CATS_STD:
            v = series[y].get(c, 0.0)
            inv_rows.append({"Year": y, "Category": c, "Gas": "CO2eq", "Emissions": v})
    inv = pd.DataFrame(inv_rows)
    land = bt._build_land_areas(iso, profile, years)
    hist = HistoricalLULUCF(inventory_emissions=inv, land_areas=land, country=iso)
    cfg = LULUCFConfig(country=iso, region=profile["region"], horizon_year=2040,
                       climate_zone=profile["climate_zone"], tier=0, profile="L-A")
    try:
        out = run_lulucf_module(hist, ProjectedLULUCF(), cfg)
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}
    wom = out.net_co2eq_by_year().set_index("Year")["Net_LULUCF_CO2eq_kt"]
    last = years[-1]
    rep_std = sum(series[last].get(c, 0.0) for c in CATS_STD)
    rep_all = sum(series[last].values())
    model = float(wom.get(last, float("nan")))
    err = (model - rep_std) / abs(rep_std) * 100 if rep_std else float("nan")
    flags = [f.test_id for f in out.validation_report if f.severity in ("red", "amber")]
    return {"model": model, "rep_std": rep_std, "rep_all": rep_all,
            "err": err, "flags": flags}


def main() -> int:
    avail_rows = []
    model_rows = []
    series_by_tag = {}
    for tag, (iso, files) in SOURCES.items():
        if not files:
            _p(f"[skip] {tag}: no files found"); continue
        series = load_country(files)
        if not series:
            _p(f"[skip] {tag}: no Table4 parsed"); continue
        series_by_tag[tag] = (iso, series)
        avail_rows.append(availability_row(tag, iso, series))

    _p("=" * 92)
    _p("  DATA AVAILABILITY (casuistry) across real BTR1 / CRF submissions")
    _p("=" * 92)
    av = pd.DataFrame(avail_rows)
    sys.stdout.buffer.write((av.to_string(index=False) + "\n").encode("ascii", "replace"))

    _p("\n" + "=" * 92)
    _p("  MODEL: WoM baseline vs reported inventory (inventory-only, refDB land)")
    _p("=" * 92)
    _p(f"  {'Source':<20} {'last':>5} {'reported(4A-G)':>15} {'WoM model':>14} {'err%':>9}  flags")
    for tag, (iso, series) in series_by_tag.items():
        res = run_model(iso, series)
        last = sorted(series)[-1]
        if res is None:
            _p(f"  {tag:<20} {last:>5} {'':>15} {'(not in refDB - no land auto-fill)':>14}")
            model_rows.append({"Source": tag, "last year": last, "note": "not in refDB"})
            continue
        if "error" in res:
            _p(f"  {tag:<20} {last:>5}  ERROR {res['error'][:50]}")
            model_rows.append({"Source": tag, "last year": last, "note": res["error"]})
            continue
        _p(f"  {tag:<20} {last:>5} {res['rep_std']:>15,.0f} {res['model']:>14,.0f} "
           f"{res['err']:>8.0f}%  {','.join(res['flags'])}")
        model_rows.append({
            "Source": tag, "last year": last,
            "reported 4A-4G (kt)": round(res["rep_std"], 0),
            "reported all incl 4H (kt)": round(res["rep_all"], 0),
            "WoM model (kt)": round(res["model"], 0),
            "error %": round(res["err"], 0),
            "flags": ",".join(res["flags"]),
        })

    # Excel
    with pd.ExcelWriter(OUT, engine="openpyxl") as xl:
        av.to_excel(xl, sheet_name="1 Data availability", index=False)
        pd.DataFrame(model_rows).to_excel(xl, sheet_name="2 Model vs reported", index=False)
        # per-country net trajectories
        traj = []
        for tag, (iso, series) in series_by_tag.items():
            for y in sorted(series):
                traj.append({"Source": tag, "Year": y,
                             "Net all cats (kt)": round(sum(series[y].values()), 0),
                             "Net 4A-4G (kt)": round(sum(series[y].get(c, 0) for c in CATS_STD), 0)})
        pd.DataFrame(traj).to_excel(xl, sheet_name="3 Net trajectories", index=False)
        wb = xl.book
        hf = PatternFill("solid", fgColor="1F4E78"); ff = Font(bold=True, color="FFFFFF")
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.fill = hf; cell.font = ff
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            for col in ws.columns:
                w = max((len(str(c.value)) for c in col if c.value is not None), default=10)
                ws.column_dimensions[get_column_letter(col[0].column)].width = min(w + 2, 40)
    _p(f"\n  Wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
