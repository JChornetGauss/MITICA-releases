"""
pam_stress_test.py
==================

Rigorous stress / simulation harness for the LULUCF catalog-formula PAM
capability (LULUCF_v1_DESIGN.md §2.4.2).

This is NOT a unit test. The point is to *put the model under load* the way
real focal points will: attach realistic PAM portfolios to the five real-data
backtest countries, then hammer the engine with hard edge cases that a user
can plausibly trigger from the UI (division-by-zero formulas, negative inputs,
a t0 set in the historical window, t0 beyond the horizon, a PAM on a category
the country doesn't report, gross over-mitigation, degenerate logistic ramps,
multi-PAM summation, WEM/WAM additivity).

For every probe it captures the REAL numeric output, contrasts it against what
a correct mitigation engine must produce, and tags the result:

  PASS    — behaved correctly.
  ANOMALY — ran, but produced a physically/logically wrong number.
  CRASH   — raised an exception that would 500 the whole module run.
  FAIL    — a harness-level assertion failed.

Run::

    python scripts/lulucf_validation/pam_stress_test.py

Exit code is the number of CRASH+ANOMALY+FAIL findings (0 = clean).
"""

from __future__ import annotations

import sys
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# --- path wiring (mirror v1_country_backtest.py) ---------------------------
_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS_DIR = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from mitica_core.modules.lulucf import run_lulucf_module  # noqa: E402
from mitica_core.modules.lulucf.g_LULUCF_PAMs import (  # noqa: E402
    SCENARIO_WAM,
    SCENARIO_WEM,
    SCENARIO_WOM,
    apply_pams,
    lulucf_pam_catalog_tree,
)

import v1_country_backtest as bt  # noqa: E402


# ---------------------------------------------------------------------------
# Findings collector
# ---------------------------------------------------------------------------

class Findings:
    def __init__(self) -> None:
        self.rows: list[dict[str, Any]] = []

    def add(self, probe: str, status: str, detail: str) -> None:
        self.rows.append({"probe": probe, "status": status, "detail": detail})
        marker = {
            "PASS": "  ok ",
            "ANOMALY": ">>ANOM",
            "CRASH": ">>CRASH",
            "FAIL": ">>FAIL",
        }.get(status, "  ?  ")
        print(f"[{marker}] {probe}: {detail}")

    @property
    def defects(self) -> list[dict[str, Any]]:
        return [r for r in self.rows if r["status"] != "PASS"]


F = Findings()


# ---------------------------------------------------------------------------
# Catalog lookup helpers (resolve catalog_id by display-name substring so the
# harness never hard-codes fragile "::<n>" indices).
# ---------------------------------------------------------------------------

_CATALOG_TREE = lulucf_pam_catalog_tree()
_ENTRIES: list[dict[str, Any]] = [
    e for items in _CATALOG_TREE.values() for e in items
]


def pam_id(name_substr: str) -> str:
    """First catalog_id whose name contains ``name_substr`` (case-insensitive)."""
    s = name_substr.lower()
    for e in _ENTRIES:
        if s in e["name"].lower():
            return e["catalog_id"]
    raise KeyError(f"No catalog PAM matching {name_substr!r}. "
                   f"Have: {[e['name'] for e in _ENTRIES]}")


def pam_entry(catalog_id: str) -> dict[str, Any]:
    for e in _ENTRIES:
        if e["catalog_id"] == catalog_id:
            return e
    raise KeyError(catalog_id)


# ---------------------------------------------------------------------------
# scenario_net access helpers
# ---------------------------------------------------------------------------

def net_at(df: pd.DataFrame, year: int, category: str, scenario: str) -> float:
    sub = df[(df["Year"] == year)
             & (df["Category"] == category)
             & (df["Scenario"] == scenario)]
    return float(sub["Net_CO2eq_kt"].sum())


def national_net(df: pd.DataFrame, year: int, scenario: str) -> float:
    sub = df[(df["Year"] == year) & (df["Scenario"] == scenario)]
    return float(sub["Net_CO2eq_kt"].sum())


def all_finite(df: pd.DataFrame) -> bool:
    col = df["Net_CO2eq_kt"]
    return bool(col.notna().all() and np.isfinite(col).all())


# ---------------------------------------------------------------------------
# PART A — real-data personas (5 backtest countries + realistic portfolios)
# ---------------------------------------------------------------------------

def _spec(catalog_id: str, category: str, scenario: str, t0: int,
          variables: dict[str, float] | None = None,
          time_distribution: str = "constant",
          t1: int | None = None, t2: int | None = None,
          name: str | None = None) -> dict[str, Any]:
    return {
        "catalog_id": catalog_id,
        "category": category,
        "scenario": scenario,
        "variables": variables or {},
        "time_distribution": time_distribution,
        "t0": t0,
        "t1": t1,
        "t2": t2,
        "name": name,
    }


def personas() -> dict[str, list[dict[str, Any]]]:
    """Realistic per-country WEM/WAM portfolios.

    Area variables (``A``) are in **hectares** (the catalog's ``A*B/1000`` →
    kt CO2-eq convention). Magnitudes are picked so the modelled mitigation is
    a plausible fraction of each country's real LULUCF net flux (a few % to
    ~30%), never absurd — that realism is itself part of the test. Every
    required (catalog-default ``null``) variable is supplied.
    """
    afforest = pam_id("Via afforested")          # Forestry::0, 4A
    restore = pam_id("Restoration of degraded")  # Forestry::2, 4A
    red_defor = pam_id("Deforestation Prevented")  # Forestry::3, 4A
    till = pam_id("Reduced and Zero Tillage")    # Croplands::0, 4B
    organic = pam_id("organic/peaty")            # Croplands::10, 4D
    arable2grass = pam_id("Conversion of arable")  # Croplands::8, 4C

    # Afforestation/restoration vars: A=area(ha), B=biomass increment
    # (t dm/ha/yr), C=below-/above-ground ratio, E=carbon fraction,
    # G=loss %, H=soil/DOM uptake (t CO2/ha/yr).
    aff_vars = {"B": 10.0, "C": 0.25, "E": 0.47, "G": 10.0, "H": 0.0}
    # Reducing deforestation: B=stock (t dm/ha), C ratio, E C-fraction,
    # G=residual emission rate (t CO2/ha).
    rd_vars = {"B": 100.0, "C": 0.25, "E": 0.47, "G": 5.0}

    return {
        # JPN — deepen the mature forest sink: afforestation (WEM) +
        # degraded-forest restoration (WAM).
        "JPN": [
            _spec(afforest, "4A", "WEM", 2025, {"A": 200_000.0, **aff_vars},
                  name="Afforestation 200 kha"),
            _spec(restore, "4A", "WAM", 2027, {"A": 100_000.0, "B": 8.0,
                  "C": 0.25, "E": 0.47, "G": 10.0}, name="Restore degraded 100 kha"),
        ],
        # FIN — cut the 4B drained-organic source (reduced tillage WEM) and
        # manage peat soils (WAM, 4D).
        "FIN": [
            _spec(till, "4B", "WEM", 2025, {"A": 300_000.0, "B": 0.6},
                  name="Reduced tillage 300 kha"),
            _spec(organic, "4D", "WAM", 2026, {"A": 80_000.0, "B": 8.0},
                  name="Organic-soil mgmt 80 kha"),
        ],
        # CAN — reduce deforestation on the boreal forest land (WEM).
        "CAN": [
            _spec(red_defor, "4A", "WEM", 2025, {"A": 5_000.0, **rd_vars},
                  name="Reduce deforestation 5 kha/yr"),
        ],
        # AUS — afforestation (WEM, 4A) + arable→grassland (WAM, 4C).
        "AUS": [
            _spec(afforest, "4A", "WEM", 2025, {"A": 150_000.0, **aff_vars},
                  name="Afforestation 150 kha"),
            _spec(arable2grass, "4C", "WAM", 2028, {"A": 500_000.0, "B": 1.0},
                  name="Arable->grassland 500 kha"),
        ],
        # NOR — reduce deforestation (WEM, 4A) + organic-soil management
        # (WAM, 4D).
        "NOR": [
            _spec(red_defor, "4A", "WEM", 2025, {"A": 2_000.0, **rd_vars},
                  name="Reduce deforestation 2 kha/yr"),
            _spec(organic, "4D", "WAM", 2026, {"A": 50_000.0, "B": 5.0},
                  name="Organic-soil mgmt 50 kha"),
        ],
    }


def run_personas() -> None:
    print("\n=== PART A: real-data personas (5 BTR1 countries) ===")
    for iso3, portfolio in personas().items():
        probe = f"persona/{iso3}"
        try:
            hist, proj, cfg = bt.build_country_inputs(iso3)
            last_hist = hist.last_historical_year()
            horizon = cfg.horizon_year
            outputs = run_lulucf_module(hist, proj, cfg, pams=portfolio)
        except Exception as exc:  # noqa: BLE001
            F.add(probe, "CRASH",
                  f"run_lulucf_module raised {type(exc).__name__}: {exc}")
            continue

        sn = outputs.scenario_net
        if sn is None or sn.empty:
            F.add(probe, "FAIL", "scenario_net is empty despite a PAM portfolio")
            continue
        if not all_finite(sn):
            F.add(probe, "ANOMALY", "scenario_net contains NaN/Inf")
            continue

        # Invariant 1 — history must be untouched: WoM == WEM == WAM for all
        # historical years.
        hist_years = sorted(y for y in sn["Year"].unique() if y <= last_hist)
        max_hist_drift = 0.0
        for y in hist_years:
            wom = national_net(sn, y, SCENARIO_WOM)
            wem = national_net(sn, y, SCENARIO_WEM)
            wam = national_net(sn, y, SCENARIO_WAM)
            max_hist_drift = max(max_hist_drift,
                                 abs(wem - wom), abs(wam - wom))
        if max_hist_drift > 1.0:  # >1 kt drift in a "historical" year is wrong
            F.add(probe, "ANOMALY",
                  f"PAMs altered HISTORY: max |WEM/WAM - WoM| over "
                  f"{len(hist_years)} historical yrs = {max_hist_drift:,.1f} kt "
                  f"(must be ~0 — the reported inventory cannot change).")
        else:
            F.add(f"{probe}/history-untouched", "PASS",
                  f"{len(hist_years)} historical yrs, max drift "
                  f"{max_hist_drift:.3f} kt")

        # Invariant 2 — at the horizon, mitigation must REDUCE net emissions:
        # WEM <= WoM and WAM <= WEM (national, since all PAMs here are real
        # source-cuts / sink-deepening).
        wom_h = national_net(sn, horizon, SCENARIO_WOM)
        wem_h = national_net(sn, horizon, SCENARIO_WEM)
        wam_h = national_net(sn, horizon, SCENARIO_WAM)
        ok_dir = (wem_h <= wom_h + 1e-6) and (wam_h <= wem_h + 1e-6)
        status = "PASS" if ok_dir else "ANOMALY"
        F.add(f"{probe}/direction@{horizon}", status,
              f"WoM={wom_h:,.0f}  WEM={wem_h:,.0f}  WAM={wam_h:,.0f} kt "
              f"(reduction WEM={wom_h - wem_h:,.0f}, WAM={wom_h - wam_h:,.0f})")


# ---------------------------------------------------------------------------
# PART B — hard edge cases on a controlled synthetic WoM table
# ---------------------------------------------------------------------------

def synthetic_wom() -> tuple[pd.DataFrame, list[int], int, int]:
    """A clean WoM emissions table: history 2015-2022, projection 2023-2050.

    4A = -50,000 kt (forest sink), 4B = +5,000 kt (cropland source).
    Columns match what ``build_scenarios`` consumes (Year, Category,
    Emissions_CO2eq_kt).
    """
    hist_years = list(range(2015, 2023))
    proj_years = list(range(2023, 2051))
    years = hist_years + proj_years
    rows = []
    for y in years:
        rows.append({"Year": y, "Category": "4A", "Emissions_CO2eq_kt": -50_000.0})
        rows.append({"Year": y, "Category": "4B", "Emissions_CO2eq_kt": +5_000.0})
    return pd.DataFrame(rows), years, hist_years[-1], proj_years[-1]


def run_edge_cases() -> None:
    print("\n=== PART B: hard edge cases (synthetic WoM) ===")
    wom_df, years, last_hist, horizon = synthetic_wom()
    first_proj = last_hist + 1

    afforest_conv = pam_id("Via Converted")    # Forestry::1  A*D/B  (div-by-zero risk)
    red_defor_fl = pam_id("Forestland to Grassland")  # Forestry::4 .../D/E/F (div-by-zero)
    orchard = pam_id("Vineyards")              # Croplands::4  .../(3*G*1E5)
    till = pam_id("Reduced and Zero Tillage")  # Croplands::0  A*B/1000  (4B)
    generalised = pam_id("Generalised")        # Croplands::11 (has 4F sub-codes)

    # ``run`` mirrors the SOLVER contract: it threads the same protective
    # kwargs the solver passes (floor_year = first projection year, plus the
    # last-historical / horizon years that drive the amber sanity flags). The
    # edge cases therefore exercise exactly what a real run does, not the bare
    # engine, and return the sanity ``flags`` so the harness can assert them.
    def run(specs: list[dict[str, Any]]):
        try:
            out = apply_pams(
                wom_df, specs, years,
                floor_year=first_proj,
                last_historical_year=last_hist,
                horizon_year=horizon,
            )
            return out["scenario_net"], list(out.get("flags", [])), None
        except Exception as exc:  # noqa: BLE001
            return None, [], exc

    def has_flag(flags: list[Any], test_id: str) -> bool:
        return any(getattr(fl, "test_id", None) == test_id for fl in flags)

    # A bad-formula PAM must fail as a clean ValueError (the API maps it to a
    # 422), NEVER as a raw ZeroDivisionError that would 500 the whole run.
    def assert_clean_formula_error(probe: str, exc: Exception | None,
                                   sn: pd.DataFrame | None) -> None:
        if isinstance(exc, ZeroDivisionError):
            F.add(probe, "FAIL",
                  "raw ZeroDivisionError escaped — would 500 the module run.")
        elif isinstance(exc, ValueError):
            F.add(probe, "PASS",
                  f"clean {type(exc).__name__} (API->422): {str(exc)[:80]}")
        elif exc is not None:
            F.add(probe, "CRASH", f"{type(exc).__name__}: {exc}")
        elif sn is None or not all_finite(sn):
            F.add(probe, "ANOMALY", "produced non-finite net, no error raised")
        else:
            F.add(probe, "ANOMALY",
                  "an impossible formula silently produced a number")

    # EC1 — division-by-zero: Forestry "via converted" A*D/B with B=0.
    entry = pam_entry(afforest_conv)
    vars0 = {v["alias"]: 0.0 if v["alias"] == "B" else (v.get("default") or 1.0)
             for v in entry["variables"]}
    sn, flags, exc = run([_spec(afforest_conv, "4A", "WEM", 2030, vars0)])
    assert_clean_formula_error("EC1/div-by-zero(B=0)", exc, sn)

    # EC2 — division-by-zero via orchard denominator G=0.
    entry = pam_entry(orchard)
    varsG = {v["alias"]: 0.0 if v["alias"] == "G" else (v.get("default") or 1.0)
             for v in entry["variables"]}
    sn, flags, exc = run([_spec(orchard, "4B", "WEM", 2030, varsG)])
    assert_clean_formula_error("EC2/div-by-zero(G=0)", exc, sn)

    # EC3 — negative variable → negative mitigation. A mitigation measure that
    # ADDS emissions is a user-input error and must be rejected, not silently
    # booked as a perverse "WEM worse than WoM".
    sn, flags, exc = run([_spec(till, "4B", "WEM", 2030,
                                {"A": -1_000_000.0, "B": 0.5})])
    if isinstance(exc, ValueError):
        F.add("EC3/negative-var", "PASS",
              f"rejected with clear {type(exc).__name__}: {str(exc)[:80]}")
    elif exc is not None:
        F.add("EC3/negative-var", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is not None:
        wem = net_at(sn, horizon, "4B", SCENARIO_WEM)
        wom = net_at(sn, horizon, "4B", SCENARIO_WOM)
        F.add("EC3/negative-var", "ANOMALY",
              f"negative input accepted: WEM net ({wem:,.0f}) vs WoM "
              f"({wom:,.0f}) — a 'mitigation' that ADDS emissions, unguarded.")

    # EC4 — t0 inside the HISTORICAL window (2018). With the solver's
    # floor_year the reported inventory must be preserved AND the user warned.
    sn, flags, exc = run([_spec(till, "4B", "WEM", 2018,
                                {"A": 100_000.0, "B": 1.0})])
    if exc is not None:
        F.add("EC4/t0-in-history", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is not None:
        drift = 0.0
        for y in range(2018, first_proj):  # 2018..2022 are historical
            drift = max(drift,
                        abs(net_at(sn, y, "4B", SCENARIO_WEM)
                            - net_at(sn, y, "4B", SCENARIO_WOM)))
        flagged = has_flag(flags, "PAM-T0-HIST")
        if drift > 1e-6:
            F.add("EC4/t0-in-history", "ANOMALY",
                  f"floor_year failed to protect history: max |WEM-WoM| over "
                  f"2018-{last_hist} = {drift:,.1f} kt.")
        elif not flagged:
            F.add("EC4/t0-in-history", "ANOMALY",
                  "history protected but no PAM-T0-HIST flag warns the user.")
        else:
            F.add("EC4/t0-in-history", "PASS",
                  f"history untouched (drift {drift:.3f} kt) + PAM-T0-HIST flag.")

    # EC5 — t0 beyond the horizon (2060). Inert AND flagged so the UI can warn.
    sn, flags, exc = run([_spec(till, "4B", "WEM", 2060,
                                {"A": 100_000.0, "B": 1.0})])
    if exc is not None:
        F.add("EC5/t0-beyond-horizon", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is not None:
        diff = abs(national_net(sn, horizon, SCENARIO_WEM)
                   - national_net(sn, horizon, SCENARIO_WOM))
        flagged = has_flag(flags, "PAM-T0-HORIZON")
        if diff >= 1e-6:
            F.add("EC5/t0-beyond-horizon", "ANOMALY",
                  f"PAM past the horizon still moved the net by {diff:.3f} kt.")
        elif not flagged:
            F.add("EC5/t0-beyond-horizon", "ANOMALY",
                  "inert PAM but no PAM-T0-HORIZON flag warns the user.")
        else:
            F.add("EC5/t0-beyond-horizon", "PASS",
                  f"inert (delta={diff:.3f} kt) + PAM-T0-HORIZON flag raised.")

    # EC6 — phantom sink: PAM on 4F, a category with NO WoM baseline. Booking
    # against a zero base is the documented 4H behaviour; the fix is to WARN.
    sn, flags, exc = run([_spec(generalised, "4F1", "WEM", 2030,
                                {"R": 50.0, "M": 1.0, "E": 10.0, "F": 2.0})])
    if exc is not None:
        F.add("EC6/phantom-sink(4F)", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is not None:
        wem = net_at(sn, horizon, "4F", SCENARIO_WEM)
        if has_flag(flags, "PAM-PHANTOM-BASE"):
            F.add("EC6/phantom-sink(4F)", "PASS",
                  f"books against zero base (WEM={wem:,.0f}) WITH a "
                  f"PAM-PHANTOM-BASE warning flag.")
        else:
            F.add("EC6/phantom-sink(4F)", "ANOMALY",
                  f"fabricated sink WEM={wem:,.0f} kt with NO warning flag.")

    # EC7 — gross over-mitigation on the +5,000 kt 4B source. The number is
    # left uncapped (transparent), but a source→sink flip must be flagged.
    sn, flags, exc = run([_spec(till, "4B", "WEM", 2030,
                                {"A": 20_000_000.0, "B": 1.0})])
    if exc is not None:
        F.add("EC7/over-mitigation", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is not None:
        wom = net_at(sn, horizon, "4B", SCENARIO_WOM)
        wem = net_at(sn, horizon, "4B", SCENARIO_WEM)
        if wem < -1e-9:  # source swung past zero into a sink
            if has_flag(flags, "PAM-OVERSHOOT"):
                F.add("EC7/over-mitigation", "PASS",
                      f"source->sink (WoM={wom:,.0f}->WEM={wem:,.0f}) flagged "
                      f"PAM-OVERSHOOT.")
            else:
                F.add("EC7/over-mitigation", "ANOMALY",
                      f"source became a {wem:,.0f} kt sink with NO warning flag.")
        else:
            F.add("EC7/over-mitigation", "PASS", f"WEM={wem:,.0f}")

    # EC8 — degenerate logistic t0=t1=t2.
    sn, flags, exc = run([_spec(till, "4B", "WEM", 2030, {"A": 100_000.0, "B": 1.0},
                                time_distribution="variable", t1=2030, t2=2030)])
    if exc is not None:
        F.add("EC8/logistic-degenerate", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is None or not all_finite(sn):
        F.add("EC8/logistic-degenerate", "ANOMALY", "non-finite net from logistic fit")
    else:
        F.add("EC8/logistic-degenerate", "PASS", "finite")

    # EC9 — inverted logistic t1 > t2.
    sn, flags, exc = run([_spec(till, "4B", "WEM", 2025, {"A": 100_000.0, "B": 1.0},
                                time_distribution="variable", t1=2045, t2=2030)])
    if exc is not None:
        F.add("EC9/logistic-inverted", "CRASH", f"{type(exc).__name__}: {exc}")
    elif sn is None or not all_finite(sn):
        F.add("EC9/logistic-inverted", "ANOMALY", "non-finite net")
    else:
        F.add("EC9/logistic-inverted", "PASS", "finite")

    # EC10 — multi-PAM summation on one category (two WEM on 4B).
    p = _spec(till, "4B", "WEM", 2030, {"A": 100_000.0, "B": 1.0})
    sn1, _, _ = run([p])
    sn2, _, _ = run([p, dict(p)])
    if sn1 is not None and sn2 is not None:
        m1 = net_at(sn1, horizon, "4B", SCENARIO_WOM) - net_at(sn1, horizon, "4B", SCENARIO_WEM)
        m2 = net_at(sn2, horizon, "4B", SCENARIO_WOM) - net_at(sn2, horizon, "4B", SCENARIO_WEM)
        ok = abs(m2 - 2 * m1) < 1e-6
        F.add("EC10/multi-PAM-sum", "PASS" if ok else "ANOMALY",
              f"1 PAM mit={m1:,.1f}, 2 identical PAMs mit={m2:,.1f} "
              f"(expect 2x): {'additive' if ok else 'NON-additive'}")

    # EC11 — WEM/WAM additivity (WAM net deeper than WEM by the WAM PAM).
    specs = [_spec(till, "4B", "WEM", 2030, {"A": 100_000.0, "B": 1.0}),
             _spec(till, "4B", "WAM", 2030, {"A": 60_000.0, "B": 1.0})]
    sn, flags, exc = run(specs)
    if sn is not None:
        wom = net_at(sn, horizon, "4B", SCENARIO_WOM)
        wem = net_at(sn, horizon, "4B", SCENARIO_WEM)
        wam = net_at(sn, horizon, "4B", SCENARIO_WAM)
        wem_mit = wom - wem
        wam_mit = wom - wam
        ok = (wam_mit > wem_mit + 1e-6) and (wam <= wem + 1e-6)
        F.add("EC11/WEM-WAM-additive", "PASS" if ok else "ANOMALY",
              f"WoM={wom:,.0f} WEM={wem:,.0f} WAM={wam:,.0f}; "
              f"WEM mit={wem_mit:,.0f}, WAM mit={wam_mit:,.0f} "
              f"({'WAM deeper' if ok else 'WAM NOT deeper'})")

    # EC12 — unknown catalog_id → must be a clear, catchable error.
    _, _, exc = run([_spec("LULUCF::Nope::99", "4A", "WEM", 2030, {})])
    if isinstance(exc, KeyError):
        F.add("EC12/unknown-id", "PASS", f"clear KeyError: {str(exc)[:60]}")
    elif exc is None:
        F.add("EC12/unknown-id", "ANOMALY", "unknown catalog_id silently accepted")
    else:
        F.add("EC12/unknown-id", "ANOMALY", f"wrong error type {type(exc).__name__}")

    # EC13 — category not offered by the entry → clear ValueError.
    _, _, exc = run([_spec(till, "4A", "WEM", 2030, {"A": 100_000.0, "B": 1.0})])
    if isinstance(exc, ValueError):
        F.add("EC13/bad-category", "PASS", f"clear ValueError: {str(exc)[:60]}")
    elif exc is None:
        F.add("EC13/bad-category", "ANOMALY",
              "tillage (4B-only) accepted on 4A without complaint")
    else:
        F.add("EC13/bad-category", "ANOMALY", f"wrong error type {type(exc).__name__}")

    # EC14 — reducing-deforestation-via-FL division-by-zero (D/E/F = 0).
    entry = pam_entry(red_defor_fl)
    varsDEF = {v["alias"]: (0.0 if v["alias"] in ("D", "E", "F")
                            else (v.get("default") or 1.0))
               for v in entry["variables"]}
    _, _, exc = run([_spec(red_defor_fl, "4A", "WEM", 2030, varsDEF)])
    assert_clean_formula_error("EC14/div-by-zero(D=E=F=0)", exc, None)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main() -> int:
    print("LULUCF PAM stress test")
    print("=" * 70)
    run_personas()
    run_edge_cases()

    print("\n" + "=" * 70)
    defects = F.defects
    by_status: dict[str, int] = {}
    for r in F.rows:
        by_status[r["status"]] = by_status.get(r["status"], 0) + 1
    print(f"Probes: {len(F.rows)}  |  " +
          "  ".join(f"{k}={v}" for k, v in sorted(by_status.items())))
    if defects:
        print(f"\n{len(defects)} finding(s) needing attention:")
        for r in defects:
            print(f"  - [{r['status']}] {r['probe']}: {r['detail']}")
    else:
        print("\nClean — no crashes, anomalies, or failures.")
    return len(defects)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        sys.exit(255)
