"use client";

/**
 * Editorial-style flow diagram. Thin strokes, warm palette matching the
 * Claude-inspired landing page. Purely SVG, no deps.
 */
export function FlowDiagram() {
  return (
    <svg
      role="img"
      aria-label="How Mitica modules fit together"
      viewBox="0 0 960 360"
      className="mx-auto w-full max-w-4xl"
    >
      <defs>
        <linearGradient id="gFlow" x1="0" x2="1">
          <stop offset="0%" stopColor="hsl(174 69% 27%)" stopOpacity="0" />
          <stop offset="50%" stopColor="hsl(174 69% 27%)" stopOpacity="0.6" />
          <stop offset="100%" stopColor="hsl(174 69% 27%)" stopOpacity="0" />
        </linearGradient>
        <marker
          id="arrowHead"
          viewBox="0 0 10 10"
          refX="9"
          refY="5"
          markerWidth="5"
          markerHeight="5"
          orient="auto"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="hsl(174 69% 27%)" opacity="0.7" />
        </marker>
      </defs>

      {/* Macro module — top-left */}
      <g>
        <rect
          x="40"
          y="40"
          width="240"
          height="100"
          rx="2"
          fill="white"
          stroke="hsl(220 20% 14%)"
          strokeOpacity="0.15"
        />
        <text
          x="60"
          y="68"
          fontSize="10"
          letterSpacing="2"
          fill="hsl(220 8% 42%)"
        >
          01 / MODULE
        </text>
        <text
          x="60"
          y="94"
          fontSize="20"
          fontFamily="var(--font-serif), Georgia, serif"
          fill="hsl(220 20% 14%)"
          fontWeight="500"
        >
          Macroeconomic
        </text>
        <text x="60" y="116" fontSize="11" fill="hsl(220 8% 42%)">
          GDP · Population · SGDP · Energy demand
        </text>
        <text x="60" y="132" fontSize="10" fontStyle="italic" fill="hsl(220 8% 42%)">
          optional
        </text>
      </g>

      {/* Sectoral module — bottom-left */}
      <g>
        <rect
          x="40"
          y="220"
          width="240"
          height="100"
          rx="2"
          fill="white"
          stroke="hsl(220 20% 14%)"
          strokeOpacity="0.15"
        />
        <text
          x="60"
          y="248"
          fontSize="10"
          letterSpacing="2"
          fill="hsl(220 8% 42%)"
        >
          02 / MODULE
        </text>
        <text
          x="60"
          y="274"
          fontSize="20"
          fontFamily="var(--font-serif), Georgia, serif"
          fill="hsl(220 20% 14%)"
          fontWeight="500"
        >
          Sectoral
        </text>
        <text x="60" y="296" fontSize="11" fill="hsl(220 8% 42%)">
          Energy industries · F-gases · LULUCF · Transport · Waste
        </text>
        <text x="60" y="312" fontSize="10" fontStyle="italic" fill="hsl(220 8% 42%)">
          optional · any combination
        </text>
      </g>

      {/* Integration — right */}
      <g>
        <rect
          x="600"
          y="120"
          width="320"
          height="140"
          rx="2"
          fill="hsl(174 69% 27%)"
          fillOpacity="0.04"
          stroke="hsl(174 69% 27%)"
          strokeOpacity="0.55"
        />
        <text
          x="624"
          y="148"
          fontSize="10"
          letterSpacing="2"
          fill="hsl(174 69% 27%)"
          fillOpacity="0.9"
        >
          03 / CORE
        </text>
        <text
          x="624"
          y="180"
          fontSize="26"
          fontFamily="var(--font-serif), Georgia, serif"
          fill="hsl(220 20% 14%)"
          fontWeight="500"
        >
          Integration
        </text>
        <text
          x="624"
          y="200"
          fontSize="13"
          fontFamily="var(--font-serif), Georgia, serif"
          fontStyle="italic"
          fill="hsl(220 8% 42%)"
        >
          Mitica v1.0
        </text>
        <text x="624" y="225" fontSize="11" fill="hsl(220 20% 14%)" fillOpacity="0.7">
          ANNALIST · PAMs · Scenarios · Targets · CRT
        </text>
        <text
          x="624"
          y="246"
          fontSize="10"
          fontStyle="italic"
          fill="hsl(174 69% 27%)"
          fillOpacity="0.85"
        >
          always active · receives what you bring
        </text>
      </g>

      {/* Arrows */}
      <path
        d="M 280 90 C 420 90, 470 170, 600 170"
        fill="none"
        stroke="url(#gFlow)"
        strokeWidth="1.5"
        markerEnd="url(#arrowHead)"
      />
      <path
        d="M 280 270 C 420 270, 470 210, 600 210"
        fill="none"
        stroke="url(#gFlow)"
        strokeWidth="1.5"
        markerEnd="url(#arrowHead)"
      />

      <text
        x="440"
        y="128"
        fontSize="10"
        fill="hsl(220 8% 42%)"
        fontStyle="italic"
      >
        proxies for ANNALIST
      </text>
      <text
        x="440"
        y="250"
        fontSize="10"
        fill="hsl(220 8% 42%)"
        fontStyle="italic"
      >
        per-sector WOM + PAMs
      </text>
    </svg>
  );
}
