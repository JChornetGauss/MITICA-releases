"""Extract the El Salvador golden fixture from the legacy energy workbook.

Reads ``Modules/Energy/M_Sec_Ener_v_3.xlsx`` (sheet 'WOM_BAU NDC 3.0' + the
WM/WAM 'NDC 3.0' sheets + 'Resumen PAM') and writes
``packages/core/tests/data/energy_es_golden.json`` with:

- ``inputs``  — the EnergySystem-shaped raw history (8 techs × 2014–2023,
  demand chain, consumption projection levels, PAM list) exactly as cached in
  the workbook (full float precision);
- ``golden``  — workbook cell values the faithful port must reproduce
  EXACTLY (demand chain, per-tech capacity/generation for all techs, emissions
  for the base-year-frozen blocks, WM/WAM dispatch);
- ``golden_tolerant`` — workbook totals that include the instance's
  authoring noise (Biomasa/Biogas EF frozen at 2020 instead of the base year —
  `ENERGY_LEGACY_SPEC_2026-06-10.md` §2) — asserted within a small relative
  tolerance to keep the divergence quantified and honest.

Run from `mitica_next/`:
    .venv\\Scripts\\python.exe scripts\\energy_validation\\extract_es_golden.py
"""

from __future__ import annotations

import json
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parents[2]          # mitica_next/
WB_PATH = ROOT.parent / "Modules" / "Energy" / "M_Sec_Ener_v_3.xlsx"
OUT_PATH = ROOT / "packages" / "core" / "tests" / "data" / "energy_es_golden.json"

WOM = "WOM_BAU NDC 3.0"
WM_A, WM_B = "WM NDC 3.0 - A", "WM NDC 3.0 - B"
WAM_A, WAM_B = "WAM NDC 3.0 - A", "WAM NDC 3.0 - B"

# Historical year grid: E..N = 2014..2023; projection S..AI = 2024..2040
HIST_COLS = {2014 + i: 5 + i for i in range(10)}            # E=5 .. N=14
PROJ_COLS = {2024 + i: 19 + i for i in range(17)}           # S=19 .. AI=35

# Technology names as they appear in column A of the scenario sheets. Row
# positions are DISCOVERED by label scanning (they shift between the WOM and
# the WM/WAM-B sheets), never hardcoded.
TECH_NAMES = [
    "Gas Natural",
    "Fosil",
    "Biomasa",
    "Hidroenergia",
    "Geotermia",
    "Eolica",
    "Solar",
    "Biogas",
]
_LABELS = {
    "generation_gwh": "net electricity generation",
    "capacity_mw": "capacity installed",
    "emissions_kt": "emis",
}


def _find_blocks(ws) -> dict[str, dict[str, int]]:
    """Locate each tech block and its labeled rows by scanning column A."""
    colA = {r: ws.cell(row=r, column=1).value for r in range(25, 235)}
    out: dict[str, dict[str, int]] = {}
    for name in TECH_NAMES:
        title = None
        for r, v in colA.items():
            if isinstance(v, str) and v.strip().lower() == name.lower():
                title = r
                break
        if title is None:
            raise SystemExit(f"{ws.title}: tech block {name!r} not found in col A")
        rows: dict[str, int] = {}
        for r in range(title + 1, title + 17):
            v = colA.get(r)
            if not isinstance(v, str):
                continue
            low = v.strip().lower()
            for field, token in _LABELS.items():
                if field not in rows and low.startswith(token):
                    rows[field] = r
        missing = [f for f in _LABELS if f not in rows]
        if missing:
            raise SystemExit(f"{ws.title}: block {name!r} missing rows {missing}")
        out[name] = rows
    return out

# Blocks whose η/EF the workbook freezes at the BASE YEAR (R=2023) — these
# reproduce exactly under the port's freeze-at-base-year rule. The rest
# (Biomasa, Hidro, Solar, Biogas) freeze at K=2020 in this instance (authoring
# noise); zero-EF blocks are exact anyway.
BASE_FROZEN_EXACT = ["Gas Natural", "Fosil"]
ZERO_EF = ["Hidroenergia", "Geotermia", "Eolica", "Solar"]

# Demand chain rows (WOM sheet; identical chain on WM/WAM at rows 240-246)
ROW_TOTAL_GENERATED = 234
ROW_IMPORTED = 235
ROW_EXPORTED = 236
ROW_TOTAL_OFFER = 237
ROW_CONSUMO = 239
ROW_TOTAL_EMIS = 218          # Total Energy Inyected — emissions kt (1A1a+1A1c)

# WM/WAM-B totals row (emissions) per spec §4 verification
ROW_B_TOTAL_EMIS = 224


def _cell(ws, row: int, col: int):
    v = ws.cell(row=row, column=col).value
    return float(v) if isinstance(v, (int, float)) else None


def _series(ws, row: int, cols: dict[int, int]) -> dict[str, float]:
    out = {}
    for year, col in cols.items():
        v = _cell(ws, row, col)
        if v is not None:
            out[str(year)] = v
    return out


def main() -> None:
    if not WB_PATH.exists():
        raise SystemExit(f"workbook not found: {WB_PATH}")
    wb = openpyxl.load_workbook(WB_PATH, data_only=True)
    wom = wb[WOM]
    wom_rows = _find_blocks(wom)

    # ---------------- inputs ----------------
    techs = []
    for name in TECH_NAMES:
        rows = wom_rows[name]
        techs.append(
            {
                "name": name,
                "generation_gwh": _series(wom, rows["generation_gwh"], HIST_COLS),
                "capacity_mw": _series(wom, rows["capacity_mw"], HIST_COLS),
                "emissions_kt": _series(wom, rows["emissions_kt"], HIST_COLS),
                # El Salvador books the Biomasa (Leña) block under 1A1c
                # Autoproductores — spec §3.
                "ipcc_code": "1A1c" if name == "Biomasa" else "1A1a",
            }
        )

    inputs = {
        "country_code": "SLV",
        "technologies": techs,
        "demand_history_gwh": _series(wom, ROW_CONSUMO, HIST_COLS),
        "import_gwh": _series(wom, ROW_IMPORTED, HIST_COLS),
        "export_gwh": _series(wom, ROW_EXPORTED, HIST_COLS),
        # The module takes consumption LEVELS; the workbook computes them from
        # the hardcoded growth vector — we feed the cached levels.
        "demand_projection_gwh": _series(wom, ROW_CONSUMO, PROJ_COLS),
    }

    # PAMs from the Resumen tables would need re-deriving scenario splits; the
    # golden WM/WAM check uses two pinned PAM additions verified in the spec:
    # Solar +152.03 MW (WM, 2024), Hidro +1.0 MW (WM, 2024), plus the WAM
    # additions read from 'Resumen PAM' (WM table C4:N10, WAM-cumulative table
    # C15:N21). We re-derive WAM-only additions as (WAM_cum − WM).
    rp = wb["Resumen PAM"]
    pam_years = [int(rp.cell(row=3, column=c).value) for c in range(3, 15)]
    tech_names_rp = {r: rp.cell(row=r, column=2).value for r in range(4, 11)}
    pams = []
    for r in range(4, 11):
        name = tech_names_rp[r]
        if not isinstance(name, str):
            continue
        for i, y in enumerate(pam_years):
            wm_mw = _cell(rp, r, 3 + i) or 0.0
            wam_mw = _cell(rp, r + 11, 3 + i) or 0.0
            if wm_mw > 0:
                pams.append({"scenario": "WM", "technology": name.strip(),
                             "year": y, "added_mw": wm_mw})
            extra = wam_mw - wm_mw
            if extra > 1e-9:
                pams.append({"scenario": "WAM", "technology": name.strip(),
                             "year": y, "added_mw": extra})
    inputs["pams"] = pams

    # ---------------- golden (exact) ----------------
    golden = {
        "demand": {
            "required_generation": _series(wom, ROW_TOTAL_GENERATED, PROJ_COLS),
            "total_offer": _series(wom, ROW_TOTAL_OFFER, PROJ_COLS),
            "losses_share_frozen": _cell(wom, 238, HIST_COLS[2023]),
        },
        "wom": {},
        "wom_emissions_exact": {},
    }
    for name in TECH_NAMES:
        rows = wom_rows[name]
        golden["wom"][name] = {
            "capacity_mw": _series(wom, rows["capacity_mw"], PROJ_COLS),
            "generation_gwh": _series(wom, rows["generation_gwh"], PROJ_COLS),
        }
    for name in BASE_FROZEN_EXACT + ZERO_EF:
        rows = wom_rows[name]
        golden["wom_emissions_exact"][name] = _series(wom, rows["emissions_kt"], PROJ_COLS)

    # WM/WAM dispatch goldens (exact for base-frozen + zero-EF blocks). Rows
    # re-discovered per sheet (the B sheets shift some blocks).
    wmb = wb[WM_B]
    wamb = wb[WAM_B]
    wma = wb[WM_A]
    wmb_rows = _find_blocks(wmb)
    wamb_rows = _find_blocks(wamb)
    wma_rows = _find_blocks(wma)
    golden["wm"] = {
        "gas_natural_generation": _series(wmb, wmb_rows["Gas Natural"]["generation_gwh"], PROJ_COLS),
        "fosil_generation": _series(wmb, wmb_rows["Fosil"]["generation_gwh"], PROJ_COLS),
        "fosil_emissions": _series(wmb, wmb_rows["Fosil"]["emissions_kt"], PROJ_COLS),
        "solar_capacity_wma": _series(wma, wma_rows["Solar"]["capacity_mw"], PROJ_COLS),
    }
    golden["wam"] = {
        "fosil_generation": _series(wamb, wamb_rows["Fosil"]["generation_gwh"], PROJ_COLS),
        "fosil_emissions": _series(wamb, wamb_rows["Fosil"]["emissions_kt"], PROJ_COLS),
    }

    # ---------------- golden_tolerant (instance authoring noise) ----------------
    golden_tolerant = {
        "wom_total_emissions": _series(wom, ROW_TOTAL_EMIS, PROJ_COLS),
        "wm_total_emissions": _series(wmb, ROW_B_TOTAL_EMIS, PROJ_COLS),
        "wam_total_emissions": _series(wamb, ROW_B_TOTAL_EMIS, PROJ_COLS),
        "note": (
            "Workbook totals include Biomasa/Biogas EF frozen at 2020 (K col) "
            "instead of the base year — the port freezes at base year (spec §2). "
            "Asserted within rel tolerance; the exact per-tech pins above carry "
            "the fidelity guarantee."
        ),
    }

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "source": str(WB_PATH),
        "extracted": "openpyxl data_only=True cached values, full precision",
        "inputs": inputs,
        "golden": golden,
        "golden_tolerant": golden_tolerant,
    }
    OUT_PATH.write_text(json.dumps(payload, indent=1), encoding="utf-8")
    print(f"wrote {OUT_PATH} ({OUT_PATH.stat().st_size} bytes)")
    print(f"techs: {[t['name'] for t in techs]}")
    print(f"pams: {len(pams)}")


if __name__ == "__main__":
    main()
