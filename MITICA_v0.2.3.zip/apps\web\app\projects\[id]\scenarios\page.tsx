"use client";

import { use, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { api } from "@/lib/api";
import type { ScenarioKind } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { Skeleton } from "@/components/ui/skeleton";
import { formatNumber } from "@/lib/utils";

const COLORS = {
  WOM: "#b91c1c",
  WEM: "#059669",
  WAM: "#0f766e",
};

// Deterministic palette for the category breakdown lines.
const CATEGORY_PALETTE = [
  "#147A6E", "#1A2438", "#8a7d5a", "#5b6dcd", "#c97064",
  "#3ea99f", "#b08a3e", "#6e7aa0", "#94634c", "#44756c",
  "#b91c1c", "#0e7490", "#7c5cb8", "#a3733a", "#4a6e44",
];

function colorForCategory(code: string): string {
  let hash = 0;
  for (let i = 0; i < code.length; i++) {
    hash = (hash * 31 + code.charCodeAt(i)) | 0;
  }
  return CATEGORY_PALETTE[Math.abs(hash) % CATEGORY_PALETTE.length];
}

export default function ScenariosPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, isLoading, error } = useQuery({
    queryKey: ["scenarios", id],
    queryFn: () => api.scenarios(id),
    retry: false,
  });

  const [sector, setSector] = useState<string>("all");

  const sectors = useMemo(() => Object.keys(data?.by_sector ?? {}), [data]);

  if (isLoading) return <Skeleton className="h-96" />;
  if (error || !data)
    return (
      <Card>
        <CardContent className="py-8 text-sm text-muted-foreground">
          Run the forecast first to see scenarios.
        </CardContent>
      </Card>
    );

  const activeSeries = sector === "all" ? data.totals : data.by_sector[sector];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Scenarios WOM / WEM / WAM</CardTitle>
          <CardDescription>
            WEM = WOM − ∑(WEM PAMs). WAM = WOM − ∑(WEM+WAM PAMs). Aggregations come from
            <code className="ml-1">mitica_core.scenarios</code>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={sector} onValueChange={setSector}>
            <TabsList>
              <TabsTrigger value="all">All sectors</TabsTrigger>
              {sectors.map((s) => (
                <TabsTrigger key={s} value={s}>
                  {s}
                </TabsTrigger>
              ))}
            </TabsList>
            <TabsContent value={sector} className="mt-4">
              <PlotlyChart
                data={(["WOM", "WEM", "WAM"] as const).map((k) => ({
                  x: data.years,
                  y: activeSeries[k],
                  type: "scatter",
                  mode: "lines+markers",
                  name: k,
                  line: { color: COLORS[k], width: k === "WOM" ? 2 : 2.5 },
                }))}
                layout={{
                  yaxis: { title: { text: "kt CO₂ eq" } },
                  xaxis: { title: { text: "Year" } },
                }}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <CategoryBreakdown
        years={data.years}
        byLevel3={data.by_level3}
        byCategory={data.by_category}
      />
    </div>
  );
}

// ----------------------------------------------------------------------------
// Category breakdown — defaults to the IPCC level-3 aggregation (1A1, 1A2, …),
// the granularity scenario series are reported at (JL decision 2026-06-10).
// A "Full detail" toggle switches back to the raw per-category view.
// ----------------------------------------------------------------------------

const SCENARIOS: ScenarioKind[] = ["WOM", "WEM", "WAM"];

function CategoryBreakdown({
  years,
  byLevel3,
  byCategory,
}: {
  years: number[];
  byLevel3?: Record<ScenarioKind, Record<string, number[]>>;
  byCategory: Record<ScenarioKind, Record<string, number[]>>;
}) {
  const [scenario, setScenario] = useState<ScenarioKind>("WOM");
  const [fullDetail, setFullDetail] = useState(false);
  // by_level3 is absent on artifacts from older API builds — fall back to the
  // raw per-category view in that case.
  const hasLevel3 = Boolean(byLevel3 && Object.keys(byLevel3.WOM ?? {}).length > 0);
  const useLevel3 = hasLevel3 && !fullDetail;
  const source = useLevel3 ? byLevel3! : byCategory;

  const codes = useMemo(
    () => Object.keys(source[scenario] ?? {}).sort(),
    [source, scenario]
  );

  // Keep the table readable: every 5th year plus the last one.
  const tableYears = useMemo(() => {
    const lastIdx = years.length - 1;
    return years
      .map((y, i) => ({ y, i }))
      .filter(({ y, i }) => i === lastIdx || y % 5 === 0);
  }, [years]);

  const traces = codes.map((code) => ({
    x: years,
    y: source[scenario]?.[code] ?? [],
    type: "scatter" as const,
    mode: "lines" as const,
    name: code,
    line: { color: colorForCategory(code), width: 1.8 },
  }));

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-4">
        <div>
          <CardTitle className="text-base">
            Category breakdown — {useLevel3 ? "IPCC level 3" : "full detail"}
          </CardTitle>
          <CardDescription>
            {useLevel3
              ? "Aggregated to IPCC level 3 (1A1, 1A2, 1A3, …) — the granularity scenario series are reported at. Module-internal depth (e.g. 1A1a/1A1c) rolls up here."
              : hasLevel3
              ? "Raw per-category series, at the depth each category was projected."
              : "Raw per-category series (level-3 aggregation not available on this forecast — re-run it to enable)."}
          </CardDescription>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <div className="flex overflow-hidden rounded-sm border border-border text-xs">
            {SCENARIOS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setScenario(s)}
                className={
                  s === scenario
                    ? "bg-primary px-3 py-1 font-medium text-primary-foreground"
                    : "bg-card px-3 py-1 text-muted-foreground hover:bg-muted"
                }
              >
                {s}
              </button>
            ))}
          </div>
          {hasLevel3 && (
            <button
              type="button"
              onClick={() => setFullDetail((v) => !v)}
              className={
                fullDetail
                  ? "rounded-sm border border-primary bg-primary/10 px-3 py-1 text-xs font-medium text-primary"
                  : "rounded-sm border border-border bg-card px-3 py-1 text-xs text-muted-foreground hover:bg-muted"
              }
            >
              Full detail
            </button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <PlotlyChart
          height={360}
          data={traces}
          layout={{
            yaxis: { title: { text: "kt CO₂ eq" } },
            xaxis: { title: { text: "Year" } },
            legend: { orientation: "h", y: -0.25 },
          }}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr>
                <th className="px-2 py-1.5 text-left">Category</th>
                {tableYears.map(({ y }) => (
                  <th key={y} className="px-2 py-1.5 text-right font-mono">
                    {y}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {codes.map((code) => {
                const series = source[scenario]?.[code] ?? [];
                return (
                  <tr key={code} className="border-t border-border">
                    <td className="px-2 py-1.5">
                      <span
                        className="inline-block h-2 w-2 rounded-full align-middle"
                        style={{ backgroundColor: colorForCategory(code) }}
                      />{" "}
                      <span className="font-mono text-xs">{code}</span>
                    </td>
                    {tableYears.map(({ y, i }) => (
                      <td key={y} className="px-2 py-1.5 text-right font-mono text-xs">
                        {series[i] != null ? formatNumber(series[i], 0) : "—"}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <p className="text-[11px] text-muted-foreground">
          Values in kt CO₂-eq, scenario {scenario}. Table shows every 5th year plus the horizon.
        </p>
      </CardContent>
    </Card>
  );
}
