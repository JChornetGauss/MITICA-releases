# MITICA Next — team package builder.
#
# Creates a clean ZIP that anyone can extract on a fresh Windows machine,
# run scripts\install.cmd once, and then double-click the desktop icon to
# launch the app.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File scripts\package_for_team.ps1
# Or via the wrapper:
#   scripts\package_for_team.cmd

$ErrorActionPreference = "Stop"

# Resolve project root from the script location
$root    = Split-Path -Parent $PSScriptRoot
$desktop = [Environment]::GetFolderPath("Desktop")
$today   = Get-Date -Format "yyyy-MM-dd"
$outZip  = Join-Path $desktop "mitica_next_$today.zip"
$stage   = Join-Path $root ".package_staging"

Write-Host ""
Write-Host "============================================================================"
Write-Host " MITICA Next - team package"
Write-Host " Source : $root"
Write-Host " Output : $outZip"
Write-Host "============================================================================"
Write-Host ""

# Clean any leftover staging from a previous failed run
if (Test-Path $stage) {
    Write-Host "[0/4] Cleaning stale staging directory ..."
    Remove-Item $stage -Recurse -Force
}

# --- Step 1: copy source tree, excluding heavy / local-only paths ----------
Write-Host "[1/4] Copying source tree (excluding heavy / local-only paths) ..."

# Folders to exclude (matched by NAME anywhere in the tree)
$excludeDirs = @(
    ".venv", "node_modules", ".next", ".pytest_cache", ".ruff_cache",
    "__pycache__", ".vscode", ".git", ".idea",
    "data", "_trash", ".package_staging"
)
# Files to exclude (matched by extension)
$excludeFiles = @("*.pyc", "*.pyo", "*.log", "*.sqlite", "*.sqlite3", "*.db")

$dest = Join-Path $stage "mitica_next"
New-Item -ItemType Directory -Path $dest -Force | Out-Null

# Use Copy-Item with -Exclude is too coarse (only top-level) — use robocopy
# but invoke it cleanly from PowerShell to avoid cmd parsing pitfalls.
$robocopyArgs = @(
    $root, $dest,
    "/MIR",
    "/XD"
) + $excludeDirs + @("/XF") + $excludeFiles + @(
    "/NFL", "/NDL", "/NJH", "/NJS", "/NP"
)

# Robocopy returns 0-7 for success (non-zero exit code != failure)
& robocopy @robocopyArgs | Out-Null
if ($LASTEXITCODE -ge 8) {
    Write-Host "       robocopy failed with exit code $LASTEXITCODE." -ForegroundColor Red
    if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
    exit 1
}
$LASTEXITCODE = 0   # robocopy success codes (1..7) confuse later checks

# --- Step 2: bundle the Energy industries template ------------------------
Write-Host "[2/4] Bundling Energy industries template into sample_data\ ..."
$energySrc = Join-Path $root "..\Modules\Energy\software (1)\templates.xlsx"
$energyDst = Join-Path $dest "sample_data\energy_template.xlsx"
if (Test-Path $energySrc) {
    Copy-Item -Path $energySrc -Destination $energyDst -Force
    Write-Host "       copied."
} else {
    Write-Host "       not found at the parent Modules folder - skipping (non-fatal)."
}

# --- Step 3: drop INSTALL.md banner --------------------------------------
Write-Host "[3/4] Adding INSTALL.md banner ..."
$installSrc = Join-Path $root "INSTALL.md"
if (Test-Path $installSrc) {
    Copy-Item -Path $installSrc -Destination (Join-Path $dest "INSTALL.md") -Force
}

# --- Step 4: compress to ZIP ---------------------------------------------
Write-Host "[4/4] Compressing to ZIP ..."
if (Test-Path $outZip) {
    Remove-Item $outZip -Force
}
Compress-Archive -Path $dest -DestinationPath $outZip -CompressionLevel Optimal

# --- Cleanup --------------------------------------------------------------
Remove-Item $stage -Recurse -Force

# --- Report ---------------------------------------------------------------
$sizeMb = [math]::Round((Get-Item $outZip).Length / 1MB, 1)

Write-Host ""
Write-Host "============================================================================"
Write-Host " Package ready." -ForegroundColor Green
Write-Host ""
Write-Host "    $outZip"
Write-Host "    Size: $sizeMb MB"
Write-Host ""
Write-Host " Send this single ZIP to your team. They:"
Write-Host "   1. Extract it anywhere (e.g. C:\MITICA\)"
Write-Host "   2. Run scripts\install.cmd once  (auto-installs Python + Node if needed)"
Write-Host "   3. Double-click 'MITICA Next' desktop shortcut to start"
Write-Host ""
Write-Host " See INSTALL.md inside the ZIP for the user-facing guide."
Write-Host "============================================================================"
Write-Host ""
