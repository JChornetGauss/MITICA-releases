"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Target as TargetIcon, AlertTriangle, CheckCircle2 } from "lucide-react";

import { api } from "@/lib/api";
import type { Target, TargetScenarioEntry, TargetScope, TargetType } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatNumber, cn } from "@/lib/utils";

const TYPE_HELP: Record<TargetType, string> = {
  PCT_FROM_BASE_YEAR:
    "Emissions at the target year must be X % below the historical level at the base year.",
  PCT_FROM_WOM:
    "Emissions at the target year must be X % below the baseline (WOM) projection for that year.",
  ABSOLUTE: "Emissions at the target year must stay at or below an absolute cap (kt CO2eq).",
  PEAK_BEFORE_YEAR:
    "Peaking year — emissions must peak no later than the target year (e.g. China).",
  INTENSITY_PER_GDP:
    "GDP intensity — emissions per unit of GDP must fall X% vs the base year (e.g. India); " +
    "needs a GDP proxy or the Macro module.",
};

function targetSummary(t: Target): string {
  switch (t.type) {
    case "PCT_FROM_BASE_YEAR":
      return `−${t.pct}% vs ${t.base_year}`;
    case "PCT_FROM_WOM":
      return `−${t.pct}% vs WOM`;
    case "ABSOLUTE":
      return `≤ ${formatNumber(t.absolute_value ?? 0, 0)} kt`;
    case "PEAK_BEFORE_YEAR":
      return `peak ≤ ${t.target_year}`;
    case "INTENSITY_PER_GDP":
      return `intensity −${t.pct}% vs ${t.base_year}`;
  }
}

/** Intensity thresholds (kt per GDP unit) are usually ≪ 1 — keep significant digits. */
function formatIntensity(v: number): string {
  if (!Number.isFinite(v)) return "—";
  if (v !== 0 && Math.abs(v) < 1) return Number(v.toPrecision(3)).toString();
  return formatNumber(v, 2);
}

const SECTOR_CHOICES: { digit: string; label: string }[] = [
  { digit: "1", label: "1 · Energy" },
  { digit: "2", label: "2 · IPPU" },
  { digit: "3", label: "3 · Agriculture" },
  { digit: "4", label: "4 · LULUCF" },
  { digit: "5", label: "5 · Waste" },
];

export default function TargetsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();

  const { data: targets } = useQuery({
    queryKey: ["targets", id],
    queryFn: () => api.listTargets(id),
  });
  const { data: evaluation, isError: evaluationUnavailable } = useQuery({
    queryKey: ["targets-eval", id],
    queryFn: () => api.evaluateTargets(id),
    retry: false,
  });
  const { data: forecast } = useQuery({
    queryKey: ["forecast", id],
    queryFn: () => api.getForecast(id),
    retry: false,
  });

  const availableCategories = useMemo(
    () => forecast?.categories.map((c) => c.ipcc_code).sort() ?? [],
    [forecast]
  );

  const [form, setForm] = useState({
    name: "NDC 2030",
    type: "PCT_FROM_BASE_YEAR" as TargetType,
    target_year: 2030,
    base_year: 2020,
    pct: 30,
    absolute_value: "",
    scope: "all" as TargetScope,
    scope_filter: "",
    conditional: false,
    notes: "",
  });

  // Field visibility per target type.
  const needsBaseYear = form.type === "PCT_FROM_BASE_YEAR" || form.type === "INTENSITY_PER_GDP";
  const needsPct = form.type !== "ABSOLUTE" && form.type !== "PEAK_BEFORE_YEAR";
  const needsAbsolute = form.type === "ABSOLUTE";

  const create = useMutation({
    mutationFn: () => {
      const target: Target = {
        id: `target_${Date.now()}`,
        name: form.name.trim() || "Unnamed target",
        type: form.type,
        target_year: Number(form.target_year),
        base_year: needsBaseYear ? Number(form.base_year) : null,
        pct: needsPct ? Number(form.pct) : null,
        absolute_value: needsAbsolute ? Number(form.absolute_value) : null,
        scope: form.scope,
        scope_filter: form.scope === "all" ? null : form.scope_filter || null,
        conditional: form.conditional,
        notes: form.notes.trim() || null,
        created_at: new Date().toISOString(),
      };
      return api.createTarget(id, target);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["targets", id] });
      qc.invalidateQueries({ queryKey: ["targets-eval", id] });
    },
  });

  const del = useMutation({
    mutationFn: (tid: string) => api.deleteTarget(id, tid),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["targets", id] });
      qc.invalidateQueries({ queryKey: ["targets-eval", id] });
    },
  });

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TargetIcon className="h-5 w-5 text-primary" /> Define a mitigation target
          </CardTitle>
          <CardDescription>
            e.g. "NDC 2030 = −30 % vs 2020 on all sectors" — shown as a reference line on the
            scenario chart with a ✓ / ✗ badge per scenario.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Name</Label>
            <Input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. NDC 2030"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Type</Label>
              <select
                className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value as TargetType })}
              >
                <option value="PCT_FROM_BASE_YEAR">% reduction vs base year</option>
                <option value="PCT_FROM_WOM">% reduction vs WOM at target year</option>
                <option value="ABSOLUTE">Absolute value (kt CO2eq)</option>
                <option value="PEAK_BEFORE_YEAR">Peaking year</option>
                <option value="INTENSITY_PER_GDP">GDP intensity reduction</option>
              </select>
            </div>
            <div>
              <Label>Target year</Label>
              <Input
                type="number"
                value={form.target_year}
                onChange={(e) => setForm({ ...form, target_year: Number(e.target.value) })}
              />
            </div>
            <p className="col-span-2 text-xs text-muted-foreground">{TYPE_HELP[form.type]}</p>
            {needsBaseYear && (
              <div>
                <Label>Base year</Label>
                <Input
                  type="number"
                  value={form.base_year}
                  onChange={(e) => setForm({ ...form, base_year: Number(e.target.value) })}
                />
              </div>
            )}
            {needsPct && (
              <div>
                <Label>
                  {form.type === "INTENSITY_PER_GDP" ? "% intensity reduction" : "% reduction"}
                </Label>
                <Input
                  type="number"
                  value={form.pct}
                  onChange={(e) => setForm({ ...form, pct: Number(e.target.value) })}
                />
              </div>
            )}
            {needsAbsolute && (
              <div className="col-span-2">
                <Label>Absolute value (kt CO2eq)</Label>
                <Input
                  type="number"
                  value={form.absolute_value}
                  onChange={(e) => setForm({ ...form, absolute_value: e.target.value })}
                />
              </div>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Scope</Label>
              <select
                className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={form.scope}
                onChange={(e) => setForm({ ...form, scope: e.target.value as TargetScope })}
              >
                <option value="all">All sectors</option>
                <option value="sector">Single sector</option>
                <option value="category">Single IPCC category</option>
              </select>
            </div>
            {form.scope === "sector" && (
              <div>
                <Label>Sector</Label>
                <select
                  className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={form.scope_filter}
                  onChange={(e) => setForm({ ...form, scope_filter: e.target.value })}
                >
                  <option value="">— pick one —</option>
                  {SECTOR_CHOICES.map((s) => (
                    <option key={s.digit} value={s.digit}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>
            )}
            {form.scope === "category" && (
              <div>
                <Label>IPCC category</Label>
                <select
                  className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={form.scope_filter}
                  onChange={(e) => setForm({ ...form, scope_filter: e.target.value })}
                >
                  <option value="">— pick one —</option>
                  {availableCategories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
          <div className="flex items-start gap-2 rounded-md border bg-muted/30 p-3">
            <input
              id="target-conditional"
              type="checkbox"
              className="mt-0.5 h-4 w-4 accent-primary"
              checked={form.conditional}
              onChange={(e) => setForm({ ...form, conditional: e.target.checked })}
            />
            <label htmlFor="target-conditional" className="text-sm">
              <span className="font-medium">Conditional target</span>
              <span className="block text-xs text-muted-foreground">
                Depends on international support. Unchecked = unconditional (domestic means).
                Label only — evaluation is identical.
              </span>
            </label>
          </div>
          <div>
            <Label>Notes (optional)</Label>
            <Input
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>
          <Button onClick={() => create.mutate()} disabled={create.isPending}>
            <Plus className="mr-2 h-4 w-4" />
            {create.isPending ? "Saving…" : "Save target"}
          </Button>
          {create.error && (
            <p className="text-xs text-destructive">{(create.error as Error).message}</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Targets & achievement</CardTitle>
          <CardDescription>
            {(targets ?? []).length} targets · evaluated against the current WOM / WEM / WAM
            projections.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Year</TableHead>
                <TableHead className="text-right">Threshold</TableHead>
                <TableHead>WOM</TableHead>
                <TableHead>WEM</TableHead>
                <TableHead>WAM</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {(evaluation?.targets ?? []).map(({ target: t, evaluation: ev, error }) => (
                <TableRow key={t.id}>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      <span className="font-medium">{t.name}</span>
                      <Badge
                        variant={t.conditional ? "warning" : "outline"}
                        className="px-1.5 py-0 text-[9px]"
                        title={
                          t.conditional
                            ? "Conditional — depends on international support"
                            : "Unconditional — stands on domestic means"
                        }
                      >
                        {t.conditional ? "conditional" : "unconditional"}
                      </Badge>
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {targetSummary(t)}
                      {" · "}
                      {t.scope === "all"
                        ? "all sectors"
                        : t.scope === "sector"
                        ? `sector ${t.scope_filter}`
                        : `cat ${t.scope_filter}`}
                    </div>
                  </TableCell>
                  <TableCell>{t.target_year}</TableCell>
                  <TableCell className="text-right font-mono text-xs">
                    {ev && ev.threshold_kt != null ? (
                      <>
                        {ev.unit === "kt_per_gdp_unit"
                          ? formatIntensity(ev.threshold_kt)
                          : formatNumber(ev.threshold_kt, 0)}
                        {ev.unit === "kt_per_gdp_unit" && (
                          <div className="font-sans text-[9px] text-muted-foreground">
                            kt per GDP unit
                          </div>
                        )}
                      </>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  {(["WOM", "WEM", "WAM"] as const).map((k) => (
                    <TableCell key={k}>
                      <AchievementBadge entry={ev?.scenarios[k]} />
                      {ev?.scenarios[k]?.peak_year != null && (
                        <div className="mt-0.5 text-[10px] text-muted-foreground">
                          peak {ev.scenarios[k].peak_year}
                        </div>
                      )}
                    </TableCell>
                  ))}
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => del.mutate(t.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {(!evaluation || evaluation.targets.length === 0) && (
                <TableRow>
                  <TableCell colSpan={7} className="py-6 text-center text-sm text-muted-foreground">
                    {/* FE-12: targets may exist while the evaluation endpoint
                        400s (no forecast yet) — don't claim there are none. */}
                    {evaluationUnavailable && (targets ?? []).length > 0
                      ? "Evaluation unavailable — run a forecast first. Your targets are saved and will be evaluated once WOM/WEM/WAM projections exist."
                      : "No targets defined yet."}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          {evaluation?.targets.some((t) => t.error) && (
            <div className="border-t bg-amber-50 p-3 text-xs text-amber-900">
              Some targets could not be evaluated:
              <ul className="mt-1 list-disc pl-5">
                {evaluation.targets
                  .filter((t) => t.error)
                  .map((t) => (
                    <li key={t.target.id}>
                      <span className="font-medium">{t.target.name}:</span> {t.error}
                    </li>
                  ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AchievementBadge({ entry }: { entry: TargetScenarioEntry | undefined }) {
  if (!entry || entry.achieved == null) return <span className="text-muted-foreground text-xs">—</span>;
  if (entry.achieved) {
    return (
      <Badge variant="success" className="gap-1">
        <CheckCircle2 className="h-3 w-3" />
        met
      </Badge>
    );
  }
  // FE-12: PEAK_BEFORE_YEAR failures carry no gap_pct (there is no absolute
  // threshold) — render a plain "not met" instead of a misleading "+0%".
  return (
    <Badge variant="warning" className="gap-1">
      <AlertTriangle className="h-3 w-3" />
      {entry.gap_pct != null ? `+${entry.gap_pct.toFixed(0)}%` : "not met"}
    </Badge>
  );
}
