"""Convert v1.1s PAMDic.pickle into a versioned JSON catalog shipped with mitica_core.

Run once after extracting PAMDic.pickle:
    python scripts/build_pam_catalog.py

Output: packages/core/src/mitica_core/data/pam_catalog.json
"""

from __future__ import annotations

import json
import pickle
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
# The source pickle extracted from the v1.1s zip
SRC = ROOT.parent / "_extracted" / "catalog_PAMDic.pickle"
# JSON destination, inside mitica_core so it ships as package data
DST = ROOT / "packages" / "core" / "src" / "mitica_core" / "data" / "pam_catalog.json"


SECTOR_LABELS = {
    "1. ENERGY": "Energy",
    "2. IPPU": "IPPU",
    "3. AGRICULTURE": "Agriculture",
    "4. LULUCF": "LULUCF",
    "5. WASTE": "Waste",
}


def clean_formula(f: str) -> str:
    """Normalise a v1.1s formula for safe_eval.

    - Strip leading '='
    - Convert comma decimals ("0,5") to dots ("0.5")
    - Normalise scientific notation "1E6" (already valid Python)
    - Strip whitespace
    """
    s = str(f).strip().lstrip("=").strip()
    # Convert comma decimals: "0,5" → "0.5" (numbers with commas between digits)
    s = re.sub(r"(\d),(\d)", r"\1.\2", s)
    return s


def main() -> None:
    with open(SRC, "rb") as fh:
        data = pickle.load(fh)

    catalog: dict[str, dict] = {}
    total_pams = 0

    for raw_sector, subsectors in data.items():
        label = SECTOR_LABELS.get(raw_sector, raw_sector)
        catalog[label] = {}
        for subsector_name, pams in subsectors.items():
            catalog[label][subsector_name] = []
            for pam_name, pam_data in pams.items():
                df = pam_data["DF"]
                categories = pam_data["Cat"]
                if isinstance(categories, str):
                    categories = [categories]
                # Drop any trailing dots/spaces, keep simple form (e.g. "1A1a")
                categories = [str(c).strip().rstrip(".") for c in categories if c]

                variables = []
                for _, row in df.iterrows():
                    var_name = row.get("Variable")
                    alias = row.get("Value")
                    units = row.get("Units")
                    pred = row.get("Pred") if "Pred" in df.columns else ""
                    if not isinstance(alias, str) or len(alias.strip()) != 1:
                        continue
                    variables.append(
                        {
                            "alias": alias.strip(),
                            "name": str(var_name).strip() if var_name else alias.strip(),
                            "unit": str(units).strip() if units and str(units) != "nan" else None,
                            "default": float(pred) if isinstance(pred, (int, float)) and pred != "" else None,
                        }
                    )

                entry = {
                    "name": str(pam_name).strip(),
                    "categories": categories,
                    "formula": clean_formula(pam_data["Formula"]),
                    "variables": variables,
                }
                catalog[label][subsector_name].append(entry)
                total_pams += 1

    DST.parent.mkdir(parents=True, exist_ok=True)
    DST.write_text(json.dumps(catalog, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[catalog] wrote {DST}")
    print(f"[catalog] sectors={len(catalog)}  pams={total_pams}")
    for sec, subs in catalog.items():
        for sub, items in subs.items():
            print(f"  {sec} / {sub}: {len(items)} PAMs")


if __name__ == "__main__":
    main()
