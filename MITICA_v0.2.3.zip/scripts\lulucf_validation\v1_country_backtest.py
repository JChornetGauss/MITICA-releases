"""
v1_country_backtest.py
======================

5-country backtest of the LULUCF engine v1.0.

Per JL's second-pass review: BUR-based anchors don't count (BURs use
old inventory methodologies and don't follow the CRT format
mandatory under the Paris Agreement ETF). All 5 countries here are
sourced from their **First Biennial Transparency Report (BTR1)**
submitted to UNFCCC in 2024 with CRT-format inventories:

  - **Canada (CAN)**   — boreal disturbance machinery (high
                         inter-annual variance from wildfires)
  - **Finland (FIN)**  — drained organic soils dominant (2022 sink
                         → source flip)
  - **Japan (JPN)**    — temperate mountainous mature forest sink
  - **Australia (AUS)**— mixed climate (tropical north + temperate
                         south); large-area, fire-prone; recent
                         sink shift
  - **Norway (NOR)**   — boreal European; forest-land-dominated sink
                         offset by drained organic soils

All 5 are Annex I parties; all 5 BTR1s use the IPCC 2006 GL Vol 4
categorisation with AR5 GWP-100 (per decisions 18/CMA.1 + 5/CMA.3).
Each fixture's ``reported_history`` carries the REAL per-year LULUCF
net flux extracted from the BTR1 narrative summary, with the source
citation in ``source``.

**Trade-off**: the previous L9 fixture for **Vietnam** exercised the
4→2 parameter collapse (sector-total-only inventory). Annex I BTR1
parties all report per-category, so dropping VNM removes that path
from the **country backtest**. The 4→2 collapse is still tested at
the unit level in
``packages/core/tests/test_modules_lulucf.py::test_historical_reports_only_sector_total_true``
and via the Layer C `T4` / calibration `compute_touchup_offset`
paths — engine coverage is preserved.

GWP set: all values converted to AR4 GWP-100 to match MITICA's
internal convention (decision §2.8 #E of the design doc). Where the
source used AR5 (most BTR1s do, per decision 18/CMA.1 + 5/CMA.3),
the value is left as-is — for CO2 the GWP is 1 in both AR4 and AR5,
which dominates LULUCF totals; the small CH4 / N2O share difference
(<5% of total) is documented as an L8-future refinement.

**Phase L9 v1.0 pass criteria** (honest):

1. Engine runs end-to-end without errors on each country.
2. No pathology: no NaN/Inf, no negative areas.
3. No T1 (area closure) red flags — real integrity check.
4. Touch-up applied + parameter_log populated + touch-up rows
   present in projection-year emissions table.

The touch-up does NOT modify the year-T MODEL output (the inventory
IS the reported value at T by definition). It adds a fading
per-category offset to projection years T+1..H, so the post-touch-up
trajectory at T+1 sits ~82% of the way from the unfitted model to
the reported inventory.

v1.1 status of the two formerly-accepted L9 limitations:
- T2 (mass balance) reds on disturbance-heavy countries are CLOSED:
  the B6→B2 cohort feedback interleaves fire / harvest / pest / wind
  into B2's annual loop and returns the uptake on the disturbed area
  to the carbon books, so the I-3 balance now closes to machine
  precision (CAN / AUS T2 went 17 / 18 → 0).
- "Does the engine PREDICT the inventory WITHOUT touch-up" still
  requires the four-θ Bayesian-ridge fit (next v1.1 task).

Usage::

    python scripts/lulucf_validation/v1_country_backtest.py
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# Allow execution either as a script or as a module under tests.
_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
if str(_CORE_SRC) not in sys.path:
    sys.path.insert(0, str(_CORE_SRC))

from mitica_core.modules.lulucf import (  # noqa: E402
    CRT_SECTOR_TOTAL,
    HistoricalLULUCF,
    LULUCFConfig,
    LULUCFOutputs,
    ProjectedLULUCF,
    aggregate_co2eq,
    get_country_profile,
    load_refdb,
    run_lulucf_module,
)


# ----------------------------------------------------------------------------
# Country fixtures — one block per backtest country
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# COUNTRY FIXTURES — values from real BTR / BUR / NIR submissions.
# Each fixture's ``reported_history`` keys are the inventory years
# whose value we have from a citable source; intermediate years are
# linear-interpolated. Values in **kt CO2-eq** (positive = source,
# negative = sink).
# ----------------------------------------------------------------------------

COUNTRY_FIXTURES: dict[str, dict[str, Any]] = {
    "CAN": {
        "description": "Canada — boreal disturbance machinery (high inter-annual variance)",
        "subsystem_tested": "B6 disturbances + B7 HWP on a fluctuating boreal sink",
        "source": (
            "Environment and Climate Change Canada, National Inventory Report 1990-2022 "
            "(submitted to UNFCCC May 2024); Canada's First Biennial Transparency Report "
            "(BTR1, Dec 2024); Climate Analytics 1.5C Pathway Explorer (canada/lulucf, "
            "Canada NIR-derived). 2005 = +81,000 (net source from disturbance peak); "
            "2020 = -7,600; 2023 = -8,700 (sink reduced by recent wildfire years). "
            "AR5 GWPs in source; CO2 dominates so the AR4/AR5 difference on the total "
            "is negligible (<5%)."
        ),
        "reported_history": {
            2005: +81_000.0,    # NIR-cited disturbance peak
            2020:  -7_600.0,    # Climate Analytics 1.5C pathway (Canada NIR 2022)
            2023:  -8_700.0,    # NIR 2024 (1990-2023) most recent published
        },
        "horizon_year": 2040,
        "anchor_year": 2023,
        "use_sector_total": False,
        "burned_area_kha_anchor": 4_000.0,
        "harvest_volume_m3_anchor": 150_000_000,
    },
    "FIN": {
        "description": "Finland — drained organic soils dominant (2022 sink→source flip)",
        "subsystem_tested": "B5 drained organic soils on cropland-on-peat",
        "source": (
            "Natural Resources Institute Finland (Luke), 'Greenhouse gas inventory 2022 "
            "final results' (Mar 2024); Finland's First Biennial Transparency Report "
            "(BTR1, 19 Dec 2024, "
            "https://unfccc.int/sites/default/files/resource/BTR1_Finland_19dec2024.pdf). "
            "2022 LULUCF = +4,440 (net SOURCE; +28% above 2021); 2021 ≈ +3,470 (derived "
            "from the +28% statement); forest+HWP net sink -8,000 partially offset by "
            "+12,500 from other land use (drained organic soils dominant). AR5 GWPs."
        ),
        "reported_history": {
            2021: +3_470.0,   # derived from Luke's "+28% vs 2021" statement
            2022: +4_440.0,   # final result, Luke 2024
        },
        "horizon_year": 2040,
        "anchor_year": 2022,
        "use_sector_total": False,
        "organic_soil_kha_4B_anchor": 1_800.0,
    },
    "JPN": {
        "description": "Japan — temperate mountainous mature forest sink",
        "subsystem_tested": "B2 cohort growth on a mature sustained sink + B7 HWP",
        "source": (
            "Japan's First Biennial Transparency Report (BTR1), Oct 2024 "
            "(https://unfccc.int/sites/default/files/resource/"
            "Japan's%20First%20Biennial%20Transparency%20Report_250402r.pdf). "
            "FY2022 LULUCF net removals = 53,200 kt CO2eq (CO2 + CH4 + N2O). "
            "AR5 GWP-100 (decision 18/CMA.1 + 5/CMA.3)."
        ),
        "reported_history": {
            2022: -53_200.0,    # Japan BTR1 FY2022 (Oct 2024)
        },
        "horizon_year": 2040,
        "anchor_year": 2022,
        "use_sector_total": False,
        "harvest_volume_m3_anchor": 31_000_000,
    },
    "AUS": {
        "description": "Australia — large-area mixed climate; recent sink shift",
        "subsystem_tested": "B1 area-driven flux + B6 fire on a recovering sink",
        "source": (
            "Australia's First Biennial Transparency Report (BTR1), 19 Dec 2024 "
            "(https://unfccc.int/sites/default/files/resource/01.%20Australia's%20"
            "first%20Biennial%20Transparency%20Report%20(BTR).pdf; "
            "DCCEEW landing page: "
            "https://www.dcceew.gov.au/about/news/australias-first-biennial-transparency-report). "
            "2022 LULUCF net emissions = -15,900 kt CO2eq (124% reduction vs 2005). "
            "Per-category 2023: Forest Land = -66,100 kt CO2eq; Cropland switched "
            "from source to small sink; Grassland near net-zero. AR5 GWP-100."
        ),
        "reported_history": {
            # 2005 was a +64.7 Mt source per Climate Change Authority data
            # (the +124% baseline); 2022 is the BTR1 anchor.
            2005:  +64_700.0,
            2022:  -15_900.0,
        },
        "horizon_year": 2040,
        "anchor_year": 2022,
        "use_sector_total": False,
        "burned_area_kha_anchor": 2_500.0,
    },
    "NOR": {
        "description": "Norway — boreal European sink with peat soil offset",
        "subsystem_tested": "B2 boreal cohort growth + B5 drained organic soils",
        "source": (
            "Norway's First Biennial Transparency Report (BTR1), Dec 2024 "
            "(https://unfccc.int/sites/default/files/resource/Norways%20first%20"
            "Biennial%20Transparency%20Report%20under%20the%20Paris%20Agreement.pdf; "
            "regjeringen.no/en/documents/norways-first-biennial-transparency-report-"
            "under-the-paris-agreement/id3086147/). 2022 LULUCF net removals = "
            "13,700 kt CO2eq (~28% of national non-LULUCF GHG emissions). "
            "Forest Land (4A) alone = -17,900 kt CO2 net sink; other categories "
            "(cropland, grassland, drained organic soils, settlements) sum to +4,200 "
            "kt CO2eq net source. AR5 GWP-100."
        ),
        "reported_history": {
            2022: -13_700.0,    # Norway BTR1 FY2022
        },
        "horizon_year": 2040,
        "anchor_year": 2022,
        "use_sector_total": False,
        "organic_soil_kha_4B_anchor": 350.0,
    },
}


# ----------------------------------------------------------------------------
# Fixture builders
# ----------------------------------------------------------------------------

def _interpolate_reported(
    reported: dict[int, float], years: list[int],
) -> dict[int, tuple[float, str]]:
    """
    Build a {year: (value, provenance)} dict for ``years`` from the
    sparse reported anchors.

    Provenance:
      - "reported"      : year is in ``reported`` directly
      - "interpolated"  : linear interpolation between two reported
                          anchors that bracket the year
      - "extrapolated"  : year sits outside the bracket of reported
                          anchors; held constant at the nearest
                          reported value
    """
    sorted_reps = sorted(reported.items())
    out: dict[int, tuple[float, str]] = {}
    for y in years:
        if y in reported:
            out[y] = (reported[y], "reported")
            continue
        # Find bracket
        before = [(yi, v) for yi, v in sorted_reps if yi < y]
        after = [(yi, v) for yi, v in sorted_reps if yi > y]
        if before and after:
            lo_y, lo_v = before[-1]
            hi_y, hi_v = after[0]
            t = (y - lo_y) / (hi_y - lo_y)
            out[y] = (lo_v + t * (hi_v - lo_v), "interpolated")
        elif before:
            out[y] = (before[-1][1], "extrapolated")
        elif after:
            out[y] = (after[0][1], "extrapolated")
        else:
            out[y] = (0.0, "extrapolated")
    return out


def _build_inventory(
    iso3: str, fixture: dict[str, Any], years: list[int],
) -> pd.DataFrame:
    """
    Build the historical inventory series for the country, interpolated
    from the real ``reported_history`` anchors. Each row carries a
    ``Provenance`` column ('reported'|'interpolated'|'extrapolated') so
    the calling code (and a future UX layer) can mark which years are
    citable.
    """
    series = _interpolate_reported(fixture["reported_history"], years)

    if fixture.get("use_sector_total", False):
        # Vietnam: only national total reported, exercises 4->2 collapse
        rows = [
            {"Year": y, "Category": CRT_SECTOR_TOTAL, "Gas": "CO2eq",
             "Emissions": float(v), "Provenance": prov}
            for y, (v, prov) in series.items()
        ]
    else:
        # Country-specific allocation across CRT categories.
        # These shares are based on the qualitative narrative in the
        # source NIR/BUR for each country (e.g. Finland's flip is
        # driven by drained organic soils on 4B). When BUR5 / BTR1 per-
        # category numbers become available offline, the shares can be
        # tightened — for now they bracket the right physical pattern.
        if iso3 == "FIN":
            # Forest+HWP -8,000 ≈ -1.8× total source; drained organic
            # +12,500 on 4B/4D → split roughly 4A:-1.8, 4B:+2.5, 4D:+0.3
            # Re-normalised to sum to 1 — Luke 2024.
            shares = {"4A": -1.80, "4B": +2.50, "4D": +0.30}
        elif iso3 == "CAN":
            # Canada NIR 2024: net flux dominated by 4A but high
            # variability from fire damage; HWP (4G) acts as a
            # smoothing sink.
            shares = {"4A": +1.15, "4B": +0.05, "4C": +0.10, "4G": -0.30}
        elif iso3 == "JPN":
            # Japan BTR1: Forest Land is the dominant sink; other
            # categories small contributions.
            shares = {"4A": +0.95, "4B": +0.03, "4G": +0.02}
        elif iso3 == "AUS":
            # Australia BTR1: 4A forest is the largest sink, cropland
            # near-neutral, grassland was historically a source now
            # near-neutral.
            shares = {"4A": +1.10, "4B": -0.05, "4C": -0.05}
        elif iso3 == "NOR":
            # Norway BTR1: 4A forest dominant sink at ~131% of total
            # net (since total = -13.7 but 4A = -17.9), offset by
            # +4.2 kt source from croplands + drained organic soils.
            shares = {"4A": +1.31, "4B": -0.20, "4D": -0.11}
        else:
            shares = {"4A": 1.0, "4B": +0.02, "4C": -0.02}

        rows = []
        for y, (v, prov) in series.items():
            for cat, share in shares.items():
                rows.append({
                    "Year": y, "Category": cat, "Gas": "CO2eq",
                    "Emissions": float(v * share),
                    "Provenance": prov,
                })
    return pd.DataFrame(rows)


def _build_land_areas(
    iso3: str, profile: dict[str, Any], years: list[int],
) -> pd.DataFrame:
    """Build a constant-area land table from the refDB country profile."""
    forest = float(profile["forest_area_kha_latest"])
    total = float(profile["total_area_kha"])
    cropland = (total - forest) * 0.45
    grassland = (total - forest) * 0.40
    settlements = (total - forest) * 0.05
    wetlands = (total - forest) * 0.05
    other = total - forest - cropland - grassland - settlements - wetlands

    rows = []
    for y in years:
        for cat, area in (
            ("4A", forest),
            ("4B", cropland),
            ("4C", grassland),
            ("4D", wetlands),
            ("4E", settlements),
            ("4F", other),
        ):
            rows.append({"Year": y, "Category": cat, "Area_kha": area})
    return pd.DataFrame(rows)


def build_country_inputs(iso3: str) -> tuple[
    HistoricalLULUCF, ProjectedLULUCF, LULUCFConfig
]:
    """Assemble the full input bundle for a backtest country."""
    if iso3 not in COUNTRY_FIXTURES:
        raise KeyError(f"No backtest fixture defined for {iso3!r}")
    fixture = COUNTRY_FIXTURES[iso3]
    refdb = load_refdb()
    profile = get_country_profile(refdb, iso3)
    if profile is None:
        raise KeyError(f"No refDB profile for {iso3!r}")

    anchor_year = int(fixture["anchor_year"])
    # Build a historical window spanning the bracketed reported anchors
    reported_years = sorted(fixture["reported_history"].keys())
    # At least 10 years of history; extend back to earliest reported year
    earliest = min(reported_years[0], anchor_year - 9)
    years = list(range(earliest, anchor_year + 1))

    inv = _build_inventory(iso3, fixture, years)
    # Strip 'Provenance' for the engine; keep in the script for output.
    inv_engine = inv[["Year", "Category", "Gas", "Emissions"]]
    land = _build_land_areas(iso3, profile, years)

    hist_kwargs: dict[str, Any] = {
        "inventory_emissions": inv_engine,
        "land_areas": land,
        "country": iso3,
    }
    # Add per-country activity drivers when the fixture defines them
    if "burned_area_kha_anchor" in fixture:
        hist_kwargs["burned_area"] = pd.DataFrame({
            "Year": [anchor_year], "Category": ["4A"],
            "BurnedArea_kha": [fixture["burned_area_kha_anchor"]],
        })
    if "harvest_volume_m3_anchor" in fixture:
        hist_kwargs["harvest_volume"] = pd.DataFrame({
            "Year": [anchor_year],
            "Volume_m3": [float(fixture["harvest_volume_m3_anchor"])],
        })
    if "organic_soil_kha_4B_anchor" in fixture:
        hist_kwargs["organic_soil_area"] = pd.DataFrame({
            "Year": [anchor_year], "Category": ["4B"],
            "DrainedArea_kha": [fixture["organic_soil_kha_4B_anchor"]],
        })
    if "macro_heads_anchor" in fixture:
        hist_kwargs["macro_heads"] = pd.DataFrame({
            "Year": [anchor_year], "Heads": [fixture["macro_heads_anchor"]],
        })

    hist = HistoricalLULUCF(**hist_kwargs)
    proj = ProjectedLULUCF()
    cfg = LULUCFConfig(
        country=iso3,
        region=profile["region"],
        horizon_year=fixture["horizon_year"],
        climate_zone=profile["climate_zone"],
        tier=0,
        profile="L-A",
    )
    return hist, proj, cfg


# ----------------------------------------------------------------------------
# Backtest runner
# ----------------------------------------------------------------------------

def backtest_one_country(iso3: str) -> dict[str, Any]:
    """Run the engine on one country and return a verification report."""
    hist, proj, cfg = build_country_inputs(iso3)
    outputs = run_lulucf_module(hist, proj, cfg)
    fixture = COUNTRY_FIXTURES[iso3]
    return _evaluate_outputs(iso3, fixture, hist, outputs)


def _evaluate_outputs(
    iso3: str,
    fixture: dict[str, Any],
    hist: HistoricalLULUCF,
    outputs: LULUCFOutputs,
) -> dict[str, Any]:
    """Apply the L9 v1.0 pass criteria to a single country's outputs."""
    last_hist = hist.last_historical_year()
    horizon = outputs.emissions["Year"].max() if not outputs.emissions.empty else last_hist

    # Anchor inventory at last historical year (CO2-eq)
    inv = aggregate_co2eq(
        hist.inventory_emissions.rename(columns={"Emissions": "Emissions_kt"})
    )
    inv_anchor_co2eq = float(
        inv[inv["Year"] == last_hist]["Emissions_CO2eq_kt"].sum()
    )

    # Model emission at year T (pre-touchup — the touchup does NOT
    # modify year-T model output; it only adds fading offsets for
    # projection years T+1..H). The "model" total here is the
    # un-anchored projection.
    model_anchor_co2eq = float(
        outputs.emissions[
            (outputs.emissions["Year"] == last_hist)
            & (outputs.emissions["Gas"] != "CO2eq")  # exclude touchup rows
        ]["Emissions_CO2eq_kt"].sum()
    )

    # Post-touch-up model at year T+1
    proj_year = last_hist + 1
    proj_em = outputs.emissions[outputs.emissions["Year"] == proj_year]
    model_proj_with_touchup = float(proj_em["Emissions_CO2eq_kt"].sum())
    # Touch-up component (Gas == 'CO2eq' marker rows from
    # compute_touchup_offset).
    touchup_at_proj = float(
        proj_em[proj_em["Gas"] == "CO2eq"]["Emissions_CO2eq_kt"].sum()
    )

    # Pathology checks
    areas_ok = bool(
        (outputs.areas["Area_kha"] >= -1e-3).all()
        and not outputs.areas["Area_kha"].isna().any()
    )
    pools_finite = bool(
        outputs.carbon_pools["C_MtC"].notna().all()
        and np.isfinite(outputs.carbon_pools["C_MtC"]).all()
    )
    emissions_finite = bool(
        outputs.emissions["Emissions_kt"].notna().all()
        and np.isfinite(outputs.emissions["Emissions_kt"]).all()
    )

    # T1 red flags (area closure) — these are real bugs, not the
    # documented cohort-integration limitation.
    t1_reds = sum(
        1 for f in outputs.validation_report
        if f.severity == "red" and f.test_id == "T1"
    )
    # T2 reds are now closed by the B6→B2 cohort feedback (v1.1). Still
    # tracked separately for transparency; expected to be 0 for all five.
    t2_reds = sum(
        1 for f in outputs.validation_report
        if f.severity == "red" and f.test_id == "T2"
    )

    # Touch-up structural checks
    touchup_in_log = sum(
        1 for p in outputs.parameter_log if p.origin == "touchup"
    )
    has_touchup_rows = (
        not proj_em.empty
        and (proj_em["Gas"] == "CO2eq").any()
    )

    # Did the unfitted engine land within touch-up threshold of the
    # real BTR1 anchor? If yes, no touch-up was needed — a positive
    # outcome (the model matches reality without anchoring).
    denom = max(abs(inv_anchor_co2eq), 1e-6)
    rel_residual = (inv_anchor_co2eq - model_anchor_co2eq) / denom
    threshold = 0.15   # matches LULUCFConfig.touchup_residual_threshold default
    naturally_within_threshold = abs(rel_residual) <= threshold

    # Pass criterion:
    #   1. structural integrity (no NaN/Inf, areas non-negative, T1 == 0)
    #   AND
    #   2a. engine is naturally within ±15% of the real BTR1 anchor
    #       (no touch-up needed — the model captures the country's
    #       LULUCF profile out of the box) -- OR --
    #   2b. touch-up was applied + logged + offset rows emitted (the
    #       calibration step anchored the projection).
    integrity = (
        areas_ok and pools_finite and emissions_finite and t1_reds == 0
    )
    touchup_path = (
        outputs.touchup_applied
        and touchup_in_log > 0
        and has_touchup_rows
    )
    passed = integrity and (naturally_within_threshold or touchup_path)

    return {
        "iso3": iso3,
        "description": fixture["description"],
        "subsystem_tested": fixture["subsystem_tested"],
        "last_hist_year": last_hist,
        "horizon_year": int(horizon),
        "inv_anchor_co2eq_kt": inv_anchor_co2eq,
        "model_anchor_co2eq_kt": model_anchor_co2eq,
        "residual_pre_touchup_kt": inv_anchor_co2eq - model_anchor_co2eq,
        "relative_residual": rel_residual,
        "model_proj_with_touchup_kt": model_proj_with_touchup,
        "touchup_at_proj_kt": touchup_at_proj,
        "touchup_applied": outputs.touchup_applied,
        "touchup_log_entries": touchup_in_log,
        "naturally_within_threshold": naturally_within_threshold,
        "n_red_flags": sum(1 for f in outputs.validation_report if f.severity == "red"),
        "n_amber_flags": sum(1 for f in outputs.validation_report if f.severity == "amber"),
        "t1_red_flags": t1_reds,
        "t2_red_flags": t2_reds,
        "areas_ok": areas_ok,
        "pools_finite": pools_finite,
        "emissions_finite": emissions_finite,
        "passed": passed,
    }


def run_all_backtests() -> list[dict[str, Any]]:
    """Run all 5 backtests and return per-country reports."""
    return [backtest_one_country(iso3) for iso3 in COUNTRY_FIXTURES]


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def _fmt(v: float) -> str:
    return f"{v:>+15,.1f}"


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    print("=" * 78)
    print("LULUCF v1.0 backtest — 5 countries")
    print("=" * 78)

    reports = run_all_backtests()

    print(
        f"\n{'ISO3':<5} {'inv_anchor':>13} {'model[T]':>13} "
        f"{'touchup@T+1':>13} {'T1':>3} {'T2':>3} {'TU.log':>7} {'pass':>5}"
    )
    print("-" * 78)
    for r in reports:
        print(
            f"{r['iso3']:<5} "
            f"{_fmt(r['inv_anchor_co2eq_kt'])} "
            f"{_fmt(r['model_anchor_co2eq_kt'])} "
            f"{_fmt(r['touchup_at_proj_kt'])} "
            f"{r['t1_red_flags']:>3} "
            f"{r['t2_red_flags']:>3} "
            f"{r['touchup_log_entries']:>7} "
            f"{'PASS' if r['passed'] else 'FAIL':>5}"
        )

    print("\nPer-country detail:")
    for r in reports:
        verdict = "PASS" if r["passed"] else "FAIL"
        fixture = COUNTRY_FIXTURES[r["iso3"]]
        print(f"\n  [{verdict}] {r['iso3']} — {r['description']}")
        print(f"    Subsystem: {r['subsystem_tested']}")
        print(
            f"    Anchor year {fixture['anchor_year']} (REAL inventory: "
            f"{r['inv_anchor_co2eq_kt']:+,.1f} kt CO2-eq), horizon "
            f"{r['horizon_year']}"
        )
        print(
            f"    model[T]={r['model_anchor_co2eq_kt']:+,.1f}, "
            f"touchup at T+1: {r['touchup_at_proj_kt']:+,.1f} kt CO2-eq"
        )
        print(
            f"    Reds: T1={r['t1_red_flags']} T2={r['t2_red_flags']} "
            f"(T2 closed by the v1.1 B6→B2 cohort feedback)"
        )
        # Print the source citation so users can audit the anchor
        src = fixture.get("source", "")
        if src:
            print(f"    Source: {src}")
        if not r["passed"]:
            checks = [
                ("areas_ok",            r["areas_ok"]),
                ("pools_finite",        r["pools_finite"]),
                ("emissions_finite",    r["emissions_finite"]),
                ("t1_reds == 0",        r["t1_red_flags"] == 0),
                ("touchup_applied",     r["touchup_applied"]),
                ("touchup_log > 0",     r["touchup_log_entries"] > 0),
            ]
            failing = [name for name, ok in checks if not ok]
            print(f"    Failing checks: {failing}")

    n_pass = sum(1 for r in reports if r["passed"])
    n_total = len(reports)
    print(f"\n  Summary: {n_pass}/{n_total} countries pass.")
    # Pass criterion per design §2.8 #F: >=4 of 5 in v1.0
    overall = n_pass >= 4
    print(f"  Overall ({'>=4 of 5' if overall else '<4 of 5'}): "
          f"{'PASS' if overall else 'FAIL'}")
    return 0 if overall else 1


if __name__ == "__main__":
    sys.exit(main())
