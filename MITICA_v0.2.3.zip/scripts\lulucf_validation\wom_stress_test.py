"""
wom_stress_test.py
==================

Rigorous stress / simulation harness for the LULUCF **WoM baseline solver**
input path (``run_lulucf_module``) — the companion to ``pam_stress_test.py``,
which hardened the PAM engine.

Where the PAM harness hammered the mitigation layer, this one hammers the
*ingestion* layer: the config + historical inventory + land areas a focal
point uploads. Those are the largest surface of arbitrary user data in the
module, and the schema only checks shallow invariants (ISO3, a 'Year' column).
The deeper contracts — horizon after the inventory, a non-empty inventory with
the required columns and finite values, config/data country agreement — are NOT
enforced, so a plausible upload mistake can either 500 the run with an opaque
trace or, worse, silently produce a non-finite / degenerate trajectory.

Two parts:

- **PART A — 5 real-data personas.** Run the five BTR1 backtest countries
  (CAN/FIN/JPN/AUS/NOR) clean through the full solver and assert the baseline
  is well-formed: finite emissions, no red integrity flag, a non-empty
  projection window reaching the horizon. These confirm the harness's notion of
  "correct" matches a real run and that the fix never regresses a clean upload.

- **PART B — hard edge cases** on a real country's inputs, mutated the way a
  user plausibly can from the UI: a horizon at/just before the last inventory
  year, an absurd horizon, an empty inventory, a missing required column, a NaN
  emission, a single inventory year, a config/data country mismatch, a negative
  land area, duplicate inventory rows.

For every probe it captures the REAL outcome, contrasts it against what a
correct solver must do, and tags:

  PASS    — rejected cleanly with an intelligible ``ValueError`` (the API maps
            it to a 422), or — for a legitimate input — ran and produced a
            finite, well-formed projection.
  ANOMALY — ran but produced a wrong/non-finite/degenerate result, OR was
            rejected with an opaque message that does not tell the user what to
            fix.
  CRASH   — raised a non-(ValueError/KeyError) exception that would 500 the run.
  FAIL    — a harness-level assertion failed.

Run::

    python scripts/lulucf_validation/wom_stress_test.py

Exit code is the number of CRASH+ANOMALY+FAIL findings (0 = clean).
"""

from __future__ import annotations

import dataclasses
import sys
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# --- path wiring (mirror v1_country_backtest.py) ---------------------------
_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS_DIR = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from mitica_core.modules.lulucf import (  # noqa: E402
    HistoricalLULUCF,
    LULUCFConfig,
    run_lulucf_module,
)

import v1_country_backtest as bt  # noqa: E402


# ---------------------------------------------------------------------------
# Findings collector (same contract as pam_stress_test.py)
# ---------------------------------------------------------------------------

class Findings:
    def __init__(self) -> None:
        self.rows: list[dict[str, Any]] = []

    def add(self, probe: str, status: str, detail: str) -> None:
        self.rows.append({"probe": probe, "status": status, "detail": detail})
        marker = {
            "PASS": "  ok ",
            "ANOMALY": ">>ANOM",
            "CRASH": ">>CRASH",
            "FAIL": ">>FAIL",
        }.get(status, "  ?  ")
        print(f"[{marker}] {probe}: {detail}")

    @property
    def defects(self) -> list[dict[str, Any]]:
        return [r for r in self.rows if r["status"] != "PASS"]


F = Findings()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def run_solver(hist, proj, cfg):
    """Run the full solver, capturing any exception (mirrors the API path)."""
    try:
        return run_lulucf_module(hist, proj, cfg), None
    except Exception as exc:  # noqa: BLE001
        return None, exc


def emissions_finite(out) -> bool:
    if out is None or out.emissions is None or out.emissions.empty:
        return False
    col = out.emissions["Emissions_CO2eq_kt"]
    return bool(col.notna().all() and np.isfinite(col).all())


def has_projection_window(out, last_hist: int, horizon: int) -> bool:
    """True iff the output reaches the horizon and includes >=1 projection yr."""
    if out is None or out.emissions is None or out.emissions.empty:
        return False
    yrs = out.emissions["Year"]
    return bool(int(yrs.max()) == horizon and (yrs > last_hist).any())


def red_flags(out) -> list[str]:
    if out is None:
        return []
    return [f.test_id for f in out.validation_report if f.severity == "red"]


def assert_rejected(probe: str, exc: Exception | None, out, *, keyword: str) -> None:
    """A malformed upload must be rejected with an intelligible ValueError.

    PASS    — a ``ValueError`` whose message names the problem (``keyword``);
              the API maps this to a clean 422 the user can act on.
    ANOMALY — no error at all (bad input silently accepted / non-finite
              output), OR rejected but with an opaque message (a 422 the user
              cannot decode).
    CRASH   — any non-(ValueError/KeyError): a raw 500.
    """
    if exc is None:
        if out is not None and not emissions_finite(out):
            F.add(probe, "ANOMALY",
                  "produced non-finite emissions, no error raised.")
        else:
            F.add(probe, "ANOMALY",
                  "bad input silently accepted (no error, ran to completion).")
        return
    msg = str(exc)
    if isinstance(exc, ValueError) and keyword.lower() in msg.lower():
        F.add(probe, "PASS", f"clean ValueError (API->422): {msg[:90]}")
    elif isinstance(exc, (ValueError, KeyError)):
        F.add(probe, "ANOMALY",
              f"rejected as {type(exc).__name__} but message is opaque "
              f"(no '{keyword}'): {msg[:90]}")
    else:
        F.add(probe, "CRASH", f"{type(exc).__name__}: {msg[:90]}")


# ---------------------------------------------------------------------------
# PART A — real-data personas (clean baseline runs)
# ---------------------------------------------------------------------------

def run_personas() -> None:
    print("\n=== PART A: real-data personas (5 BTR1 countries, clean) ===")
    for iso3 in ("CAN", "FIN", "JPN", "AUS", "NOR"):
        probe = f"persona/{iso3}"
        try:
            hist, proj, cfg = bt.build_country_inputs(iso3)
            last_hist = hist.last_historical_year()
            horizon = cfg.horizon_year
        except Exception as exc:  # noqa: BLE001
            F.add(probe, "FAIL", f"fixture build raised {type(exc).__name__}: {exc}")
            continue
        out, exc = run_solver(hist, proj, cfg)
        if exc is not None:
            F.add(probe, "CRASH",
                  f"clean upload raised {type(exc).__name__}: {str(exc)[:80]}")
            continue
        if not emissions_finite(out):
            F.add(probe, "ANOMALY", "clean upload produced non-finite emissions")
            continue
        reds = red_flags(out)
        if reds:
            F.add(probe, "ANOMALY",
                  f"clean upload raised RED integrity flag(s): {reds}")
            continue
        if not has_projection_window(out, last_hist, horizon):
            F.add(probe, "ANOMALY",
                  f"projection window malformed (last_hist={last_hist}, "
                  f"horizon={horizon}, max yr "
                  f"{int(out.emissions['Year'].max())})")
            continue
        net = out.net_co2eq_by_year()
        net_h = float(net[net["Year"] == horizon]["Net_LULUCF_CO2eq_kt"].sum())
        F.add(probe, "PASS",
              f"clean run {last_hist}->{horizon}: net@{horizon}={net_h:,.0f} kt, "
              f"no red flags, finite.")


# ---------------------------------------------------------------------------
# PART B — hard edge cases (mutated real-country inputs)
# ---------------------------------------------------------------------------

def _mutate_hist(hist: HistoricalLULUCF, **overrides) -> HistoricalLULUCF:
    return dataclasses.replace(hist, **overrides)


def run_edge_cases() -> None:
    print("\n=== PART B: hard edge cases (mutated CAN inputs) ===")
    base_hist, base_proj, base_cfg = bt.build_country_inputs("CAN")
    last_hist = base_hist.last_historical_year()

    # WC1 — horizon_year == last historical year: nothing to project.
    cfg = dataclasses.replace(base_cfg, horizon_year=last_hist)
    out, exc = run_solver(base_hist, base_proj, cfg)
    assert_rejected("WC1/horizon==last_hist", exc, out, keyword="horizon")

    # WC2 — horizon_year < last historical year: a backwards window.
    cfg = dataclasses.replace(base_cfg, horizon_year=last_hist - 5)
    out, exc = run_solver(base_hist, base_proj, cfg)
    assert_rejected("WC2/horizon<last_hist", exc, out, keyword="horizon")

    # WC3 — absurd horizon (validation-layer probe): a 98,000-year window must
    # be rejected by the config bound, not accepted and then looped over.
    try:
        LULUCFConfig(country="CAN", region=base_cfg.region,
                     horizon_year=99_999,
                     climate_zone=base_cfg.climate_zone)
        cfg_exc: Exception | None = None
    except Exception as exc:  # noqa: BLE001
        cfg_exc = exc
    assert_rejected("WC3/horizon-absurd(config)", cfg_exc, None, keyword="horizon")

    # WC4 — empty inventory: last_historical_year() does int(NaN).
    empty_inv = pd.DataFrame(columns=["Year", "Category", "Gas", "Emissions"])
    try:
        hist = _mutate_hist(base_hist, inventory_emissions=empty_inv)
        out, exc = run_solver(hist, base_proj, base_cfg)
    except Exception as exc2:  # noqa: BLE001 — construction may itself raise
        out, exc = None, exc2
    assert_rejected("WC4/empty-inventory", exc, out, keyword="empty")

    # WC5 — inventory missing the 'Emissions' column.
    inv = base_hist.inventory_emissions.drop(columns=["Emissions"])
    try:
        hist = _mutate_hist(base_hist, inventory_emissions=inv)
        out, exc = run_solver(hist, base_proj, base_cfg)
    except Exception as exc2:  # noqa: BLE001
        out, exc = None, exc2
    assert_rejected("WC5/missing-Emissions-col", exc, out, keyword="Emissions")

    # WC6 — inventory missing the 'Category' column.
    inv = base_hist.inventory_emissions.drop(columns=["Category"])
    try:
        hist = _mutate_hist(base_hist, inventory_emissions=inv)
        out, exc = run_solver(hist, base_proj, base_cfg)
    except Exception as exc2:  # noqa: BLE001
        out, exc = None, exc2
    assert_rejected("WC6/missing-Category-col", exc, out, keyword="Category")

    # WC7 — a NaN emission value: silently propagates into the net flux.
    inv = base_hist.inventory_emissions.copy()
    inv.loc[inv.index[0], "Emissions"] = np.nan
    hist = _mutate_hist(base_hist, inventory_emissions=inv)
    out, exc = run_solver(hist, base_proj, base_cfg)
    assert_rejected("WC7/NaN-emission", exc, out, keyword="finite")

    # WC8 — single inventory year (legitimate low-data upload). The engine
    # should HANDLE it (theta-fit skips <2 yrs), not crash. PASS = finite run.
    one_year = base_hist.inventory_emissions
    one_year = one_year[one_year["Year"] == last_hist].reset_index(drop=True)
    land_one = base_hist.land_areas
    land_one = land_one[land_one["Year"] == last_hist].reset_index(drop=True)
    hist = _mutate_hist(base_hist, inventory_emissions=one_year,
                        land_areas=land_one)
    out, exc = run_solver(hist, base_proj, base_cfg)
    if exc is not None:
        F.add("WC8/single-year", "CRASH" if not isinstance(exc, (ValueError, KeyError))
              else "ANOMALY", f"{type(exc).__name__}: {str(exc)[:80]}")
    elif not emissions_finite(out):
        F.add("WC8/single-year", "ANOMALY", "non-finite emissions on 1-year input")
    else:
        F.add("WC8/single-year", "PASS",
              "single-year upload ran to a finite projection.")

    # WC9 — config.country != historical.country (silent climate-zone mismatch).
    cfg = dataclasses.replace(base_cfg, country="FRA")
    out, exc = run_solver(base_hist, base_proj, cfg)
    assert_rejected("WC9/country-mismatch", exc, out, keyword="country")

    # WC10 — duplicate (Year, Category, Gas) inventory rows. Tolerated, but must
    # not blow up; flagged here if it yields non-finite output.
    inv = pd.concat([base_hist.inventory_emissions,
                     base_hist.inventory_emissions], ignore_index=True)
    hist = _mutate_hist(base_hist, inventory_emissions=inv)
    out, exc = run_solver(hist, base_proj, base_cfg)
    if exc is not None:
        F.add("WC10/duplicate-rows",
              "CRASH" if not isinstance(exc, (ValueError, KeyError)) else "ANOMALY",
              f"{type(exc).__name__}: {str(exc)[:80]}")
    elif not emissions_finite(out):
        F.add("WC10/duplicate-rows", "ANOMALY", "non-finite emissions")
    else:
        F.add("WC10/duplicate-rows", "PASS", "tolerated, finite output.")

    # WC11 — a negative land area. A physical impossibility: the engine must
    # surface it (a red integrity flag), not run it as a real shrinking sink.
    land = base_hist.land_areas.copy()
    mask = land["Category"] == "4A"
    if mask.any():
        land.loc[land.index[mask][0], "Area_kha"] = -1000.0
    hist = _mutate_hist(base_hist, land_areas=land)
    out, exc = run_solver(hist, base_proj, base_cfg)
    if exc is not None and not isinstance(exc, (ValueError, KeyError)):
        F.add("WC11/negative-area", "CRASH", f"{type(exc).__name__}: {str(exc)[:80]}")
    elif isinstance(exc, (ValueError, KeyError)):
        F.add("WC11/negative-area", "PASS",
              f"rejected: {type(exc).__name__}: {str(exc)[:70]}")
    elif out is not None and red_flags(out):
        F.add("WC11/negative-area", "PASS",
              f"negative area surfaced by red flag(s): {red_flags(out)}")
    else:
        F.add("WC11/negative-area", "ANOMALY",
              "negative land area ran with NO red flag and no error.")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main() -> int:
    print("LULUCF WoM solver input stress test")
    print("=" * 70)
    run_personas()
    run_edge_cases()

    print("\n" + "=" * 70)
    defects = F.defects
    by_status: dict[str, int] = {}
    for r in F.rows:
        by_status[r["status"]] = by_status.get(r["status"], 0) + 1
    print(f"Probes: {len(F.rows)}  |  " +
          "  ".join(f"{k}={v}" for k, v in sorted(by_status.items())))
    if defects:
        print(f"\n{len(defects)} finding(s) needing attention:")
        for r in defects:
            print(f"  - [{r['status']}] {r['probe']}: {r['detail']}")
    else:
        print("\nClean - no crashes, anomalies, or failures.")
    return len(defects)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        sys.exit(255)
