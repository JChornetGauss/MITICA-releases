# LULUCF reference database

This directory ships the **reference database** (refDB) the LULUCF
engine consults for IPCC default factors and per-country baseline
data. Each vintage is a single self-contained JSON file:

```
refdb/
  v2026_1.json   ← current vintage (sealed 2026-05-25)
  archive/       ← previous vintages (after refresh)
```

## Why versioned

LULUCF calibration is anchored to TWO vintages: the user's inventory
submission AND the reference database. Inventories get recalculated
(the Finland 2022 LULUCF revision went from 4.4 to 12.0 Mt CO2eq);
default factors get updated (each IPCC refinement). Pinning both lets
us re-run a country's projection a year later with the same engine
and get the same answer — `LULUCFOutputs.refdb_version_used` carries
the vintage tag in every result.

## Structure

Each `vYYYY_N.json` file has:

- `version` — vintage tag (e.g. `"v2026_1"`).
- `sealed_at` — ISO date of sealing.
- `sources` — list of references the file is built from.
- `notes` — operational notes (e.g. "country profiles are
  illustrative for v1.0").
- `ipcc_defaults` — structural constants (Chapman-Richards
  parameters per climate zone, R, CF, k_DOM, SOC_REF, F_LU, EFs
  for B5 sources, HWP half-lives, B6 transfer fractions).
- `countries` — keyed by ISO3. Per-country baseline:
  climate_zone, ecological_zone (FAO GEZ), MAT (°C), total area
  (kha), latest forest area + year, growing stock, wood removals,
  organic soil area, mean burned area.
- `regional_priors` — per region: modal climate zone,
  deforestation rate prior, forest increment prior.

## v1.0 scope

The values shipped here are reasonable order-of-magnitude defaults
derived from public knowledge of FRA 2020 + FAOSTAT, NOT a
programmatic pull. Real production-grade values come from the
refresh script (see below).

15 countries are populated for v2026_1:
- LAC: CRI, BRA, CHL, ARG, MEX
- SSA: KEN, MOZ
- APAC: VNM, IDN, JPN, CHN, IND
- EEU: FIN
- HIC: CAN, USA

These cover the 5-country backtest (Canada / Finland / Chile /
Brazil / Vietnam — Phase L9) plus 10 more priority NDC focal-point
countries. Other countries fall back to regional priors.

## Refreshing

The refresh script lives at:

```
scripts/lulucf_validation/refresh_refdb.py
```

It re-pulls FAO FRA + FAOSTAT and re-seals a new vintage tag.
**In v1.0 this script is a documented stub** — the actual API
clients to FRA / FAOSTAT are L9-future work. To refresh now,
edit the JSON manually and bump the version tag.

## Programmatic access

The Python loader is at:

```
packages/core/src/mitica_core/modules/lulucf/g_LULUCF_RefDB.py
```

Public entry points:

- `load_refdb(version="v2026_1")` → dict
- `get_country_profile(refdb, country)` → dict | None
- `get_ipcc_defaults(refdb)` → dict
- `get_regional_prior(refdb, region)` → dict | None
- `auto_derive_climate_zone(refdb, country)` → climate-zone str | None
- `auto_derive_mat(refdb, country)` → MAT °C | None

The Layer C T3 check (EF within IPCC band) and the calibration step
consult these accessors to find the prior for a given country.
