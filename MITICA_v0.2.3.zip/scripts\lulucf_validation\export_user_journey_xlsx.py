"""
export_user_journey_xlsx.py
===========================

Write an Excel workbook documenting EXACTLY what was fed into the Canada
user-journey simulation, the provenance of every input (what is real BTR/NIR
data vs interpolated vs synthetic), the independent verification of the real
anchors, and the scenario results.

Output: MITICA_LULUCF_user_journey_CAN.xlsx in the MITICA_project root.

Honesty is the point: the workbook makes unmistakably clear that only three
NET-total anchor points are genuine reported figures; the per-category split,
the intermediate years, and the land areas are reconstruction by the MITICA
test fixture, NOT the data submitted to the BTR.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]            # mitica_next
_PROJECT_ROOT = _REPO_ROOT.parent        # MITICA_project
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS_DIR = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

import v1_country_backtest as bt  # noqa: E402
from mitica_core.modules.lulucf import run_lulucf_module  # noqa: E402

ISO = "CAN"
OUT = _PROJECT_ROOT / "MITICA_LULUCF_user_journey_CAN.xlsx"

# Import the exact PAMs and input-stripping used by the simulation so the
# workbook and the sim can never drift.
from user_journey_sim import build_inventory_only_inputs, build_pams  # noqa: E402


def _net_series_with_provenance() -> pd.DataFrame:
    fixture = bt.COUNTRY_FIXTURES[ISO]
    anchor_year = int(fixture["anchor_year"])
    reported_years = sorted(fixture["reported_history"].keys())
    earliest = min(reported_years[0], anchor_year - 9)
    years = list(range(earliest, anchor_year + 1))
    series = bt._interpolate_reported(fixture["reported_history"], years)
    rows = []
    for y in years:
        v, prov = series[y]
        rows.append({
            "Year": y,
            "Net_LULUCF_kt_CO2eq": round(v, 1),
            "Provenance": prov,
            "Real reported figure?": "YES (NIR/BTR1)" if prov == "reported" else "no - linear interpolation",
        })
    return pd.DataFrame(rows)


def _per_category_input() -> pd.DataFrame:
    fixture = bt.COUNTRY_FIXTURES[ISO]
    anchor_year = int(fixture["anchor_year"])
    reported_years = sorted(fixture["reported_history"].keys())
    earliest = min(reported_years[0], anchor_year - 9)
    years = list(range(earliest, anchor_year + 1))
    inv = bt._build_inventory(ISO, fixture, years)
    inv = inv.rename(columns={"Emissions": "Emissions_kt_CO2eq"})
    inv["SYNTHETIC per-category split?"] = "YES - fixture shares, NOT reported CRT"
    return inv[["Year", "Category", "Gas", "Emissions_kt_CO2eq",
                "Provenance", "SYNTHETIC per-category split?"]]


def main() -> int:
    hist, proj, cfg = build_inventory_only_inputs()
    fixture = bt.COUNTRY_FIXTURES[ISO]
    pams = build_pams()

    # --- run WoM + scenarios ---
    wom = run_lulucf_module(hist, proj, cfg)
    wom_net = {int(r["Year"]): float(r["Net_LULUCF_CO2eq_kt"])
               for _, r in wom.net_co2eq_by_year().iterrows()}
    out = run_lulucf_module(hist, proj, cfg, pams=pams)
    sc = out.scenario_net

    def net_by_year(scenario: str) -> dict[int, float]:
        sub = sc[sc["Scenario"] == scenario]
        return {int(y): float(v) for y, v in sub.groupby("Year")["Net_CO2eq_kt"].sum().items()}

    wom_s, wem_s, wam_s = net_by_year("WoM"), net_by_year("WEM"), net_by_year("WAM")

    # ----------------------------------------------------------------- sheets
    # 0. READ ME
    readme = pd.DataFrame({
        "MITICA LULUCF - user-journey workbook (Canada)": [
            "WHAT THIS IS",
            "A record of a simulated focal-point session: a Canadian user who has ONLY a national",
            "LULUCF inventory uses MITICA to build WoM / WEM / WAM scenarios.",
            "",
            "HONESTY / PROVENANCE - read before trusting any number:",
            "1. NET totals: only THREE year-anchors are genuine reported figures (2005, 2020, 2023).",
            "   - 2005 = +81,000 kt (source) and 2023 = -8,700 kt (sink) are CONFIRMED against Canada's",
            "     official NIR (canada.ca: 'net fluxes fluctuated between removals of 8.7 Mt in 2023 and",
            "     emissions of 81 Mt in 2005').",
            "   - 2020 = -7,600 kt is from Climate Analytics' Canada-NIR pathway (secondary source).",
            "   - EVERY OTHER YEAR is LINEAR INTERPOLATION between those anchors - not reported.",
            "2. PER-CATEGORY split (4A/4B/4C/4G): SYNTHETIC. The net is divided with hand-set shares",
            "   from a qualitative NIR narrative, NOT the reported CRT per-category numbers.",
            "3. LAND AREAS: derived from the refDB country profile (FAO/FRA) with fixed fractions - not reported.",
            "",
            "=> These inputs are NOT the data submitted to the BTR. They are a fixture approximation",
            "   anchored on 3 real net-total points. To validate against the real submission, the actual",
            "   Canada BTR1 / NIR CRT tables (per category, per year) must be loaded.",
            "",
            "SHEETS: 1 Inventory(net) | 2 Inventory(per-category) | 3 Land&Config | 4 PAMs |",
            "        5 Results-Scenarios | 6 Results-PAM ranking | 7 Verification-vs-BTR",
        ]
    })

    inv_net = _net_series_with_provenance()
    inv_cat = _per_category_input()

    # 3. Land & config
    land = hist.land_areas.copy()
    land = land[land["Year"] == land["Year"].max()].rename(
        columns={"Area_kha": "Area_kha (constant over years)"})
    land["Provenance"] = "refDB FAO/FRA profile + fixed split (NOT reported)"
    cfg_rows = pd.DataFrame({
        "Setting": ["country", "region", "climate_zone", "profile detected", "tier",
                    "horizon_year", "last inventory year", "optional data provided"],
        "Value": [cfg.country, cfg.region, cfg.climate_zone, "L-A (minimum viable)",
                  cfg.tier, cfg.horizon_year, hist.last_historical_year(),
                  "NONE (inventory only)"],
    })

    # 4. PAMs
    pam_rows = []
    for p in pams:
        pam_rows.append({
            "Scenario": p["scenario"], "Name": p["name"],
            "Catalog id": p["catalog_id"], "CRT category": p["category"],
            "Start year t0": p["t0"], "Time profile": p["time_distribution"],
            "Variables": ", ".join(f"{k}={v}" for k, v in p["variables"].items()),
        })
    pams_df = pd.DataFrame(pam_rows)

    # 5. Scenario results
    rep_net = {r["Year"]: r["Net_LULUCF_kt_CO2eq"] for _, r in inv_net.iterrows()}
    horizon = cfg.horizon_year
    res_rows = []
    for y in sorted(wom_s):
        res_rows.append({
            "Year": y,
            "Reported inventory (net, kt)": rep_net.get(y, ""),
            "WoM (kt)": round(wom_s[y], 0),
            "WEM (kt)": round(wem_s.get(y, wom_s[y]), 0),
            "WAM (kt)": round(wam_s.get(y, wom_s[y]), 0),
            "WEM mitigation (kt/yr)": round(wom_s[y] - wem_s.get(y, wom_s[y]), 0),
            "WAM mitigation (kt/yr)": round(wom_s[y] - wam_s.get(y, wom_s[y]), 0),
        })
    res_df = pd.DataFrame(res_rows)

    # 6. PAM ranking
    rank_df = out.pam_summary.copy()
    rank_df = rank_df.sort_values("Total_Mitigation_CO2eq_kt",
                                  key=lambda s: s.abs(), ascending=False)

    # 7. Verification
    ver_rows = [
        {"Input element": "Net LULUCF 2005",
         "Fed to MITICA": "+81,000 kt (source)",
         "Real reported value": "+81 Mt (canada.ca NIR)",
         "Match?": "YES - confirmed",
         "Source": "canada.ca GHG indicators / NIR 1990-2023"},
        {"Input element": "Net LULUCF 2023",
         "Fed to MITICA": "-8,700 kt (sink)",
         "Real reported value": "-8.7 Mt removals (canada.ca NIR)",
         "Match?": "YES - confirmed",
         "Source": "canada.ca GHG indicators / NIR 1990-2023"},
        {"Input element": "Net LULUCF 2020",
         "Fed to MITICA": "-7,600 kt",
         "Real reported value": "Climate Analytics Canada-NIR pathway",
         "Match?": "secondary source (not primary NIR)",
         "Source": "1p5ndc-pathways.climateanalytics.org/countries/canada"},
        {"Input element": "Net LULUCF 2006-2019, 2021-2022",
         "Fed to MITICA": "linear interpolation",
         "Real reported value": "the NIR has actual annual values",
         "Match?": "NO - interpolated, not reported",
         "Source": "(reconstruction)"},
        {"Input element": "Per-category split 4A/4B/4C/4G",
         "Fed to MITICA": "net x fixed shares (4A 1.15, 4B .05, 4C .10, 4G -.30)",
         "Real reported value": "CRT Table 4 per-category, per-year",
         "Match?": "NO - synthetic fixture split",
         "Source": "(reconstruction)"},
        {"Input element": "Land areas (4A-4F)",
         "Fed to MITICA": "refDB FAO/FRA + fixed fractions",
         "Real reported value": "CRT Table 4.1 land representation",
         "Match?": "NO - refDB-derived",
         "Source": "MITICA refDB"},
    ]
    ver_df = pd.DataFrame(ver_rows)

    # ----------------------------------------------------------------- write
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(OUT, engine="openpyxl") as xl:
        readme.to_excel(xl, sheet_name="0 READ ME", index=False)
        inv_net.to_excel(xl, sheet_name="1 Inventory (net)", index=False)
        inv_cat.to_excel(xl, sheet_name="2 Inventory (per-cat)", index=False)
        # land + config stacked on one sheet
        land.to_excel(xl, sheet_name="3 Land & Config", index=False, startrow=0)
        cfg_rows.to_excel(xl, sheet_name="3 Land & Config", index=False,
                          startrow=len(land) + 3)
        pams_df.to_excel(xl, sheet_name="4 PAMs", index=False)
        res_df.to_excel(xl, sheet_name="5 Results-Scenarios", index=False)
        rank_df.to_excel(xl, sheet_name="6 Results-PAM ranking", index=False)
        ver_df.to_excel(xl, sheet_name="7 Verification vs BTR", index=False)

        # light formatting
        wb = xl.book
        head_fill = PatternFill("solid", fgColor="1F4E78")
        head_font = Font(bold=True, color="FFFFFF")
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.fill = head_fill
                cell.font = head_font
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            for col in ws.columns:
                width = max((len(str(c.value)) for c in col if c.value is not None),
                            default=10)
                ws.column_dimensions[get_column_letter(col[0].column)].width = min(width + 2, 60)

    print(f"Wrote {OUT}")
    print(f"  net anchors confirmed: 2005=+81 Mt, 2023=-8.7 Mt (canada.ca NIR)")
    print(f"  WoM @2023 model = {wom_s.get(2023):,.0f} kt vs reported -8,700 kt")
    print(f"  rows: inv(net)={len(inv_net)} inv(cat)={len(inv_cat)} pams={len(pams_df)} scen={len(res_df)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
