"""Parse CRT Table1.A(a)s1 — 1.A.1.a emissions series for the BTR backtest tier.

Extends the validated PoC (data/btr/_poc_parser_1a1a.py, spot-checked on CHL +
KAZ) to all 8 downloaded CRT zips. For every year-workbook in each zip it
extracts, from sheet ``Table1.A(a)s1``:

- the 1.A.1.a aggregate row (total: consumption TJ, CO2/CH4/N2O kt), and
- the per-fuel drill-down rows (liquid / solid / gaseous / other fossil /
  peat / biomass). Biomass CO2 is a memo item — NOT part of the 1.A.1.a total.

Output: data/btr/{ISO}_1a1a.csv (long format: iso, year, fuel, consumption_tj,
co2_kt, ch4_kt, n2o_kt; fuel='total' = the aggregate row; notation keys
NO/NE/NA/IE/C → empty cell).

Validation (printed, never silently fixed):
1. Per-fuel fossil CO2 sum (liquid+solid+gaseous+other_fossil+peat) must match
   the 1.A.1.a total row within tolerance — mismatches are listed per year.
2. Spot-checks: for 2 records per country the exact cell is re-read from the
   raw sheet with a FRESH openpyxl load at the recorded (row, col) coordinate
   and compared against the CSV value.

Year always comes from the sheet header (top-right cell), never the filename.

Run:  .venv\\Scripts\\python.exe scripts\\energy_validation\\parse_btr_1a1a.py
"""

from __future__ import annotations

import csv
import io
import re
import zipfile
from pathlib import Path

import openpyxl

D = Path(__file__).parent / "data" / "btr"
ISOS = ["BRA", "CHL", "COL", "EGY", "GEO", "IDN", "KAZ", "TUR"]

SHEET = "Table1.A(a)s1"
FUELS = {
    "liquid": "liquid",
    "solid": "solid",
    "gaseous": "gaseous",
    "other fossil": "other_fossil",
    "peat": "peat",
    "biomass": "biomass",
}
# Fossil fuels included in the 1.A.1.a total (biomass = memo item, excluded)
FOSSIL_FUELS = ("liquid", "solid", "gaseous", "other_fossil", "peat")
NOTATION = {"NO", "NE", "NA", "IE", "C"}
# Column offsets from the label column (verified on BRA/CHL/EGY/KAZ raw sheets)
OFF_TJ, OFF_CO2, OFF_CH4, OFF_N2O = 1, 6, 7, 8


def num(v):
    """Numeric cell value, or None for notation keys (NO/NE/NA/IE/C, combos)."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    parts = {p.strip().upper() for p in s.split(",")}
    if parts and parts <= NOTATION:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def parse_sheet(ws):
    """Return (year, records) where records = list of dicts with values AND
    1-based cell coordinates (for the spot-check re-read)."""
    rows = [
        [getattr(c, "value", None) for c in r]
        for r in ws.iter_rows(max_row=80, max_col=14)
    ]
    # --- inventory year from the header (NEVER the filename) ---
    year = None
    for r in rows[:5]:
        for v in r:
            if v is None:
                continue
            if isinstance(v, (int, float)) and 1989 <= int(v) <= 2030:
                year = int(v)
                break
            m = re.search(r"^(?:Inventory\s+)?((?:19|20)\d{2})$", str(v).strip())
            if m and 1989 <= int(m.group(1)) <= 2030:
                year = int(m.group(1))
                break
        if year:
            break
    # --- locate label column via the '1.A.1. Energy industries' anchor ---
    lab_col = anchor_row = None
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            if re.match(r"^\s*1\.A\.1\.?\s+Energy industries", str(v or "")):
                lab_col, anchor_row = j, i
                break
        if lab_col is not None:
            break
    if lab_col is None:
        return year, None
    # --- the 1.A.1.a aggregate row (not the .i/.ii/.iii drill-downs) ---
    a_row = None
    for i in range(anchor_row, min(anchor_row + 30, len(rows))):
        lab = str(rows[i][lab_col] or "")
        if re.match(r"^\s*(1\.A\.1\.a\.?\s|a\.\s+Public electricity)", lab) \
                and ".a.i" not in lab:
            a_row = i
            break
    if a_row is None:
        return year, None

    c = lab_col

    def rec(i, fuel):
        return {
            "fuel": fuel,
            "consumption_tj": num(rows[i][c + OFF_TJ]),
            "co2_kt": num(rows[i][c + OFF_CO2]),
            "ch4_kt": num(rows[i][c + OFF_CH4]),
            "n2o_kt": num(rows[i][c + OFF_N2O]),
            # 1-based coordinates of the CO2 cell, for the spot-check re-read
            "_row": i + 1,
            "_co2_col": c + OFF_CO2 + 1,
        }

    out = [rec(a_row, "total")]
    for i in range(a_row + 1, min(a_row + 8, len(rows))):
        lab = re.sub(r"\s*\(\d+\)\s*$", "", str(rows[i][lab_col] or "").strip()).lower()
        key = next((v for k, v in FUELS.items() if lab.startswith(k)), None)
        if key is None:
            break
        out.append(rec(i, key))
    return year, out


def parse_zip(iso: str, zpath: Path):
    """Return (records, coords, problems).

    records: list of (iso, year, fuel, tj, co2, ch4, n2o)
    coords:  {(year, fuel): (member, row, co2_col, co2_value)}
    problems: list of strings (skipped/unparseable workbooks)
    """
    z = zipfile.ZipFile(zpath)
    records, coords, problems = [], {}, []
    members = sorted(
        n for n in z.namelist()
        if n.lower().endswith(".xlsx") and "~$" not in n
    )
    for name in members:
        wb = openpyxl.load_workbook(
            io.BytesIO(z.read(name)), read_only=True, data_only=True
        )
        if SHEET not in wb.sheetnames:
            problems.append(f"{name}: sheet {SHEET} missing")
            wb.close()
            continue
        year, data = parse_sheet(wb[SHEET])
        wb.close()
        if year is None or data is None:
            problems.append(f"{name}: year={year} data={'ok' if data else 'MISSING'}")
            continue
        for r in data:
            records.append((iso, year, r["fuel"], r["consumption_tj"],
                            r["co2_kt"], r["ch4_kt"], r["n2o_kt"]))
            coords[(year, r["fuel"])] = (name, r["_row"], r["_co2_col"], r["co2_kt"])
    return records, coords, problems


def validate_fuel_sums(iso: str, records) -> list[str]:
    """Check Σ fossil-fuel CO2 == 1.A.1.a total CO2 per year. Return messages."""
    by_year: dict[int, dict[str, float | None]] = {}
    for _iso, year, fuel, _tj, co2, _ch4, _n2o in records:
        by_year.setdefault(year, {})[fuel] = co2
    msgs = []
    for year in sorted(by_year):
        d = by_year[year]
        total = d.get("total")
        if total is None:
            msgs.append(f"{iso} {year}: total CO2 row empty/notation-key")
            continue
        s = sum(d.get(f) or 0.0 for f in FOSSIL_FUELS)
        tol = max(0.5, abs(total) * 1e-3)   # kt
        if abs(s - total) > tol:
            msgs.append(
                f"{iso} {year}: fuel-sum {s:.2f} != total {total:.2f} "
                f"(diff {s - total:+.2f} kt)"
            )
    return msgs


def spot_check(iso: str, zpath: Path, coords) -> list[str]:
    """Re-read 2 CO2 cells per country at recorded coordinates (fresh load)."""
    candidates = [k for k, v in coords.items() if v[3] is not None]
    if not candidates:
        return [f"{iso}: NO non-null CO2 values to spot-check"]
    candidates.sort()
    picks = [candidates[0], candidates[-1]]
    if picks[0] == picks[1]:
        picks = picks[:1]
    z = zipfile.ZipFile(zpath)
    msgs = []
    for key in picks:
        member, row, col, parsed = coords[key]
        wb = openpyxl.load_workbook(
            io.BytesIO(z.read(member)), read_only=True, data_only=True
        )
        ws = wb[SHEET]
        raw = None
        for r in ws.iter_rows(min_row=row, max_row=row, min_col=col, max_col=col):
            raw = r[0].value
        wb.close()
        cell = f"{openpyxl.utils.get_column_letter(col)}{row}"
        ok = (
            raw is not None
            and isinstance(raw, (int, float))
            and abs(float(raw) - parsed) <= max(1e-9, abs(parsed) * 1e-12)
        )
        msgs.append(
            f"{iso} {key[0]} {key[1]:>6s}  sheet!{cell} raw={raw!r}  "
            f"csv={parsed!r}  {'OK' if ok else 'MISMATCH'}"
        )
    return msgs


def main() -> None:
    all_mismatches, all_problems, all_spots = [], [], []
    for iso in ISOS:
        zpath = D / f"{iso}_CRT.zip"
        if not zpath.exists():
            print(f"{iso}: ZIP MISSING — skipped", flush=True)
            all_problems.append(f"{iso}: zip missing")
            continue
        records, coords, problems = parse_zip(iso, zpath)
        all_problems += [f"{iso}: {p}" for p in problems]
        out = D / f"{iso}_1a1a.csv"
        with open(out, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["iso", "year", "fuel", "consumption_tj",
                        "co2_kt", "ch4_kt", "n2o_kt"])
            for r in sorted(records, key=lambda x: (x[1], x[2] != "total", x[2])):
                w.writerow(r)
        years = sorted({r[1] for r in records})
        mism = validate_fuel_sums(iso, records)
        all_mismatches += mism
        spots = spot_check(iso, zpath, coords)
        all_spots += spots
        print(
            f"{iso}: {len(records)} rows, years "
            f"{years[0]}-{years[-1]} (n={len(years)}), "
            f"fuel-sum mismatches: {len(mism)}, problems: {len(problems)} -> {out}",
            flush=True,
        )

    print("\n=== FUEL-SUM MISMATCHES (fossil-fuel sum vs 1.A.1.a total) ===")
    print("\n".join(all_mismatches) if all_mismatches else "none")
    print("\n=== WORKBOOK PROBLEMS ===")
    print("\n".join(all_problems) if all_problems else "none")
    print("\n=== SPOT-CHECKS (fresh re-read of the raw cell) ===")
    print("\n".join(all_spots))


if __name__ == "__main__":
    main()
