"""Re-parse Eurostat env_air_gge keeping the WASTE sector (CRF5*) rows.

The energy harness's tidy_env_air_gge.csv was filtered to the CRF1A1 family, so
it carries no CRF5 codes. This script re-parses the SAME raw bulk-API gz already
on disk (scripts/energy_validation/data/eurostat/raw/env_air_gge.tsv.gz) and
writes a waste-sector tidy file under scripts/waste_validation/data/eurostat/.

DATA-HONESTY: every value is parsed from the raw file with pandas. No
LLM-extracted numbers. If the raw file is missing the script fails loudly.

Kept: src_crf in {CRF5, CRF5A, CRF5B, CRF5C, CRF5D}; airpol GHG (CO2-eq, the
module's output unit) plus CO2/CH4/N2O (for optional gas inspection); unit THS_T
(= kt). Output long: geo, year, airpol, src_crf, value (kt), flag.

Run: .venv\\Scripts\\python.exe scripts\\waste_validation\\parse_waste_eurostat.py
"""
from __future__ import annotations

import gzip
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
RAW = (ROOT / "scripts" / "energy_validation" / "data" / "eurostat" / "raw"
       / "env_air_gge.tsv.gz")
OUT_DIR = Path(__file__).parent / "data" / "eurostat"

KEEP_CRF = ("CRF5", "CRF5A", "CRF5B", "CRF5C", "CRF5D")
KEEP_AIRPOL = ("GHG", "CO2", "CH4", "N2O")


def parse_tsv(path: Path) -> pd.DataFrame:
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        df = pd.read_csv(fh, sep="\t", dtype=str)
    first = df.columns[0]
    dims = first.split("\\")[0].split(",")
    df[dims] = df[first].str.split(",", expand=True)
    df = df.drop(columns=[first])
    year_cols = [c for c in df.columns if c not in dims]
    long = df.melt(id_vars=dims, value_vars=year_cols,
                   var_name="year", value_name="raw_value")
    long["year"] = long["year"].str.strip().astype(int)
    v = long["raw_value"].str.strip()
    long["flag"] = v.str.extract(r"[\d.]\s+([a-z ]+)$", expand=False)
    num = v.str.replace(r"\s*[a-z ]+$", "", regex=True).replace(":", pd.NA)
    long["value"] = pd.to_numeric(num, errors="coerce")
    return long.dropna(subset=["value"]).reset_index(drop=True)


def main() -> None:
    if not RAW.exists():
        raise SystemExit(f"raw gge file missing: {RAW}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    long = parse_tsv(RAW)
    tidy = long[(long["unit"] == "THS_T")
                & long["airpol"].isin(KEEP_AIRPOL)
                & long["src_crf"].isin(KEEP_CRF)].copy()
    keep = ["geo", "year", "airpol", "src_crf", "value", "flag"]
    tidy = tidy[keep].sort_values(["geo", "src_crf", "airpol", "year"])
    out = OUT_DIR / "tidy_waste_gge.csv"
    tidy.to_csv(out, index=False)
    print(f"wrote {out}  ({len(tidy):,} rows)")
    print("geo n:", tidy["geo"].nunique(),
          "| years:", tidy["year"].min(), "-", tidy["year"].max())
    print("src_crf:", sorted(tidy["src_crf"].unique()))
    print("airpol:", sorted(tidy["airpol"].unique()))
    # quick GHG coverage by category
    ghg = tidy[tidy["airpol"] == "GHG"]
    print("\nGHG geo-coverage per category (n geos with >=1 year):")
    for crf in KEEP_CRF:
        print(f"  {crf}: {ghg[ghg.src_crf == crf]['geo'].nunique()}")


if __name__ == "__main__":
    main()
