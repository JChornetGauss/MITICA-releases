"""
calibrate_growth_and_phi_priors.py
==================================

Offline calibration of the **v4** macro priors (see ``docs/MACRO_v4_DESIGN.md``)
from the cached WDI panel in ``scripts/macro_validation/wdi_data/``.

Grouping is by **development phase** (World Bank income class, ``wb_income``),
per Decision D5: LIC→L, LMC→LM, UMC→UM, HIC→H.

Calibrates:

* **B0** — per group, the PIB-per-cápita growth priors:
    - ``g_mean`` (ḡ): median of Δln y (1%-trimmed),
    - ``ar1`` (ρ): pooled within-country AR(1) on Δln y,
    - ``g_min``/``g_max``: p5/p95 of the 5-year rolling mean of Δln y (T3 band).

* **B2-EC norm** — per group, per non-reference sector j ∈ {primary, secondary}
  (tertiary reference): the structural norm η*_j = α_j + β_j·ln y + γ_j·(ln y)²
  + μ_j·ln P, estimated by **pooled OLS with the intercept retained** (the EC
  attractor needs the *level*, so — unlike the v3 compositional calibration —
  we keep α).

* **B2-EC attractor** — per group, the error-correction fit of
    Δη_{j,t} = ρ_η·Δη_{j,t−1} + φ·(η*_{j,t} − η_{j,t−1}) + ε
  pooled across countries and sectors → ``(phi, rho_eta)``; plus a pooled
  central ``phi`` and its cross-group dispersion ``std_phi`` (Decision D4).

Graceful: if the WDI CSVs are absent it prints a skip and exits 0 (the engine
ships with the placeholder priors in ``g_Macro_v4_priors.py``).

Output: ``wdi_data/calibrated_growth_and_phi_priors.json``.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent / "wdi_data"
OUT = DATA_DIR / "calibrated_growth_and_phi_priors.json"

INCOME_MAP = {"LIC": "L", "LMC": "LM", "UMC": "UM", "HIC": "H"}
GROUPS = ("L", "LM", "UM", "H")
NON_REF = ("primary", "secondary")

PHI_FLOOR, PHI_CEIL = 0.02, 0.60   # sane bounds for the attractor strength


def _have_inputs() -> bool:
    needed = ["countries.csv", "GDP_pc.csv", "Pop.csv",
              "SGDP_primary.csv", "SGDP_secondary.csv", "SGDP_tertiary.csv"]
    return all((DATA_DIR / f).exists() for f in needed)


def _load_csv(short: str) -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / f"{short}.csv").rename(columns={"value": short})
    return df[["iso3", "Year", short]]


def _groups() -> pd.DataFrame:
    c = pd.read_csv(DATA_DIR / "countries.csv")[["iso3", "wb_income"]].dropna()
    c["group"] = c["wb_income"].map(INCOME_MAP)
    return c.dropna(subset=["group"])[["iso3", "group"]]


# ---------------------------------------------------------------------------
# B0 — growth priors
# ---------------------------------------------------------------------------

def _pooled_ar1(sub: pd.DataFrame) -> float:
    """Within-country demeaned AR(1) on Δln y. Returns ρ clamped to [0, 0.9]."""
    parts_x, parts_y = [], []
    for _iso, chunk in sub.groupby("iso3"):
        g = chunk.sort_values("Year")["dln_y"].to_numpy(dtype=float)
        g = g[np.isfinite(g)]
        if len(g) < 4:
            continue
        x, y = g[:-1], g[1:]
        x = x - x.mean()
        y = y - y.mean()
        parts_x.append(x)
        parts_y.append(y)
    if not parts_x:
        return 0.30
    X = np.concatenate(parts_x)
    Y = np.concatenate(parts_y)
    denom = float(np.dot(X, X))
    if denom <= 1e-12:
        return 0.30
    rho = float(np.dot(X, Y) / denom)
    return max(0.0, min(0.9, rho))


def calibrate_b0(panel: pd.DataFrame) -> dict:
    out: dict = {}
    for grp in GROUPS:
        sub = panel[panel["group"] == grp].dropna(subset=["dln_y"])
        g = sub["dln_y"].to_numpy(dtype=float)
        g = g[np.isfinite(g)]
        if len(g) < 50:
            out[grp] = None
            continue
        lo, hi = np.percentile(g, 1), np.percentile(g, 99)
        g_trim = g[(g >= lo) & (g <= hi)]
        roll = []
        for _iso, chunk in sub.groupby("iso3"):
            s = chunk.sort_values("Year")["dln_y"].to_numpy(dtype=float)
            s = s[np.isfinite(s)]
            for i in range(len(s) - 4):
                roll.append(float(np.mean(s[i:i + 5])))
        roll_arr = np.array(roll) if roll else g_trim
        out[grp] = {
            "g_mean": float(np.median(g_trim)),
            "ar1": _pooled_ar1(sub),
            "g_min": float(np.percentile(roll_arr, 5)),
            "g_max": float(np.percentile(roll_arr, 95)),
            "n": int(len(g_trim)),
        }
    return out


# ---------------------------------------------------------------------------
# B2-EC norm + attractor
# ---------------------------------------------------------------------------

def _shares_panel() -> pd.DataFrame:
    frames = {s: _load_csv(s) for s in
              ("GDP_pc", "GDP_tot", "Pop",
               "SGDP_primary", "SGDP_secondary", "SGDP_tertiary")}
    panel = frames["GDP_pc"]
    for s in ("GDP_tot", "Pop", "SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        panel = panel.merge(frames[s], on=["iso3", "Year"], how="inner")
    panel = panel.merge(_groups(), on="iso3", how="inner")
    for c in ("GDP_pc", "GDP_tot", "Pop",
              "SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        panel = panel[panel[c].notna() & (panel[c] > 0)]
    panel["sig_p"] = panel["SGDP_primary"] / panel["GDP_tot"]
    panel["sig_s"] = panel["SGDP_secondary"] / panel["GDP_tot"]
    panel["sig_t"] = panel["SGDP_tertiary"] / panel["GDP_tot"]
    ok = ((panel[["sig_p", "sig_s", "sig_t"]] >= 1e-3).all(axis=1)
          & (panel[["sig_p", "sig_s", "sig_t"]] <= 0.999).all(axis=1))
    panel = panel[ok].copy()
    panel["eta_primary"] = np.log(panel["sig_p"] / panel["sig_t"])
    panel["eta_secondary"] = np.log(panel["sig_s"] / panel["sig_t"])
    panel["log_y"] = np.log(panel["GDP_pc"])
    panel["log_P"] = np.log(panel["Pop"])
    return panel.sort_values(["iso3", "Year"])


def _ols(y: np.ndarray, X: np.ndarray) -> np.ndarray | None:
    try:
        return np.linalg.inv(X.T @ X) @ (X.T @ y)
    except np.linalg.LinAlgError:
        return None


def calibrate_norm(panel: pd.DataFrame) -> dict:
    """GLOBAL structural norm η*_j ~ 1 + log_y + log_y² + log_P (pooled OLS on
    the full panel, intercept retained).

    The norm is the cross-country income→structure relationship
    (Chenery-Syrquin), which is a *global* pattern identified by the panel's
    full income range — NOT a within-income-group object (a single income
    slice has no income variation, so a per-group fit is unidentified). It is
    therefore estimated once on all countries. Grouping by development phase
    (Decision D5) applies to B0 growth and to the attractor φ, not to the norm.
    Returns ``{sector: {alpha, beta, gamma, mu}}``.
    """
    out: dict = {}
    for j in NON_REF:
        d = panel.dropna(subset=[f"eta_{j}", "log_y", "log_P"])
        ly = d["log_y"].to_numpy()
        X = np.column_stack([np.ones(len(d)), ly, ly ** 2, d["log_P"].to_numpy()])
        b = _ols(d[f"eta_{j}"].to_numpy(), X)
        out[j] = (None if b is None else
                  {"alpha": float(b[0]), "beta": float(b[1]),
                   "gamma": float(b[2]), "mu": float(b[3])})
    return out


def _norm_eta(coef: dict, log_y: float, log_P: float) -> float:
    return coef["alpha"] + coef["beta"] * log_y + coef["gamma"] * log_y ** 2 + coef["mu"] * log_P


def calibrate_norm_support(panel: pd.DataFrame) -> dict:
    """Income/population support of the panel rows the norm was fit on.

    The norm η*_j is a quadratic in ``log_y``; outside the income range where it
    was identified it extrapolates to a degenerate softmax (all-tertiary as
    ``log_y → −∞``). The income-norm *overlay* (a UI diagnostic) is therefore
    only well-posed inside this support, and the engine suppresses it outside.

    ``log_y`` = ln(GDP per capita, **constant USD** — the WDI panel unit);
    ``log_P`` = ln(population). The robust [p1, p99] range is the guard band;
    the raw [min, max] is recorded for reference.
    """
    ly = panel["log_y"].to_numpy(dtype=float)
    lp = panel["log_P"].to_numpy(dtype=float)
    ly = ly[np.isfinite(ly)]
    lp = lp[np.isfinite(lp)]
    return {
        "log_y": [float(np.percentile(ly, 1)), float(np.percentile(ly, 99))],
        "log_y_minmax": [float(ly.min()), float(ly.max())],
        "log_P": [float(np.percentile(lp, 1)), float(np.percentile(lp, 99))],
        "log_P_minmax": [float(lp.min()), float(lp.max())],
        "n": int(len(ly)),
        "units": "log_y = ln(GDP per capita, constant USD); log_P = ln(population)",
    }


def calibrate_phi(panel: pd.DataFrame, norm: dict) -> dict:
    """Pooled EC fit  Δη = ρ_η·Δη_lag + φ·(η* − η_lag),  per group (both sectors)."""
    out: dict = {}
    phis = []
    for grp in GROUPS:
        sub = panel[panel["group"] == grp]
        gx, gy = [], []
        for j in NON_REF:
            coef = norm.get(j)  # global norm (same for every group)
            if coef is None:
                continue
            for _iso, chunk in sub.groupby("iso3"):
                c = chunk.sort_values("Year")
                eta = c[f"eta_{j}"].to_numpy(dtype=float)
                ly = c["log_y"].to_numpy(dtype=float)
                lp = c["log_P"].to_numpy(dtype=float)
                if len(eta) < 4:
                    continue
                for t in range(2, len(eta)):
                    d_eta = eta[t] - eta[t - 1]
                    d_eta_lag = eta[t - 1] - eta[t - 2]
                    gap = _norm_eta(coef, ly[t], lp[t]) - eta[t - 1]
                    gx.append([d_eta_lag, gap])
                    gy.append(d_eta)
        if len(gy) < 100:
            out[grp] = None
            continue
        X = np.asarray(gx)
        b = _ols(np.asarray(gy), X)
        if b is None:
            out[grp] = None
            continue
        rho_eta = float(max(0.0, min(0.95, b[0])))
        phi = float(max(PHI_FLOOR, min(PHI_CEIL, b[1])))
        out[grp] = {"phi": phi, "rho_eta": rho_eta, "n": int(len(gy))}
        phis.append(phi)
    pooled_phi = float(np.median(phis)) if phis else 0.15
    std_phi = float(np.std(phis, ddof=1)) if len(phis) > 1 else 0.12
    out["_pooled"] = {"phi": pooled_phi, "std_phi": max(0.05, std_phi)}
    return out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    if not _have_inputs():
        print("[calibrate_growth_and_phi_priors] WDI CSVs missing; skipping "
              "(engine uses placeholder v4 priors).")
        return 0

    # B0 panel
    countries = _groups()
    gpanel = _load_csv("GDP_pc").merge(countries, on="iso3", how="inner")
    gpanel = gpanel[gpanel["GDP_pc"] > 0].sort_values(["iso3", "Year"])
    gpanel["log_y"] = np.log(gpanel["GDP_pc"])
    gpanel["dln_y"] = gpanel.groupby("iso3")["log_y"].diff()
    b0 = calibrate_b0(gpanel)

    # Norm + φ panel
    spanel = _shares_panel()
    norm = calibrate_norm(spanel)
    norm["_support"] = calibrate_norm_support(spanel)
    phi = calibrate_phi(spanel, norm)

    payload = {
        "_meta": {
            "source": "WDI cached panel; grouping by WB income class (wb_income)",
            "groups": list(GROUPS),
            "spec_b0": "Δln y = (1−ρ)ḡ + ρ Δln y_{t−1} (+ optional I/Y, WAP)",
            "spec_norm": "η*_j = α + β log y + γ (log y)² + μ log P (pooled OLS, intercept kept); "
                         "log y = ln(GDP per capita, constant USD). b2ec_norm._support = the "
                         "income/pop range the norm is identified on; the UI overlay is suppressed outside it.",
            "spec_phi": "Δη = ρ_η Δη_lag + φ (η* − η_lag), pooled EC fit per group",
            "phi_bounds": [PHI_FLOOR, PHI_CEIL],
        },
        "b0": b0,
        "b2ec_norm": norm,
        "b2ec_phi": phi,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=2))

    # ---- human-readable sanity report ----
    print("=== v4 growth + φ calibration (by development phase) ===\n")
    print(f"{'grp':<4} {'g_mean':>8} {'ar1':>6} {'g_min':>8} {'g_max':>8} {'n':>7}")
    for g in GROUPS:
        d = b0[g]
        if d:
            print(f"{g:<4} {d['g_mean']:>8.4f} {d['ar1']:>6.2f} "
                  f"{d['g_min']:>8.4f} {d['g_max']:>8.4f} {d['n']:>7}")
    print("\nGlobal norm η* (β<0 expected for primary; secondary hump γ<0):")
    for j in NON_REF:
        c = norm.get(j)
        if c:
            print(f"  {j:<10} α={c['alpha']:+.3f} β={c['beta']:+.3f} "
                  f"γ={c['gamma']:+.4f} μ={c['mu']:+.3f}")
    sup = norm.get("_support")
    if sup:
        ly_lo, ly_hi = sup["log_y"]
        print(f"  support log_y∈[{ly_lo:.2f}, {ly_hi:.2f}]  "
              f"(GDP/cap ≈ ${math.exp(ly_lo):,.0f}–${math.exp(ly_hi):,.0f}, constant USD), "
              f"log_P∈[{sup['log_P'][0]:.2f}, {sup['log_P'][1]:.2f}], n={sup['n']}")
    print("\nAttractor φ (per group, pooled both sectors):")
    for g in GROUPS:
        d = phi.get(g)
        if d:
            print(f"  {g:<3} φ={d['phi']:.3f} ρ_η={d['rho_eta']:.3f} n={d['n']}")
    print(f"  pooled φ={phi['_pooled']['phi']:.3f} std_phi={phi['_pooled']['std_phi']:.3f}")
    print(f"\nWrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
