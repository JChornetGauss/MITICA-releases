"""
calibrate_transport_priors.py — offline calibration of the SI-006 transport priors.

Fits the income→transport-CO2-per-cápita relationship on the REAL panel
(`scripts/transport_validation/data/panel.csv`: OWID/Climate Watch transport CO2
+ WDI GDP-pc/pop) and writes `transport_priors.json` for the engine to load.

Embeds the calibration rules VALIDATED by the backtest (see TRANSPORT_BACKTEST.md):

  1. income curvature γ·exp(α·exp(β·gdppc))·exp(−δ·t) — a GLOBAL/cross-country
     object (never re-fit per country),
  2. fit per development-phase group (WB income class), and
  3. shrink each group's curvature to the global one by group population
     (wg = n_group/(n_group+K_GROUP)) so thin/narrow groups lean global.

Graceful: if the panel CSV is absent it prints a skip and exits 0 (the engine
ships documented fallback params in priors.py).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

HERE = Path(__file__).resolve().parent
PANEL = HERE / "data" / "panel.csv"
OUT = HERE / "data" / "transport_priors.json"

GROUPS = ("L", "LM", "UM", "H")
K_GROUP = 12.0   # group-curvature shrinkage to global (validated)


def income_group(gdp_pc: float) -> str:
    """World Bank FY24 income-class thresholds (current USD)."""
    if gdp_pc < 1086:
        return "L"
    if gdp_pc < 4256:
        return "LM"
    if gdp_pc < 13206:
        return "UM"
    return "H"


def _logco2pc(X, lng, a, b, d):
    gdppc_k, year = X
    return lng + a * np.exp(b * gdppc_k) - d * (year - 2000.0)


def _is_degenerate(c: dict) -> bool:
    """A fit that hit the bounds (|a| or |lng| ≈ 20) or lost its income response
    (|b|<0.02) is unidentified — the group's income range is too narrow/saturated
    to pin a curvature. Such groups defer to the global curve (rule 3)."""
    return abs(c["a"]) > 15.0 or abs(c["lng"]) > 15.0 or abs(c["b"]) < 0.02


def fit(df: pd.DataFrame) -> dict | None:
    g = df["gdp_pc"].to_numpy() / 1000.0
    yr = df["Year"].to_numpy().astype(float)
    y = np.log((df["transport_co2e_t"] / df["pop"]).to_numpy())
    p0 = [float(np.median(y)), -3.0, -0.25, 0.005]
    bounds = ([-20, -50, -5, -0.1], [20, -1e-6, -1e-6, 0.1])
    try:
        popt, _ = curve_fit(_logco2pc, (g, yr), y, p0=p0, bounds=bounds, maxfev=20000)
    except Exception:
        return None
    c = dict(lng=float(popt[0]), a=float(popt[1]), b=float(popt[2]), d=float(popt[3]))
    return None if _is_degenerate(c) else c


def main() -> int:
    if not PANEL.exists():
        print(f"[calibrate_transport_priors] panel missing ({PANEL}); skipping "
              "(engine uses documented fallback priors).")
        return 0

    panel = pd.read_csv(PANEL)
    panel = panel[(panel.transport_co2e_t > 0) & (panel.gdp_pc > 0) & (panel["pop"] > 0)].copy()
    # group by calibration-period mean income (use full series here for the prior)
    grp = panel.groupby("iso3")["gdp_pc"].mean().map(income_group)
    panel["grp"] = panel.iso3.map(grp)

    glob = fit(panel)
    groups = {}
    for gname in GROUPS:
        gdf = panel[panel.grp == gname]
        ncty = gdf.iso3.nunique()
        gcur = fit(gdf) if ncty >= 5 else None
        wg = ncty / (ncty + K_GROUP)
        groups[gname] = {"curve": gcur, "n_countries": int(ncty), "shrink_to_global_w": float(wg)}

    payload = {
        "_meta": {
            "source": "OWID/Climate Watch transport CO2 + WDI (panel.csv)",
            "spec": "log co2pc = lng + a·exp(b·gdppc_k) − d·(year−2000); gdppc_k=GDP_pc/1000",
            "rules": "income curvature is global; per-group curvature shrunk to global by group population (K_GROUP)",
            "K_GROUP": K_GROUP,
            "n_countries": int(panel.iso3.nunique()),
            "years": [int(panel.Year.min()), int(panel.Year.max())],
        },
        "global": glob,
        "groups": groups,
    }
    OUT.write_text(json.dumps(payload, indent=2))

    print("=== transport income→CO2pc calibration (real panel) ===")
    print(f"countries {panel.iso3.nunique()} | years {panel.Year.min()}-{panel.Year.max()}\n")
    print(f"global: lng={glob['lng']:.3f} a={glob['a']:.3f} b={glob['b']:.4f} d={glob['d']:.4f}")
    for gname in GROUPS:
        gg = groups[gname]
        c = gg["curve"]
        if c:
            print(f"  {gname:<3} n={gg['n_countries']:<3} wg={gg['shrink_to_global_w']:.2f} "
                  f"| lng={c['lng']:.3f} a={c['a']:.3f} b={c['b']:.4f} d={c['d']:.4f}")
        else:
            print(f"  {gname:<3} n={gg['n_countries']:<3} → global fallback")
    print(f"\nWrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
