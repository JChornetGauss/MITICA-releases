@echo off
rem MITICA Next — are API and Web running? What versions?
pushd "%~dp0.."
node scripts\status.mjs
popd
