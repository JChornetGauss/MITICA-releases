"""
can_crf_real.py
===============

Read Canada's REAL LULUCF inventory from the submitted CRF Reporter Excel files
(2023 submission, AR4 GWP) and assemble the per-category, per-year series in the
shape MITICA's engine expects: ['Year', 'Category', 'Gas', 'Emissions'] with
Category in 4A..4G and Emissions in kt CO2-eq (AR4: CH4=25, N2O=298).

This is the ACTUAL data submitted to the UNFCCC — no interpolation, no synthetic
category split. CRF Table 4 (LULUCF), one file per inventory year 1990-2021.

The CRF "Net CO2 emissions/removals" sign convention: negative = removal (sink),
positive = emission (source). MITICA uses the same convention.

Notation keys NO / NE / IE / NA / IE (not occurring / not estimated / included
elsewhere / not applicable) are non-numeric and counted as 0.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd

_HERE = Path(__file__).resolve()
_CRF_DIR = _HERE.parent / "_can_crf"

# AR4 GWP-100 (MITICA vocabulary)
GWP = {"CO2": 1.0, "CH4": 25.0, "N2O": 298.0}

# CRF Table 4 top-level label -> MITICA CRT category
_LABEL_TO_CAT = {
    "A. Forest land": "4A",
    "B. Cropland": "4B",
    "C. Grassland": "4C",
    "D. Wetlands": "4D",
    "E. Settlements": "4E",
    "F. Other land": "4F",
    "G. Harvested wood": "4G",
}


def _num(v) -> float:
    """CRF cell -> float; notation keys (NO/NE/IE/NA) -> 0.0."""
    if isinstance(v, (int, float)):
        return float(v)
    return 0.0


def _year_from_name(fname: str) -> int:
    # CAN_2023_<YEAR>_<date>_<time>.xlsx
    return int(fname.split("_")[2])


def _read_one(path: str) -> list[dict]:
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb["Table4"]
    year = _year_from_name(os.path.basename(path))
    rows: list[dict] = []
    total_co2 = total_ch4 = total_n2o = None
    for row in ws.iter_rows(values_only=True):
        label = row[0]
        if not isinstance(label, str):
            continue
        lab = label.strip()
        # Per-category top-level rows: col1=Net CO2, col2=CH4, col3=N2O
        cat = None
        for prefix, c in _LABEL_TO_CAT.items():
            if lab.startswith(prefix):
                cat = c
                break
        if cat is not None:
            co2 = _num(row[1]); ch4 = _num(row[2]); n2o = _num(row[3])
            for gas, val in (("CO2", co2), ("CH4", ch4), ("N2O", n2o)):
                rows.append({"Year": year, "Category": cat, "Gas": gas,
                             "Emissions_native_kt": val})
        elif lab.startswith("4. Total LULUCF"):
            total_co2 = _num(row[1]); total_ch4 = _num(row[2]); total_n2o = _num(row[3])
    # stash the reported total as a check row (Category '4_total_reported')
    if total_co2 is not None:
        for gas, val in (("CO2", total_co2), ("CH4", total_ch4), ("N2O", total_n2o)):
            rows.append({"Year": year, "Category": "4_total_reported", "Gas": gas,
                         "Emissions_native_kt": val})
    return rows


def load_raw() -> pd.DataFrame:
    """Long per-gas native-unit table across all years (incl. the reported total)."""
    files = sorted(f for f in os.listdir(_CRF_DIR) if f.endswith(".xlsx"))
    allrows: list[dict] = []
    for f in files:
        allrows.extend(_read_one(str(_CRF_DIR / f)))
    return pd.DataFrame(allrows)


def build_real_can_inventory() -> pd.DataFrame:
    """Engine-ready inventory: ['Year','Category','Gas','Emissions'] in kt CO2-eq
    per CRT category (4A..4G), AR4 GWP. Excludes the reported-total check rows."""
    raw = load_raw()
    cat = raw[raw["Category"].isin(list(_LABEL_TO_CAT.values()))].copy()
    cat["co2eq"] = cat.apply(
        lambda r: r["Emissions_native_kt"] * GWP[r["Gas"]], axis=1)
    inv = (cat.groupby(["Year", "Category"], as_index=False)["co2eq"].sum()
              .rename(columns={"co2eq": "Emissions"}))
    inv["Gas"] = "CO2eq"
    return inv[["Year", "Category", "Gas", "Emissions"]].sort_values(["Year", "Category"])


def reported_total_co2eq() -> pd.Series:
    """The CRF-reported '4. Total LULUCF' net CO2-eq per year (AR4) — the ground
    truth to validate our per-category aggregation against."""
    raw = load_raw()
    tot = raw[raw["Category"] == "4_total_reported"].copy()
    tot["co2eq"] = tot.apply(lambda r: r["Emissions_native_kt"] * GWP[r["Gas"]], axis=1)
    return tot.groupby("Year")["co2eq"].sum()


def main() -> int:
    inv = build_real_can_inventory()
    net = inv.groupby("Year")["Emissions"].sum()
    rep = reported_total_co2eq()
    lines = ["Canada REAL LULUCF inventory (2023 CRF submission, AR4 GWP)",
             "Year |  net CO2eq (our sum) |  CRF reported total |  diff",
             "-" * 60]
    for y in sorted(net.index):
        d = net[y] - rep.get(y, float("nan"))
        lines.append(f"{y} | {net[y]:>18,.0f} | {rep.get(y, float('nan')):>18,.0f} | {d:>8,.1f}")
    # category structure at a couple of years
    for yr in (2005, 2021):
        lines.append(f"\nper-category @ {yr} (kt CO2eq):")
        sub = inv[inv["Year"] == yr]
        for _, r in sub.iterrows():
            lines.append(f"   {r['Category']}: {r['Emissions']:>14,.0f}")
    sys.stdout.buffer.write(("\n".join(lines)).encode("ascii", "replace"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
