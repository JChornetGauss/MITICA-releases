# mitica-core

Pure Python library with the scientific core of MITICA Next.

No UI, no network, no side effects. Consumable from:
- The FastAPI backend (`mitica_api`)
- A Jupyter notebook
- A CLI job
- Any other Python process

## Modules

- `contracts` — Pydantic models (`Inventory`, `Forecast`, `PAM`, `Scenario`, `ModuleOutput`)
- `ipcc` — IPCC category codes, AR5 GWPs, disaggregation resolver
- `proxies` — Proxy loading & linear-regression extension
- `extractors` — Excel template, CSV, IPCC CRT JSON parsers
- `modifiers` — `avoid_negative`, `avoid_outcomes`, `smooth`, `lineal_fix`, `adjust_value` (v1.1s bugs fixed)
- `safe_eval` — AST-whitelist formula evaluator (replaces `eval()` in PAMs)
- `pams` — PAM domain, `R·M·(REF-MEF)`, time distribution (constant/logistic)
- `scenarios` — WEM/WAM aggregation
- `macc` — MACC curve data
- `crt` — IPCC CRT JSON reader & CRT-style Excel generator
- `forecast` — Orchestrator (`forecast_all(...)`)
- `models/` — `annalist`, `linreg`, `sarimax`, `ag`, `thymeboost`
