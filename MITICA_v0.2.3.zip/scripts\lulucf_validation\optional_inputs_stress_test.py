"""
optional_inputs_stress_test.py
==============================

Rigorous stress / simulation harness for the LULUCF module's **optional input
frames / activity drivers** (the L-B .. L-E ladder, LULUCF_v1_DESIGN.md §6.3).

The PAM, WoM, and API harnesses hardened the mandatory path (inventory + land),
the engine entry, and the HTTP boundary. But a focal point climbing the data
ladder spends most of their effort uploading the OPTIONAL frames — forest
cohorts, HWP pools, burned area, drained organic soil, harvest, livestock
heads, fertiliser/lime/urea, rice, pest/wind-throw, and the projected
afforestation / deforestation / harvest / national-EF paths. Each is consumed
deep in the physical cascade (B1..B7, Layer C), often via a bare ``row["Col"]``
guarded only for ``is None`` / ``empty`` — NOT for the columns it reads.

Contract asserted for every malformed optional frame:

  * a missing required column must raise a CLEAR ``ValueError`` that names the
    frame and the column (→ API 422), never a bare ``KeyError`` (opaque 422),
    an ``AttributeError``/``TypeError`` (HTTP 500), or a silent run;
  * a non-finite (NaN/Inf) value in a required numeric column must either be
    rejected cleanly OR be absorbed into a still-FINITE projection — never
    silently corrupt the reported emissions with NaN/Inf;
  * a valid frame must run to a finite projection (sanity — confirms the frame
    is actually consumed and the harness is exercising a live path).

Tags: PASS / ANOMALY (opaque rejection, silent accept, or silent corruption) /
CRASH (a non-ValueError/KeyError exception) / FAIL (harness bug).

Run::

    python scripts/lulucf_validation/optional_inputs_stress_test.py

Exit code is the number of CRASH+ANOMALY+FAIL findings (0 = clean).
"""

from __future__ import annotations

import dataclasses
import sys
import traceback
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd

# --- path wiring (mirror wom_stress_test.py) -------------------------------
_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS_DIR = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from mitica_core.modules.lulucf import (  # noqa: E402
    HWP_PRODUCT_CLASSES,
    HistoricalLULUCF,
    LULUCFConfig,
    ProjectedLULUCF,
    run_lulucf_module,
)

import v1_country_backtest as bt  # noqa: E402


# ---------------------------------------------------------------------------
# Findings collector
# ---------------------------------------------------------------------------

class Findings:
    def __init__(self) -> None:
        self.rows: list[dict[str, Any]] = []

    def add(self, probe: str, status: str, detail: str) -> None:
        self.rows.append({"probe": probe, "status": status, "detail": detail})
        marker = {
            "PASS": "  ok ",
            "ANOMALY": ">>ANOM",
            "CRASH": ">>CRASH",
            "FAIL": ">>FAIL",
        }.get(status, "  ?  ")
        print(f"[{marker}] {probe}: {detail[:108]}")

    @property
    def defects(self) -> list[dict[str, Any]]:
        return [r for r in self.rows if r["status"] != "PASS"]


F = Findings()


# ---------------------------------------------------------------------------
# Solver driver + assertions
# ---------------------------------------------------------------------------

def run_solver(hist: HistoricalLULUCF, proj: ProjectedLULUCF,
               cfg: LULUCFConfig) -> tuple[Any, BaseException | None]:
    """Run the full module; return (outputs, exception) — never raises."""
    try:
        out = run_lulucf_module(hist, proj, cfg)
        return out, None
    except BaseException as exc:  # noqa: BLE001 — we classify it ourselves
        return None, exc


def emissions_finite(out: Any) -> bool:
    if out is None:
        return False
    em = out.emissions
    if em is None or len(em) == 0:
        return False
    cols = [c for c in ("Emissions_kt", "Emissions_CO2eq_kt") if c in em.columns]
    if not cols:
        return False
    for c in cols:
        vals = pd.to_numeric(em[c], errors="coerce").to_numpy("float64")
        if not np.isfinite(vals).all():
            return False
    return True


def _is_clear_value_error(exc: BaseException | None, keyword: str) -> bool:
    return isinstance(exc, ValueError) and keyword.lower() in str(exc).lower()


def assert_rejected(probe: str, exc: BaseException | None, out: Any,
                    *, keyword: str) -> None:
    """A structurally malformed frame (missing required column) must be a CLEAR
    ValueError naming the frame/column. Bare KeyError = opaque (→422 but
    unhelpful); other exceptions = CRASH (→500); silent accept = ANOMALY."""
    if isinstance(exc, ValueError):
        if keyword.lower() in str(exc).lower():
            F.add(probe, "PASS", f"clean ValueError: {str(exc).splitlines()[0]}")
        else:
            F.add(probe, "ANOMALY",
                  f"ValueError but message lacks {keyword!r}: {str(exc)[:70]}")
    elif isinstance(exc, KeyError):
        F.add(probe, "ANOMALY",
              f"opaque KeyError {exc} (->422 but no guidance); want a ValueError.")
    elif exc is not None:
        F.add(probe, "CRASH",
              f"{type(exc).__name__}: {str(exc)[:70]} (would 500).")
    else:
        fin = "finite" if emissions_finite(out) else "NON-FINITE"
        F.add(probe, "ANOMALY",
              f"malformed frame silently accepted (emissions {fin}).")


def assert_no_silent_corruption(probe: str, exc: BaseException | None,
                                out: Any) -> None:
    """A non-finite value in a numeric column must be rejected cleanly OR
    absorbed into a finite run — never silently corrupt the emissions, never
    crash with a non-ValueError."""
    if isinstance(exc, ValueError):
        F.add(probe, "PASS", f"clean ValueError: {str(exc).splitlines()[0][:70]}")
    elif isinstance(exc, KeyError):
        F.add(probe, "ANOMALY", f"opaque KeyError {exc}; want a ValueError.")
    elif exc is not None:
        F.add(probe, "CRASH", f"{type(exc).__name__}: {str(exc)[:70]} (would 500).")
    elif emissions_finite(out):
        F.add(probe, "PASS", "NaN absorbed; projection stayed finite.")
    else:
        F.add(probe, "ANOMALY", "NaN silently corrupted emissions (non-finite output).")


def assert_clean(probe: str, exc: BaseException | None, out: Any) -> None:
    """Sanity: a VALID frame must run to a finite projection."""
    if exc is not None:
        F.add(probe, "ANOMALY",
              f"valid frame did not run: {type(exc).__name__}: {str(exc)[:70]}")
    elif emissions_finite(out):
        F.add(probe, "PASS", "valid frame -> finite projection.")
    else:
        F.add(probe, "ANOMALY", "valid frame -> non-finite emissions.")


# ---------------------------------------------------------------------------
# Frame builders + driver
# ---------------------------------------------------------------------------

BASE_ISO = "CAN"
_BASE_HIST, _BASE_PROJ, _BASE_CFG = bt.build_country_inputs(BASE_ISO)
LAST = _BASE_HIST.last_historical_year()
HORIZON = _BASE_CFG.horizon_year
MIDPROJ = LAST + 1
HIST_YEARS = sorted(int(y) for y in pd.unique(_BASE_HIST.land_areas["Year"]))


def valid_proj_land() -> pd.DataFrame:
    """A flat projected land-area path (last historical split held constant
    across the projection window) — a valid L-B/L-D area input."""
    snap = _BASE_HIST.land_areas
    snap_last = snap[snap["Year"] == LAST][["Category", "Area_kha"]]
    rows: list[dict[str, Any]] = []
    for y in range(MIDPROJ, HORIZON + 1):
        for _, r in snap_last.iterrows():
            rows.append({"Year": y, "Category": r["Category"],
                         "Area_kha": float(r["Area_kha"])})
    return pd.DataFrame(rows)


def with_hist(attr: str, df: pd.DataFrame | None) -> tuple[Any, BaseException | None]:
    try:
        hist = dataclasses.replace(_BASE_HIST, **{attr: df})
    except BaseException as exc:  # noqa: BLE001 — schema __post_init__ may reject
        return None, exc
    return run_solver(hist, _BASE_PROJ, _BASE_CFG)


def with_proj(attr: str, df: pd.DataFrame | None,
              **extra: pd.DataFrame) -> tuple[Any, BaseException | None]:
    try:
        proj = dataclasses.replace(_BASE_PROJ, **{attr: df}, **extra)
    except BaseException as exc:  # noqa: BLE001
        return None, exc
    return run_solver(_BASE_HIST, proj, _BASE_CFG)


def drop(df: pd.DataFrame, col: str) -> pd.DataFrame:
    return df.drop(columns=[col])


def nan_in(df: pd.DataFrame, col: str) -> pd.DataFrame:
    out = df.copy()
    out.loc[out.index[0], col] = np.nan
    return out


# ---------------------------------------------------------------------------
# Frame catalog: (label, kind, valid-builder, [required cols to drop],
#                 [numeric cols to NaN]).
# Only frames actually consumed by the cascade are listed.
# ---------------------------------------------------------------------------

def _valid(attr: str) -> pd.DataFrame:
    L = LAST
    if attr == "forest_cohort_areas":
        return pd.DataFrame({"Year": [L, L], "AgeClass5y": [0, 20],
                             "Area_kha": [1500.0, 1500.0]})
    if attr == "hwp_historical":
        pc = list(HWP_PRODUCT_CLASSES)[0]
        return pd.DataFrame({"Year": [L], "ProductClass": [pc], "Pool_ktC": [1000.0]})
    if attr == "burned_area":
        return pd.DataFrame({"Year": [L], "Category": ["4A"], "BurnedArea_kha": [12.0]})
    if attr == "organic_soil_area":
        return pd.DataFrame({"Year": [L], "Category": ["4B"], "DrainedArea_kha": [80.0]})
    if attr == "harvest_volume":
        return pd.DataFrame({"Year": [L], "Volume_m3": [5.0e6]})
    if attr == "macro_heads":
        return pd.DataFrame({"Year": [L], "Heads": [9.0e6]})
    if attr == "macro_sgdp_primary":
        # Must span the historical land-area years so derive_l_agric_path finds
        # the year-overlap it requires.
        return pd.DataFrame({
            "Year": HIST_YEARS,
            "SGDP_primary": [3.0e10 * (1.0 + 0.02 * i) for i in range(len(HIST_YEARS))],
        })
    if attr == "n_fertilizer_applied":
        return pd.DataFrame({"Year": [L], "N_kt": [600.0]})
    if attr == "lime_applied":
        return pd.DataFrame({"Year": [L], "Lime_kt": [200.0]})
    if attr == "urea_applied":
        return pd.DataFrame({"Year": [L], "Urea_kt": [150.0]})
    if attr == "rice_cultivated_area":
        return pd.DataFrame({"Year": [L], "Area_kha": [25.0]})
    if attr == "pest_area":
        return pd.DataFrame({"Year": [L], "Category": ["4A"], "Area_kha": [40.0]})
    if attr == "wind_throw_area":
        return pd.DataFrame({"Year": [L], "Category": ["4A"], "Area_kha": [30.0]})
    # projected frames
    if attr == "afforestation_schedule":
        return pd.DataFrame({"Year": [MIDPROJ], "Area_kha": [50.0]})
    if attr == "deforestation_path":
        return pd.DataFrame({"Year": [MIDPROJ], "Area_kha": [40.0]})
    if attr == "harvest_schedule":
        return pd.DataFrame({"Year": [MIDPROJ], "Volume_m3": [5.0e6]})
    if attr == "national_efs":
        return pd.DataFrame({"Category": ["4A"], "Gas": ["CO2"],
                             "EF": [1.2], "Unit": ["tC/ha"]})
    raise KeyError(attr)


# label, attr, kind, drop_cols, nan_cols
FRAMES: list[tuple[str, str, str, list[str], list[str]]] = [
    # Historical, direct unguarded access (B2 / B7)
    ("forest_cohort_areas", "forest_cohort_areas", "hist",
     ["AgeClass5y", "Area_kha"], ["Area_kha"]),
    ("hwp_historical", "hwp_historical", "hist",
     ["ProductClass", "Pool_ktC"], ["Pool_ktC"]),
    # Historical, stitch-family (B5 / B6) — value col guarded, so a dropped
    # value col is silently skipped (good-behaviour: must stay finite); NaN
    # must not corrupt.
    ("burned_area", "burned_area", "hist", ["BurnedArea_kha"], ["BurnedArea_kha"]),
    ("organic_soil_area", "organic_soil_area", "hist",
     ["DrainedArea_kha"], ["DrainedArea_kha"]),
    ("harvest_volume", "harvest_volume", "hist", ["Volume_m3"], ["Volume_m3"]),
    ("macro_heads", "macro_heads", "hist", ["Heads"], ["Heads"]),
    ("macro_sgdp_primary", "macro_sgdp_primary", "hist",
     ["SGDP_primary"], ["SGDP_primary"]),
    ("n_fertilizer_applied", "n_fertilizer_applied", "hist", ["N_kt"], ["N_kt"]),
    ("lime_applied", "lime_applied", "hist", ["Lime_kt"], ["Lime_kt"]),
    ("urea_applied", "urea_applied", "hist", ["Urea_kt"], ["Urea_kt"]),
    ("rice_cultivated_area", "rice_cultivated_area", "hist", ["Area_kha"], ["Area_kha"]),
    ("pest_area", "pest_area", "hist", ["Area_kha"], ["Area_kha"]),
    ("wind_throw_area", "wind_throw_area", "hist", ["Area_kha"], ["Area_kha"]),
    # Projected, no __post_init__ guard at all (Year + value unguarded)
    ("proj/afforestation_schedule", "afforestation_schedule", "proj",
     ["Year", "Area_kha"], ["Area_kha"]),
    ("proj/deforestation_path", "deforestation_path", "proj",
     ["Year", "Area_kha"], ["Area_kha"]),
    ("proj/harvest_schedule", "harvest_schedule", "proj",
     ["Year", "Volume_m3"], ["Volume_m3"]),
    # national_efs is handled separately: it triggers profile L-D, which needs a
    # co-supplied proj.land_areas to reach a finite run (see run_national_efs).
]


def run_frame_probes() -> None:
    for label, attr, kind, drop_cols, nan_cols in FRAMES:
        run = with_hist if kind == "hist" else with_proj
        valid = _valid(attr)

        # Sanity: the valid frame must run finite (path is live).
        out, exc = run(attr, valid)
        assert_clean(f"{label}/valid", exc, out)

        # Drop each required column -> must be a clear rejection (or, for the
        # stitch family where a dropped value col is by-design skipped, a finite
        # tolerated run; the assert below treats a silent-but-finite skip as a
        # PASS only when the column is the stitch value col — to keep the harness
        # honest we always demand "clear reject OR finite", never crash).
        for col in drop_cols:
            out, exc = run(attr, drop(valid, col))
            # A missing structural column should be rejected with the frame /
            # column named. Stitch-family value cols may instead be tolerated
            # (silently skipped) and stay finite — both are acceptable; a crash
            # or non-finite is not.
            if isinstance(exc, ValueError) or isinstance(exc, KeyError) or exc is not None:
                assert_rejected(f"{label}/drop:{col}", exc, out, keyword=attr)
            elif emissions_finite(out):
                F.add(f"{label}/drop:{col}", "PASS",
                      "tolerated (value col skipped); projection finite.")
            else:
                F.add(f"{label}/drop:{col}", "ANOMALY",
                      "dropped column -> non-finite emissions.")

        # NaN in each numeric column -> reject cleanly or stay finite.
        for col in nan_cols:
            out, exc = run(attr, nan_in(valid, col))
            assert_no_silent_corruption(f"{label}/nan:{col}", exc, out)


def run_national_efs_probes() -> None:
    """national_efs triggers profile L-D, which requires a projected land path;
    co-supply a flat valid one so the run reaches Layer C."""
    efs = _valid("national_efs")
    land = valid_proj_land()

    out, exc = with_proj("national_efs", efs, land_areas=land)
    assert_clean("proj/national_efs/valid", exc, out)

    for col in ("EF", "Category"):
        out, exc = with_proj("national_efs", drop(efs, col), land_areas=land)
        assert_rejected(f"proj/national_efs/drop:{col}", exc, out, keyword="national_efs")

    out, exc = with_proj("national_efs", nan_in(efs, "EF"), land_areas=land)
    assert_no_silent_corruption("proj/national_efs/nan:EF", exc, out)


def main() -> int:
    print("LULUCF optional-input / activity-driver stress test")
    print("=" * 70)
    print(f"base country={BASE_ISO}  last_hist={LAST}  horizon={HORIZON}\n")

    print("=== per-frame probes (valid / drop-required-col / NaN) ===")
    run_frame_probes()
    run_national_efs_probes()

    print("\n" + "=" * 70)
    n_def = len(F.defects)
    print(f"Probes: {len(F.rows)}  |  PASS={len(F.rows) - n_def}")
    if n_def:
        print(f"\n{n_def} finding(s) need attention:")
        for r in F.defects:
            print(f"  [{r['status']}] {r['probe']}: {r['detail'][:88]}")
    else:
        print("\nClean - no crashes, anomalies, or failures.")
    return n_def


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(99)
