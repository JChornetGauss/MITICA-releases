"""TED-as-input backtest on the EU energy panel (reuses scripts/.../data).

Question: when the user supplies a projected Total Energy Demand (TED), does the
engine (a) honor it and (b) split it across sectors better than today's pure
bottom-up WoM? And does the U3 intensity benchmark flag the divergence sensibly?

Design — project the last 5 observed years so we can score against reality:
  * Train  : 1995 .. 2019.
  * Project: 2020 .. 2024 (observed, for scoring).
  * TED_obs(year) = Σ observed sectoral SED + households (the Eurostat total).

Three configurations per country, all scored against the observed sectoral SED:
  A) WoM            — observed macro (GDP/Pop/SGDP), NO TED pin. Today's model.
  B) TED-pinned     — observed macro + pinned observed TED. Isolates the split.
  C) TED-pinned/F3  — observed Pop only + pinned TED; macro projected. Realistic.

Metrics (mean over the 5 test years, per country, then pooled median / p90):
  * sectoral MAPE per Eurostat bin (primary, manufacturing[+constr], services,
    transport[pass+freight], households);
  * TED total MAPE (≈0 for the pinned configs by construction; the WoM number is
    the error TED-pinning removes);
  * the U3 signal: pinned-TED horizon gap vs the model's bottom-up WoM, and the
    implied intensity-decline rates (user vs model).

Eurostat aggregates lump manuf+construction and transport pass+freight; the
module splits them internally, so we compare bin sums (the within-bin split does
not affect the bin metric). Energy is in ktoe; macro in constant EUR — both fed
as-is (the engine is unit-robust; only ratios/shares are compared).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA = Path(__file__).resolve().parent / "data"
OUTDIR = Path(__file__).resolve().parent / "results"

TRAIN_START, TRAIN_END, TEST_END = 1995, 2019, 2024

# Eurostat 2-letter -> MITICA region (Western HIC vs catch-up HIC_TRANS).
EU_META = {
    "AT": "HIC", "BE": "HIC", "BG": "HIC_TRANS", "HR": "HIC_TRANS",
    "CY": "HIC", "CZ": "HIC_TRANS", "DK": "HIC", "EE": "HIC_TRANS",
    "FI": "HIC", "FR": "HIC", "DE": "HIC", "EL": "HIC", "HU": "HIC_TRANS",
    "IE": "HIC", "IT": "HIC", "LV": "HIC_TRANS", "LT": "HIC_TRANS",
    "LU": "HIC", "MT": "HIC_TRANS", "NL": "HIC", "PL": "HIC_TRANS",
    "PT": "HIC_TRANS", "RO": "HIC_TRANS", "SK": "HIC_TRANS", "SI": "HIC_TRANS",
    "ES": "HIC", "SE": "HIC",
}

# Eurostat -> MITICA 6-sector mapping (manuf:constr 70:30, pass:freight 65:35).
EUROSTAT_BINS = {
    "primary":       (["SED_primary"], lambda s: s["SED_primary"]),
    "manufacturing": (["SED_manufacturing", "SED_construction"],
                      lambda s: s["SED_manufacturing"] + s["SED_construction"]),
    "services":      (["SED_services"], lambda s: s["SED_services"]),
    "transport":     (["SED_transport_pass", "SED_transport_freight"],
                      lambda s: s["SED_transport_pass"] + s["SED_transport_freight"]),
}
OBS_SED_COLS = ["SED_primary", "SED_manufacturing", "SED_services",
                "SED_transport", "SED_households"]


def _slice(df, a, b):
    out = df[(df["Year"] >= a) & (df["Year"] <= b)].sort_values("Year").reset_index(drop=True)
    return out if not out.empty else None


def _load(cc):
    out = {}
    for k in ("gdp_pop", "sgdp", "sed"):
        p = DATA / f"{cc}_{k}.csv"
        if not p.exists() or p.stat().st_size < 10:
            return None
        out[k] = pd.read_csv(p)
    return out


def _six_sector(sed_raw):
    o = pd.DataFrame({"Year": sed_raw["Year"]})
    o["SED_primary"] = sed_raw["SED_primary"]
    o["SED_manufacturing"] = sed_raw["SED_manufacturing"] * 0.70
    o["SED_construction"] = sed_raw["SED_manufacturing"] * 0.30
    o["SED_services"] = sed_raw["SED_services"]
    o["SED_transport_pass"] = sed_raw["SED_transport"] * 0.65
    o["SED_transport_freight"] = sed_raw["SED_transport"] * 0.35
    return o


def _full_coverage(df, lo, hi):
    ys = set(df["Year"].astype(int))
    return all(y in ys for y in range(lo, hi + 1))


def _mape(proj, obs):
    return float(np.mean(np.abs((np.asarray(proj) - np.asarray(obs)) / np.asarray(obs))))


def _bias(proj, obs):
    return float(np.mean((np.asarray(proj) - np.asarray(obs)) / np.asarray(obs)))


def run_country(cc):
    raw = _load(cc)
    if raw is None:
        return None
    gp, sg, sed_raw = raw["gdp_pop"], raw["sgdp"], raw["sed"]
    if "SED_primary" not in sed_raw.columns:
        return None
    for df, lo, hi in [(gp, TRAIN_START, TEST_END), (sg, TRAIN_START, TEST_END),
                       (sed_raw, TRAIN_START, TEST_END)]:
        if not _full_coverage(df, lo, hi):
            return {"cc": cc, "error": "incomplete coverage"}

    sed6 = _six_sector(sed_raw)
    sed_hh = sed_raw[["Year", "SED_households"]].rename(columns={"SED_households": "SED_hh"})
    gdp = sg.copy()
    gdp["GDP_tot"] = sg["SGDP_primary"] + sg["SGDP_secondary"] + sg["SGDP_tertiary"]
    gdp = gdp[["Year", "GDP_tot"]]

    hist = HistoricalData(
        gdp_tot=_slice(gdp, TRAIN_START, TRAIN_END),
        population=_slice(gp[["Year", "Pop"]], TRAIN_START, TRAIN_END),
        sgdp=_slice(sg, TRAIN_START, TRAIN_END),
        sed=_slice(sed6, TRAIN_START, TRAIN_END),
        sed_hh=_slice(sed_hh, TRAIN_START, TRAIN_END),
    )
    test_years = list(range(TRAIN_END + 1, TEST_END + 1))

    # observed projected drivers + observed TED pin
    gdp_f = _slice(gdp, TRAIN_END + 1, TEST_END)
    pop_f = _slice(gp[["Year", "Pop"]], TRAIN_END + 1, TEST_END)
    sg_f = _slice(sg, TRAIN_END + 1, TEST_END)
    ted_obs = sed_raw.copy()
    ted_obs["TED"] = sed_raw[OBS_SED_COLS].sum(axis=1)
    ted_pin = _slice(ted_obs[["Year", "TED"]], TRAIN_END + 1, TEST_END)

    cfg = MacroConfig(region=EU_META[cc], dev_group="H", horizon_year=TEST_END,
                      validate_historical=False, verbose=False)

    configs = {
        "A_WoM":      ProjectedInputs(gdp_tot=gdp_f, population=pop_f, sgdp=sg_f),
        "B_TEDpin":   ProjectedInputs(gdp_tot=gdp_f, population=pop_f, sgdp=sg_f, ted=ted_pin),
        "C_TEDpinF3": ProjectedInputs(population=pop_f, ted=ted_pin),
    }
    obs = sed_raw.set_index("Year")
    res = {"cc": cc, "region": EU_META[cc]}
    for tag, proj in configs.items():
        try:
            out = run_macro_module(hist, proj, cfg)
        except Exception as e:  # pragma: no cover
            res[f"{tag}_error"] = str(e)[:100]
            continue
        s = out.sed.set_index("Year")
        h = out.sed_hh.set_index("Year")
        der = out.derived.set_index("Year")
        # sectoral bin MAPEs
        for bin_name, (_cols, agg) in EUROSTAT_BINS.items():
            obs_col = {"primary": "SED_primary", "manufacturing": "SED_manufacturing",
                       "services": "SED_services", "transport": "SED_transport"}[bin_name]
            proj_v = [float(agg(s.loc[y])) for y in test_years]
            obs_v = [float(obs.at[y, obs_col]) for y in test_years]
            res[f"{tag}_mape_{bin_name}"] = _mape(proj_v, obs_v)
            res[f"{tag}_bias_{bin_name}"] = _bias(proj_v, obs_v)
        # households
        proj_hh = [float(h.at[y, "SED_hh"]) for y in test_years]
        obs_hh = [float(obs.at[y, "SED_households"]) for y in test_years]
        res[f"{tag}_mape_households"] = _mape(proj_hh, obs_hh)
        res[f"{tag}_bias_households"] = _bias(proj_hh, obs_hh)
        # TED total
        proj_ted = [float(der.at[y, "TED"]) for y in test_years]
        obs_ted = [float(ted_obs.set_index("Year").at[y, "TED"]) for y in test_years]
        res[f"{tag}_mape_TED"] = _mape(proj_ted, obs_ted)
        res[f"{tag}_bias_TED"] = _bias(proj_ted, obs_ted)
        # mean sectoral MAPE across the 5 bins
        bins5 = ["primary", "manufacturing", "services", "transport", "households"]
        res[f"{tag}_mape_sectoral_mean"] = float(np.mean(
            [res[f"{tag}_mape_{b}"] for b in bins5]))
        # U3 signal
        u3 = [f for f in out.validation_report if f.test_id == "U3"]
        res[f"{tag}_u3"] = u3[0].severity if u3 else ""
    return res


def _pool(df, region=None):
    sub = df if region is None else df[df["region"] == region]
    return sub


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    rows, errs = [], []
    for cc in EU_META:
        r = run_country(cc)
        if r is None:
            errs.append((cc, "no data")); continue
        if "error" in r:
            errs.append((cc, r["error"])); continue
        rows.append(r)
    df = pd.DataFrame(rows)
    df.to_csv(OUTDIR / "ted_backtest.csv", index=False)

    print("=== TED-as-input backtest (EU, train 1995-2019, project 2020-2024) ===")
    print(f"  scored {len(df)}/{len(EU_META)}; skipped: {errs}\n")

    def line(label, col_a, col_b=None):
        a = df[col_a]
        s = f"  {label:<26} med={a.median():6.1%}  p90={a.quantile(.9):6.1%}"
        if col_b:
            b = df[col_b]
            s += f"   ||  {b.median():6.1%} / {b.quantile(.9):6.1%}"
        print(s)

    print("--- TED total error: WoM (A) vs pinned (B) [pinned ~0 by construction] ---")
    line("TED total MAPE", "A_WoM_mape_TED", "B_TEDpin_mape_TED")
    line("TED total bias", "A_WoM_bias_TED", "B_TEDpin_bias_TED")

    print("\n--- Sectoral MAPE (mean of 5 bins): A_WoM | B_TEDpin | C_TEDpinF3 ---")
    for tag in ("A_WoM", "B_TEDpin", "C_TEDpinF3"):
        line(f"{tag}", f"{tag}_mape_sectoral_mean")

    print("\n--- Per-bin sectoral MAPE: A_WoM (med) -> B_TEDpin (med) ---")
    for b in ("primary", "manufacturing", "services", "transport", "households"):
        a = df[f"A_WoM_mape_{b}"].median()
        bb = df[f"B_TEDpin_mape_{b}"].median()
        print(f"  {b:<16} {a:6.1%}  ->  {bb:6.1%}   (Δ {bb-a:+.1%})")

    print("\n--- U3 verdict distribution (config B, pinned=observed) ---")
    print("  ", df["B_TEDpin_u3"].value_counts().to_dict())

    print("\n--- By region (sectoral mean MAPE, B_TEDpin) ---")
    for reg in ("HIC", "HIC_TRANS"):
        sub = df[df["region"] == reg]
        if len(sub):
            print(f"  {reg:<12} n={len(sub):<2} A={sub['A_WoM_mape_sectoral_mean'].median():.1%}"
                  f"  B={sub['B_TEDpin_mape_sectoral_mean'].median():.1%}")
    print(f"\nWrote {OUTDIR / 'ted_backtest.csv'}")


if __name__ == "__main__":
    main()
