"""
Estimate the v3 Solow closure priors from a WDI panel.

What this script does
---------------------
1. Downloads three additional WDI indicators if not cached:
     NE.GDI.TOTL.KD      Gross capital formation (constant 2015 USD)
     SL.TLF.CACT.ZS      Labour force participation rate (% of pop 15+)
     SL.UEM.TOTL.ZS      Unemployment rate (% of total labour force)
2. Builds a per-country panel of Y, K, L:
     Y  : NY.GDP.MKTP.KD  (already cached as GDP_tot.csv)
     K  : perpetual inventory K_t = (1-δ)·K_{t-1} + I_t, with K_0 = 2.5·Y_0
          (decision #4) and I_t = NE.GDI.TOTL.KD.
     L  : g_L approximated by g_P (population growth). Participation and
          unemployment used only to set regional ILO defaults.
3. Solow residual per country-year:
        g_A = g_Y - α·g_K - (1-α)·g_L
   with α = 1/3 (decision #5).
4. Per-region aggregates:
     tfp_growth_mean : country-mean of g_A then regional median
     tfp_growth_ar1  : country AR(1) on g_A then regional median
     tfp_growth_min  : regional p5 of country-mean g_A
     tfp_growth_max  : regional p95
     participation   : regional median of SL.TLF.CACT.ZS / 100
     unemployment    : regional median of SL.UEM.TOTL.ZS / 100

What this script does NOT do
----------------------------
* No cross-country panel regression. The Solow accounting is done
  country-by-country and then aggregated to regions; this is the
  standard practice in growth-accounting calibrations (Caselli 2005).
* No labour quality (human capital) adjustment. The Penn World Table
  decomposition labsh·hc is left for v3.2 if needed; the design uses a
  pure Cobb-Douglas with α=1/3.
* No bootstrap on the AR(1) coefficient. The country panels are short
  (avg ~30 obs); the regional median across countries is a more honest
  summary than a single panel regression.

Output
------
``scripts/macro_validation/wdi_data/calibrated_solow_priors.json``
keyed by region with all six Solow fields populated. The loader in
``g_Macro_Priors.py`` overrides PriorsSolow values when this file exists.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import wbgapi as wb

DATA_DIR = Path("scripts/macro_validation/wdi_data")
OUT_PATH = DATA_DIR / "calibrated_solow_priors.json"

REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")

# WDI codes to download if not cached.
EXTRA_INDICATORS = {
    "Inv_total":     "NE.GDI.TOTL.KD",   # gross capital formation
    "participation": "SL.TLF.CACT.ZS",   # labour force participation %
    "unemployment":  "SL.UEM.TOTL.ZS",   # unemployment rate %
}

ALPHA = 1.0 / 3.0
DELTA = 0.05
K0_TO_Y0_RATIO = 2.5
YEAR_MIN = 1960
YEAR_MAX = 2024
MIN_OBS_PER_COUNTRY = 10   # require ≥ 10 years of valid g_A per country


# ---------------------------------------------------------------------------
# Downloading
# ---------------------------------------------------------------------------


def fetch_indicator(code: str) -> pd.DataFrame:
    df = wb.data.DataFrame(
        code, time=range(YEAR_MIN, YEAR_MAX + 1),
        skipBlanks=True, columns="series", labels=False,
    ).reset_index().rename(
        columns={"economy": "iso3", "time": "Year_str", code: "value"}
    )
    df["Year"] = df["Year_str"].str.lstrip("YR").astype(int)
    df = df.drop(columns=["Year_str"]).dropna(subset=["value"])
    return df[["iso3", "Year", "value"]]


def ensure_indicators_cached() -> None:
    for short, code in EXTRA_INDICATORS.items():
        p = DATA_DIR / f"{short}.csv"
        if p.exists():
            continue
        print(f"  [api] {code} -> {short}.csv", flush=True)
        df = fetch_indicator(code)
        df.to_csv(p, index=False)
        print(f"        {len(df):,} rows", flush=True)


# ---------------------------------------------------------------------------
# Per-country Solow accounting
# ---------------------------------------------------------------------------


def build_country_panel() -> pd.DataFrame:
    """Assemble iso3 × Year panel with Y, I, P, region. Missing rows dropped."""
    countries = pd.read_csv(DATA_DIR / "countries.csv")
    countries = countries.dropna(subset=["mitica_region"])
    Y = pd.read_csv(DATA_DIR / "GDP_tot.csv").rename(columns={"value": "Y"})
    P = pd.read_csv(DATA_DIR / "Pop.csv").rename(columns={"value": "P"})
    I = pd.read_csv(DATA_DIR / "Inv_total.csv").rename(columns={"value": "I"})
    pi = pd.read_csv(DATA_DIR / "participation.csv").rename(
        columns={"value": "participation_pct"})
    u = pd.read_csv(DATA_DIR / "unemployment.csv").rename(
        columns={"value": "unemployment_pct"})

    df = (Y.merge(P, on=["iso3", "Year"])
            .merge(I, on=["iso3", "Year"]))
    df = df[(df["Y"] > 0) & (df["P"] > 0) & (df["I"] > 0)]
    df = df.merge(countries[["iso3", "mitica_region"]], on="iso3", how="inner")
    # π and u are optional in the per-country merge (we want them only for
    # the regional ILO summary, not for the Solow residual).
    return df, pi, u


def compute_tfp_for_country(group: pd.DataFrame) -> pd.DataFrame:
    """Build K_t via PIH and Solow residual g_A_t."""
    group = group.sort_values("Year").reset_index(drop=True)
    n = len(group)
    if n < 3:
        return pd.DataFrame()
    K = np.empty(n)
    K[0] = K0_TO_Y0_RATIO * float(group["Y"].iloc[0])
    for i in range(1, n):
        K[i] = (1.0 - DELTA) * K[i - 1] + float(group["I"].iloc[i])
    log_Y = np.log(group["Y"].values)
    log_K = np.log(K)
    log_P = np.log(group["P"].values)
    g_Y = np.diff(log_Y)
    g_K = np.diff(log_K)
    g_L = np.diff(log_P)  # approximate g_L by g_P
    g_A = g_Y - ALPHA * g_K - (1.0 - ALPHA) * g_L
    return pd.DataFrame({
        "iso3": group["iso3"].iloc[0],
        "Year": group["Year"].values[1:],
        "g_Y": g_Y, "g_K": g_K, "g_L": g_L, "g_A": g_A,
        "region": group["mitica_region"].iloc[0],
    })


def aggregate_country(g_A: np.ndarray) -> tuple[float, float, int]:
    """Return (mean_g_A, ar1_rho, n_obs) for a single country."""
    n = len(g_A)
    if n < MIN_OBS_PER_COUNTRY:
        return np.nan, np.nan, n
    mean = float(np.mean(g_A))
    # AR(1): regress (g_A - mean) on lagged (g_A - mean)
    x = g_A[:-1] - mean
    y = g_A[1:] - mean
    denom = float(np.dot(x, x))
    rho = float(np.dot(x, y) / denom) if denom > 1e-12 else 0.0
    rho = max(-0.95, min(0.95, rho))
    return mean, rho, n


def calibrate_regional() -> dict:
    """Run the Solow accounting per country and aggregate to MITICA regions."""
    panel, pi_df, u_df = build_country_panel()
    countries = pd.read_csv(DATA_DIR / "countries.csv")
    region_map = countries.set_index("iso3")["mitica_region"]

    # Per-country Solow residual
    tfp_panel_parts = []
    for iso3, group in panel.groupby("iso3"):
        out = compute_tfp_for_country(group)
        if len(out) > 0:
            tfp_panel_parts.append(out)
    tfp_panel = pd.concat(tfp_panel_parts, ignore_index=True)

    # Per-country aggregates
    country_rows = []
    for iso3, group in tfp_panel.groupby("iso3"):
        g_A = group["g_A"].values
        # Trim tails (top/bottom 5%) for robustness to data errors
        if len(g_A) >= 20:
            lo, hi = np.percentile(g_A, [5, 95])
            g_A = g_A[(g_A >= lo) & (g_A <= hi)]
        mean, rho, n = aggregate_country(g_A)
        if np.isnan(mean):
            continue
        country_rows.append({
            "iso3": iso3,
            "region": region_map.get(iso3),
            "mean_g_A": mean, "ar1": rho, "n_obs": n,
        })
    country_df = pd.DataFrame(country_rows)

    # ILO defaults per region: median across the country medians
    pi_country = pi_df.groupby("iso3")["participation_pct"].median() / 100.0
    u_country = u_df.groupby("iso3")["unemployment_pct"].median() / 100.0
    pi_country = pi_country.to_frame().merge(
        region_map.to_frame(), left_index=True, right_index=True
    )
    u_country = u_country.to_frame().merge(
        region_map.to_frame(), left_index=True, right_index=True
    )

    # Recent GDPpc distribution per region (for D4.3 benchmark).
    # Use 2015-2024 panel of GDP_pc.
    gpc_recent = panel[(panel["Year"] >= 2015) & (panel["Year"] <= 2024)] \
                   [["mitica_region", "iso3", "Year", "Y", "P"]]
    gpc_recent["gpc"] = gpc_recent["Y"] / gpc_recent["P"]
    gpc_regional = {}
    for r in REGIONS:
        sub = gpc_recent[gpc_recent["mitica_region"] == r]["gpc"]
        if len(sub) >= 30:
            gpc_regional[r] = (float(np.percentile(sub, 5)),
                                float(np.percentile(sub, 95)))
        else:
            gpc_regional[r] = (None, None)

    # Regional aggregates
    out: dict = {}
    for r in REGIONS:
        sub = country_df[country_df["region"] == r]
        if len(sub) < 3:
            out[r] = None
            continue
        mean_g = float(np.median(sub["mean_g_A"]))
        rho = float(np.median(sub["ar1"]))
        p5 = float(np.percentile(sub["mean_g_A"], 5))
        p95 = float(np.percentile(sub["mean_g_A"], 95))
        # ILO regional medians
        pi_sub = pi_country[pi_country["mitica_region"] == r]["participation_pct"]
        u_sub = u_country[u_country["mitica_region"] == r]["unemployment_pct"]
        pi_med = float(pi_sub.median()) if len(pi_sub) > 0 else None
        u_med = float(u_sub.median()) if len(u_sub) > 0 else None
        gpc_p5, gpc_p95 = gpc_regional.get(r, (None, None))
        out[r] = {
            "tfp_growth_mean": mean_g,
            "tfp_growth_ar1":  rho,
            "tfp_growth_min":  p5,
            "tfp_growth_max":  p95,
            "participation":   pi_med,
            "unemployment":    u_med,
            "gdp_pc_p5_recent":  gpc_p5,
            "gdp_pc_p95_recent": gpc_p95,
            "n_countries":     int(len(sub)),
        }
    return out


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def print_summary(calib: dict) -> None:
    print("\n" + "=" * 100)
    print("Solow closure priors -- WDI calibration (Cobb-Douglas, alpha=1/3, delta=0.05)")
    print("g_L approximated by g_Pop. K_0 = 2.5 * Y_0 (PIH bootstrap).")
    print("=" * 100)
    print(f"{'region':<10}  {'mean_g':>8}  {'p5':>8}  {'p95':>8}  "
          f"{'ar1':>8}  {'pi':>6}  {'u':>6}  {'n':>4}")
    for r in REGIONS:
        d = calib.get(r)
        if d is None:
            print(f"{r:<10}  {'n/a':>8}  {'n/a':>8}  {'n/a':>8}  "
                  f"{'n/a':>8}  {'n/a':>6}  {'n/a':>6}  {'0':>4}")
            continue
        print(f"{r:<10}  "
              f"{d['tfp_growth_mean']:+8.4f}  "
              f"{d['tfp_growth_min']:+8.4f}  "
              f"{d['tfp_growth_max']:+8.4f}  "
              f"{d['tfp_growth_ar1']:+8.3f}  "
              f"{d['participation']:>6.3f}  "
              f"{d['unemployment']:>6.3f}  "
              f"{d['n_countries']:>4}")


def write_json(calib: dict, path: Path) -> None:
    payload = {
        "_meta": {
            "source": "World Bank WDI panel; per-country Solow accounting "
                      "(α=1/3, δ=5%, K_0=2.5·Y_0, g_L≈g_P). "
                      "Regional medians and 5/95 percentiles across countries.",
            "indicators": [
                "NY.GDP.MKTP.KD", "SP.POP.TOTL", "NE.GDI.TOTL.KD",
                "SL.TLF.CACT.ZS", "SL.UEM.TOTL.ZS",
            ],
            "year_range": [YEAR_MIN, YEAR_MAX],
            "min_obs_per_country": MIN_OBS_PER_COUNTRY,
        },
        "regions": calib,
    }
    path.write_text(json.dumps(payload, indent=2))
    print(f"\nWrote Solow priors to {path.resolve()}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    print("=== MITICA Solow priors -- WDI calibration ===\n")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    print("Ensuring WDI indicators are cached:")
    ensure_indicators_cached()
    print("\nRunning per-country Solow accounting and regional aggregation ...")
    calib = calibrate_regional()
    print_summary(calib)
    write_json(calib, OUT_PATH)


if __name__ == "__main__":
    main()
