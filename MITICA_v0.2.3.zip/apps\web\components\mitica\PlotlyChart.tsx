"use client";

import dynamic from "next/dynamic";
import type { Data, Layout, Config } from "plotly.js-dist-min";

// Plotly touches window; only load it on the client.
const Plot = dynamic(() => import("react-plotly.js").then((m) => m.default), { ssr: false });

interface PlotlyChartProps {
  data: Data[];
  layout?: Partial<Layout>;
  config?: Partial<Config>;
  height?: number;
}

export function PlotlyChart({ data, layout, config, height = 380 }: PlotlyChartProps) {
  return (
    <Plot
      data={data}
      layout={{
        autosize: true,
        margin: { l: 50, r: 20, t: 30, b: 40 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
        font: { family: "inherit", size: 12 },
        xaxis: { gridcolor: "rgba(150,150,150,0.2)" },
        yaxis: { gridcolor: "rgba(150,150,150,0.2)" },
        legend: { orientation: "h", y: -0.2 },
        ...layout,
      }}
      config={{ displaylogo: false, responsive: true, ...config }}
      style={{ width: "100%", height }}
      useResizeHandler
    />
  );
}
