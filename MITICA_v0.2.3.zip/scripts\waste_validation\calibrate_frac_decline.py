"""Calibrate (and, as it turned out, REJECT) a high-income ``frac_to_swds``
projected DECLINE on the C2 real-data backtests — docs/WASTE_BACKTEST.md §8.

The C2 backtest found the EU 5A over-projection (+10.3% bias) coincides with the
CONSTANT landfilled fraction. The §5.2 recommendation was an income-conditioned
DECLINING frac_to_swds for high-income (H) countries, applied to PROJECTED
deposition only (history anchors the inventory and is untouched). This harness
tests a grid of decline rates and reports the EU and BTR panel skill for each.

RESULT (see the printed grid / docs/WASTE_BACKTEST.md §8): REJECTED. The bias is a
legacy-STOCK artifact, not a projected-deposition one — the FOD's multi-decade
memory means cutting *future* deposition barely moves *near-term* CH4. Even an
unrealistic 8%/yr decline left the EU 5A bias at +7.0% (never the <5% target),
while every rate monotonically worsened the one growing high-income BTR country
(CHL). The engine change was reverted; this script is the reproducible evidence.

SELF-CONTAINED: it injects the H-only projected decline by monkeypatching the
(reverted) production engine at runtime — ``income_group`` is spied to learn each
country's group, and ``_reconstruct_deposition`` is wrapped to scale projected
deposition for H countries. So it reproduces the grid against the shipped tree with
NO dependency on the removed prior constants.

Run: .venv\\Scripts\\python.exe scripts\\waste_validation\\calibrate_frac_decline.py
"""
from __future__ import annotations

import contextlib
import io
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

import mitica_core.modules.waste.model as wmodel  # noqa: E402

import eu_waste_backtest as eu  # noqa: E402
import btr_waste_backtest as btr  # noqa: E402

GRID = [0.0, 0.01, 0.02, 0.03, 0.05, 0.08]
FLOOR = 0.40            # long-horizon guard (non-binding over the ~6-yr window)
CUT_YEAR = 2018         # both backtests train ≤ 2018, so base_year = last_hist = 2018
RESULTS = Path(__file__).parent / "results"

# --- runtime injection of the H-only projected decline (engine is reverted) ------
_orig_income = wmodel.income_group
_orig_recon = wmodel._reconstruct_deposition
_state = {"group": "UM", "rate": 0.0}


def _income_spy(gdp_pc):
    g = _orig_income(gdp_pc)
    _state["group"] = g          # model resolves income just before building deposition
    return g


def _recon_patched(years, pop, msw, frac):
    dep = _orig_recon(years, pop, msw, frac)
    rate = _state["rate"]
    if rate > 0 and _state["group"] == "H":   # H-only, projected-only
        dep = {
            y: (v * max(FLOOR, (1.0 - rate) ** (y - CUT_YEAR)) if y > CUT_YEAR else v)
            for y, v in dep.items()
        }
    return dep


wmodel.income_group = _income_spy
wmodel._reconstruct_deposition = _recon_patched


def _silence(fn):
    with contextlib.redirect_stdout(io.StringIO()):
        fn()


def main() -> None:
    rows = []
    for rate in GRID:
        _state["rate"] = rate
        _silence(eu.main)
        _silence(btr.main)

        e = pd.read_csv(RESULTS / "eu_summary.csv").dropna(subset=["mape_tot"])
        eH = e[e.income == "H"]
        b = pd.read_csv(RESULTS / "btr_summary.csv").dropna(subset=["mape_tot"])
        chl = b[b.iso == "CHL"].iloc[0]

        rows.append({
            "rate_%/yr": rate * 100,
            "EU_5A_bias_H": eH.bias_5A.median(),
            "EU_5A_mape_H": eH.mape_5A.median(),
            "EU_5A_p90": e.mape_5A.quantile(0.9),
            "EU_tot_mape": e.mape_tot.median(),
            "EU_tot_bias": e.bias_tot.median(),
            "BTR_5A_mape_med": b.mape_5A.median(),
            "BTR_5A_bias_med": b.bias_5A.median(),
            "BTR_tot_mape_med": b.mape_tot.median(),
            "CHL_5A_mape": chl.mape_5A,
            "CHL_5A_bias": chl.bias_5A,
        })

    df = pd.DataFrame(rows)
    pd.set_option("display.width", 200)
    pd.set_option("display.max_columns", 30)
    print("\n=== frac_to_swds H-decline calibration grid (REJECTED — see §8) ===")
    print(df.round(2).to_string(index=False))
    df.to_csv(RESULTS / "frac_decline_grid.csv", index=False)
    print(f"\nwrote {RESULTS / 'frac_decline_grid.csv'}")


if __name__ == "__main__":
    main()
