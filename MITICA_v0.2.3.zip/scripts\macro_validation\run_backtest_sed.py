"""European backtest harness for the *energy* side of the macro module
(B5 sectoral energy demand and B6 residential).

Mirrors ``run_backtest.py`` (which targets B2 = sectoral GDP) but with three
key differences:

  1. The training/test split is wider — energy series start in 1990 and we use
     1990-2005 as training (16 years), 2006-2023 as test (last reliable EU
     year; some countries have 2024 only for select series).

  2. We compare four B5 form combinations:
       - b5=log_log             + b6=log_log         (baseline)
       - b5=intensity_convergence + b6=log_log
       - b5=log_log             + b6=saturation      (M9)
       - b5=intensity_convergence + b6=saturation    (M8 + M9 combined)

  3. Sectors validated:
       - SED_primary       (Eurostat FC_OTH_AF_E)
       - SED_manufacturing (Eurostat FC_IND_E — manuf+constr lumped)
       - SED_services      (Eurostat FC_OTH_CP_E)
       - SED_transport     (Eurostat FC_TRA_E — pass+freight lumped)
       - SED_hh            (Eurostat FC_OTH_HH_E)

The MITICA module separates manuf/construction and transport_pass/freight
internally. Here we compare against Eurostat aggregates by summing the
module's manuf+construction and transport_pass+transport_freight outputs.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from mitica_core.modules.macro import (
    HistoricalData,
    MacroConfig,
    ProjectedInputs,
    run_macro_module,
)

DATA_DIR = Path("scripts/macro_validation/data")
OUT_DIR  = Path("scripts/macro_validation/results")


def load_country(code: str) -> dict[str, pd.DataFrame]:
    out: dict[str, pd.DataFrame] = {}
    for key in ("gdp_pop", "sgdp", "sinv", "irate", "sed"):
        p = DATA_DIR / f"{code}_{key}.csv"
        if not p.exists() or p.stat().st_size < 10:
            out[key] = pd.DataFrame()
            continue
        try:
            out[key] = pd.read_csv(p)
        except Exception:
            out[key] = pd.DataFrame()
    return out


def _slice(df: pd.DataFrame, lo: int, hi: int) -> pd.DataFrame | None:
    if df is None or df.empty:
        return None
    out = df[(df["Year"] >= lo) & (df["Year"] <= hi)].sort_values("Year").reset_index(drop=True)
    return out if not out.empty else None


def build_hist(raw: dict[str, pd.DataFrame],
               train_start: int, train_end: int) -> HistoricalData:
    """Build a HistoricalData for the training window, including SED & SED_hh.

    The MITICA module wants SED_<sector> columns for the 6 productive energy
    sectors. From Eurostat we only have:
        - SED_primary (agriculture)
        - SED_manufacturing (full industry, includes construction)
        - SED_services
        - SED_transport (passenger + freight)
        - SED_hh (households)
    We map them as:
        - SED_primary           <- SED_primary
        - SED_manufacturing     <- SED_manufacturing * 0.70 (share manuf in industry)
        - SED_construction      <- SED_manufacturing * 0.30
        - SED_services          <- SED_services
        - SED_transport_pass    <- SED_transport * 0.65 (passenger share)
        - SED_transport_freight <- SED_transport * 0.35
    These shares come from EU energy balance averages and let the module
    operate on its native 6-sector schema. The validation compares aggregates
    (manuf+constr / pass+freight) against the Eurostat aggregates that we
    actually observe, so the within-aggregate split has no effect on the
    metrics.
    """
    gdp_pop = _slice(raw["gdp_pop"], train_start, train_end)
    sgdp    = _slice(raw["sgdp"],    train_start, train_end)
    sinv    = _slice(raw["sinv"],    train_start, train_end)
    irate   = _slice(raw["irate"],   train_start, train_end)
    sed_raw = _slice(raw["sed"],     train_start, train_end)

    # reconcile GDP_tot to sum of SGVA (same convention as run_backtest.py)
    gdp_tot = sgdp.copy()
    gdp_tot["GDP_tot"] = (
        sgdp["SGDP_primary"] + sgdp["SGDP_secondary"] + sgdp["SGDP_tertiary"]
    )
    gdp_tot = gdp_tot[["Year", "GDP_tot"]]

    sed = None
    sed_hh = None
    if sed_raw is not None and "SED_primary" in sed_raw.columns:
        # Build the 6-sector SED frame in MITICA schema.
        sed = pd.DataFrame({"Year": sed_raw["Year"]})
        sed["SED_primary"] = sed_raw["SED_primary"]
        ind = sed_raw["SED_manufacturing"] if "SED_manufacturing" in sed_raw else None
        if ind is not None:
            sed["SED_manufacturing"] = ind * 0.70
            sed["SED_construction"]  = ind * 0.30
        srv = sed_raw["SED_services"] if "SED_services" in sed_raw else None
        if srv is not None:
            sed["SED_services"] = srv
        trn = sed_raw["SED_transport"] if "SED_transport" in sed_raw else None
        if trn is not None:
            sed["SED_transport_pass"]    = trn * 0.65
            sed["SED_transport_freight"] = trn * 0.35
        sed = sed.dropna(subset=[c for c in sed.columns if c != "Year"])
        if sed.empty:
            sed = None
    if sed_raw is not None and "SED_households" in sed_raw.columns:
        sed_hh = sed_raw[["Year", "SED_households"]].rename(
            columns={"SED_households": "SED_hh"})
        sed_hh = sed_hh.dropna()
        if sed_hh.empty:
            sed_hh = None

    return HistoricalData(
        gdp_tot=gdp_tot,
        population=gdp_pop[["Year", "Pop"]],
        sgdp=sgdp,
        sinv=sinv,
        irate=irate,
        sed=sed,
        sed_hh=sed_hh,
    )


def build_proj(raw: dict[str, pd.DataFrame], train_end: int, test_end: int) -> ProjectedInputs:
    """Drivers for the test window — we feed actual Pop, SInv, iRate paths."""
    def _slice_future(df, lo, hi):
        if df is None or df.empty:
            return None
        out = df[(df["Year"] > lo) & (df["Year"] <= hi)].sort_values("Year").reset_index(drop=True)
        return out if not out.empty else None
    pop_f   = _slice_future(raw["gdp_pop"], train_end, test_end)
    sinv_f  = _slice_future(raw["sinv"],    train_end, test_end)
    irate_f = _slice_future(raw["irate"],   train_end, test_end)
    return ProjectedInputs(
        population=(pop_f[["Year", "Pop"]] if pop_f is not None else None),
        sinv=sinv_f,
        irate=irate_f,
    )


def evaluate_country(
    code: str,
    train_start: int,
    train_end: int,
    test_end: int,
    shrinkage: float,
    region: str,
    b5_form: str,
    b6_form: str,
) -> dict:
    raw = load_country(code)
    for key in ("gdp_pop", "sgdp", "sinv", "sed"):
        if raw.get(key) is None or raw[key].empty:
            return {"country": code, "status": f"missing_{key}"}
    if "SED_primary" not in raw["sed"].columns:
        return {"country": code, "status": "no_SED_primary"}

    # Gap checks on driver futures
    def has_gap(df, lo, hi):
        if df is None or df.empty: return True
        ys = set(df["Year"].astype(int)); return any(y not in ys for y in range(lo, hi+1))
    if has_gap(raw["gdp_pop"], train_end+1, test_end):
        return {"country": code, "status": "gap_in_pop_test_window"}
    if has_gap(raw["sinv"],    train_end+1, test_end):
        return {"country": code, "status": "gap_in_sinv_test_window"}

    hist = build_hist(raw, train_start, train_end)
    proj = build_proj(raw, train_end, test_end)
    cfg = MacroConfig(
        region=region,
        horizon_year=test_end,
        estimation_shrinkage=shrinkage,
        b5_form=b5_form,
        b6_form=b6_form,
        verbose=False,
    )
    try:
        out = run_macro_module(hist, proj, cfg)
    except Exception as e:
        return {"country": code, "status": f"crash: {type(e).__name__}: {e}"}

    # Aggregate the module's 6-sector SED output into Eurostat-comparable bins
    sed_proj = out.sed.set_index("Year")
    sed_hh_proj = out.sed_hh.set_index("Year")
    sed_actual = raw["sed"].set_index("Year")

    metrics: dict[str, dict[str, float]] = {}
    bins = {
        "primary":       ("SED_primary",       lambda d: d["SED_primary"]),
        "manufacturing": ("SED_manufacturing", lambda d: d["SED_manufacturing"] + d["SED_construction"]),
        "services":      ("SED_services",      lambda d: d["SED_services"]),
        "transport":     ("SED_transport",     lambda d: d["SED_transport_pass"] + d["SED_transport_freight"]),
        "households":    ("SED_households",    None),
    }
    for bin_name, (actual_col, agg) in bins.items():
        if actual_col not in sed_actual.columns:
            continue
        years = [y for y in range(train_end+1, test_end+1)
                 if y in sed_actual.index and pd.notna(sed_actual.at[y, actual_col])]
        if not years:
            continue
        actual_v = np.array([float(sed_actual.at[y, actual_col]) for y in years])
        if bin_name == "households":
            proj_v = np.array([float(sed_hh_proj.at[y, "SED_hh"]) for y in years
                               if y in sed_hh_proj.index])
            years_used = [y for y in years if y in sed_hh_proj.index]
            actual_v = np.array([float(sed_actual.at[y, actual_col]) for y in years_used])
        else:
            years_used = [y for y in years if y in sed_proj.index]
            actual_v = np.array([float(sed_actual.at[y, actual_col]) for y in years_used])
            proj_v = np.array([float(agg(sed_proj.loc[y])) for y in years_used])

        if len(actual_v) == 0 or len(proj_v) == 0:
            continue
        err = (proj_v - actual_v) / actual_v
        metrics[bin_name] = {
            "n_years": len(years_used),
            "mape_pct": float(np.mean(np.abs(err)) * 100),
            "bias_pct": float(np.mean(err) * 100),
            "endpoint_dev_pct": float(err[-1] * 100),
        }

    return {
        "country": code, "status": "ok",
        "shrinkage": shrinkage, "b5_form": b5_form, "b6_form": b6_form,
        "region": region, "metrics": metrics,
    }


def discover_countries() -> list[str]:
    codes = []
    for p in sorted(DATA_DIR.glob("*_sed.csv")):
        cc = p.name.split("_")[0]
        if p.stat().st_size < 10:
            continue
        # also require gdp_pop/sgdp/sinv/sed locally
        if all((DATA_DIR / f"{cc}_{k}.csv").exists()
               and (DATA_DIR / f"{cc}_{k}.csv").stat().st_size > 10
               for k in ("gdp_pop", "sgdp", "sinv")):
            codes.append(cc)
    return codes


# Mapping of Eurostat 2-letter -> WDI iso3, used to pull MITICA region from
# wdi_data/countries.csv when classifying each country.
_EUROSTAT_TO_ISO3 = {
    "AT": "AUT", "BE": "BEL", "BG": "BGR", "CY": "CYP", "CZ": "CZE",
    "DE": "DEU", "DK": "DNK", "EE": "EST", "EL": "GRC", "ES": "ESP",
    "FI": "FIN", "FR": "FRA", "HR": "HRV", "HU": "HUN", "IE": "IRL",
    "IT": "ITA", "LT": "LTU", "LU": "LUX", "LV": "LVA", "MT": "MLT",
    "NL": "NLD", "PL": "POL", "PT": "PRT", "RO": "ROU", "SE": "SWE",
    "SI": "SVN", "SK": "SVK", "UK": "GBR", "NO": "NOR", "CH": "CHE",
}


def region_for_eurostat_code(code: str) -> str:
    """Look up the MITICA region for a Eurostat 2-letter country code via
    wdi_data/countries.csv. Falls back to HIC for unknown countries."""
    countries_csv = DATA_DIR.parent / "wdi_data" / "countries.csv"
    fallback = "HIC"
    if not countries_csv.exists():
        return fallback
    iso3 = _EUROSTAT_TO_ISO3.get(code)
    if iso3 is None:
        return fallback
    df = pd.read_csv(countries_csv)
    row = df[df["iso3"] == iso3]
    if row.empty:
        return fallback
    r = row.iloc[0]["mitica_region"]
    return r if isinstance(r, str) else fallback


def main() -> None:
    countries = discover_countries()
    train_start, train_end, test_end = 1995, 2005, 2023
    shrink = 0.5

    region_by_code = {c: region_for_eurostat_code(c) for c in countries}
    print(f"\n=== European SED backtest ===")
    print(f"  Train: {train_start}-{train_end}  Test: {train_end+1}-{test_end}")
    print(f"  Shrinkage={shrink}  Region assignment per country:")
    for c in countries:
        print(f"    {c:<4} -> {region_by_code[c]}")
    print(f"  Countries ({len(countries)}): {countries}\n")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for b5_form in ("log_log", "intensity_convergence"):
        for b6_form in ("log_log", "saturation"):
            tag = f"b5={b5_form}/b6={b6_form}"
            print(f"  --- {tag} ---")
            for code in countries:
                r = evaluate_country(code, train_start, train_end, test_end,
                                     shrink, region_by_code[code],
                                     b5_form, b6_form)
                if r.get("status") != "ok":
                    continue
                for bin_name, m in r["metrics"].items():
                    rows.append({
                        "country": code, "b5_form": b5_form, "b6_form": b6_form,
                        "region": region_by_code[code], "bin": bin_name, **m,
                    })

    if not rows:
        print("\nNo OK results.")
        return

    summary = pd.DataFrame(rows)
    summary.to_csv(OUT_DIR / f"sed_summary_{train_start}_{train_end}_{test_end}.csv",
                   index=False)
    print(f"\n  Wrote {OUT_DIR / f'sed_summary_{train_start}_{train_end}_{test_end}.csv'}")

    forms = [("log_log","log_log"), ("intensity_convergence","log_log"),
             ("log_log","saturation"), ("intensity_convergence","saturation")]
    bins = ["primary", "manufacturing", "services", "transport", "households"]

    def _table_per_pool(sub_summary: pd.DataFrame, label: str):
        print(f"\n  --- {label}: median MAPE % across countries ---")
        hdr = f"  {'bin':<14}"
        for b5, b6 in forms:
            hdr += f"  {b5[:6]}/{b6[:6]:>8}"
        print(hdr)
        for b in bins:
            row = f"  {b:<14}"
            for b5, b6 in forms:
                ss = sub_summary[(sub_summary["bin"] == b)
                                 & (sub_summary["b5_form"] == b5)
                                 & (sub_summary["b6_form"] == b6)]["mape_pct"]
                row += f"  {ss.median() if not ss.empty else float('nan'):>14.2f}"
            print(row)

    _table_per_pool(summary, "Aggregate (all 29 countries)")
    for sub in ("HIC", "HIC_TRANS"):
        sub_summary = summary[summary["region"] == sub]
        n = sub_summary["country"].nunique()
        if n == 0:
            continue
        _table_per_pool(sub_summary, f"{sub} sub-pool ({n} countries)")


if __name__ == "__main__":
    main()
