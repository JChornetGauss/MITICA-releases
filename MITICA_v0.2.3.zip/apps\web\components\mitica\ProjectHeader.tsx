"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Project } from "@/lib/types";

export function ProjectHeader({ project }: { project: Project }) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
      <div>
        <Link
          href="/"
          className="mb-2 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" /> All projects
        </Link>
        <h1 className="text-2xl font-bold tracking-tight">{project.name}</h1>
        <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
          <Badge variant="outline">{project.country_code}</Badge>
          {project.horizon_year && <span>horizon {project.horizon_year}</span>}
          {project.reference_year && <span>· ref {project.reference_year}</span>}
        </div>
        {project.description && (
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{project.description}</p>
        )}
      </div>
      <div className="flex gap-2">
        <Button asChild variant="outline" size="sm">
          <a href={`/api/v1/projects/${project.id}/forecast`} target="_blank" rel="noreferrer">
            Forecast JSON
          </a>
        </Button>
      </div>
    </div>
  );
}
