"""
analyze_btr_cache.py — build the casuistry + model matrices from _btr_series.json
(produced by fetch_parse_btr.py). Writes MITICA_LULUCF_ALL_BTR1_casuistry.xlsx.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

_HERE = Path(__file__).resolve()
_REPO = _HERE.parents[2]
_PROJECT_ROOT = _REPO.parent
for p in (str(_REPO / "packages" / "core" / "src"), str(_HERE.parent)):
    if p not in sys.path:
        sys.path.insert(0, p)
import v1_country_backtest as bt  # noqa: E402
import _country_iso3  # noqa: E402
from mitica_core.modules.lulucf import (  # noqa: E402
    HistoricalLULUCF, LULUCFConfig, ProjectedLULUCF, run_lulucf_module)

_CACHE = _HERE.parent / "_btr_series.json"
OUT = _PROJECT_ROOT / "MITICA_LULUCF_ALL_BTR1_casuistry.xlsx"
CATS_STD = ["4A", "4B", "4C", "4D", "4E", "4F", "4G"]


def _p(s=""):
    sys.stdout.buffer.write((str(s) + "\n").encode("ascii", "replace"))


def cats_of(rec):
    return {k: v for k, v in rec.items() if not k.startswith("_")}


def availability(iso, country, series, refdb):
    years = sorted(int(y) for y in series)
    last = years[-1]
    present, gases, has4h = set(), set(), False
    for y in years:
        rec = series[str(y)]
        for k, v in cats_of(rec).items():
            if abs(v) > 1:
                present.add(k)
                if k == "4H":
                    has4h = True
        gases.update(rec.get("_gases", []))
    only_total = len(present) == 0
    net_last = sum(cats_of(series[str(last)]).values())
    rep_last = series[str(last)].get("_total")
    return {
        "ISO": iso, "Country": country, "Years": f"{years[0]}-{last}", "N": len(years),
        "Contig": "Y" if len(years) == last - years[0] + 1 else "N",
        "Detail": "TOTAL-ONLY" if only_total else "per-cat",
        "Cats": ",".join(sorted(present)), "4H": "Y" if has4h else "",
        "Gases": ",".join(sorted(gases)),
        "Net last(kt)": round(net_last, 0),
        "Reported total(kt)": round(rep_last, 0) if rep_last is not None else None,
        "refDB": "Y" if bt.get_country_profile(refdb, iso) else "",
    }


_LAND_CATS = ["4A", "4B", "4C", "4D", "4E", "4F"]
_REGION_FALLBACK = {"region": "LAC", "climate_zone": "tropical"}


def _real_land(series) -> dict | None:
    """Latest available real Table-4.1 land (kha per 4A..4F), or None."""
    ys = sorted(int(y) for y in series
                if isinstance(series[str(y)].get("_land"), dict) and series[str(y)]["_land"])
    if not ys:
        return None
    ld = series[str(ys[-1])]["_land"]
    out = {c: float(ld.get(c, 0.0)) for c in _LAND_CATS}
    return out if sum(out.values()) > 0 else None


def model(iso, series, refdb):
    profile = bt.get_country_profile(refdb, iso)
    years = sorted(int(y) for y in series)
    # Feed ALL reported categories (incl 4H 'Other'); fall back to sector total.
    cats = sorted({k for y in series for k, v in series[str(y)].items()
                   if not k.startswith("_") and abs(v) > 1})
    if cats:
        rows = [{"Year": y, "Category": c, "Gas": "CO2eq",
                 "Emissions": series[str(y)].get(c, 0.0)} for y in years for c in cats]
        rep = sum(series[str(years[-1])].get(c, 0.0) for c in cats)
    else:
        rows = [{"Year": y, "Category": "4_total", "Gas": "CO2eq",
                 "Emissions": series[str(y)].get("_total", 0.0) or 0.0} for y in years]
        rep = series[str(years[-1])].get("_total", 0.0) or 0.0
    inv = pd.DataFrame(rows)
    if inv["Emissions"].abs().sum() == 0:
        return {"note": "no data"}

    # Land: prefer real Table 4.1; else refDB; else skip.
    rl = _real_land(series)
    if rl is not None:
        land = pd.DataFrame([{"Year": y, "Category": c, "Area_kha": a}
                             for y in years for c, a in rl.items()])
        land_src = "real"
    elif profile is not None:
        land = bt._build_land_areas(iso, profile, years)
        land_src = "refDB"
    else:
        return {"note": "no land"}
    region = profile["region"] if profile else _REGION_FALLBACK["region"]
    zone = profile["climate_zone"] if profile else _REGION_FALLBACK["climate_zone"]
    try:
        hist = HistoricalLULUCF(inventory_emissions=inv, land_areas=land, country=iso)
        cfg = LULUCFConfig(country=iso, region=region, horizon_year=2040,
                           climate_zone=zone, tier=0, profile="L-A")
        out = run_lulucf_module(hist, ProjectedLULUCF(), cfg)
    except Exception as e:
        return {"note": f"CRASH:{type(e).__name__}", "land_src": land_src}
    import numpy as _np
    finite = bool(_np.isfinite(
        pd.to_numeric(out.emissions["Emissions_CO2eq_kt"], errors="coerce")
        .to_numpy("float64")).all())
    wom = out.net_co2eq_by_year().set_index("Year")["Net_LULUCF_CO2eq_kt"]
    last = years[-1]
    m = float(wom.get(last, float("nan")))
    err = (m - rep) / abs(rep) * 100 if abs(rep) > 1e-9 else float("nan")
    # Anchored = WoM reproduces the reported net at T, within 15% OR 1 kt absolute
    # (the absolute floor handles countries whose net cancels to ~0, where the
    # relative error is undefined).
    anchored = "Y" if abs(m - rep) <= max(0.15 * abs(rep), 1.0) else "NO"
    return {"ISO": iso, "land": land_src, "reported(kt)": round(rep, 0),
            "WoM model(kt)": round(m, 0), "err%": round(err, 1),
            "anchored": anchored, "finite": "Y" if finite else "NO",
            "sign flip": "YES" if (rep < 0) != (m < 0) else "",
            "flags": ",".join(f.test_id for f in out.validation_report
                              if f.severity in ("red", "amber"))}


def main():
    if not _CACHE.exists():
        _p("no cache yet"); return 1
    raw = json.loads(_CACHE.read_text(encoding="utf-8", errors="replace"))
    cache = {}  # de-collide by country -> ISO3 (idempotent)
    for k, e in raw.items():
        nk = _country_iso3.iso3(e.get("country", "")) or k
        if nk not in cache:
            cache[nk] = e
    refdb = bt.load_refdb()
    av, md, skipped = [], [], []
    for iso in sorted(cache):
        c = cache[iso]
        series = c["series"]
        av.append(availability(iso, c["country"], series, refdb))
        m = model(iso, series, refdb)
        if m and "note" not in m:
            md.append(m)
        elif m:
            skipped.append((iso, m["note"]))
    av_df = pd.DataFrame(av)
    md_df = pd.DataFrame(md).sort_values("err%", key=lambda s: s.abs(), ascending=False) if md else pd.DataFrame()

    _p(f"=== {len(av)} countries parsed ===")
    sys.stdout.buffer.write((av_df.to_string(index=False) + "\n").encode("ascii", "replace"))
    # casuistry summary
    _p("\n=== CASUISTRY SUMMARY ===")
    _p(f"  per-category: {(av_df['Detail']=='per-cat').sum()}   total-only: {(av_df['Detail']=='TOTAL-ONLY').sum()}")
    _p(f"  report 4H 'Other': {(av_df['4H']=='Y').sum()}")
    _p(f"  non-contiguous years: {(av_df['Contig']=='N').sum()}")
    _p(f"  gases CO2-only: {(av_df['Gases']=='CO2').sum()}   CO2+CH4+N2O: {av_df['Gases'].str.contains('N2O').sum()}")
    _p(f"  in MITICA refDB: {(av_df['refDB']=='Y').sum()} / {len(av_df)}")
    yr = av_df['N']
    _p(f"  year coverage: min={yr.min()} max={yr.max()} median={int(yr.median())}")
    if len(md_df):
        _p(f"\n=== MODEL vs reported — ALL runnable countries (n={len(md_df)}) ===")
        sys.stdout.buffer.write((md_df.to_string(index=False) + "\n").encode("ascii", "replace"))
        nonfin = (md_df["finite"] == "NO").sum()
        crashes = [s for s in skipped if s[1].startswith("CRASH")]
        _p(f"\n  ran: {len(md_df)}   land=real: {(md_df['land']=='real').sum()}   "
           f"land=refDB: {(md_df['land']=='refDB').sum()}")
        _p(f"  ROBUSTNESS: non-finite emissions: {nonfin}   crashes: {len(crashes)}"
           + (f" -> {crashes}" if crashes else ""))
        _p(f"  ANCHORING: reproduces reported net @anchor: {(md_df['anchored']=='Y').sum()}/{len(md_df)}"
           f"   sign flips: {(md_df['sign flip']=='YES').sum()}")
        skip_nodata = [s for s in skipped if not s[1].startswith("CRASH")]
        if skip_nodata:
            _p(f"  skipped (no land / no per-cat data): {len(skip_nodata)} -> "
               f"{[s[0] for s in skip_nodata][:25]}")

    with pd.ExcelWriter(OUT, engine="openpyxl") as xl:
        av_df.to_excel(xl, sheet_name="1 Data availability", index=False)
        if len(md_df):
            md_df.to_excel(xl, sheet_name="2 Model vs reported", index=False)
        wb = xl.book
        hf = PatternFill("solid", fgColor="1F4E78"); ff = Font(bold=True, color="FFFFFF")
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.fill = hf; cell.font = ff
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            for col in ws.columns:
                w = max((len(str(c.value)) for c in col if c.value is not None), default=8)
                ws.column_dimensions[get_column_letter(col[0].column)].width = min(w + 2, 30)
    _p(f"\nWrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
