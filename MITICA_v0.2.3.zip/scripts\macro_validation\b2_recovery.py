"""B2 estimation — Monte Carlo recovery test against synthetic ground truth.

Validates whether the Bayesian ridge estimator in g_Macro_LayerB2 actually
recovers known coefficients when the data is generated from the model.

This is the standard econometric check before applying the method to real
country data: if the estimator can't recover what it should under the most
favourable conditions (clean data-generating process, full driver set),
there is no point in trusting it on a real country.

Three rounds of tests:

  1. Ideal conditions: 25 years, low noise, moderately correlated drivers
     → expect tight recovery (signs correct, magnitudes within 1-2 SE).
  2. Short series: 10 years, same noise
     → expect wider posteriors, possible sign noise on weakly identified
     coefficients (delta).
  3. High multicollinearity: SInv and GFCF_pub strongly correlated
     → expect inflated SEs, possible coefficient swaps.

For each round we run N_REPS replications and aggregate the bias and
coverage (% of replications where the 95% credible interval contains
the truth).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from mitica_core.modules.macro import HistoricalData
from mitica_core.modules.macro.g_Macro_LayerB2 import estimate_sector_coefficients
from mitica_core.modules.macro.g_Macro_Priors import get_priors

# ---------------------------------------------------------------------------
# Ground truth — chosen to be plausible for a non-Annex I country
# ---------------------------------------------------------------------------

TRUE_PARAMS = {
    "primary":   {"alpha": -8.0, "beta": 0.40, "gamma": 0.20, "zeta": 0.95, "delta": -0.015},
    "secondary": {"alpha": -7.0, "beta": 0.45, "gamma": 0.25, "zeta": 1.00, "delta": -0.020},
    "tertiary":  {"alpha": -6.0, "beta": 0.30, "gamma": 0.10, "zeta": 1.10, "delta": -0.010},
}


def make_country(
    n_years: int = 25,
    seed: int = 42,
    noise_sigma: float = 0.02,
    collinearity: float = 0.0,
) -> HistoricalData:
    """Generate one synthetic country.

    ``collinearity`` in [0, 1] controls the correlation between SInv and
    GFCF_pub at the sector level. 0 = independent shocks; 1 = identical
    shocks (perfect collinearity).
    """
    rng = np.random.default_rng(seed)
    years = list(range(2000, 2000 + n_years))

    pop = 10e6 * (1.012 ** np.arange(n_years))
    irate = 5.0 + 0.5 * rng.standard_normal(n_years)

    def driver(base, growth, noise_std, shared_noise=None):
        idio = rng.standard_normal(n_years)
        if shared_noise is not None:
            eff = (1 - collinearity) * idio + collinearity * shared_noise
        else:
            eff = idio
        return base * (growth ** np.arange(n_years)) * np.exp(noise_std * eff)

    shared = {s: rng.standard_normal(n_years) for s in ["primary", "secondary", "tertiary"]}
    sinv = {
        "primary":   driver(100, 1.04, 0.05, shared["primary"]),
        "secondary": driver(200, 1.05, 0.05, shared["secondary"]),
        "tertiary":  driver(150, 1.06, 0.05, shared["tertiary"]),
    }
    gfcf = {
        "primary":   driver(30, 1.025, 0.08, shared["primary"]),
        "secondary": driver(50, 1.03,  0.08, shared["secondary"]),
        "tertiary":  driver(40, 1.035, 0.08, shared["tertiary"]),
    }

    sgdp = {}
    for s in ["primary", "secondary", "tertiary"]:
        p = TRUE_PARAMS[s]
        log_y = (
            p["alpha"]
            + p["beta"]  * np.log(sinv[s])
            + p["gamma"] * np.log(gfcf[s])
            + p["zeta"]  * np.log(pop)
            + p["delta"] * irate
            + noise_sigma * rng.standard_normal(n_years)
        )
        sgdp[s] = np.exp(log_y)

    gdp_tot = sgdp["primary"] + sgdp["secondary"] + sgdp["tertiary"]
    return HistoricalData(
        gdp_tot=pd.DataFrame({"Year": years, "GDP_tot": gdp_tot}),
        population=pd.DataFrame({"Year": years, "Pop": pop}),
        sgdp=pd.DataFrame({
            "Year": years,
            "SGDP_primary": sgdp["primary"],
            "SGDP_secondary": sgdp["secondary"],
            "SGDP_tertiary": sgdp["tertiary"],
        }),
        sinv=pd.DataFrame({
            "Year": years,
            "SInv_primary": sinv["primary"],
            "SInv_secondary": sinv["secondary"],
            "SInv_tertiary": sinv["tertiary"],
        }),
        gfcf_pub=pd.DataFrame({
            "Year": years,
            "GFCF_pub_primary": gfcf["primary"],
            "GFCF_pub_secondary": gfcf["secondary"],
            "GFCF_pub_tertiary": gfcf["tertiary"],
        }),
        irate=pd.DataFrame({"Year": years, "iRate": irate}),
    )


# ---------------------------------------------------------------------------
# Recovery diagnostic
# ---------------------------------------------------------------------------


def recovery_metrics(hist: HistoricalData, shrinkage: float, region: str = "LAC") -> dict:
    """Return per-parameter dict of (estimated, std_error, true, abs_error,
    in_ci_95)."""
    priors = get_priors(region)
    coefs, _active, params = estimate_sector_coefficients(hist, priors, shrinkage)
    result: dict[str, dict] = {}
    for sector, true_p in TRUE_PARAMS.items():
        sect_d: dict[str, dict] = {}
        for p_name, true_v in true_p.items():
            est_v = coefs[sector][p_name]
            log_entry = next(
                (e for e in params if e.name == f"B2.{sector}.{p_name}"), None,
            )
            se = log_entry.std_error if (log_entry and log_entry.std_error) else float("nan")
            in_ci = abs(est_v - true_v) <= 1.96 * se if se == se else False  # NaN-safe
            sect_d[p_name] = {
                "true": true_v,
                "est": est_v,
                "se": se,
                "abs_err": abs(est_v - true_v),
                "in_ci_95": bool(in_ci),
                "origin": log_entry.origin if log_entry else "?",
            }
        result[sector] = sect_d
    return result


def print_recovery(label: str, m: dict) -> None:
    print(f"\n{'=' * 78}\n{label}\n{'=' * 78}")
    for sector, sect_d in m.items():
        print(f"\n  [{sector}]")
        print(f"  {'param':<6} {'true':>9} {'est':>10} {'± SE':>10} {'err':>9} {'in 95% CI':>10} origin")
        for p_name, d in sect_d.items():
            ci_mark = "Y" if d["in_ci_95"] else ("N" if d["se"] == d["se"] else "—")
            se_str = f"{d['se']:.4f}" if d["se"] == d["se"] else "n/a"
            print(
                f"  {p_name:<6} {d['true']:>+9.4f} {d['est']:>+10.4f} "
                f"{se_str:>10} {d['abs_err']:>+9.4f} {ci_mark:>10}  {d['origin']}"
            )


# ---------------------------------------------------------------------------
# Monte Carlo aggregation
# ---------------------------------------------------------------------------


def monte_carlo(
    n_reps: int,
    n_years: int,
    shrinkage: float,
    noise_sigma: float = 0.02,
    collinearity: float = 0.0,
) -> dict:
    """Run ``n_reps`` independent replications and return summary
    statistics per (sector, param)."""
    accum: dict[tuple, dict[str, list]] = {}
    for r in range(n_reps):
        hist = make_country(
            n_years=n_years,
            seed=1000 + r,
            noise_sigma=noise_sigma,
            collinearity=collinearity,
        )
        m = recovery_metrics(hist, shrinkage)
        for sector, sect_d in m.items():
            for p_name, d in sect_d.items():
                key = (sector, p_name)
                if key not in accum:
                    accum[key] = {"err": [], "se": [], "in_ci": []}
                accum[key]["err"].append(d["est"] - d["true"])
                accum[key]["se"].append(d["se"])
                accum[key]["in_ci"].append(d["in_ci_95"])

    summary: dict[tuple, dict] = {}
    for key, lists in accum.items():
        errs = np.array(lists["err"])
        ses = np.array([s for s in lists["se"] if s == s])
        coverage = float(np.mean(lists["in_ci"]))
        summary[key] = {
            "mean_err": float(np.mean(errs)),       # bias
            "std_err":  float(np.std(errs)),        # estimator dispersion across reps
            "rmse":     float(np.sqrt(np.mean(errs**2))),
            "mean_se":  float(np.mean(ses)) if ses.size else float("nan"),
            "coverage": coverage,                   # frac of 95% CIs containing truth
            "n_reps":   n_reps,
        }
    return summary


def print_mc_summary(label: str, s: dict) -> None:
    print(f"\n{'=' * 78}\n{label}\n{'=' * 78}")
    print(f"  {'sector':<10} {'param':<6} {'bias':>9} {'std(err)':>10} "
          f"{'RMSE':>9} {'mean SE':>9} {'95% cov':>8}")
    for (sector, p), d in s.items():
        print(
            f"  {sector:<10} {p:<6} {d['mean_err']:>+9.4f} {d['std_err']:>10.4f} "
            f"{d['rmse']:>9.4f} {d['mean_se']:>9.4f} {d['coverage']:>8.0%}"
        )


# ---------------------------------------------------------------------------
# Run the three rounds
# ---------------------------------------------------------------------------


def main() -> None:
    print("MITICA B2 — synthetic recovery test")
    print(f"True parameters: {TRUE_PARAMS}\n")

    # ---- Single-country illustrative example (clean conditions) ----
    hist = make_country(n_years=25, seed=42)
    for sh in [0.0, 0.5, 0.9]:
        m = recovery_metrics(hist, shrinkage=sh)
        print_recovery(f"Single replication · n=25 · shrinkage={sh}", m)

    # ---- Monte Carlo: ideal conditions ----
    print_mc_summary(
        "Monte Carlo · ideal (n=25 · noise sigma=0.02 · no collinearity · "
        "shrinkage=0.5 · 200 reps)",
        monte_carlo(n_reps=200, n_years=25, shrinkage=0.5),
    )

    # ---- Monte Carlo: short series ----
    print_mc_summary(
        "Monte Carlo · short series (n=10 · shrinkage=0.5 · 200 reps)",
        monte_carlo(n_reps=200, n_years=10, shrinkage=0.5),
    )

    # ---- Monte Carlo: high collinearity ----
    print_mc_summary(
        "Monte Carlo · high collinearity (n=25 · rho=0.85 · shrinkage=0.5 · 200 reps)",
        monte_carlo(n_reps=200, n_years=25, shrinkage=0.5, collinearity=0.85),
    )

    # ---- Monte Carlo: zero shrinkage (pure OLS) ----
    print_mc_summary(
        "Monte Carlo · ideal · shrinkage=0.0 (OLS) (n=25 · 200 reps)",
        monte_carlo(n_reps=200, n_years=25, shrinkage=0.0),
    )


if __name__ == "__main__":
    main()
