"use client";

import { use, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Wand2, CheckCircle2, Circle, Minus, Plus, TrendingDown, Sigma,
  Target, Settings2, ArrowRight, CheckCheck, AlertTriangle, X,
  GitCompare, ChevronDown, ChevronRight, Loader2,
} from "lucide-react";

import { api } from "@/lib/api";
import type {
  AutoAdjustments,
  CategoryForecast,
  CompareMethodsResponse,
  ModifierKind,
} from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { GasBreakdown } from "@/components/mitica/GasBreakdown";
import { cn } from "@/lib/utils";

// SI-008 audit trail: categories overridden by a sectoral module carry
// metadata.source (+ metadata.source_scenario). Everything else is projected
// by MITICA Core (ANNALIST by default).
const MODULE_SOURCE_LABELS: Record<string, string> = {
  energy_module: "Energy",
  fgases_module: "F-gases",
  transport_module: "Transport",
  lulucf_module: "LULUCF",
  waste_module: "Waste",
};

function provenanceOf(cat: CategoryForecast): {
  label: string;
  isModule: boolean;
  tooltip: string;
} {
  const src = typeof cat.metadata?.source === "string" ? (cat.metadata.source as string) : null;
  const moduleLabel = src ? MODULE_SOURCE_LABELS[src] : undefined;
  if (moduleLabel) {
    const scen =
      typeof cat.metadata?.source_scenario === "string"
        ? ` · scenario: ${cat.metadata.source_scenario}`
        : "";
    return {
      label: moduleLabel,
      isModule: true,
      tooltip: `projected by the ${moduleLabel} module (SI-008 override)${scen}`,
    };
  }
  return {
    label: cat.method,
    isModule: false,
    tooltip: `projected by MITICA Core (${cat.method})`,
  };
}

// Forecast.adjusted_categories messages carry a deterministic severity prefix
// ("warning: " | "info: "); the remainder is shown verbatim.
function splitSeverity(msg: string): { severity: "warning" | "info"; text: string } {
  if (msg.startsWith("warning:")) return { severity: "warning", text: msg.slice(8).trim() };
  if (msg.startsWith("info:")) return { severity: "info", text: msg.slice(5).trim() };
  return { severity: "warning", text: msg };
}

function autoAdjustmentsOf(cat: CategoryForecast): AutoAdjustments | null {
  const adj = cat.metadata?.auto_adjustments;
  return adj && typeof adj === "object" ? adj : null;
}

function autoAdjustmentTooltip(adj: AutoAdjustments): string {
  const parts: string[] = [];
  if (adj.lift_kt != null) {
    const years =
      adj.raw_negative_years != null && adj.projection_years != null
        ? ` — raw path negative in ${adj.raw_negative_years}/${adj.projection_years} projection years`
        : "";
    parts.push(
      `avoid_negative lifted the projection by ${adj.lift_kt.toLocaleString(undefined, {
        maximumFractionDigits: 0,
      })} kt CO2-eq${years}`
    );
  }
  if (adj.reference_lift_kt != null) {
    const years =
      adj.reference_raw_negative_years != null && adj.reference_projection_years != null
        ? ` (${adj.reference_raw_negative_years}/${adj.reference_projection_years} years negative)`
        : "";
    parts.push(
      `reference path lifted by ${adj.reference_lift_kt.toLocaleString(undefined, {
        maximumFractionDigits: 0,
      })} kt CO2-eq${years}`
    );
  }
  return parts.join("; ") || "lifted by the avoid-negative rule";
}

const MODIFIERS: {
  kind: ModifierKind;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}[] = [
  { kind: "AVOID_NEGATIVE", label: "Avoid negative", icon: Plus, description: "Shift negative forecast values up to zero (sectors 1/2/3/5)" },
  { kind: "AVOID_DECREASE", label: "Avoid decrease", icon: TrendingDown, description: "Enforce non-decreasing slope on the forecast" },
  { kind: "AVOID_INCREASE", label: "Avoid increase", icon: Minus, description: "Cap runaway increase at the historical slope" },
  { kind: "AVOID_OUTCOMES", label: "Remove outliers", icon: Sigma, description: "Interpolate values > 1.5σ outside historical mean" },
  { kind: "SMOOTH", label: "Smooth", icon: Wand2, description: "Savitzky-Golay smoothing, preserving historical" },
  { kind: "LINEAL_FIX", label: "Polynomial fit", icon: Settings2, description: "Re-extrapolate historical with a polynomial" },
];

export default function ValidatePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();

  const { data: forecast, isLoading } = useQuery({
    queryKey: ["forecast", id],
    queryFn: () => api.getForecast(id),
    retry: false,
  });

  const [selectedCode, setSelectedCode] = useState<string | null>(null);
  // FE-10: the dismissal is keyed to the forecast identity (created_at + the
  // warning content), so a refetch carrying NEW warnings re-shows the banner
  // instead of inheriting a stale dismissal.
  const [dismissedWarningsKey, setDismissedWarningsKey] = useState<string | null>(null);
  const warningsKey = useMemo(() => {
    if (!forecast) return null;
    const failed = Object.keys(forecast.failed_categories ?? {}).sort().join(",");
    const extrapolated = Object.keys(forecast.extrapolated_proxies ?? {}).sort().join(",");
    const adjusted = Object.keys(forecast.adjusted_categories ?? {}).sort().join(",");
    return `${forecast.created_at}|${failed}|${extrapolated}|${adjusted}`;
  }, [forecast]);
  // Reset the dismissal whenever the forecast identity changes.
  useEffect(() => {
    setDismissedWarningsKey((prev) => (prev !== null && prev !== warningsKey ? null : prev));
  }, [warningsKey]);
  useEffect(() => {
    if (forecast && !selectedCode && forecast.categories.length > 0) {
      setSelectedCode(forecast.categories[0].ipcc_code);
    }
  }, [forecast, selectedCode]);

  const apply = useMutation({
    mutationFn: (kind: ModifierKind) =>
      api.applyModifier(id, { category: selectedCode!, modifier: kind }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const validateOne = useMutation({
    mutationFn: ({ code, validated }: { code: string; validated: boolean }) =>
      api.validateCategory(id, code, validated),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const validateAll = useMutation({
    mutationFn: () => api.validateAll(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", id] });
      qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const selectedCat: CategoryForecast | undefined = useMemo(() => {
    return forecast?.categories.find((c) => c.ipcc_code === selectedCode);
  }, [forecast, selectedCode]);

  const total = forecast?.categories.length ?? 0;
  const validatedCount = forecast?.categories.filter((c) => c.validated).length ?? 0;
  const allValidated = total > 0 && validatedCount === total;

  if (isLoading)
    return (
      <div className="grid gap-4 md:grid-cols-[260px_1fr]">
        <Skeleton className="h-96" />
        <Skeleton className="h-96" />
      </div>
    );
  if (!forecast)
    return (
      <Card>
        <CardContent className="py-8 text-sm text-muted-foreground">
          No forecast available. Run a forecast first.
        </CardContent>
      </Card>
    );

  // Additive contract fields — absent in artifacts from older builds.
  const failedCategories = forecast.failed_categories ?? {};
  const extrapolatedProxies = forecast.extrapolated_proxies ?? {};
  const adjustedCategories = forecast.adjusted_categories ?? {};
  const nFailed = Object.keys(failedCategories).length;
  const nExtrapolated = Object.keys(extrapolatedProxies).length;
  const nAdjusted = Object.keys(adjustedCategories).length;
  const showWarnings =
    dismissedWarningsKey !== warningsKey &&
    (nFailed > 0 || nExtrapolated > 0 || nAdjusted > 0);

  // Jump to next unvalidated category after saving
  function goNextUnvalidated() {
    if (!forecast) return;
    const idx = forecast.categories.findIndex((c) => c.ipcc_code === selectedCode);
    const after = forecast.categories.slice(idx + 1);
    const before = forecast.categories.slice(0, idx);
    const next = [...after, ...before].find((c) => !c.validated);
    if (next) setSelectedCode(next.ipcc_code);
  }

  return (
    <div className="space-y-4">
      {/* ---- Forecast warnings (failed categories / extrapolated drivers) ---- */}
      {showWarnings && (
        <div className="relative rounded-md border border-amber-300 bg-amber-50 p-3 pr-10 text-xs text-amber-900">
          <button
            className="absolute right-2 top-2 rounded p-1 hover:bg-amber-100"
            onClick={() => setDismissedWarningsKey(warningsKey)}
            aria-label="Dismiss warnings"
          >
            <X className="h-3.5 w-3.5" />
          </button>
          <div className="flex items-center gap-1.5 font-medium">
            <AlertTriangle className="h-3.5 w-3.5" /> Forecast warnings
          </div>
          {nFailed > 0 && (
            <div className="mt-1.5">
              <span className="font-medium">
                {nFailed} {nFailed === 1 ? "category" : "categories"} failed and{" "}
                {nFailed === 1 ? "is" : "are"} excluded from totals:
              </span>
              <ul className="mt-0.5 list-disc pl-5">
                {Object.entries(failedCategories).map(([code, msg]) => (
                  <li key={code}>
                    <span className="font-mono">{code}</span> — {msg}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {nExtrapolated > 0 && (
            <div className="mt-1.5">
              <span className="font-medium">
                Drivers extrapolated beyond their last observed year:
              </span>{" "}
              {Object.entries(extrapolatedProxies)
                .map(([name, year]) => `${name} (≤${year})`)
                .join(", ")}
              . Projections past those years follow a linear time-trend, not the driver.
            </div>
          )}
          {nAdjusted > 0 && (
            <div className="mt-1.5">
              <span className="font-medium">
                Auto-adjustment notice — {nAdjusted}{" "}
                {nAdjusted === 1 ? "category was" : "categories were"} lifted by the
                avoid-negative rule; review them before validating.
              </span>
              <ul className="mt-0.5 list-disc pl-5">
                {Object.entries(adjustedCategories).map(([code, msg]) => {
                  const { severity, text } = splitSeverity(msg);
                  return (
                    <li
                      key={code}
                      className={
                        severity === "warning" ? "text-amber-900" : "text-muted-foreground"
                      }
                    >
                      <button
                        className="font-mono underline-offset-2 hover:underline"
                        onClick={() => setSelectedCode(code)}
                      >
                        {code}
                      </button>{" "}
                      — {text}
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* ---- Progress banner ---- */}
      <Card className={cn(allValidated && "border-emerald-500/40 bg-emerald-500/5")}>
        <CardContent className="flex items-center gap-4 py-4">
          <div className="flex-1">
            <div className="mb-1 flex items-center gap-2 text-sm font-medium">
              <span>Validation progress</span>
              <Badge variant={allValidated ? "success" : "outline"}>
                {validatedCount} / {total}
              </Badge>
            </div>
            <Progress value={total > 0 ? (validatedCount / total) * 100 : 0} />
            <p className="mt-1 text-xs text-muted-foreground">
              Each category must be explicitly validated before moving to PAMs.
              Applying a modifier resets the flag for that category.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => validateAll.mutate()}
            disabled={validateAll.isPending || allValidated}
          >
            <CheckCheck className="mr-2 h-4 w-4" />
            {allValidated ? "All validated" : "Accept all (no changes)"}
          </Button>
          {/* FE-09: `asChild disabled` only styles the <a> — it stays clickable.
              Render a real disabled <button> until everything is validated. */}
          {allValidated ? (
            <Button asChild>
              <Link href={`/projects/${id}/pams`}>
                Next: PAMs <ArrowRight className="ml-2 h-3 w-3" />
              </Link>
            </Button>
          ) : (
            <Button disabled>
              Next: PAMs <ArrowRight className="ml-2 h-3 w-3" />
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-[260px_1fr]">
        <Card className="h-fit">
          <CardHeader>
            <CardTitle className="text-base">Categories</CardTitle>
            <CardDescription>
              {validatedCount}/{total} validated
            </CardDescription>
          </CardHeader>
          <CardContent className="max-h-[70vh] overflow-y-auto px-2">
            <ul className="space-y-0.5">
              {forecast.categories.map((c) => {
                const prov = provenanceOf(c);
                return (
                  <li key={c.ipcc_code}>
                    <button
                      className={cn(
                        "flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors",
                        c.ipcc_code === selectedCode
                          ? "bg-primary/10 text-foreground"
                          : "hover:bg-muted"
                      )}
                      onClick={() => setSelectedCode(c.ipcc_code)}
                    >
                      {c.validated ? (
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                      ) : (
                        <Circle className="h-3.5 w-3.5 shrink-0 text-muted-foreground/40" />
                      )}
                      <span className="font-mono text-xs">{c.ipcc_code}</span>
                      {prov.isModule && (
                        <span
                          className="ml-auto shrink-0 rounded border border-primary/30 bg-primary/10 px-1 text-[9px] font-medium text-primary"
                          title={prov.tooltip}
                        >
                          {prov.label}
                        </span>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {selectedCat && (
            <>
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <CardTitle className="font-mono text-base">{selectedCat.ipcc_code}</CardTitle>
                      <CardDescription>
                        Method: {selectedCat.method} · Years {selectedCat.years[0]} –{" "}
                        {selectedCat.years.at(-1)}
                      </CardDescription>
                      {(selectedCat.proxies_used ?? []).length > 0 && (
                        <div className="mt-1.5 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
                          <span>Drivers used:</span>
                          {(selectedCat.proxies_used ?? []).map((p) => (
                            <span
                              key={p}
                              className="rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] text-foreground/80"
                            >
                              {p}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {(() => {
                        const adj = autoAdjustmentsOf(selectedCat);
                        if (!adj) return null;
                        return (
                          <Badge
                            variant="outline"
                            className={cn(
                              adj.severity === "warning"
                                ? "border-amber-400 bg-amber-100 text-amber-900"
                                : "border-muted-foreground/30 bg-muted text-muted-foreground"
                            )}
                            title={autoAdjustmentTooltip(adj)}
                          >
                            auto-lifted
                          </Badge>
                        );
                      })()}
                      {(() => {
                        const prov = provenanceOf(selectedCat);
                        return (
                          <Badge
                            variant={prov.isModule ? "secondary" : "outline"}
                            title={prov.tooltip}
                          >
                            {prov.isModule ? `${prov.label} module` : prov.label}
                          </Badge>
                        );
                      })()}
                      {selectedCat.validated ? (
                        <Badge variant="success">Validated ✓</Badge>
                      ) : (
                        <Badge variant="outline">Unvalidated</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <PlotlyChart
                    data={[
                      {
                        x: selectedCat.years,
                        y: selectedCat.historical,
                        type: "scatter",
                        mode: "lines+markers",
                        name: "Historical",
                        line: { color: "#0ea5e9", width: 2 },
                      },
                      {
                        x: selectedCat.years,
                        y: selectedCat.forecast,
                        type: "scatter",
                        mode: "lines+markers",
                        name: "Forecast (WOM)",
                        line: { color: "#0f766e", width: 2, dash: "dot" },
                      },
                    ]}
                    layout={{
                      yaxis: { title: { text: "kt CO₂ eq" } },
                      xaxis: { title: { text: "Year" } },
                    }}
                  />
                  <div className="mt-3 flex items-center justify-end gap-2">
                    {selectedCat.validated ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          validateOne.mutate({
                            code: selectedCat.ipcc_code,
                            validated: false,
                          })
                        }
                      >
                        Un-validate
                      </Button>
                    ) : (
                      <>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() =>
                            validateOne
                              .mutateAsync({
                                code: selectedCat.ipcc_code,
                                validated: true,
                              })
                              .then(() => goNextUnvalidated())
                          }
                          disabled={validateOne.isPending}
                        >
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          Validate + next
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Per-gas breakdown (BI-001) — only when the inventory has multi-gas data */}
              <GasBreakdown category={selectedCat} />

              {/* GUY-18 — compare forecasting methods (QA/QC) */}
              <CompareMethodsPanel
                projectId={id}
                category={selectedCat.ipcc_code}
              />

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Modifiers</CardTitle>
                  <CardDescription>
                    Each modifier rewrites this category's forecast and clears the validation flag —
                    re-check the chart before validating.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                    {MODIFIERS.map((m) => {
                      const Icon = m.icon;
                      return (
                        <Button
                          key={m.kind}
                          variant="outline"
                          className="h-auto flex-col items-start gap-1 p-3 text-left"
                          onClick={() => apply.mutate(m.kind)}
                          disabled={apply.isPending}
                        >
                          <div className="flex w-full items-center gap-2">
                            <Icon className="h-4 w-4 text-primary" />
                            <span className="font-medium">{m.label}</span>
                          </div>
                          <p className="text-xs font-normal text-muted-foreground">
                            {m.description}
                          </p>
                        </Button>
                      );
                    })}
                  </div>
                  {apply.error && (
                    <p className="mt-3 text-xs text-destructive">{(apply.error as Error).message}</p>
                  )}

                  <AdjustValuePanel
                    projectId={id}
                    category={selectedCat.ipcc_code}
                    years={selectedCat.years}
                  />
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function AdjustValuePanel({
  projectId,
  category,
  years,
}: {
  projectId: string;
  category: string;
  years: number[];
}) {
  const qc = useQueryClient();
  const [year, setYear] = useState<number>(years.at(-1) ?? 2030);
  const [target, setTarget] = useState<string>("");
  const apply = useMutation({
    mutationFn: () =>
      api.applyModifier(projectId, {
        category,
        modifier: "ADJUST_VALUE",
        params: { year, target_value: Number(target) },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["forecast", projectId] });
      qc.invalidateQueries({ queryKey: ["project", projectId] });
    },
  });

  return (
    <div className="mt-4 rounded-md border bg-muted/30 p-3">
      <div className="mb-2 flex items-center gap-2 text-sm font-medium">
        <Target className="h-4 w-4 text-primary" /> Anchor forecast to a target value
      </div>
      <div className="flex flex-wrap items-end gap-2">
        <div>
          <label className="text-xs text-muted-foreground">Year</label>
          <select
            className="block h-9 rounded-md border border-input bg-background px-2 text-sm"
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
          >
            {years.slice(-10).map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Target (kt CO2eq)</label>
          <input
            className="block h-9 w-32 rounded-md border border-input bg-background px-2 text-sm"
            type="number"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder="5000"
          />
        </div>
        <Button size="sm" disabled={!target || apply.isPending} onClick={() => apply.mutate()}>
          Anchor
        </Button>
      </div>
    </div>
  );
}

// GUY-18 — per-method line colors. ANNALIST (the primary/recommended method)
// is drawn bold; the comparison methods use distinct hues. Unknown methods
// fall back to a neutral grey.
const METHOD_COLORS: Record<string, string> = {
  ANNALIST: "#0f766e",
  SARIMAX: "#d97706",
  GBR: "#7c3aed",
  LINREG: "#db2777",
};
const FALLBACK_COLORS = ["#64748b", "#0891b2", "#65a30d", "#c026d3"];

// First index in `years` where any method has a non-null projected value —
// this is the projection-start boundary the chart marks with a vline.
function projectionStartYear(
  years: number[],
  series: Record<string, (number | null)[]>
): number | null {
  let firstIdx = Infinity;
  for (const path of Object.values(series)) {
    const i = path.findIndex((v) => v != null);
    if (i >= 0 && i < firstIdx) firstIdx = i;
  }
  return firstIdx === Infinity ? null : years[firstIdx] ?? null;
}

function CompareMethodsPanel({
  projectId,
  category,
}: {
  projectId: string;
  category: string;
}) {
  const [open, setOpen] = useState(false);
  // Cache the result per category so collapsing/re-expanding (or returning to a
  // category) doesn't re-fire the compute. Reset when the category changes.
  const [resultByCat, setResultByCat] = useState<
    Record<string, CompareMethodsResponse>
  >({});
  const result = resultByCat[category];

  const compare = useMutation({
    mutationFn: () => api.compareMethods(projectId, category),
    onSuccess: (data) => setResultByCat((prev) => ({ ...prev, [category]: data })),
  });

  // Collapse + clear the pending error whenever the selected category changes,
  // so the panel never shows stale state from a previous category.
  useEffect(() => {
    setOpen(false);
    compare.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  function toggle() {
    const next = !open;
    setOpen(next);
    // Lazily compute on first expand for this category.
    if (next && !result && !compare.isPending) compare.mutate();
  }

  const startYear = result
    ? projectionStartYear(result.years, result.series)
    : null;

  // Plot traces: bold historical + one line per method (color-keyed, legend).
  const traces = result
    ? [
        {
          x: result.years,
          y: result.historical,
          type: "scatter" as const,
          mode: "lines+markers" as const,
          name: "Historical",
          line: { color: "#0ea5e9", width: 3 },
        },
        ...Object.entries(result.series).map(([method, path], i) => ({
          x: result.years,
          y: path,
          type: "scatter" as const,
          mode: "lines" as const,
          name: method,
          line: {
            color:
              METHOD_COLORS[method] ??
              FALLBACK_COLORS[i % FALLBACK_COLORS.length],
            width: method === "ANNALIST" ? 3 : 1.75,
            dash: method === "ANNALIST" ? undefined : ("dot" as const),
          },
        })),
      ]
    : [];

  return (
    <Card>
      <CardHeader className="cursor-pointer select-none" onClick={toggle}>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {open ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
            <GitCompare className="h-4 w-4 text-primary" />
            <CardTitle className="text-base">Compare methods (QA/QC)</CardTitle>
          </div>
          {compare.isPending && (
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          )}
        </div>
        {open && (
          <CardDescription>
            ANNALIST is the primary, recommended method. SARIMAX and Gradient
            Boosting (GBR) are comparison / QA-QC methods (MITICA manual,
            Table 1) — use them to sanity-check the WoM, not as the default
            projection.
          </CardDescription>
        )}
      </CardHeader>
      {open && (
        <CardContent>
          {compare.isPending && (
            <div className="flex items-center gap-2 py-8 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Running comparison methods — this can take a couple of seconds…
            </div>
          )}
          {compare.isError && !compare.isPending && (
            <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
              <p className="font-medium">Could not compare methods.</p>
              <p className="mt-1 text-xs">{(compare.error as Error).message}</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-2"
                onClick={() => compare.mutate()}
              >
                Retry
              </Button>
            </div>
          )}
          {result && !compare.isPending && (
            <>
              <PlotlyChart
                data={traces}
                layout={{
                  yaxis: { title: { text: "kt CO₂ eq" } },
                  xaxis: { title: { text: "Year" } },
                  shapes:
                    startYear != null
                      ? [
                          {
                            type: "line",
                            x0: startYear,
                            x1: startYear,
                            yref: "paper",
                            y0: 0,
                            y1: 1,
                            line: {
                              color: "rgba(150,150,150,0.6)",
                              width: 1,
                              dash: "dash",
                            },
                          },
                        ]
                      : undefined,
                  annotations:
                    startYear != null
                      ? [
                          {
                            x: startYear,
                            yref: "paper",
                            y: 1,
                            text: `projection start ${startYear}`,
                            showarrow: false,
                            font: { size: 10, color: "#94a3b8" },
                            xanchor: "left",
                            yanchor: "bottom",
                          },
                        ]
                      : undefined,
                }}
              />
              {/* Per-method status notes — amber for any non-"ok" note. */}
              <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                {Object.entries(result.notes).map(([method, note], i) => {
                  const ok = note.trim().toLowerCase() === "ok";
                  return (
                    <span
                      key={method}
                      className={cn(
                        "inline-flex items-center gap-1",
                        ok ? "text-muted-foreground" : "text-amber-700"
                      )}
                    >
                      {i > 0 && (
                        <span className="text-muted-foreground/40">·</span>
                      )}
                      {!ok && <AlertTriangle className="h-3 w-3" />}
                      <span className="font-medium">{method}:</span>
                      <span>{note}</span>
                    </span>
                  );
                })}
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                Read-only QA/QC view — nothing here changes the WoM forecast.
              </p>
            </>
          )}
        </CardContent>
      )}
    </Card>
  );
}
