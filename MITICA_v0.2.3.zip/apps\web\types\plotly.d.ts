// Minimal ambient types for plotly.js-dist-min — we only re-export what we use.
declare module "plotly.js-dist-min" {
  export type Data = Record<string, unknown>;
  export type Layout = Record<string, unknown>;
  export type Config = Record<string, unknown>;
  const plotly: unknown;
  export default plotly;
}
