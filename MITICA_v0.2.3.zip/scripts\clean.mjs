#!/usr/bin/env node
// MITICA Next — nuke dev caches. Use when the dev stack behaves oddly.
// - apps/web/.next
// - Python __pycache__, .pytest_cache, .ruff_cache, .mypy_cache
// Does NOT touch: .venv, node_modules, data/
import { rmSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { execSync } from "node:child_process";

const ROOT = resolve(new URL("..", import.meta.url).pathname);

const TARGETS = [
  "apps/web/.next",
  ".ruff_cache",
  ".mypy_cache",
  ".pytest_cache",
];

for (const rel of TARGETS) {
  const abs = join(ROOT, rel);
  if (existsSync(abs)) {
    try {
      rmSync(abs, { recursive: true, force: true });
      console.log(`  removed ${rel}`);
    } catch (e) {
      console.log(`  failed  ${rel}  (${e.message})`);
    }
  }
}

// Python __pycache__ everywhere under packages/
try {
  execSync(
    `powershell -NoProfile -Command "Get-ChildItem -Path packages -Recurse -Directory -Filter '__pycache__' | Remove-Item -Recurse -Force"`,
    { cwd: ROOT, stdio: "pipe" }
  );
  console.log("  removed packages/**/__pycache__");
} catch {
  // fallthrough — not critical
}

console.log("\n  done.\n");
