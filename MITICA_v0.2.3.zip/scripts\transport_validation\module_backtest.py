"""
module_backtest.py — T4 BACKTEST GATE for the production transport module (SI-006).

Re-runs the validated real-data protocol of ``docs/TRANSPORT_BACKTEST.md``
(prototype spike, 2026-06-03) against the PRODUCTION module
``mitica_core.modules.transport.run_transport_module``:

  * calibrate on history <= 2012 (fed as ``road_co2_history``),
  * OBSERVED drivers (gdp_pc, population) through 2023 fed as the projected
    drivers (the TED trick — pin the driver path, test the response),
  * score the module WoM vs observed road/transport CO2 2013–2023 (MAPE + bias),
  * over every country the panel supports (prototype rule: >=6 hist, >=3 fut yrs).

Without fleet data the module resolves to tier T2, whose math is the prototype's
P2 persona. Three comparisons are produced:

  1. MODULE (production, shipped full-panel priors JSON) — the gate subject.
  2. PROTOTYPE personas P1/P1g/P2/P4 re-run on the SAME country set with the
     ORIGINAL prototype code (imported, not copied; leave-one-out priors) — the
     like-for-like drift baseline. The documented headline (median 14.2 %,
     p90 25.0 %) was P4 over the 10 focus countries.
  3. PARITY: P2 math recomputed in this script on the module's SHIPPED priors —
     isolates pure porting drift from the prior-calibration difference
     (leave-one-out per country vs the one shipped full-panel fit).

GATE: module median/p90 within ~2pp of the prototype baseline; no crashes or
non-finite outputs.

Outputs: results/module_backtest_results.csv + results/summary.txt.
Data honesty: every number comes from pandas parsing of the raw files on disk
(scripts/transport_validation/data/) — no LLM-extracted values anywhere.
"""
from __future__ import annotations

import sys
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):  # Windows cp1252 console safety
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))  # import the ORIGINAL prototype code, not a copy

import transport_prototype as proto  # noqa: E402  (fit_global/predict/run_persona/mape)

from mitica_core.modules.transport import (  # noqa: E402
    TransportConfig,
    TransportInputs,
    income_group,
    prior_log_co2pc,
    run_transport_module,
)

PANEL = HERE / "data" / "panel.csv"
RESULTS_DIR = HERE / "results"
CUTOFF = 2012
LAST_YEAR = 2023
MIN_HIST, MIN_FUT = 6, 3          # prototype inclusion rule
GATE_TOL_PP = 2.0                 # gate tolerance, percentage points
FOCUS = ["DEU", "ESP", "NOR", "MEX", "BRA", "THA", "IND", "VNM", "KEN", "ETH"]
# Documented prototype table (TRANSPORT_BACKTEST.md §4), P2 column — spot refs.
DOC_P2 = {"DEU": 6.2, "ESP": 27.7, "NOR": 13.4, "MEX": 14.5, "BRA": 7.9,
          "THA": 8.5, "IND": 26.0, "VNM": 43.8, "KEN": 35.4, "ETH": 12.1}


def mape(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(np.mean(np.abs((pred - actual) / actual)) * 100.0)


def bias(actual: np.ndarray, pred: np.ndarray) -> float:
    """Mean signed percentage error (pred vs actual)."""
    return float(np.mean((pred - actual) / actual) * 100.0)


def run_module_for(sub: pd.DataFrame, grp: str) -> tuple[dict[int, float], str]:
    """Run the production module: hist<=CUTOFF as inventory, observed drivers
    through LAST_YEAR as the projection. Returns ({year: kt}, tier)."""
    hist = sub[sub.Year <= CUTOFF]
    inp = TransportInputs(
        country_code=str(sub.iso3.iloc[0]),
        gdp_pc={int(r.Year): float(r.gdp_pc) for r in sub.itertuples()},
        population={int(r.Year): float(r.pop) for r in sub.itertuples()},
        # panel is in tonnes CO2-eq; module convention is kt
        road_co2_history={int(r.Year): float(r.transport_co2e_t) / 1e3
                          for r in hist.itertuples()},
    )
    cfg = TransportConfig(horizon_year=LAST_YEAR, dev_group=grp, scenarios=("WoM",))
    out = run_transport_module(inp, cfg)
    last_hist = max(inp.road_co2_history)
    pred = {r.year: r.total_kt_co2eq() for r in out.rows
            if r.scenario == "WoM" and r.year > last_hist}
    return pred, out.tier


def p2_with_shipped_priors(hist: pd.DataFrame, fut: pd.DataFrame, grp: str) -> np.ndarray:
    """The prototype P2 persona computed on the module's SHIPPED priors
    (prior_log_co2pc). Floors stay on the module's internal scale (tonnes:
    exp(prior)·pop, no /1e3) and the history is fed in kt exactly as the module
    receives it — so a faithful T2 port must reproduce the module output to
    numerical precision (kt)."""
    floor_h = np.array([np.exp(prior_log_co2pc(grp, g, int(y))) * p
                        for g, y, p in zip(hist.gdp_pc, hist.Year, hist["pop"])])
    floor_f = np.array([np.exp(prior_log_co2pc(grp, g, int(y))) * p
                        for g, y, p in zip(fut.gdp_pc, fut.Year, fut["pop"])])
    h = hist.assign(transport_co2e_t=hist.transport_co2e_t / 1e3)
    f = fut.assign(transport_co2e_t=fut.transport_co2e_t / 1e3)
    return proto.run_persona("P2", h, f, floor_h, floor_f)


def loo_floors(panel: pd.DataFrame, c: str, grp: str,
               hist: pd.DataFrame, fut: pd.DataFrame) -> tuple[np.ndarray, ...]:
    """Leave-one-out prior floors exactly as the prototype main() builds them."""
    gh = (hist["gdp_pc"].to_numpy(), hist["Year"].to_numpy(), hist["pop"].to_numpy())
    gf = (fut["gdp_pc"].to_numpy(), fut["Year"].to_numpy(), fut["pop"].to_numpy())

    prior_glob = proto.fit_global(panel[panel.iso3 != c])
    floor_glob_h = proto.predict(prior_glob, *gh, scale=1.0)
    floor_glob_f = proto.predict(prior_glob, *gf, scale=1.0)

    grp_df = panel[(panel.grp == grp) & (panel.iso3 != c)]
    n_grp = grp_df.iso3.nunique()
    prior_gcur = proto.fit_global(grp_df) if n_grp >= 5 else prior_glob
    wg = n_grp / (n_grp + proto.K_GROUP)
    floor_h = np.exp(wg * np.log(proto.predict(prior_gcur, *gh, 1.0))
                     + (1 - wg) * np.log(floor_glob_h))
    floor_f = np.exp(wg * np.log(proto.predict(prior_gcur, *gf, 1.0))
                     + (1 - wg) * np.log(floor_glob_f))
    return floor_glob_h, floor_glob_f, floor_h, floor_f


def main() -> int:
    RESULTS_DIR.mkdir(exist_ok=True)
    panel = pd.read_csv(PANEL)
    panel = panel[(panel.transport_co2e_t > 0) & (panel.gdp_pc > 0)
                  & (panel["pop"] > 0)].copy()

    # group every country by calibration-period mean income (prototype rule)
    grp_of = {}
    for c in panel.iso3.unique():
        s = panel[(panel.iso3 == c) & (panel.Year <= CUTOFF)]
        if len(s):
            grp_of[c] = proto.income_group(float(s["gdp_pc"].mean()))
    panel = panel.assign(grp=panel.iso3.map(grp_of))

    countries = []
    for c in sorted(panel.iso3.unique()):
        sub = panel[panel.iso3 == c]
        nh = int((sub.Year <= CUTOFF).sum())
        nf = int(((sub.Year > CUTOFF) & (sub.Year <= LAST_YEAR)).sum())
        if nh >= MIN_HIST and nf >= MIN_FUT:
            countries.append(c)
    print(f"=== T4 BACKTEST GATE — production transport module vs prototype ===")
    print(f"protocol: calibrate <= {CUTOFF}, project {CUTOFF+1}-{LAST_YEAR} | "
          f"{len(countries)} countries (of {panel.iso3.nunique()} in panel)\n")

    rows, crashes, nonfinite = [], [], []
    for i, c in enumerate(countries, 1):
        sub = panel[panel.iso3 == c].sort_values("Year")
        hist = sub[sub.Year <= CUTOFF]
        fut = sub[(sub.Year > CUTOFF) & (sub.Year <= LAST_YEAR)]
        grp = grp_of[c]
        fut_years = fut.Year.to_numpy()
        actual_kt = fut.transport_co2e_t.to_numpy() / 1e3

        row = dict(iso3=c, grp=grp, n_hist=len(hist), n_fut=len(fut),
                   gdp_pc_2023=float(sub.gdp_pc.iloc[-1]))

        # --- 1. PRODUCTION MODULE -----------------------------------------
        try:
            pred_map, tier = run_module_for(sub, grp)
            pred = np.array([pred_map.get(int(y), np.nan) for y in fut_years])
            if not np.all(np.isfinite(pred)) or np.any(pred <= 0):
                nonfinite.append(c)
                row.update(tier=tier, mape_module=np.nan, bias_module=np.nan,
                           bias_2023_module=np.nan, module_ok=False)
            else:
                row.update(tier=tier,
                           mape_module=mape(actual_kt, pred),
                           bias_module=bias(actual_kt, pred),
                           bias_2023_module=float((pred[-1] - actual_kt[-1])
                                                  / actual_kt[-1] * 100.0),
                           module_ok=True)
        except Exception as e:
            crashes.append((c, f"{type(e).__name__}: {e}"))
            row.update(tier="CRASH", mape_module=np.nan, bias_module=np.nan,
                       bias_2023_module=np.nan, module_ok=False)
            pred = None

        # --- 2. PARITY: P2 on shipped priors (porting-drift isolator) ------
        try:
            p2_ship = p2_with_shipped_priors(hist, fut, grp)
            row["mape_p2_shipped"] = mape(actual_kt, p2_ship)
            if pred is not None and np.all(np.isfinite(pred)):
                row["parity_maxreldiff_pct"] = float(
                    np.max(np.abs(pred - p2_ship) / p2_ship) * 100.0)
        except Exception as e:
            row["parity_error"] = f"{type(e).__name__}: {e}"

        # --- 3. PROTOTYPE personas, leave-one-out priors (original code) ---
        try:
            fg_h, fg_f, fl_h, fl_f = loo_floors(panel, c, grp, hist, fut)
            row["mape_P1"] = mape(actual_kt, proto.run_persona(
                "P1", hist, fut, fg_h, fg_f) / 1e3)
            row["mape_P1g"] = mape(actual_kt, proto.run_persona(
                "P1", hist, fut, fl_h, fl_f) / 1e3)
            row["mape_P2"] = mape(actual_kt, proto.run_persona(
                "P2", hist, fut, fl_h, fl_f) / 1e3)
            row["mape_P4"] = mape(actual_kt, proto.run_persona(
                "P4", hist, fut, fl_h, fl_f) / 1e3)
        except Exception as e:
            row["proto_error"] = f"{type(e).__name__}: {e}"

        rows.append(row)
        if i % 25 == 0:
            print(f"  ...{i}/{len(countries)} countries done")

    r = pd.DataFrame(rows)
    out_csv = RESULTS_DIR / "module_backtest_results.csv"
    r.to_csv(out_csv, index=False)

    # ---------------- summary ----------------
    lines = []

    def say(s=""):
        lines.append(s)
        print(s)

    ok = r[r.module_ok == True]  # noqa: E712
    say(f"\n=== RESULTS (n={len(r)} countries; module OK on {len(ok)}) ===")
    say(f"tiers resolved: {r.tier.value_counts().to_dict()}")
    say("")
    say(f"{'method':<28}{'median':>9}{'p90':>9}{'max':>9}")
    stats = {}
    for label, col in [("MODULE (production T2)", "mape_module"),
                       ("P2 shipped-priors parity", "mape_p2_shipped"),
                       ("proto P1 (global prior)", "mape_P1"),
                       ("proto P1g (group prior)", "mape_P1g"),
                       ("proto P2 (LOO, validated)", "mape_P2"),
                       ("proto P4 (LOO, validated)", "mape_P4")]:
        if col in r:
            s = r[col].dropna()
            stats[col] = (s.median(), s.quantile(0.9))
            say(f"{label:<28}{s.median():>8.1f}%{s.quantile(0.9):>8.1f}%{s.max():>8.1f}%")
    say("")
    say(f"module bias (mean signed err): median {ok.bias_module.median():+.1f}%, "
        f"2023-horizon bias median {ok.bias_2023_module.median():+.1f}%")
    if "parity_maxreldiff_pct" in r:
        pmax = r.parity_maxreldiff_pct.max()
        say(f"PARITY module vs P2-on-shipped-priors: max rel diff "
            f"{pmax:.2e}% across all countries/years "
            f"({'EXACT PORT' if pmax < 1e-6 else 'DIFFERS — investigate'})")

    # per-country drift vs the like-for-like prototype baseline (LOO P2)
    both = r.dropna(subset=["mape_module", "mape_P2"])
    drift = (both.mape_module - both.mape_P2)
    say(f"\nper-country drift MODULE - proto-P2(LOO): median {drift.median():+.2f}pp, "
        f"p90 |drift| {drift.abs().quantile(0.9):.2f}pp, max |drift| {drift.abs().max():.2f}pp")

    # focus-10 vs the documented table (TRANSPORT_BACKTEST.md §4, P2 column)
    say(f"\nfocus-10 (documented §4) — module vs doc P2:")
    say(f"{'iso3':<6}{'module':>9}{'docP2':>8}{'P2 rerun':>10}")
    for c in FOCUS:
        m = r[r.iso3 == c]
        if len(m):
            say(f"{c:<6}{m.mape_module.iloc[0]:>8.1f}%{DOC_P2[c]:>7.1f}%"
                f"{m.mape_P2.iloc[0]:>9.1f}%")
    foc = r[r.iso3.isin(FOCUS)].mape_module.dropna()
    say(f"focus-10 module aggregate: median {foc.median():.1f}% / p90 "
        f"{foc.quantile(0.9):.1f}%  (doc P2: 13.9/36.2, doc P4 headline: 14.2/25.0)")

    # ---------------- gate verdict ----------------
    med_m, p90_m = stats["mape_module"]
    med_b, p90_b = stats["mape_P2"]
    say(f"\n=== GATE (tolerance {GATE_TOL_PP}pp) ===")
    say(f"vs documented prototype headline (P4, focus-10): 14.2 / 25.0 "
        f"-> module {med_m:.1f} / {p90_m:.1f} "
        f"(delta {med_m-14.2:+.1f} / {p90_m-25.0:+.1f}pp)")
    say(f"vs prototype P2 re-run, same {len(both)} countries, LOO priors: "
        f"{med_b:.1f} / {p90_b:.1f} -> module {med_m:.1f} / {p90_m:.1f} "
        f"(delta {med_m-med_b:+.1f} / {p90_m-p90_b:+.1f}pp)")
    say(f"crashes: {len(crashes)} {[c for c, _ in crashes]}")
    say(f"non-finite outputs: {len(nonfinite)} {nonfinite}")
    for c, msg in crashes:
        say(f"  CRASH {c}: {msg}")

    gate_doc = abs(med_m - 14.2) <= GATE_TOL_PP and abs(p90_m - 25.0) <= GATE_TOL_PP
    gate_proto = abs(med_m - med_b) <= GATE_TOL_PP and abs(p90_m - p90_b) <= GATE_TOL_PP
    gate_clean = not crashes and not nonfinite
    say(f"\ngate vs documented 14.2/25.0 : {'PASS' if gate_doc else 'FAIL'}")
    say(f"gate vs like-for-like proto P2: {'PASS' if gate_proto else 'FAIL'}")
    say(f"gate crashes/non-finite       : {'PASS' if gate_clean else 'FAIL'}")

    worst = ok.sort_values("mape_module", ascending=False).head(5)
    say(f"\ntop-5 worst (module): " + ", ".join(
        f"{w.iso3} {w.mape_module:.0f}% ({w.grp}, bias {w.bias_module:+.0f}%)"
        for _, w in worst.iterrows()))

    (RESULTS_DIR / "summary.txt").write_text("\n".join(lines), encoding="utf-8")
    print(f"\nwrote {out_csv}")
    print(f"wrote {RESULTS_DIR / 'summary.txt'}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(1)
