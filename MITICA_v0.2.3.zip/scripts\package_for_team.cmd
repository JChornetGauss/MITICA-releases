@echo off
rem Thin wrapper around package_for_team.ps1 (PowerShell handles paths with
rem parens and spaces more reliably than cmd's parser).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0package_for_team.ps1" %*
