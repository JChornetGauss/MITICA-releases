"""
Estimate the v3 Solow closure priors from Penn World Table (PWT) 10.01.

Why PWT
-------
The default calibration (`calibrate_solow_priors.py`) uses WDI's gross
capital formation (NE.GDI.TOTL.KD) and bootstraps K_0 via perpetual
inventory from K_0 = 2.5·Y_0. PWT improves on this in three ways:

  1. ``cn`` / ``rkna``: capital stock measured directly (not constructed).
  2. ``emp``: persons engaged in millions — more accurate than P · π · (1-u).
  3. ``labsh``: labour-compensation share of GDP, lets us validate α=1/3.
  4. ``rtfpna``: TFP series pre-computed by PWT — useful as an external
     comparator for the Cobb-Douglas residual we estimate.

Specification
-------------
For each MITICA region r:

    g_{A,c,t} = g_{Y,c,t} - α · g_{K,c,t} - (1-α) · g_{L,c,t}

with α = 1/3 (decision #5 in MACRO_v3_DESIGN.md §2.8). Per country, mean
g_A, AR(1) coefficient, p5/p95 of country means. Per region, median across
countries.

Input file
----------
PWT 10.01 is distributed by the Groningen Growth and Development Centre.
Download manually from:

    https://www.rug.nl/ggdc/productivity/pwt/

and save as:

    scripts/macro_validation/wdi_data/pwt1001.xlsx

The script reads sheet ``Data`` and uses columns:
    countrycode, year, rgdpna, rkna, emp, labsh, hc, rtfpna.

If the file is absent the script prints clear instructions and exits 0
(non-fatal). The existing WDI-PIH calibration remains the loader's
default; this PWT calibration is supplementary.

Output
------
``scripts/macro_validation/wdi_data/calibrated_solow_priors_pwt.json``
with the same schema as the WDI calibration. When both files are present,
the loader (`g_Macro_Priors._load_calibrated_solow`) picks PWT.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path("scripts/macro_validation/wdi_data")
PWT_PATH = DATA_DIR / "pwt1001.xlsx"
OUT_PATH = DATA_DIR / "calibrated_solow_priors_pwt.json"

REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")
ALPHA = 1.0 / 3.0
MIN_OBS_PER_COUNTRY = 10


# ---------------------------------------------------------------------------


def load_pwt() -> pd.DataFrame | None:
    """Return the PWT panel from disk, or None if the file is absent."""
    if not PWT_PATH.exists():
        print(f"  [skip] PWT not found at {PWT_PATH.resolve()}")
        print()
        print("  Download PWT 10.01 from "
              "https://www.rug.nl/ggdc/productivity/pwt/")
        print(f"  and save the Excel file as: {PWT_PATH.resolve()}")
        print()
        print("  This is a one-off manual step because the GGDC download "
              "URLs are not stable across releases.")
        return None
    try:
        df = pd.read_excel(PWT_PATH, sheet_name="Data")
    except Exception as e:  # pragma: no cover — diagnostic only
        print(f"  [error] failed to read {PWT_PATH}: {e}")
        return None
    required = {"countrycode", "year", "rgdpna", "rkna", "emp"}
    missing = required - set(df.columns)
    if missing:
        print(f"  [error] PWT sheet 'Data' missing columns: {missing}")
        return None
    return df


def attach_regions(pwt: pd.DataFrame) -> pd.DataFrame:
    """Merge MITICA region from the existing countries.csv."""
    countries = pd.read_csv(DATA_DIR / "countries.csv")
    countries = countries.dropna(subset=["mitica_region"])
    df = pwt.rename(columns={"countrycode": "iso3", "year": "Year"})
    df = df.merge(countries[["iso3", "mitica_region"]], on="iso3", how="inner")
    return df


def compute_country_tfp(group: pd.DataFrame) -> pd.DataFrame:
    """Per-country: Cobb-Douglas residual g_A using PWT's K and L directly."""
    group = group.sort_values("Year").reset_index(drop=True)
    g = group[(group["rgdpna"] > 0) & (group["rkna"] > 0) & (group["emp"] > 0)]
    if len(g) < 3:
        return pd.DataFrame()
    log_Y = np.log(g["rgdpna"].values)
    log_K = np.log(g["rkna"].values)
    log_L = np.log(g["emp"].values)
    g_Y = np.diff(log_Y)
    g_K = np.diff(log_K)
    g_L = np.diff(log_L)
    g_A = g_Y - ALPHA * g_K - (1.0 - ALPHA) * g_L
    return pd.DataFrame({
        "iso3": g["iso3"].iloc[0],
        "Year": g["Year"].values[1:],
        "g_Y": g_Y, "g_K": g_K, "g_L": g_L, "g_A": g_A,
        "labsh": g["labsh"].values[1:] if "labsh" in g.columns
                  else np.full(len(g_Y), np.nan),
        "region": g["mitica_region"].iloc[0],
    })


def aggregate_country(g_A: np.ndarray) -> tuple[float, float, int]:
    n = len(g_A)
    if n < MIN_OBS_PER_COUNTRY:
        return np.nan, np.nan, n
    mean = float(np.mean(g_A))
    x = g_A[:-1] - mean
    y = g_A[1:] - mean
    denom = float(np.dot(x, x))
    rho = float(np.dot(x, y) / denom) if denom > 1e-12 else 0.0
    rho = max(-0.95, min(0.95, rho))
    return mean, rho, n


def calibrate(pwt_with_regions: pd.DataFrame) -> dict:
    parts = []
    for iso3, group in pwt_with_regions.groupby("iso3"):
        sub = compute_country_tfp(group)
        if len(sub) > 0:
            parts.append(sub)
    tfp_panel = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    if tfp_panel.empty:
        return {r: None for r in REGIONS}

    country_rows = []
    for iso3, group in tfp_panel.groupby("iso3"):
        g_A = group["g_A"].values
        if len(g_A) >= 20:
            lo, hi = np.percentile(g_A, [5, 95])
            g_A = g_A[(g_A >= lo) & (g_A <= hi)]
        mean, rho, n = aggregate_country(g_A)
        if np.isnan(mean):
            continue
        country_rows.append({
            "iso3": iso3, "region": group["region"].iloc[0],
            "mean_g_A": mean, "ar1": rho, "n_obs": n,
            "labsh_mean": float(np.nanmean(group["labsh"]))
                          if not group["labsh"].isna().all() else None,
        })
    country_df = pd.DataFrame(country_rows)

    out: dict = {}
    for r in REGIONS:
        sub = country_df[country_df["region"] == r]
        if len(sub) < 3:
            out[r] = None
            continue
        mean_g = float(np.median(sub["mean_g_A"]))
        rho = float(np.median(sub["ar1"]))
        p5 = float(np.percentile(sub["mean_g_A"], 5))
        p95 = float(np.percentile(sub["mean_g_A"], 95))
        labsh_med = (float(sub["labsh_mean"].dropna().median())
                     if sub["labsh_mean"].notna().any() else None)
        out[r] = {
            "tfp_growth_mean": mean_g,
            "tfp_growth_ar1":  rho,
            "tfp_growth_min":  p5,
            "tfp_growth_max":  p95,
            "labsh_median":    labsh_med,
            "implied_alpha":   (1.0 - labsh_med) if labsh_med is not None else None,
            "n_countries":     int(len(sub)),
        }
    return out


def write_json(calib: dict, path: Path) -> None:
    payload = {
        "_meta": {
            "source": ("Penn World Table 10.01 (Feenstra-Inklaar-Timmer). "
                       "Cobb-Douglas residual g_A = g_Y - α·g_K - (1-α)·g_L "
                       "with α=1/3 (decision #5); K from PWT 'rkna' (capital "
                       "at constant 2017 national prices); L from PWT 'emp' "
                       "(persons engaged, millions); Y from PWT 'rgdpna'."),
            "alpha":        ALPHA,
            "min_obs_per_country": MIN_OBS_PER_COUNTRY,
            "year_range":   None,
        },
        "regions": calib,
    }
    path.write_text(json.dumps(payload, indent=2))
    print(f"\nWrote PWT-based Solow priors to {path.resolve()}")


def print_summary(calib: dict) -> None:
    print("\n" + "=" * 100)
    print("PWT-based Solow priors -- regional Cobb-Douglas residuals")
    print("Compare against WDI-PIH calibration in calibrated_solow_priors.json")
    print("=" * 100)
    print(f"{'region':<10}  {'mean_g':>9}  {'p5':>9}  {'p95':>9}  "
          f"{'ar1':>7}  {'1-labsh':>8}  {'n':>4}")
    for r in REGIONS:
        d = calib.get(r)
        if d is None:
            print(f"{r:<10}  {'n/a':>9}  {'n/a':>9}  {'n/a':>9}  "
                  f"{'n/a':>7}  {'n/a':>8}  {'0':>4}")
            continue
        alpha_emp = d.get("implied_alpha")
        alpha_str = f"{alpha_emp:>8.3f}" if alpha_emp is not None else "n/a".rjust(8)
        print(f"{r:<10}  "
              f"{d['tfp_growth_mean']:+9.4f}  "
              f"{d['tfp_growth_min']:+9.4f}  "
              f"{d['tfp_growth_max']:+9.4f}  "
              f"{d['tfp_growth_ar1']:+7.3f}  "
              f"{alpha_str}  "
              f"{d['n_countries']:>4}")


def main() -> int:
    print("=== MITICA Solow priors -- PWT calibration ===\n")
    print("Loading PWT 10.01 from disk:")
    pwt = load_pwt()
    if pwt is None:
        return 0   # graceful skip
    print(f"  PWT loaded: {len(pwt):,} country-year rows")
    pwt = attach_regions(pwt)
    print(f"  After region merge: {len(pwt):,} rows ({pwt['iso3'].nunique()} countries)")
    print("\nRunning per-country Solow accounting using PWT's rkna and emp ...")
    calib = calibrate(pwt)
    print_summary(calib)
    write_json(calib, OUT_PATH)
    return 0


if __name__ == "__main__":
    sys.exit(main())
