"""Smoke probe: run the waste module on one EU country, print shapes/outputs."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.waste import WasteConfig, WasteInputs, run_waste_module  # noqa: E402

GGE = Path(__file__).parent / "data" / "eurostat" / "tidy_waste_gge.csv"
WDI = ROOT / "scripts" / "energy_validation" / "data" / "wdi"
GEO_ISO = {"DE": "DEU"}


def main() -> None:
    gge = pd.read_csv(GGE)
    pop = pd.read_csv(WDI / "pop.csv")
    gdp = pd.read_csv(WDI / "gdp_const_usd.csv")
    geo, iso = "DE", "DEU"

    p = pop[pop.iso3 == iso].set_index("year")["value"].to_dict()
    g = gdp[gdp.iso3 == iso].set_index("year")["value"].to_dict()
    gdp_pc = {y: g[y] / p[y] for y in p if y in g and p[y] > 0}

    inv: dict[str, dict[int, float]] = {}
    for cat, crf in (("5A", "CRF5A"), ("5B", "CRF5B"), ("5C", "CRF5C"), ("5D", "CRF5D")):
        d = gge[(gge.geo == geo) & (gge.src_crf == crf) & (gge.airpol == "GHG")]
        s = {int(r.year): float(r.value) for r in d.itertuples() if r.year <= 2018}
        if s:
            inv[cat] = s

    inp = WasteInputs(
        country_code=geo,
        population={y: p[y] for y in p if 1990 <= y <= 2024},
        gdp_pc={y: gdp_pc[y] for y in gdp_pc if 1990 <= y <= 2024},
        inventory=inv,
    )
    cfg = WasteConfig(horizon_year=2024, climate_zone="temperate_wet", scenarios=("WoM",))
    out = run_waste_module(inp, cfg)

    print("tier:", out.tier, "| income:", out.income_group)
    print("resolution_log:", out.resolution_log)
    print("flags:", [(f.test_id, f.variable) for f in out.validation_report])
    tot = out.scenario_totals_kt_co2eq()["WoM"]
    print("\n2018 base inventory per cat:", {c: round(inv[c][2018], 1) for c in inv})
    for y in (2018, 2019, 2022, 2024):
        row = next((r for r in out.rows if r.year == y), None)
        if row:
            print(y, "model by cat:", {k: round(v, 1) for k, v in row.by_category().items()},
                  "tot", round(row.total_kt_co2eq(), 1))
    # observed 2024
    for cat, crf in (("5A", "CRF5A"), ("5D", "CRF5D")):
        d = gge[(gge.geo == geo) & (gge.src_crf == crf) & (gge.airpol == "GHG")]
        obs = {int(r.year): float(r.value) for r in d.itertuples()}
        print(f"obs {cat} 2018/2024:", round(obs.get(2018, 0), 1), round(obs.get(2024, 0), 1))


if __name__ == "__main__":
    main()
