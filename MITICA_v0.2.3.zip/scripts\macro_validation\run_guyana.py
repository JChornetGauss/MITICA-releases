"""
run_guyana.py — run the MITICA macro module on REAL Guyana data and inspect the
ANNALIST proxies + the Layer-C validation report.

Guyana is the macro-v4 backtest's stated structural-break frontier: the post-2019
oil boom drove GDP per cápita from ~$6k (2019) to ~$33k (2024) and the
secondary/industry share to ~75 %. This is a hard real stress test — we expect
the validator to FIRE (that is the correct behaviour), not to project the boom as
if it were trend.

Data: cached WDI (real World Bank; the same vintage the macro priors were
calibrated on, so units are consistent), cross-checked live against the WB API.
"""
from __future__ import annotations

import sys
import pandas as pd

from mitica_core.modules.macro import (
    HistoricalData, MacroConfig, ProjectedInputs,
    as_annalist_proxies, run_macro_module,
)

W = "scripts/macro_validation/wdi_data"
ISO = "GUY"
START, HORIZON = 2000, 2035


def _series(fname: str, col: str) -> pd.DataFrame:
    d = pd.read_csv(f"{W}/{fname}.csv")
    d = d[(d.iso3 == ISO) & (d.Year >= START)][["Year", "value"]].rename(columns={"value": col})
    return d.sort_values("Year").reset_index(drop=True)


def main() -> int:
    gdp = _series("GDP_tot", "GDP_tot")
    pop = _series("Pop", "Pop")
    sp = _series("SGDP_primary", "SGDP_primary")
    ss = _series("SGDP_secondary", "SGDP_secondary")
    st = _series("SGDP_tertiary", "SGDP_tertiary")
    sgdp = sp.merge(ss, on="Year").merge(st, on="Year")
    # reconcile value-added sectoral GDP to GDP_tot (market prices) proportionally
    sgdp = sgdp.merge(gdp, on="Year")
    tot = sgdp[["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"]].sum(axis=1)
    for c in ("SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        sgdp[c] = sgdp[c] / tot * sgdp["GDP_tot"]
    sgdp = sgdp.drop(columns="GDP_tot")

    hist = HistoricalData(gdp_tot=gdp, population=pop, sgdp=sgdp)
    cfg = MacroConfig(region="LAC", horizon_year=HORIZON, estimation_shrinkage=0.5,
                      validate_historical=True, verbose=False)
    out = run_macro_module(hist, ProjectedInputs(), cfg)

    print("=== MITICA macro — Guyana (real WDI, structural-break stress test) ===")
    print(f"history {START}-2024 | horizon {HORIZON} | flow {out.flow_detected}")
    # observed boom
    g = gdp.set_index("Year")["GDP_tot"]
    pc19 = g.get(2019, float('nan')) / pop.set_index("Year")["Pop"].get(2019, 1)
    pc24 = g.get(2024, float('nan')) / pop.set_index("Year")["Pop"].get(2024, 1)
    print(f"observed GDP/cap: 2019 ${pc19:,.0f} → 2024 ${pc24:,.0f}  (~{pc24/pc19:.1f}x)\n")

    # ---- proxies ----
    px = as_annalist_proxies(out)
    print(f"proxies produced ({len(px)}): {', '.join(sorted(px))}")
    gdp = px["GDP"].set_index("Year")["GDP"]
    pcp = px["GDP_per_cap"].set_index("Year")["GDP_per_cap"]
    print("GDP_per_cap projection (selected years):")
    for y in (2024, 2027, 2030, 2035):
        if y in pcp.index:
            print(f"  {y}: ${pcp[y]:,.0f}")
    # implied projected growth
    if 2024 in pcp.index and HORIZON in pcp.index:
        import numpy as np
        cagr = (pcp[HORIZON] / pcp[2024]) ** (1 / (HORIZON - 2024)) - 1
        print(f"  implied GDP/cap CAGR 2024→{HORIZON}: {cagr*100:.1f}%/yr")

    # sectoral structure projection
    sh = out.sgdp.set_index("Year")
    print("secondary (industry/oil) GDP share:")
    for y in (2024, 2030, 2035):
        if y in sh.index:
            row = sh.loc[y]
            tot = row["SGDP_primary"] + row["SGDP_secondary"] + row["SGDP_tertiary"]
            print(f"  {y}: {row['SGDP_secondary']/tot*100:.0f}%")

    # ---- validation ----
    print(f"\n=== validation report ({len(out.validation_report)} flags) ===")
    order = {"red": 0, "amber": 1, "info": 2}
    for f in sorted(out.validation_report, key=lambda x: order.get(x.severity, 9)):
        print(f"  [{f.severity:<5}] {f.test_id:<8} {f.variable:<16} {f.message[:90]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
