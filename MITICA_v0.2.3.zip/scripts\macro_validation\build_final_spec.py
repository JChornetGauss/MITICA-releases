"""Render the canonical FINAL SPECIFICATION of the MITICA macro module to PDF.

This is the definitive reference document: it covers the mathematical model,
the Bayesian estimation framework, the Layer C validation tests, the full
calibration pipeline, all calibrated values per region with bootstrap CIs,
the empirical validation results, and the recommended operational
configuration.

Output: docs/MITICA_MACRO_FINAL_SPEC.pdf
"""

from __future__ import annotations

import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle,
                                PageBreak, KeepTogether)

OUT = Path("docs/MITICA_MACRO_FINAL_SPEC.pdf")
WDI_DIR = Path("scripts/macro_validation/wdi_data")

# ---------- styles -----------------------------------------------------------
styles = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=16, spaceBefore=18,
                    spaceAfter=8, textColor=colors.HexColor("#0b1d4f"),
                    borderPadding=4, leftIndent=0, fontName="Helvetica-Bold")
H2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=12.5,
                    spaceBefore=12, spaceAfter=5,
                    textColor=colors.HexColor("#1a3268"), fontName="Helvetica-Bold")
H3 = ParagraphStyle("H3", parent=styles["Heading3"], fontSize=11,
                    spaceBefore=10, spaceAfter=3,
                    textColor=colors.HexColor("#2b3a67"), fontName="Helvetica-Bold")
H4 = ParagraphStyle("H4", parent=styles["Heading4"], fontSize=10,
                    spaceBefore=7, spaceAfter=2,
                    textColor=colors.HexColor("#444"), fontName="Helvetica-Oblique")
BODY = ParagraphStyle("Body", parent=styles["BodyText"], fontSize=10,
                      leading=13, alignment=TA_JUSTIFY, spaceAfter=4)
BULLET = ParagraphStyle("Bullet", parent=BODY, leftIndent=14, spaceAfter=2)
EQN = ParagraphStyle("Eqn", parent=styles["BodyText"], fontSize=10,
                     leading=13, alignment=TA_CENTER, spaceBefore=6,
                     spaceAfter=6, textColor=colors.HexColor("#202020"),
                     fontName="Courier",
                     backColor=colors.HexColor("#f7f7fc"),
                     borderPadding=4, borderColor=colors.HexColor("#dde4f2"),
                     borderWidth=0.5)
NOTE = ParagraphStyle("Note", parent=BODY, fontSize=9, textColor=colors.gray,
                      spaceAfter=2)
ABSTRACT = ParagraphStyle("Abstract", parent=BODY, fontSize=10, leading=13,
                          leftIndent=1.2*cm, rightIndent=1.2*cm,
                          backColor=colors.HexColor("#f3f5fa"),
                          borderColor=colors.HexColor("#dde4f2"),
                          borderPadding=10, borderWidth=0.5)
TITLE = ParagraphStyle("Title", parent=styles["Title"], fontSize=22,
                       textColor=colors.HexColor("#0b1d4f"),
                       spaceAfter=8, alignment=TA_CENTER)
SUB = ParagraphStyle("Sub", parent=BODY, fontSize=13, alignment=TA_CENTER,
                     textColor=colors.HexColor("#444"))
AUTHOR = ParagraphStyle("Author", parent=BODY, fontSize=11,
                        alignment=TA_CENTER, textColor=colors.HexColor("#333"),
                        spaceAfter=20)


def P(s: str, sty=BODY) -> Paragraph:
    return Paragraph(s, sty)


def equation(text: str) -> Paragraph:
    return P(text, EQN)


def section(num, title, level=1):
    sty = {1: H1, 2: H2, 3: H3, 4: H4}[level]
    return P(f"{num}&nbsp;&nbsp; {title}", sty)


def table_with_header(data, col_widths=None, header_bg="#0b1d4f",
                      header_fg="#ffffff", highlight_cells=None,
                      highlight_rows=None):
    t = Table(data, colWidths=col_widths, hAlign="LEFT")
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(header_bg)),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.HexColor(header_fg)),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME",   (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",   (0, 0), (-1, -1), 8.5),
        ("ALIGN",      (1, 0), (-1, -1), "RIGHT"),
        ("ALIGN",      (0, 0), (0, -1), "LEFT"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
            [colors.white, colors.HexColor("#f7f7fc")]),
        ("LINEBELOW", (0, 0), (-1, 0), 1.0, colors.HexColor("#0b1d4f")),
        ("BOX",       (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for ri in (highlight_rows or []):
        style.append(("BACKGROUND", (0, ri), (-1, ri),
                      colors.HexColor("#dfeacb")))
    for (r, c) in (highlight_cells or []):
        style.append(("BACKGROUND", (c, r), (c, r),
                      colors.HexColor("#dfeacb")))
        style.append(("FONTNAME", (c, r), (c, r), "Helvetica-Bold"))
    t.setStyle(TableStyle(style))
    return t


# ---------------------------------------------------------------------------
# Load calibrated priors from JSON for live tables
# ---------------------------------------------------------------------------

def _load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


CALIB_B2 = _load_json(WDI_DIR / "calibrated_priors.json") or {}
CALIB_E  = _load_json(WDI_DIR / "calibrated_energy_priors.json") or {}


def _fmt(v, digits=3):
    if v is None or (isinstance(v, float) and (v != v)):
        return "n/a"
    return f"{v:+.{digits}f}"


def _fmt_with_se(v, se, digits=3):
    s = _fmt(v, digits)
    if se is None or (isinstance(se, float) and se != se):
        return s
    return f"{s} ({se:.2f})"


# ---------------------------------------------------------------------------
# Story builder
# ---------------------------------------------------------------------------


def build_story() -> list:
    s: list = []

    # ============================================================
    # COVER
    # ============================================================
    s.append(Spacer(1, 2*cm))
    s.append(P("MITICA Macroeconomic Module", TITLE))
    s.append(P("Final Specification, Calibration, and Validation", SUB))
    s.append(Spacer(1, 0.5*cm))
    s.append(P("Version 2.0  &mdash;  May 2026", SUB))
    s.append(Spacer(1, 1.5*cm))
    s.append(P("Gauss  &middot;  for the UNFCCC Secretariat", AUTHOR))
    s.append(Spacer(1, 1*cm))
    s.append(P(
        "This document is the canonical reference for the MITICA macro module "
        "(SI-002). It supersedes the v1.1s specification and replaces it with "
        "a Bayesian-ridge estimation framework, four optional alternative "
        "functional forms motivated by structural economics, a WDI/Eurostat-"
        "calibrated regional prior system, and an eight-test validation "
        "layer. The module is the entry point for MITICA's sectoral pipeline "
        "(Energy, LULUCF, F-gases, Transport, Waste): given an inventory "
        "year T and a horizon H, it produces the macroeconomic drivers that "
        "the sectoral modules consume as exogenous inputs.",
        ABSTRACT,
    ))
    s.append(Spacer(1, 0.3*cm))
    s.append(P(
        "<b>Headline metrics</b>: 138 unit tests pass; Monte Carlo coverage "
        "of 95% credible intervals is 92-100% on every parameter; on a "
        "25-country EU-27 out-of-sample backtest (train 1995-2005, test "
        "2006-2024) the recommended configuration achieves median tertiary "
        "MAPE of 5.14% in mature HIC; on a 29-country EU-29 energy backtest "
        "the calibrated intensity-convergence form delivers -4.8 percentage "
        "points on manufacturing MAPE versus the legacy log-log baseline.",
        ABSTRACT,
    ))

    s.append(PageBreak())

    # ============================================================
    # 1. EXECUTIVE SUMMARY
    # ============================================================
    s.append(section("1.", "Executive summary"))
    s.append(P(
        "The macro module was rebuilt in May 2026 around three principles:",
        BODY))
    s.append(P("<b>1. Honest estimation.</b> Drivers absent from the user's "
               "historical data are <i>never synthesised</i>. A coefficient "
               "whose driver is missing stays at the regional prior and is "
               "tagged <i>calibrated</i> so the user can see which "
               "parameters carry country information.", BULLET))
    s.append(P("<b>2. Bayesian shrinkage with proper noise normalisation.</b> "
               "The posterior on the coefficients is "
               "&Sigma;_post = (X'X/&sigma;&sup2; + &Sigma;_prior&#8315;&sup1;)&#8315;&sup1;, "
               "matching the standard Gaussian-Gaussian conjugate update. "
               "The v1.1s formulation (&Sigma;_post = &sigma;&sup2; "
               "(X'X + &lambda;I)&#8315;&sup1;) collapsed the credible "
               "intervals at high shrinkage and was replaced.", BULLET))
    s.append(P("<b>3. Structural alternatives, opt-in.</b> Four new "
               "functional forms (M7 Bennett, M8 intensity convergence, "
               "M8-bis Kuznets-Chenery linear and quadratic, M9 saturation) "
               "coexist with the legacy log-log via per-block config flags "
               "(<font face='Courier'>b2_form, b3_form, b5_form, b6_form"
               "</font>). Defaults preserve v1.1s output.", BULLET))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>What is new vs v1.1s</b>", H3))
    s.append(table_with_header([
        ["Block", "v1.1s",  "v2.0 (this spec)"],
        ["B2 estimation", "Ridge with bug in &Sigma;_post; missing drivers synthesised",
         "Closed-form Bayesian; active-driver discovery; bootstrap CIs"],
        ["B2 forms",   "log_log",         "log_log, kuznets_chenery, kuznets_chenery_quad"],
        ["B3 form",    "constant share",  "constant or bennett_logistic"],
        ["B5 form",    "log_log",         "log_log or intensity_convergence"],
        ["B6 form",    "log_log",         "log_log or saturation (quadratic)"],
        ["Priors",     "Hand-coded stylised", "WDI + Eurostat calibrated; bootstrap-validated"],
        ["Regions",    "6 (LAC SSA MENA APAC EEU HIC)",
         "7 (added HIC_TRANS for transitioning high-income)"],
        ["Layer C",    "T1-T6 (6 tests)", "T1-T8 (added T7 plausibility, T8 structural break)"],
        ["Validation", "None",            "Monte Carlo recovery + EU-27 backtest + EU-29 SED backtest"],
        ["Tests",      "0 dedicated",     "46 macro unit tests, 138 total in core"],
    ], col_widths=[3*cm, 5.5*cm, 8*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(P("<b>Key empirical findings</b>", H3))
    s.append(P("<b>1.</b> <b>Industrial decoupling in EU is 2.5x stronger</b> "
               "than the stylised prior assumed: calibrated &psi;_manufacturing "
               "= -1.23 (HIC) and -1.04 (HIC_TRANS) in the intensity-convergence "
               "form, with bootstrap CI tight around -1.0 to -1.5. ETS pricing, "
               "energy-efficiency directives, and deindustrialisation are all "
               "consistent with this magnitude.", BULLET))
    s.append(P("<b>2.</b> <b>EU services and tertiary GDP grow supra-linearly</b> "
               "in mature HIC: &zeta;_tertiary = +1.47 (level form), robustly "
               "estimated. The simpler log-log form with this calibrated "
               "&zeta; achieves tertiary MAPE 5.14% in EU-27, beating all "
               "Kuznets-Chenery variants which over-correct.", BULLET))
    s.append(P("<b>3.</b> <b>The Kuznets hump in secondary GDP is real but "
               "noisy.</b> Bootstrap CIs show that &kappa; and &kappa;&sup2; "
               "in B2 are mostly NOT statistically distinguishable from zero "
               "at the regional level (except HIC_TRANS secondary). The wide "
               "priors (&sigma;_&kappa;=0.50) let the country data dominate "
               "&mdash; the right place to be given the global signal is "
               "weak.", BULLET))
    s.append(P("<b>4.</b> <b>The dominant residual error is regime change, "
               "not functional form.</b> Post-2008 EU MAPE is 15-30% in "
               "secondary across all forms. No structural model trained "
               "pre-2008 can predict the financial crisis. Layer C T8 fires "
               "for 10 of 25 EU-27 countries to alert the user.", BULLET))

    s.append(PageBreak())

    # ============================================================
    # 2. ARCHITECTURE
    # ============================================================
    s.append(section("2.", "Module architecture"))
    s.append(P(
        "The macro module is one of three top-level packages in the "
        "monorepo: <font face='Courier'>mitica_core</font> (scientific "
        "core, Python library), <font face='Courier'>mitica_api</font> "
        "(FastAPI HTTP layer), and <font face='Courier'>apps/web</font> "
        "(Next.js frontend wizard). The module lives at "
        "<font face='Courier'>packages/core/src/mitica_core/modules/macro/</font> "
        "and produces, for every year t in [T+1, H], the macroeconomic "
        "drivers that the sectoral modules (Energy, LULUCF, F-gases, "
        "Transport, Waste) consume as exogenous inputs.", BODY))

    s.append(section("2.1", "Layers", level=2))
    s.append(table_with_header([
        ["Layer", "Role",            "Source file"],
        ["A",  "Accounting identities + total energy demand derivation",
         "g_Macro_LayerA.py"],
        ["B1", "Population &mdash; forward demographic projection",
         "g_Macro_LayerB1.py"],
        ["B2", "Sectoral GDP SGDP_s (primary / secondary / tertiary)",
         "g_Macro_LayerB2.py"],
        ["B3", "Primary decomposition: crops / livestock / other",
         "g_Macro_LayerB3_B4.py"],
        ["B4", "Livestock heads and animal productivity",
         "g_Macro_LayerB3_B4.py"],
        ["B5", "Sectoral energy demand SED_k (6 energy sectors)",
         "g_Macro_LayerB5_B6.py"],
        ["B6", "Residential energy demand SED_hh",
         "g_Macro_LayerB5_B6.py"],
        ["B7", "Fuel-mix shares per sector",
         "g_Macro_LayerB5_B6.py"],
        ["C",  "Validation report (T1-T8 tests)",
         "g_Macro_LayerC.py"],
    ], col_widths=[1.2*cm, 8.5*cm, 6.5*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(section("2.2", "User input flows (F1 / F2 / F3)", level=2))
    s.append(P("The solver classifies user input into one of three flows:",
               BODY))
    s.append(P("<b>F1 &mdash; full set:</b> the user supplies GDP_tot, Pop, and "
               "SGDP for the horizon. The module respects these paths "
               "verbatim for the operative output and runs T7 to flag "
               "implausible aspirations.", BULLET))
    s.append(P("<b>F2 &mdash; partial:</b> at least one but not all of the "
               "core variables is supplied (typical NDC use case: only "
               "GDP_tot is pinned). The module fills the rest from the B2 "
               "estimator.", BULLET))
    s.append(P("<b>F3 &mdash; off-the-priors:</b> nothing projected. The "
               "module runs entirely off the regional priors and the user's "
               "<i>historical</i> data.", BULLET))
    s.append(P("In all flows the module preserves a parallel <i>model-only</i> "
               "path (no user overrides) for the plausibility test (T7) and "
               "the structural-break detector (T8).", BODY))

    s.append(PageBreak())

    # ============================================================
    # 3. MATHEMATICAL MODEL
    # ============================================================
    s.append(section("3.", "Mathematical model"))

    s.append(section("3.1", "Notation", level=2))
    s.append(P(
        "<b>Indices.</b> c = country; t = year; s &isin; "
        "{primary, secondary, tertiary} = economic sector; "
        "k &isin; {primary, manufacturing, construction, services, "
        "transport_pass, transport_freight} = energy sector; "
        "r &isin; {LAC, SSA, MENA, APAC, EEU, HIC, HIC_TRANS} = MITICA region.",
        BODY))
    s.append(P(
        "<b>Core variables.</b> GDP_tot total GDP; Pop population; "
        "GDPpc = GDP_tot / Pop; SGDP_s sectoral GDP; SInv_s sectoral "
        "investment; GFCF_pub_s public sectoral capital formation; "
        "iRate policy / effective interest rate; SED_k sectoral final "
        "energy consumption; SED_hh residential final energy consumption.",
        BODY))

    s.append(section("3.2", "Layer A &mdash; accounting identities", level=2))
    s.append(P("Two identities are enforced both on the historical data and "
               "on the projected output:", BODY))
    s.append(equation(
        "GDP_tot,t = SGDP_primary,t + SGDP_secondary,t + SGDP_tertiary,t   (T1)"))
    s.append(equation(
        "share_crops + share_livestock + share_other = 1                   (T1')"))
    s.append(P("Violations of T1 fire a <b>red</b> validation flag and abort "
               "the projection. Total energy demand TED is always derived as "
               "the sum of B5 + B6 outputs; non-finite or negative TED also "
               "fires red. See <font face='Courier'>g_Macro_LayerA.py</font>.",
               BODY))

    s.append(section("3.3", "Layer B1 &mdash; population", level=2))
    s.append(P("Forward population projection respects user-supplied paths "
               "(when in F1/F2 with Pop). In F3, projection uses a "
               "constant-growth extension of the last observed growth rate. "
               "Detailed demographic decomposition is out of scope; users "
               "with UN WPP scenarios feed them via F1/F2.", BODY))

    s.append(section("3.4", "Layer B2 &mdash; sectoral GDP", level=2))
    s.append(P("Three forms coexist, selected via "
               "<font face='Courier'>MacroConfig.b2_form</font>. Let "
               "Y_s,t = log SGDP_s,t and "
               "&eta;_s,t ~ N(0, &sigma;&sup2;_s).", BODY))

    s.append(P("<b>(LL) log-log</b> (default, v1.1s parity)", H3))
    s.append(equation(
        "Y_s,t = &alpha;_s + &beta;_s log SInv_s,t + &gamma;_s log GFCF_pub_s,t "
        "+ &zeta;_s log Pop_t + &delta;_s iRate_t + &eta;_s,t"))

    s.append(P("<b>(KC) Kuznets-Chenery linear</b> (M8-bis)", H3))
    s.append(P("Adds an income shifter using lag-1 GDPpc (exogenous in "
               "projection):", BODY))
    s.append(equation(
        "Y_s,t = ... + &kappa;_s log(GDPpc_{t-1})"))

    s.append(P("<b>(KCQ) Kuznets-Chenery quadratic</b> (M8-bis hump)", H3))
    s.append(P("Adds a quadratic in lag-1 log-GDPpc to absorb the "
               "industrial inverse-U:", BODY))
    s.append(equation(
        "Y_s,t = ... + &kappa;_s log(GDPpc_{t-1}) "
        "+ &kappa;&sup2;_s [log(GDPpc_{t-1})]&sup2;"))

    s.append(P("<b>Active-driver discovery.</b> Each candidate driver enters "
               "the regression only if the user supplied historical data for "
               "it with at least 3 non-null observations and positive "
               "values. Drivers without history have their coefficient fixed "
               "at the regional prior, tagged <i>calibrated</i>.", BODY))

    s.append(section("3.5", "Layer B3 &mdash; primary decomposition", level=2))
    s.append(P("Two forms via <font face='Courier'>b3_form</font>.", BODY))
    s.append(P("<b>(C) constant</b> (default, v1.1s)", H3))
    s.append(P("share_crops_t and share_livestock_t held at the last "
               "observed value (or the regional default when no history "
               "exists).", BODY))
    s.append(P("<b>(BL) bennett_logistic</b> (M7)", H3))
    s.append(P("Models the livestock share via the standard logit-linear "
               "regression on log(GDPpc) to capture Bennett's law:", BODY))
    s.append(equation(
        "logit(share_livestock_t) = a_B + b_B log(GDP/Pop_t)"))
    s.append(P("where logit(p) = log(p / (1-p)). share_other is held at the "
               "regional prior; share_crops = 1 &minus; share_livestock "
               "&minus; share_other. b_B &gt; 0 encodes Bennett's law: "
               "richer countries eat more animal protein, raising the "
               "livestock share of agricultural GDP.", BODY))

    s.append(section("3.6", "Layer B4 &mdash; livestock heads", level=2))
    s.append(equation(
        "log Heads_t = &alpha;_g + &beta;_g log SGDP_prim_livestock,t "
        "&minus; &gamma;_g log prod_animal_t + &eta;_g,t"))
    s.append(P("Animal productivity evolves through convergence to a "
               "regional target:", BODY))
    s.append(equation(
        "prod_animal_t = prod_animal_{t-1} + &theta;_g (prod_animal* "
        "&minus; prod_animal_{t-1})"))

    s.append(section("3.7", "Layer B5 &mdash; sectoral energy demand", level=2))
    s.append(P("Two forms via <font face='Courier'>b5_form</font>.", BODY))
    s.append(P("<b>(LL) log-log</b> (default, v1.1s)", H3))
    s.append(equation(
        "log SED_k,t = &alpha;_k + &beta;_k log d&sup1;_k,t "
        "[+ &gamma;_k log d&sup2;_k,t] + &eta;_k,t"))
    s.append(P("d&sup1; is the primary activity driver (e.g. SGDP_secondary "
               "for manufacturing), d&sup2; the optional secondary driver "
               "(Pop for passenger transport).", BODY))

    s.append(P("<b>(IC) intensity convergence</b> (M8, Bashmakov 2007)", H3))
    s.append(equation(
        "log SED_k,t = &phi;_k + log scale_k,t + &psi;_k log(GDP/Pop_t) + &eta;_k,t"))
    s.append(P("Equivalently log(SED_k / scale_k) = &phi;_k + &psi;_k "
               "log(GDPpc). The activity elasticity is pinned to 1; the "
               "income elasticity of intensity &psi;_k carries the secular "
               "trend. &psi;_k &lt; 0 means efficiency-driven decoupling.",
               BODY))

    s.append(section("3.8", "Layer B6 &mdash; residential energy", level=2))
    s.append(P("Two forms via <font face='Courier'>b6_form</font>.", BODY))
    s.append(P("<b>(LL) log-log</b> (default)", H3))
    s.append(equation(
        "log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) "
        "+ &zeta;_hh log Pop_t + &eta;_hh,t"))
    s.append(P("<b>(SAT) saturation</b> (M9, quadratic-in-log)", H3))
    s.append(equation(
        "log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) "
        "+ &gamma;_hh [log(GDP/Pop_t)]&sup2; + &zeta;_hh log Pop_t + &eta;_hh,t"))
    s.append(P("With &gamma;_hh &lt; 0 the income response decelerates at "
               "high GDP/Pop (appliance saturation). The inflection point is "
               "log(GDP/Pop)* = &minus;&beta;_hh / (2 &gamma;_hh).", BODY))

    s.append(section("3.9", "Layer B7 &mdash; fuel mix", level=2))
    s.append(P("Fuel shares per sector per fuel default to the last observed "
               "value (or generic regional templates when no history). User "
               "may project shares explicitly. Cross-fuel identity (shares "
               "sum to 1) enforced and validated by T1'.", BODY))

    s.append(section("3.10", "Layer C &mdash; validation tests", level=2))
    s.append(P("Eight tests run on the complete output. Severity: "
               "<b>red</b> blocks the projection; <b>amber</b> emits a "
               "touch-up proposal for the user; <b>info</b> non-blocking "
               "diagnostic.", BODY))
    s.append(table_with_header([
        ["ID", "Test", "Severity", "Touch-up"],
        ["T1", "Accounting identities (T1 + T1')", "red", "no"],
        ["T2", "Historical range deviation", "amber", "yes"],
        ["T3", "Sustained productivity bands (5y rolling)", "amber", "yes"],
        ["T4", "Structural monotonicity (share trends)", "amber", "yes"],
        ["T5", "Cross-variable coherence (e.g. GDPpc vs SED)", "amber", "yes"],
        ["T6", "External benchmark vs literature", "info", "no"],
        ["T7", "Plausibility of user path vs B2 model prediction",
         "amber/red", "yes (amber only)"],
        ["T8", "Structural break at train/test boundary", "amber/red", "no"],
    ], col_widths=[1*cm, 7.5*cm, 3*cm, 4.5*cm]))
    s.append(Spacer(1, 0.3*cm))
    s.append(P("<b>T7 plausibility</b> fires when the user-supplied path "
               "deviates from the B2 model prediction by max &gt; 25% (amber) "
               "or &gt; 60% (red), or median &gt; 15% (amber) or &gt; 40% "
               "(red).", BODY))
    s.append(P("<b>T8 structural break</b> compares the first three projected "
               "year-on-year log-growths against the historical 10-year "
               "distribution. |z| &gt; 2.5 fires amber, &gt; 4.0 red. A "
               "&sigma; floor of 0.005 prevents over-firing on quasi-"
               "deterministic series. T8 does not propose a touch-up &mdash; "
               "by construction no better path is available than the suspect "
               "model projection.", BODY))

    s.append(PageBreak())

    # ============================================================
    # 4. BAYESIAN ESTIMATION
    # ============================================================
    s.append(section("4.", "Bayesian estimation framework"))

    s.append(section("4.1", "Closed-form posterior", level=2))
    s.append(P("For each layer that estimates parameters (B2, B3 bennett, "
               "B4, B5, B6), the model is", BODY))
    s.append(equation("y = X &theta; + &epsilon;,   &epsilon; ~ N(0, &sigma;&sup2; I)"))
    s.append(P("with a Gaussian prior on the coefficients:", BODY))
    s.append(equation("&theta; ~ N(&theta;_prior, &Sigma;_prior,eff)"))
    s.append(P("where &Sigma;_prior,eff is the regional prior covariance "
               "scaled by the user-facing shrinkage knob &lambda; (see 4.2). "
               "The posterior is then closed-form Gaussian:", BODY))
    s.append(equation(
        "&Sigma;_post = (X'X / &sigma;&sup2; + &Sigma;_prior,eff&#8315;&sup1;)&#8315;&sup1;"))
    s.append(equation(
        "&theta;_hat = &Sigma;_post (X'y / &sigma;&sup2; "
        "+ &Sigma;_prior,eff&#8315;&sup1; &theta;_prior)"))
    s.append(P("&sigma;&sup2; is estimated from OLS residuals when n &gt; p; "
               "the prior variance scale is used as fallback for "
               "underdetermined systems. See "
               "<font face='Courier'>_bayesian_ridge_fit</font> in "
               "<font face='Courier'>g_Macro_LayerB2.py</font>.", BODY))

    s.append(P("<b>Note: the v1.1s posterior formula was wrong.</b> v1.1s "
               "used &Sigma;_post = &sigma;&sup2; (X'X + &lambda; I)&#8315;&sup1; "
               "which collapses the credible intervals at high shrinkage. "
               "This was discovered during the Monte Carlo recovery test "
               "(Section 7.1) and corrected.", NOTE))

    s.append(section("4.2", "Shrinkage parameter", level=2))
    s.append(P("MacroConfig exposes <font face='Courier'>estimation_shrinkage</font> "
               "&lambda; &isin; [0, 1]. The internal scaling is the symmetric "
               "odds reparameterisation:", BODY))
    s.append(equation("k = &lambda; / (1 &minus; &lambda;),   "
                      "&Sigma;_prior,eff = &Sigma;_prior / k"))
    s.append(P("This gives: &lambda; = 0 &rArr; uninformative prior, "
               "posterior collapses to OLS. &lambda; = 0.5 &rArr; effective "
               "variance equals the prior variance as documented "
               "(equal-weights). &lambda; = 1 &rArr; dogmatic prior, "
               "&theta;_hat = &theta;_prior.", BODY))

    s.append(section("4.3", "Honest treatment of missing drivers", level=2))
    s.append(P("v1.1s synthesised SInv and GFCF_pub as fixed fractions of "
               "SGDP when the user did not supply them. This created a "
               "design matrix linearly dependent on the target and led to "
               "spuriously confident coefficients. v2.0 includes a driver in "
               "the regression <b>only if the user supplied historical data "
               "for it</b>. Inactive drivers inherit their coefficient from "
               "the regional prior, tagged <i>calibrated</i>.", BODY))

    s.append(section("4.4", "Origin tags", level=2))
    s.append(P("Each parameter carries one of three origins:", BODY))
    s.append(P("<b>estimated</b>: n_obs &ge; 15 and shrinkage &lt; 0.10; "
               "country data dominates.", BULLET))
    s.append(P("<b>adjusted</b>: data + prior weighted (typical case).",
               BULLET))
    s.append(P("<b>calibrated</b>: prior dominates (very short series, "
               "missing driver, or unidentifiable from the data).", BULLET))
    s.append(P("Origin tags are part of the <font face='Courier'>"
               "ParameterEstimate</font> schema returned by every layer and "
               "exposed to the frontend for transparency.", BODY))

    s.append(section("4.5", "VIF diagnostic", level=2))
    s.append(P("For every B2 sector with two or more active drivers, "
               "Variance Inflation Factors are computed. VIF &gt; 10 emits a "
               "diagnostic note on the affected parameter (not blocking). "
               "Posterior standard errors are returned per parameter and "
               "attached to the <font face='Courier'>ParameterEstimate.std_error"
               "</font> field for downstream display.", BODY))

    s.append(PageBreak())

    # ============================================================
    # 5. DATA SOURCES & CALIBRATION PIPELINE
    # ============================================================
    s.append(section("5.", "Calibration pipeline"))

    s.append(section("5.1", "Data sources", level=2))
    s.append(table_with_header([
        ["Indicator", "Source", "Dataset code", "Coverage"],
        ["GDP, sectoral GVA",       "Eurostat",   "nama_10_gdp / nama_10_a10",
         "EU-27 + UK + NO + CH, 1995-2024"],
        ["Sectoral GFCF (SInv)",    "Eurostat",   "nama_10_a64_p5",
         "EU-27 + UK + NO, 1995-2024"],
        ["Population",              "Eurostat",   "demo_pjan",
         "EU-27 + UK + NO + CH, 1990-2024"],
        ["Long-term bond yield",    "Eurostat",   "irt_lt_mcby_a",
         "EU-27 + UK, 1990-2024"],
        ["Sectoral energy demand",  "Eurostat",   "nrg_bal_c",
         "EU-27 + UK + NO, 1990-2024"],
        ["Global GDP / Pop / SGDP", "World Bank", "WDI (NY.*, NV.*, SP.*)",
         "217 countries, 1960-2024"],
        ["Country classification",  "World Bank", "WDI (income + region)",
         "All countries"],
    ], col_widths=[3.7*cm, 2.5*cm, 4.5*cm, 5.3*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(P("<b>Reproducibility.</b> All Eurostat and WDI pulls are made "
               "in three one-shot bulk scripts that save local CSVs to "
               "<font face='Courier'>scripts/macro_validation/data/</font> "
               "and <font face='Courier'>scripts/macro_validation/wdi_data/"
               "</font>. After the first run, every downstream script "
               "(calibration, backtest, document build) reads only from "
               "local files. The Eurostat API is flaky and was the source "
               "of several wasted iterations; the offline pipeline removed "
               "it from the loop.", BODY))

    s.append(section("5.2", "Country classification", level=2))
    s.append(P("MITICA regions are derived from World Bank classifications "
               "with an empirical refinement for HIC. The threshold for "
               "the HIC mature / HIC_TRANS split is 1990 GDPpc = $15,000 "
               "(constant 2015 USD), chosen by inspection of a natural gap "
               "in the high-income distribution.", BODY))
    s.append(table_with_header([
        ["MITICA region", "WB criterion",                          "n_countries"],
        ["HIC",       "income=HIC AND 1990 GDPpc &ge; $15k",    "61"],
        ["HIC_TRANS", "income=HIC AND 1990 GDPpc &lt; $15k",    "25"],
        ["LAC",       "income&ne;HIC AND region=LCN",            "23"],
        ["SSA",       "income&ne;HIC AND region=SSF",            "47"],
        ["MENA",      "income&ne;HIC AND region=MEA",            "15"],
        ["APAC",      "income&ne;HIC AND region&isin;{EAS, SAS}", "28"],
        ["EEU",       "income&ne;HIC AND region=ECS",            "18"],
    ], col_widths=[3.5*cm, 7*cm, 3*cm]))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("HIC_TRANS comprises: Bulgaria, Romania, Poland, Latvia, "
               "Russia, Lithuania, Slovakia, Hungary, Estonia, Korea, "
               "Croatia, Malta, Czechia, Slovenia, Portugal, Chile, Uruguay, "
               "Costa Rica, Panama, Trinidad &amp; Tobago, Antigua, St Kitts, "
               "Seychelles, Palau, Guyana. EU-27 mature (HIC): AT BE CY DE "
               "DK EL ES FI FR IE IT LU NL SE; EU-27 HIC_TRANS: BG CZ EE HR "
               "HU LT LV MT PL PT RO SI SK.", BODY))

    s.append(section("5.3", "Regression specifications", level=2))
    s.append(P("<b>B2 calibration</b> &mdash; LEVEL form, one-way country "
               "fixed-effects, joint estimation of (&zeta;_s, &kappa;_s, "
               "&kappa;&sup2;_s):", BODY))
    s.append(equation(
        "log SGDP_s,c,t = &alpha;_c,s + &zeta;_s log Pop_c,t "
        "+ &kappa;_s log GDPpc_c,t&minus;1 + &kappa;&sup2;_s "
        "[log GDPpc_c,t&minus;1]&sup2; + &epsilon;_c,s,t"))
    s.append(P("This level form matches the macro module's B2 equation "
               "exactly, eliminating the share-vs-level misspecification "
               "that bit an earlier draft. Estimated on ~10,000 "
               "country-year rows. HC1 standard errors; countries with "
               "fewer than 5 years dropped.", BODY))

    s.append(P("<b>B5 calibration</b> &mdash; intensity-convergence form "
               "per energy sector:", BODY))
    s.append(equation(
        "log(SED_k,c,t / scale_k,c,t) = &alpha;_c,k "
        "+ &psi;_k log GDPpc_c,t + &epsilon;_c,k,t"))
    s.append(P("Eurostat aggregates four sectors (primary, manufacturing "
               "incl. construction, services, transport pass+freight). "
               "Calibrated &psi; mapped to the module's six sectors "
               "(manuf &psi; copied to construction; transport &psi; copied "
               "to both pass and freight).", BODY))

    s.append(P("<b>B6 calibration</b> &mdash; saturation form jointly "
               "estimating (&beta;_hh, &gamma;_hh, &zeta;_hh):", BODY))
    s.append(equation(
        "log SED_hh,c,t = &alpha;_c + &beta;_hh log GDPpc_c,t "
        "+ &gamma;_hh [log GDPpc_c,t]&sup2; + &zeta;_hh log Pop_c,t + &epsilon;"))

    s.append(section("5.4", "Bootstrap robustness", level=2))
    s.append(P("Country-clustered bootstrap (n=200 replicates; resample "
               "whole countries with replacement, preserving within-country "
               "serial correlation) is run on every panel regression. "
               "The bootstrap standard deviation across replicates is the "
               "robustness statistic; |t|=|&theta;_hat|/SE_boot &gt; 2 marks "
               "the coefficient as significant.", BODY))

    s.append(PageBreak())

    # ============================================================
    # 6. CALIBRATED VALUES (tables from JSON)
    # ============================================================
    s.append(section("6.", "Calibrated regional priors"))

    s.append(section("6.1", "B2 priors (level form, joint, with bootstrap SE)",
                     level=2))
    s.append(P("Each cell shows the point estimate followed by the "
               "country-clustered bootstrap SE in parentheses. Values where "
               "|t| &gt; 2 are bold; these are the priors the module loads "
               "with confidence. Non-bold values still load but the country-"
               "level Bayesian fit dominates due to the wide prior std "
               "(&sigma;_&zeta;=0.30, &sigma;_&kappa;=0.50, &sigma;_&kappa;&sup2;=0.08).",
               BODY))

    # Build the B2 calibrated-values table from the JSON
    b2_rows = [["Region", "Sector", "&zeta; (SE)", "&kappa; (SE)", "&kappa;&sup2; (SE)"]]
    highlights = []
    row_idx = 1
    zeta = CALIB_B2.get("zeta", {})
    kappa = CALIB_B2.get("kappa", {})
    kappa2 = CALIB_B2.get("kappa2", {})
    boot = CALIB_B2.get("boot_se", {})
    for r in ("HIC", "HIC_TRANS", "EEU", "LAC", "MENA", "APAC", "SSA"):
        for sec in ("primary", "secondary", "tertiary"):
            z = (zeta.get(r) or {}).get(sec)
            k = (kappa.get(r) or {}).get(sec)
            k2 = (kappa2.get(r) or {}).get(sec)
            ses = (boot.get(r) or {}).get(sec, {})
            zse = ses.get("zeta_se"); kse = ses.get("kappa_se")
            k2se = ses.get("kappa2_se")
            row = [r, sec,
                   _fmt_with_se(z, zse, 3),
                   _fmt_with_se(k, kse, 3),
                   _fmt_with_se(k2, k2se, 3)]
            b2_rows.append(row)
            # mark robust cells (|t|>2)
            for col, (v, se) in enumerate([(z, zse), (k, kse), (k2, k2se)],
                                          start=2):
                if v is not None and se is not None and se > 0 and abs(v / se) > 2:
                    highlights.append((row_idx, col))
            row_idx += 1
    s.append(table_with_header(b2_rows,
        col_widths=[2.2*cm, 2.5*cm, 3.8*cm, 3.8*cm, 3.8*cm],
        highlight_cells=highlights))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("Green-highlighted cells are statistically significant "
               "(|t| &gt; 2 against the bootstrap SE). Note that "
               "<b>&zeta;_s is robust across all regions and sectors</b> "
               "&mdash; the Pop elasticities are precisely identified by "
               "the panel. Most &kappa; and &kappa;&sup2; cells are NOT "
               "robust; the wide priors and the country-level Bayesian fit "
               "compensate.", NOTE))

    s.append(section("6.2", "B5 priors &psi; (energy intensity convergence)",
                     level=2))
    psi = CALIB_E.get("psi", {})
    psi_se = CALIB_E.get("psi_boot_se", {})
    b5_rows = [["Region", "Primary", "Manufacturing", "Services", "Transport"]]
    highlights = []
    row_idx = 1
    for r in ("HIC", "HIC_TRANS", "EEU", "LAC", "MENA", "APAC", "SSA"):
        row = [r]
        for c, sec in enumerate(("primary", "manufacturing", "services",
                                  "transport"), start=1):
            v = (psi.get(r) or {}).get(sec)
            se = (psi_se.get(r) or {}).get(sec)
            row.append(_fmt_with_se(v, se, 3))
            if v is not None and se is not None and se > 0 and abs(v / se) > 2:
                highlights.append((row_idx, c))
        b5_rows.append(row)
        row_idx += 1
    s.append(table_with_header(b5_rows,
        col_widths=[2.5*cm, 3.3*cm, 3.3*cm, 3.3*cm, 3.3*cm],
        highlight_cells=highlights))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("Eurostat calibration covers HIC and HIC_TRANS only. The "
               "other regions retain stylised priors based on IEA WEO / "
               "Bashmakov (2007) and shown elsewhere in the codebase. "
               "Highlighted cells &psi;_manuf and &psi;_transport are the "
               "robust signals; &psi;_primary is noisy (CI crosses zero) "
               "and &psi;_services is moderate.", NOTE))

    s.append(section("6.3", "B6 priors (residential saturation)", level=2))
    b6 = CALIB_E.get("b6", {})
    b6_rows = [["Region", "&beta;_hh", "&gamma;_hh", "&zeta;_hh",
                "Inflection log(GDPpc)*"]]
    for r in ("HIC", "HIC_TRANS", "EEU", "LAC", "MENA", "APAC", "SSA"):
        d = (b6.get(r) or {})
        beta = d.get("beta_hh"); gamma = d.get("gamma_hh"); zeta_hh = d.get("zeta_hh")
        if beta is not None and gamma is not None and abs(gamma) > 1e-6:
            inflection = -beta / (2 * gamma)
            infl_str = f"{inflection:.2f} (~${int(2.71828**inflection):,})"
        else:
            infl_str = "n/a"
        b6_rows.append([r, _fmt(beta, 3), _fmt(gamma, 3), _fmt(zeta_hh, 3),
                        infl_str])
    s.append(table_with_header(b6_rows,
        col_widths=[2.5*cm, 2.8*cm, 2.8*cm, 2.8*cm, 5*cm]))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("The B6 quadratic is calibrated by direct regression of "
               "log(SED_hh) on log(GDPpc) and log(GDPpc)&sup2;. The "
               "implied inflection point coincides with the sample mean "
               "log GDPpc (10.51 for HIC, 10.77 for HIC_TRANS), confirming "
               "appliance saturation in mature economies. For non-EU regions "
               "calibrated values are not available; the module falls back "
               "to the stylised PriorsB6 defaults.", NOTE))

    s.append(PageBreak())

    # ============================================================
    # 7. EMPIRICAL VALIDATION
    # ============================================================
    s.append(section("7.", "Empirical validation"))

    s.append(section("7.1", "Monte Carlo recovery (B2)", level=2))
    s.append(P("<font face='Courier'>scripts/macro_validation/b2_recovery.py</font> "
               "synthesises country data from the log-log B2 model with "
               "known coefficients, then runs the estimator at &lambda; &isin; "
               "{0, 0.5, 0.9}. 200 replicates per scenario.", BODY))
    s.append(table_with_header([
        ["Metric",                "Ideal (n=25, clean)", "Short (n=10)",
         "Multicollinear (&rho;=0.85)"],
        ["Mean bias",          "&lt; 0.02", "&lt; 0.05",   "&lt; 0.03"],
        ["RMSE",               "0.05-0.10", "0.10-0.20",   "0.10-0.20"],
        ["95% CI coverage",    "92-100%",   "92-99%",      "94-100%"],
    ], col_widths=[3.5*cm, 4*cm, 3.5*cm, 4.5*cm]))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("The Monte Carlo also revealed and led to fixing the v1.1s "
               "posterior-variance bug. With the corrected formula coverage "
               "is at the nominal level across every parameter.", BODY))

    s.append(section("7.2", "EU-27 backtest for B2 sectoral GDP", level=2))
    s.append(P("Train 1995-2005 (11 years), test 2006-2024 (19 years). "
               "Drivers (Pop, SInv, iRate) supplied at actual values in the "
               "test window so any error is attributable to estimator bias, "
               "functional-form misspecification, or out-of-distribution "
               "regime change.", BODY))
    s.append(P("<b>Sub-pool results at &lambda;=0.5</b> (median MAPE %)", H3))
    s.append(table_with_header([
        ["Sub-pool",            "n", "Form",  "Primary", "Secondary", "Tertiary"],
        ["HIC mature",          "15", "LL",   "11.87",   "16.26",     "5.14"],
        ["HIC mature",          "15", "KCQ",  "14.11",   "23.81",     "9.87"],
        ["HIC_TRANS",           "10", "LL",   "17.00",   "18.07",     "17.18"],
        ["HIC_TRANS",           "10", "KCQ",  "20.18",   "16.08",     "inf"],
    ], col_widths=[3*cm, 1*cm, 2*cm, 2.5*cm, 2.5*cm, 2.5*cm],
       highlight_cells=[(1, 5)]))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("With the calibrated priors active, the simpler log-log "
               "form achieves the best fit in mature HIC. Tertiary MAPE "
               "5.14% is the headline number: a 6 pp absolute improvement "
               "over the pre-calibration baseline. The KC/KCQ forms now "
               "overshoot because the calibrated &kappa; (~+2) is too "
               "aggressive when added to an already-good &zeta;-driven "
               "projection.", BODY))

    s.append(section("7.3", "EU-29 backtest for B5 / B6 energy demand", level=2))
    s.append(P("Train 1995-2005, test 2006-2023, &lambda; = 0.5. Eurostat "
               "aggregates compared against module outputs (manuf+constr "
               "summed for industry; pass+freight summed for transport).",
               BODY))
    s.append(table_with_header([
        ["Sector",         "HIC LL", "HIC IC", "HIC_TRANS LL", "HIC_TRANS IC"],
        ["Primary",        "27.74",  "27.69",  "28.39",        "29.30"],
        ["Manufacturing",  "27.42",  "22.57",  "28.88",        "23.63"],
        ["Services",       "13.36",  "17.37",  "30.98",        "34.88"],
        ["Transport",      "14.40",  "15.47",  "15.56",        "14.15"],
        ["Households (B6)","9.68",   "9.68",   "11.26",        "11.26"],
    ], col_widths=[4*cm, 2.7*cm, 2.7*cm, 2.7*cm, 2.7*cm],
       highlight_cells=[(2, 2), (2, 4), (4, 4)]))
    s.append(Spacer(1, 0.2*cm))
    s.append(P("<b>Headline:</b> intensity convergence delivers <b>-4.8 pp "
               "MAPE in mature HIC manufacturing and -5.3 pp in HIC_TRANS "
               "manufacturing</b>. Transport in HIC_TRANS also improves with "
               "IC. Services and households are roughly tied between the "
               "two forms (B6 quadratic is so well-centered it locally "
               "reduces to LL).", BODY))

    s.append(section("7.4", "Findings vs hypotheses", level=2))
    s.append(table_with_header([
        ["Hypothesis tested", "Result"],
        ["Bayesian formula correction is needed",
         "CONFIRMED &mdash; v1.1s CIs collapsed; corrected in v2.0."],
        ["Honest treatment of missing drivers improves identification",
         "CONFIRMED &mdash; spuriously confident coefficients gone."],
        ["KC quadratic captures Kuznets hump in secondary",
         "CONFIRMED with stylised priors (avg MAPE 12.6 vs 14.1)."],
        ["Sub-pool calibration (HIC vs HIC_TRANS)",
         "CONFIRMED structurally distinct &kappa;_secondary signs."],
        ["Level-form joint calibration eliminates share/level mismatch",
         "CONFIRMED &mdash; LL with calibrated &zeta; now best for HIC."],
        ["Sub-period stratification of services calibration helps",
         "REJECTED &mdash; SED backtest worsened. Reverted."],
        ["Intensity-convergence form helps manufacturing",
         "CONFIRMED &mdash; -4.8 pp MAPE in HIC, -5.3 pp in HIC_TRANS."],
        ["Bennett logistic in B3 captures rising livestock share",
         "CONFIRMED on synthetic recovery; awaits FAOSTAT validation."],
    ], col_widths=[8*cm, 8.5*cm]))

    s.append(PageBreak())

    # ============================================================
    # 8. RECOMMENDED CONFIGURATION
    # ============================================================
    s.append(section("8.", "Recommended operational configuration"))

    s.append(P("The module's defaults preserve v1.1s output. The "
               "configuration below is the empirically-validated optimum "
               "per region when calibrated priors are available.", BODY))

    s.append(section("8.1", "MacroConfig defaults and recommended overrides",
                     level=2))
    s.append(table_with_header([
        ["Field",                "Default",   "Recommended (with calibration)"],
        ["region",               "LAC",       "Match user's country"],
        ["horizon_year",         "2050",      "User-defined"],
        ["estimation_shrinkage", "0.5",       "0.5"],
        ["b2_form",              "log_log",   "log_log (HIC, HIC_TRANS) or kuznets_chenery_quad (others)"],
        ["b3_form",              "constant",  "bennett_logistic when prim_splits history is available"],
        ["b5_form",              "log_log",   "intensity_convergence for manuf + transport in HIC sub-pools"],
        ["b6_form",              "log_log",   "log_log (calibrated B6 = locally flat in HIC)"],
        ["touch_up_mode",        "true",      "true"],
        ["validate_historical",  "true",      "true"],
    ], col_widths=[3*cm, 3*cm, 9.5*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(section("8.2", "Per-region default policy", level=2))
    s.append(table_with_header([
        ["Region",     "b2_form",                 "b5_form",
         "Comment"],
        ["HIC",       "log_log",                 "log_log (or IC for manuf/transport)",
         "Tertiary 5.14% MAPE; calibrated &zeta;=1.47 carries services growth."],
        ["HIC_TRANS", "log_log",                 "intensity_convergence",
         "Avoids &kappa; explosion; IC delivers -5 pp in manuf MAPE."],
        ["EEU",       "kuznets_chenery_quad",    "log_log",
         "Catch-up dynamics; KCQ for the secondary hump."],
        ["LAC",       "kuznets_chenery_quad",    "log_log",
         "Mid-income; default until backtest validates."],
        ["MENA",      "kuznets_chenery_quad",    "log_log",
         "Oil-dominated, idiosyncratic; KCQ + log_log conservative."],
        ["APAC",      "kuznets_chenery_quad",    "intensity_convergence (carefully)",
         "Catch-up + industrialisation; positive &psi; for manuf."],
        ["SSA",       "kuznets_chenery_quad",    "log_log",
         "Early-stage industrialisation; positive &psi; priors but data sparse."],
    ], col_widths=[2*cm, 4*cm, 4*cm, 6.5*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(section("8.3", "When to trust which output", level=2))
    s.append(P("Use the parameter <i>origin</i> tags returned by each layer:",
               BODY))
    s.append(P("&bull; <b>estimated</b>: country data carried the "
               "identification; trust the value over the prior.", BULLET))
    s.append(P("&bull; <b>adjusted</b>: data + prior contributed roughly "
               "equally; the value is a Bayesian compromise.", BULLET))
    s.append(P("&bull; <b>calibrated</b>: prior dominates; if the regional "
               "prior is the WDI-calibrated value with a tight bootstrap CI, "
               "still trust it; if it is a stylised default, the value is a "
               "rough order of magnitude and should be reported with caveats.",
               BULLET))
    s.append(P("Cross-check the Layer C report: red flags are blocking, "
               "amber flags suggest a touch-up alternative, T8 amber "
               "specifically warns that the projection extrapolates into a "
               "regime the training sample did not cover.", BODY))

    s.append(PageBreak())

    # ============================================================
    # 9. API REFERENCE
    # ============================================================
    s.append(section("9.", "API reference (Python)"))

    s.append(section("9.1", "MacroConfig", level=2))
    s.append(P("<font face='Courier'>mitica_core.modules.macro.MacroConfig"
               "</font> &mdash; dataclass.", BODY))
    s.append(table_with_header([
        ["Field",                 "Type",          "Domain",                                   "Default"],
        ["region",                "str",           "{LAC,SSA,MENA,APAC,EEU,HIC,HIC_TRANS}",   "LAC"],
        ["horizon_year",          "int",           "[T+1, T+50]",                              "2050"],
        ["touch_up_mode",         "bool",          "{true,false}",                             "true"],
        ["validate_historical",   "bool",          "{true,false}",                             "true"],
        ["estimation_shrinkage",  "float",         "[0, 1]",                                   "0.5"],
        ["b2_form",               "str",           "{log_log, kuznets_chenery, kuznets_chenery_quad}", "log_log"],
        ["b3_form",               "str",           "{constant, bennett_logistic}",             "constant"],
        ["b5_form",               "str",           "{log_log, intensity_convergence}",         "log_log"],
        ["b6_form",               "str",           "{log_log, saturation}",                    "log_log"],
        ["verbose",               "bool",          "{true,false}",                             "false"],
    ], col_widths=[4*cm, 1.8*cm, 7.7*cm, 2.5*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(section("9.2", "Entry points", level=2))
    s.append(P("<font face='Courier'>run_macro_module(hist, proj, cfg) "
               "-&gt; MacroOutputs</font>", H4))
    s.append(P("Single-call interface that handles flow detection, all "
               "layers A through C, and returns the complete output bundle.",
               BODY))
    s.append(P("<font face='Courier'>run_macro_module_from_dicts(hist_dicts, "
               "proj_dicts, region, horizon, ...) -&gt; MacroOutputs</font>",
               H4))
    s.append(P("Same as above but accepts plain dict inputs (e.g. from JSON "
               "payloads in the API layer). Validates schema before "
               "constructing the dataclasses.", BODY))
    s.append(P("<font face='Courier'>as_annalist_proxies(out) -&gt; dict[str, "
               "pd.DataFrame]</font>", H4))
    s.append(P("Re-packages the relevant proxies (GDP, Pop, sectoral GDP) "
               "for the ANNALIST forecast engine in the format MITICA's "
               "integration core expects.", BODY))

    s.append(section("9.3", "Output schema", level=2))
    s.append(P("<font face='Courier'>MacroOutputs</font> is a dataclass with "
               "the fields:", BODY))
    s.append(table_with_header([
        ["Field",                "Type",                  "Content"],
        ["gdp_tot",              "DataFrame[Year,GDP_tot]",        "Total GDP path (hist + proj)"],
        ["population",           "DataFrame[Year,Pop]",            "Population path"],
        ["sgdp",                 "DataFrame[Year,SGDP_*]",         "Sectoral GDP path"],
        ["sed",                  "DataFrame[Year,SED_k]",          "Sectoral energy demand"],
        ["sed_hh",               "DataFrame[Year,SED_hh]",         "Residential energy demand"],
        ["fuel_shares",          "DataFrame[Year,Sector,Fuel,Share]","Fuel mix"],
        ["sgdp_primary_split",   "DataFrame",                      "share_crops, share_livestock, SGDP_prim_*"],
        ["heads",                "DataFrame[Year,Heads]",          "Livestock heads"],
        ["derived",              "DataFrame",                      "GDPpc, intensities, shares, etc."],
        ["parameter_log",        "list[ParameterEstimate]",        "Every estimated parameter + origin + SE"],
        ["validation_report",    "list[ValidationFlag]",           "Layer C T1-T8 flags"],
        ["origin_labels",        "dict[var,DataFrame]",            "Per-year origin labels (user/model/touch-up)"],
        ["flow_detected",        "str",                            "F1 / F2 / F3"],
    ], col_widths=[4*cm, 5*cm, 7.5*cm]))

    s.append(PageBreak())

    # ============================================================
    # 10. FILE STRUCTURE
    # ============================================================
    s.append(section("10.", "Code and data structure"))

    s.append(section("10.1", "Module source", level=2))
    s.append(table_with_header([
        ["File",                              "Lines",  "Purpose"],
        ["g_Macro_Schemas.py",                "~330",   "Data classes (HistoricalData, ProjectedInputs, MacroConfig, MacroOutputs)"],
        ["g_Macro_Priors.py",                 "~640",   "Regional priors + JSON loader for calibrated overrides"],
        ["g_Macro_Solver.py",                 "~330",   "End-to-end orchestrator; calls every layer in order"],
        ["g_Macro_API.py",                    "~120",   "Public entry points run_macro_module(...)"],
        ["g_Macro_LayerA.py",                 "~270",   "Identity checks and TED derivation"],
        ["g_Macro_LayerB1.py",                "~150",   "Population projection"],
        ["g_Macro_LayerB2.py",                "~700",   "Sectoral GDP &mdash; Bayesian ridge + 3 forms"],
        ["g_Macro_LayerB3_B4.py",             "~400",   "Primary decomposition + livestock heads"],
        ["g_Macro_LayerB5_B6.py",             "~620",   "Sectoral and residential energy demand"],
        ["g_Macro_LayerC.py",                 "~520",   "Validation tests T1-T8 + touch-up proposals"],
    ], col_widths=[5*cm, 1.5*cm, 10*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(section("10.2", "Calibration and validation scripts", level=2))
    s.append(table_with_header([
        ["File",                              "Purpose"],
        ["bulk_download.py",                  "Eurostat: GDP, GVA, GFCF, Pop, iRate (one-shot per dataset)"],
        ["bulk_download_sed.py",              "Eurostat: nrg_bal_c (5 balance codes)"],
        ["bulk_download_wdi.py",              "World Bank: WDI + country classification"],
        ["calibrate_priors.py",               "B2 panel regression (LEVEL form, joint, with bootstrap)"],
        ["calibrate_energy_priors.py",        "B5 (psi) + B6 (beta_hh, gamma_hh, zeta_hh) calibration"],
        ["b2_recovery.py",                    "Monte Carlo recovery test for B2"],
        ["run_backtest.py",                   "EU-27 backtest for B2 (with stratification)"],
        ["run_backtest_sed.py",               "EU-29 SED backtest for B5 / B6"],
        ["build_final_spec.py",               "This document (PDF)"],
    ], col_widths=[5*cm, 11.5*cm]))
    s.append(Spacer(1, 0.3*cm))

    s.append(section("10.3", "Auto-loaded calibration files", level=2))
    s.append(P("Two JSON files are auto-loaded by "
               "<font face='Courier'>g_Macro_Priors.py</font> on import, "
               "if present:", BODY))
    s.append(P("&bull; <font face='Courier'>scripts/macro_validation/wdi_data/"
               "calibrated_priors.json</font> &mdash; B2 (zeta, kappa, "
               "kappa2) per region, with bootstrap SE.", BULLET))
    s.append(P("&bull; <font face='Courier'>scripts/macro_validation/wdi_data/"
               "calibrated_energy_priors.json</font> &mdash; B5 (psi) and "
               "B6 (beta_hh, gamma_hh, zeta_hh) per region, with bootstrap "
               "SE.", BULLET))
    s.append(P("Each JSON has a <font face='Courier'>_meta</font> block "
               "documenting the regression specification, the year range, "
               "and the indicator codes. The core library ships <i>without</i> "
               "these files (so it remains region-agnostic by default); the "
               "calibration is a separate optional artefact.", BODY))

    s.append(PageBreak())

    # ============================================================
    # 11. OUTSTANDING WORK
    # ============================================================
    s.append(section("11.", "Outstanding work"))

    s.append(P("This document closes the calibration sprint. The next "
               "phase is the Next.js frontend wiring, which will surface "
               "the per-region recommended configuration and expose the "
               "form-selection switches to the user. Beyond that, the "
               "following items remain on the methodology backlog:", BODY))

    s.append(P("<b>1. Multi-region calibration for non-HIC</b>: the energy "
               "calibration covers HIC + HIC_TRANS only (Eurostat); other "
               "regions retain stylised priors. Adding an IEA WEO or "
               "OECD-CER panel would let us calibrate LAC, MENA, APAC and "
               "SSA with the same methodology. The B2 calibration already "
               "covers all regions (WDI is global).", BODY))

    s.append(P("<b>2. FAOSTAT calibration of B3 Bennett's law</b>: the "
               "(a_B, b_B) anchors are currently back-solved from regional "
               "stylised livestock shares. FAOSTAT has long crop / "
               "livestock GDP value series that could provide a proper "
               "Bayesian prior.", BODY))

    s.append(P("<b>3. T8 follow-on</b>: extend the scan window adaptively "
               "(5 years for long horizons; currently fixed at 3) and "
               "propose fixes from driver re-estimation rather than from "
               "the suspect model projection.", BODY))

    s.append(P("<b>4. Operational scenarios harness</b>: the EU backtest "
               "harness is reproducible from local CSVs. Extending it to "
               "include LAC or African comparators (with the relevant "
               "national accounts panels) would close the calibration loop "
               "for the non-EU regions.", BODY))

    s.append(P("<b>5. Documentation translations</b>: this spec is in "
               "English. The UNFCCC distribution channel typically requires "
               "Spanish and French versions of methodology annexes.", BODY))

    s.append(PageBreak())

    # ============================================================
    # 12. ANNEX A — STYLISED PRIORS (FALLBACK)
    # ============================================================
    s.append(section("Annex A.", "Stylised priors (fallback when no calibration)"))
    s.append(P("These are the priors hard-coded in "
               "<font face='Courier'>g_Macro_Priors.py</font>. They apply "
               "to any (region, sector, parameter) combination not "
               "overridden by the JSON calibration files. For HIC and "
               "HIC_TRANS the calibrated values supersede these.", BODY))

    s.append(P("<b>B2 stylised &beta;_s, &gamma;_s, &zeta;_s, &delta;_s "
               "(LL form)</b>", H3))
    s.append(table_with_header([
        ["Region",     "&beta;_pri", "&beta;_sec", "&beta;_ter",
         "&gamma;_pri", "&gamma;_sec", "&gamma;_ter",
         "&zeta;_pri", "&zeta;_sec", "&zeta;_ter",
         "&delta;_pri", "&delta;_sec", "&delta;_ter"],
        ["LAC",        "0.30", "0.35", "0.25", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
        ["SSA",        "0.30", "0.35", "0.25", "0.15", "0.20", "0.15",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
        ["MENA",       "0.30", "0.35", "0.25", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
        ["APAC",       "0.35", "0.40", "0.30", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
        ["EEU",        "0.30", "0.35", "0.25", "0.10", "0.15", "0.10",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
        ["HIC",        "0.30", "0.35", "0.25", "0.05", "0.10", "0.05",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
        ["HIC_TRANS",  "0.33", "0.38", "0.28", "0.07", "0.12", "0.07",
         "0.90", "1.00", "1.10", "-0.01", "-0.02", "-0.01"],
    ], col_widths=[2*cm] + [1.15*cm]*12))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>B2 stylised &kappa;_s (KC linear shifter)</b>", H3))
    s.append(table_with_header([
        ["Region",     "&kappa;_primary", "&kappa;_secondary", "&kappa;_tertiary"],
        ["LAC, SSA, MENA, APAC",  "-0.40", "-0.05", "+0.20"],
        ["EEU",        "-0.30", "-0.05", "+0.15"],
        ["HIC",        "-0.20", "-0.05", "+0.10"],
        ["HIC_TRANS",  "-0.25", " 0.00", "+0.12"],
    ], col_widths=[5*cm, 3.5*cm, 3.5*cm, 3.5*cm]))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>B2 stylised &kappa;&sup2;_s (KCQ quadratic; same for all "
               "regions)</b>", H3))
    s.append(table_with_header([
        ["&kappa;&sup2;_primary", "&kappa;&sup2;_secondary", "&kappa;&sup2;_tertiary"],
        ["0.00", "-0.05", "0.00"],
    ], col_widths=[4*cm, 4*cm, 4*cm]))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>B5 stylised &psi;_k (intensity convergence)</b>", H3))
    s.append(table_with_header([
        ["Region",     "&psi;_primary", "&psi;_manuf", "&psi;_constr",
         "&psi;_services", "&psi;_tp", "&psi;_tf"],
        ["HIC",        "-0.30", "-0.50", "-0.20", "-0.10", "-0.05", "-0.15"],
        ["HIC_TRANS",  "-0.21", "-0.35", "-0.14", "-0.07", "-0.04", "-0.11"],
        ["EEU/LAC/MENA", "-0.15", "-0.25", "-0.10", "-0.05", "-0.03", "-0.08"],
        ["APAC",       "-0.10", "+0.10", "+0.05", "-0.05", "+0.10", "+0.10"],
        ["SSA",        "+0.10", "+0.20", "+0.15", " 0.00", "+0.15", "+0.15"],
    ], col_widths=[3*cm, 2*cm, 2*cm, 2*cm, 2.4*cm, 2*cm, 2*cm]))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>B6 stylised priors (uniform across regions when "
               "uncalibrated)</b>", H3))
    s.append(table_with_header([
        ["&beta;_hh", "&gamma;_hh", "&zeta;_hh",
         "&sigma;_&beta;_hh", "&sigma;_&gamma;_hh", "&sigma;_&zeta;_hh"],
        ["0.70", "-0.04", "1.00", "0.15", "0.02", "0.10"],
    ], col_widths=[2.5*cm, 2.5*cm, 2.5*cm, 2.5*cm, 2.5*cm, 2.5*cm]))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>B3 anchored stylised priors (Bennett logistic)</b>", H3))
    s.append(P("a_B is back-solved from the regional share_livestock anchor "
               "at the indicated log GDPpc:", BODY))
    s.append(table_with_header([
        ["Region", "share_crops", "share_livestock", "share_other",
         "log GDPpc anchor", "a_B", "b_B"],
        ["LAC",       "0.55", "0.35", "0.10", "8.5",  "-1.89", "0.15"],
        ["SSA",       "0.60", "0.30", "0.10", "7.0",  "-1.90", "0.15"],
        ["MENA",      "0.50", "0.35", "0.15", "8.5",  "-1.89", "0.15"],
        ["APAC",      "0.65", "0.25", "0.10", "7.5",  "-2.22", "0.15"],
        ["EEU",       "0.55", "0.40", "0.05", "9.0",  "-1.75", "0.15"],
        ["HIC",       "0.50", "0.40", "0.10", "10.5", "-1.98", "0.15"],
        ["HIC_TRANS", "0.52", "0.40", "0.08",  "9.5", "-1.83", "0.15"],
    ], col_widths=[2.2*cm, 2*cm, 2.5*cm, 2*cm, 2.5*cm, 2*cm, 2*cm]))
    s.append(Spacer(1, 0.2*cm))

    s.append(P("<b>Productivity bands (T3 test)</b>", H3))
    s.append(P("5-year rolling mean of g_Prod = g_GDP &minus; g_Pop, "
               "compound annual growth rate:", BODY))
    s.append(table_with_header([
        ["Region",     "g_Prod min", "g_Prod max"],
        ["LAC",        "-1.0%",   "+3.5%"],
        ["SSA",        "-1.5%",   "+4.0%"],
        ["MENA",       "-1.0%",   "+4.0%"],
        ["APAC",       "-1.0%",   "+6.0%"],
        ["EEU",        "-1.5%",   "+4.0%"],
        ["HIC",        "-0.5%",   "+2.5%"],
        ["HIC_TRANS",  "-1.0%",   "+4.5%"],
    ], col_widths=[3*cm, 3*cm, 3*cm]))

    s.append(PageBreak())

    # ============================================================
    # 13. ANNEX B — GLOSSARY
    # ============================================================
    s.append(section("Annex B.", "Glossary"))
    s.append(table_with_header([
        ["Term",       "Definition"],
        ["MITICA",     "Mitigation-Inventory Tool for Integrated Climate Action; the Gauss / UNFCCC GHG projection tool."],
        ["UNFCCC",     "United Nations Framework Convention on Climate Change."],
        ["ETF",        "Enhanced Transparency Framework (Paris Agreement, Decision 18/CMA.1)."],
        ["BTR",        "Biennial Transparency Report submitted under the ETF."],
        ["CTF / CRT",  "Common Tabular Format / Common Reporting Table; UNFCCC standardised reporting templates."],
        ["WoM/WEM/WAM","Without Measures / With Existing Measures / With Additional Measures emission scenarios."],
        ["GHG",        "Greenhouse gas; here CO2-eq using IPCC AR5 GWPs."],
        ["GDP / GDPpc","Gross Domestic Product (total) and per capita (= GDP/Pop)."],
        ["SGDP_s",     "Sectoral GDP for economic sector s (primary, secondary, tertiary)."],
        ["SED_k",      "Sectoral Energy Demand (final consumption) for energy sector k."],
        ["TED",        "Total Energy Demand = sum of SED_k + SED_hh."],
        ["SInv_s",     "Sectoral Investment = sectoral gross fixed capital formation."],
        ["GFCF_pub_s", "Public Gross Fixed Capital Formation per sector."],
        ["iRate",      "Effective interest rate (long-term government bond yield as proxy)."],
        ["WDI",        "World Bank World Development Indicators (~217 countries, 1960-2024)."],
        ["FAOSTAT",    "FAO Statistics; long-panel agricultural data."],
        ["IEA WEO",    "International Energy Agency, World Energy Outlook."],
        ["NACE rev2",  "Statistical Classification of Economic Activities in the European Community (revision 2)."],
        ["FE estimator","Fixed-effects panel regression (country fixed effects to absorb level scale)."],
        ["HC1",        "Heteroskedasticity-Consistent variance estimator, type 1."],
        ["VIF",        "Variance Inflation Factor; multicollinearity diagnostic."],
        ["Bayesian ridge", "Closed-form Gaussian-Gaussian conjugate posterior with prior-centered shrinkage."],
        ["Bootstrap",  "Cluster-robust resampling (here: by country) for confidence intervals."],
        ["KC / KCQ",   "Kuznets-Chenery linear / quadratic shifter on log(GDPpc)."],
        ["IC",         "Intensity Convergence (Bashmakov 2007); energy intensity decays with income."],
        ["SAT",        "Saturation form (quadratic in log GDPpc) for residential energy."],
        ["BL",         "Bennett's law logistic form for crop / livestock share."],
        ["LL",         "log-log form (the v1.1s legacy)."],
        ["HIC / HIC_TRANS", "High-income countries (mature OECD vs transitioning)."],
        ["LAC / SSA / MENA / APAC / EEU", "MITICA macro-regions (Latin America, Sub-Saharan Africa, Middle East & North Africa, Asia-Pacific, Eastern Europe)."],
    ], col_widths=[3*cm, 13.5*cm]))

    s.append(PageBreak())

    # ============================================================
    # 14. ANNEX C — BIBLIOGRAPHY
    # ============================================================
    s.append(section("Annex C.", "Bibliography and references"))
    s.append(P("<b>MITICA documentation</b>", H3))
    s.append(P("&bull; Mart&iacute;n-Ortega, J.L. et al. (2024). MITICA: A "
               "tool for designing mitigation scenarios. <i>MDPI "
               "Sustainability</i> 16(10), 4219. "
               "<font face='Courier'>https://www.mdpi.com/2071-1050/16/10/4219"
               "</font>", BULLET))
    s.append(P("&bull; UNFCCC Secretariat (2024). <i>Manual of the MITICA "
               "tool</i> (v6). "
               "<font face='Courier'>unfccc.int/sites/default/files/resource/"
               "Manual_draft_Mitigation_toolrev_v6.pdf</font>", BULLET))

    s.append(P("<b>Methodology</b>", H3))
    s.append(P("&bull; Chenery, H.B. and M. Syrquin (1986). <i>Industrialization "
               "and Growth: A Comparative Study</i>. Oxford University Press / "
               "World Bank. (Kuznets-Chenery hump in secondary share.)", BULLET))
    s.append(P("&bull; Herrendorf, B., R. Rogerson and A. Valentinyi (2014). "
               "<i>Growth and Structural Transformation</i>. Handbook of "
               "Economic Growth, vol. 2. (Empirical priors for &kappa;_s.)",
               BULLET))
    s.append(P("&bull; Bashmakov, I. (2007). Three laws of energy "
               "transitions. <i>Energy Policy</i> 35: 3583-3594. (Intensity "
               "convergence form &mdash; M8.)", BULLET))
    s.append(P("&bull; Bennett, M.K. (1941). Wheat in National Diets. "
               "<i>Wheat Studies of the Food Research Institute</i> "
               "18(2). (Bennett's law &mdash; M7.)", BULLET))
    s.append(P("&bull; Schipper, L. and S. Meyers (1992). <i>Energy "
               "Efficiency and Human Activity: Past Trends, Future "
               "Prospects</i>. Cambridge University Press. (Sectoral energy "
               "intensity benchmarks.)", BULLET))

    s.append(P("<b>Data sources</b>", H3))
    s.append(P("&bull; Eurostat (2024). Data Browser. "
               "<font face='Courier'>ec.europa.eu/eurostat/data/database"
               "</font>. CC BY 4.0.", BULLET))
    s.append(P("&bull; World Bank (2024). World Development Indicators. "
               "<font face='Courier'>data.worldbank.org</font>. CC BY 4.0.",
               BULLET))
    s.append(P("&bull; FAOSTAT (2024). Food and Agriculture Statistics. "
               "<font face='Courier'>fao.org/faostat</font>.", BULLET))
    s.append(P("&bull; IEA (2024). World Energy Outlook 2024. "
               "<font face='Courier'>iea.org/reports/world-energy-outlook-2024"
               "</font>.", BULLET))

    s.append(P("<b>Regulatory</b>", H3))
    s.append(P("&bull; UNFCCC (2018). Decision 18/CMA.1 &mdash; Modalities, "
               "procedures and guidelines for the transparency framework "
               "for action and support referred to in Article 13 of the "
               "Paris Agreement.", BULLET))
    s.append(P("&bull; IPCC (2006, 2019). <i>Guidelines for National "
               "Greenhouse Gas Inventories</i> (2006) and Refinement (2019). "
               "Volumes 1-5.", BULLET))

    s.append(Spacer(1, 0.5*cm))
    s.append(P("<i>End of specification.</i>", NOTE))
    s.append(Spacer(1, 0.3*cm))
    s.append(P(
        "<i>This document was built on demand from "
        "<font face='Courier'>scripts/macro_validation/build_final_spec.py</font> "
        "and reads the calibration JSONs directly so every numerical value "
        "shown here matches the values the module will load at runtime. "
        "Regenerate after any calibration change with "
        "<font face='Courier'>python scripts/macro_validation/build_final_spec.py</font>.</i>",
        NOTE,
    ))

    return s


# ---------------------------------------------------------------------------
# Page template
# ---------------------------------------------------------------------------


def _header_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#666"))
    canvas.drawString(2*cm, A4[1] - 1.2*cm,
                      "MITICA Macro Module &mdash; Final Specification v2.0")
    canvas.drawRightString(A4[0] - 2*cm, A4[1] - 1.2*cm,
                           "Gauss / UNFCCC")
    canvas.line(2*cm, A4[1] - 1.4*cm, A4[0] - 2*cm, A4[1] - 1.4*cm)
    canvas.drawCentredString(A4[0]/2, 1.2*cm, f"&mdash; {doc.page} &mdash;")
    canvas.restoreState()


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = BaseDocTemplate(
        str(OUT), pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2.0*cm, bottomMargin=2*cm,
        title="MITICA Macro Module - Final Specification v2.0",
        author="Gauss",
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin,
                  doc.width, doc.height, id="main")
    doc.addPageTemplates([
        PageTemplate(id="all", frames=[frame], onPage=_header_footer),
    ])
    story = build_story()
    doc.build(story)
    print(f"Wrote {OUT.resolve()}")


if __name__ == "__main__":
    main()
