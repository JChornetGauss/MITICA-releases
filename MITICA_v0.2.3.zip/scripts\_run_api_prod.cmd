@echo off
rem Helper invoked by start.cmd — runs the API in PRODUCTION mode (no --reload).
rem
rem Python resolution order:
rem   1. .venv\Scripts\python.exe          (dev mode - repo checkout)
rem   2. ..\tools\python\python.exe        (installed mode - portable Python)

setlocal EnableDelayedExpansion
set _ROOT=%~dp0..
for %%i in ("%_ROOT%") do set ROOT=%%~fi
cd /d "%ROOT%"
title MITICA API (production)

if "%MITICA_WORKERS%"=="" set MITICA_WORKERS=1

rem -- Resolve Python executable --
if exist "%ROOT%\.venv\Scripts\python.exe" (
    set PYTHON=%ROOT%\.venv\Scripts\python.exe
) else if exist "%ROOT%\..\tools\python\python.exe" (
    set PYTHON=%ROOT%\..\tools\python\python.exe
) else (
    echo.
    echo [MITICA API] ERROR: No Python found.
    echo   Expected: .venv\Scripts\python.exe  ^(dev mode^)
    echo        or:  ..\tools\python\python.exe  ^(installed mode^)
    echo.
    pause
    exit /b 1
)

echo.
echo [MITICA API] Python : %PYTHON%
echo [MITICA API] starting uvicorn on http://127.0.0.1:8000  (workers=%MITICA_WORKERS%)
echo.

"%PYTHON%" -m uvicorn mitica_api.main:app ^
    --host 127.0.0.1 --port 8000 ^
    --workers %MITICA_WORKERS% ^
    --proxy-headers

echo.
echo [MITICA API] server exited. Press any key to close this window.
pause >nul
