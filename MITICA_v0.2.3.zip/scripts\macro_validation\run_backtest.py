"""Run the European backtest for all countries in the local data directory.

100% offline — reads only the CSVs produced once by ``bulk_download.py``.
No Eurostat API calls happen here, by design (the API has historically been
flaky and we want a reproducible benchmark).

Splits each country's series into a training window and a test window, runs
the macro module on the training window, projects to the end of the test
window, and compares projected SGDP_s against the actual values.

Outputs:
* Per-country, per-sector metrics (MAPE, RMSE, bias) printed to stdout.
* Consolidated CSVs under ``scripts/macro_validation/results/``:
    - ``summary_<train>_<test>.csv``  one row per (country, shrinkage, sector)
    - ``yearly_<train>_<test>.csv``   one row per (country, shrinkage, sector, year)
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from mitica_core.modules.macro import (
    HistoricalData,
    MacroConfig,
    ProjectedInputs,
    run_macro_module,
)

DATA_DIR = Path("scripts/macro_validation/data")


# ---------------------------------------------------------------------------
# Per-country backtest
# ---------------------------------------------------------------------------


def load_country(code: str) -> dict[str, pd.DataFrame]:
    """Reload all fetched CSVs for one country into DataFrames."""
    out: dict[str, pd.DataFrame] = {}
    for key in ("gdp_pop", "sgdp", "sinv", "irate"):
        p = DATA_DIR / f"{code}_{key}.csv"
        if not p.exists() or p.stat().st_size < 10:
            out[key] = pd.DataFrame()
            continue
        try:
            out[key] = pd.read_csv(p)
        except (pd.errors.EmptyDataError, Exception):
            out[key] = pd.DataFrame()
    return out


def build_hist_from(
    raw: dict[str, pd.DataFrame],
    train_start: int,
    train_end: int,
) -> HistoricalData:
    """Slice raw series to the training window and build a HistoricalData."""
    def _slice(df: pd.DataFrame, lo: int, hi: int) -> pd.DataFrame | None:
        if df is None or df.empty:
            return None
        out = df[(df["Year"] >= lo) & (df["Year"] <= hi)].sort_values("Year").reset_index(drop=True)
        return out if not out.empty else None

    gdp_pop = _slice(raw["gdp_pop"], train_start, train_end)
    sgdp    = _slice(raw["sgdp"],    train_start, train_end)
    sinv    = _slice(raw["sinv"],    train_start, train_end)
    irate   = _slice(raw["irate"],   train_start, train_end)

    # Reconcile GDP_tot to the sum of sectoral GVA so Layer A's T1 identity
    # holds exactly. Eurostat's B1GQ (GDP at market prices) differs from the
    # sum of B1G (sectoral GVA) by taxes on products less subsidies, which
    # are not allocated to sectors in nama_10_a10. For backtest purposes we
    # use the GVA-consistent total — same convention the macro module assumes.
    gdp_tot = sgdp.copy()
    gdp_tot["GDP_tot"] = (
        sgdp["SGDP_primary"] + sgdp["SGDP_secondary"] + sgdp["SGDP_tertiary"]
    )
    gdp_tot = gdp_tot[["Year", "GDP_tot"]]

    return HistoricalData(
        gdp_tot=gdp_tot,
        population=gdp_pop[["Year", "Pop"]],
        sgdp=sgdp,
        sinv=sinv,
        irate=irate,
        # GFCF_pub is intentionally None — not available from Eurostat at sector
        # granularity. The B2 estimator will keep gamma_s at the regional prior.
    )


def build_projected_drivers(
    raw: dict[str, pd.DataFrame],
    train_end: int,
    test_end: int,
) -> ProjectedInputs:
    """Build the ProjectedInputs containing ONLY the driver paths (SInv,
    iRate, Pop) for the test years. SGDP_s and GDP_tot are intentionally
    excluded so the module produces them itself.
    """
    def _slice_future(df: pd.DataFrame, lo: int, hi: int) -> pd.DataFrame | None:
        if df is None or df.empty:
            return None
        out = df[(df["Year"] > lo) & (df["Year"] <= hi)].sort_values("Year").reset_index(drop=True)
        return out if not out.empty else None

    pop_future = _slice_future(raw["gdp_pop"], train_end, test_end)
    sinv_future = _slice_future(raw["sinv"], train_end, test_end)
    irate_future = _slice_future(raw["irate"], train_end, test_end)

    return ProjectedInputs(
        population=(pop_future[["Year", "Pop"]] if pop_future is not None else None),
        sinv=sinv_future,
        irate=irate_future,
    )


def _has_gap(df: pd.DataFrame, lo: int, hi: int) -> bool:
    """Return True if df is missing any year in [lo, hi]."""
    if df is None or df.empty:
        return True
    years = set(df["Year"].astype(int).tolist())
    return any(y not in years for y in range(lo, hi + 1))


def evaluate_country(
    code: str,
    train_start: int,
    train_end: int,
    test_end: int,
    shrinkage: float,
    region: str = "HIC",
    b2_form: str = "log_log",
) -> dict:
    """Run the backtest for one country and return metrics. Returns a
    status='skipped' / 'failed' dict (never raises) so one bad country does
    not abort the batch."""
    raw = load_country(code)
    # Mandatory series for training and projection
    for key in ("gdp_pop", "sgdp", "sinv"):
        if raw.get(key) is None or raw[key].empty:
            return {"country": code, "status": f"missing_{key}"}
    # Test window completeness — Pop and SInv must be gap-free in [train_end+1, test_end]
    if _has_gap(raw["gdp_pop"], train_end + 1, test_end):
        return {"country": code, "status": "gap_in_pop_test_window"}
    if _has_gap(raw["sinv"], train_end + 1, test_end):
        return {"country": code, "status": "gap_in_sinv_test_window"}
    # Training window completeness — at least 10 of 11 years
    train_years = set(raw["gdp_pop"]["Year"].astype(int))
    train_coverage = sum(1 for y in range(train_start, train_end + 1) if y in train_years)
    if train_coverage < (train_end - train_start + 1) - 1:
        return {"country": code, "status": f"train_coverage_only_{train_coverage}_years"}

    hist = build_hist_from(raw, train_start, train_end)
    proj = build_projected_drivers(raw, train_end, test_end)
    cfg = MacroConfig(
        region=region,
        horizon_year=test_end,
        estimation_shrinkage=shrinkage,
        b2_form=b2_form,
        verbose=False,
    )
    try:
        out = run_macro_module(hist, proj, cfg)
    except Exception as e:
        return {"country": code, "status": f"crash: {type(e).__name__}: {e}"}

    # Compare projected SGDP_s against actuals for the test window
    actual_sgdp = raw["sgdp"]
    projected = out.sgdp
    sectors = ["primary", "secondary", "tertiary"]

    metrics: dict[str, dict[str, float]] = {}
    for s in sectors:
        col = f"SGDP_{s}"
        if col not in projected.columns or col not in actual_sgdp.columns:
            continue
        a = (actual_sgdp[(actual_sgdp["Year"] > train_end)
                        & (actual_sgdp["Year"] <= test_end)]
             .set_index("Year")[col])
        p = (projected[(projected["Year"] > train_end)
                       & (projected["Year"] <= test_end)]
             .set_index("Year")[col])
        common = a.index.intersection(p.index)
        if len(common) == 0:
            continue
        a_v = a.loc[common].values
        p_v = p.loc[common].values
        err = (p_v - a_v) / a_v
        mape = float(np.mean(np.abs(err)) * 100)
        bias = float(np.mean(err) * 100)
        rmse = float(np.sqrt(np.mean(((p_v - a_v) / a_v) ** 2)) * 100)
        end_dev = float((p_v[-1] - a_v[-1]) / a_v[-1] * 100)
        metrics[s] = {
            "n_years": int(len(common)),
            "mape_pct": mape,
            "bias_pct": bias,
            "rmse_pct": rmse,
            "endpoint_dev_pct": end_dev,
        }

    # Parameter origins
    origin_counts = {"estimated": 0, "adjusted": 0, "calibrated": 0}
    for p in out.parameter_log:
        if p.origin in origin_counts:
            origin_counts[p.origin] += 1

    return {
        "country": code,
        "status": "ok",
        "train": f"{train_start}-{train_end}",
        "test": f"{train_end+1}-{test_end}",
        "shrinkage": shrinkage,
        "region": region,
        "b2_form": b2_form,
        "metrics": metrics,
        "origin": origin_counts,
        "n_amber_flags": sum(1 for f in out.validation_report if f.severity == "amber"),
        "n_red_flags":   sum(1 for f in out.validation_report if f.severity == "red"),
    }


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def print_report(result: dict) -> None:
    if result.get("status") != "ok":
        print(f"  {result['country']}  --  {result.get('status', 'unknown')}")
        return
    c = result["country"]
    print(f"\n  === {c}  train {result['train']}  test {result['test']}  "
          f"shrinkage={result['shrinkage']}  region={result['region']} ===")
    print(f"    params: estimated={result['origin']['estimated']} "
          f"adjusted={result['origin']['adjusted']} "
          f"calibrated={result['origin']['calibrated']}")
    print(f"    flags:  {result['n_red_flags']} red  {result['n_amber_flags']} amber")
    print(f"    {'sector':<12} {'n':>3} {'MAPE %':>8} {'RMSE %':>8} "
          f"{'bias %':>8} {'endpoint':>10}")
    for s, m in result["metrics"].items():
        print(f"    {s:<12} {m['n_years']:>3} {m['mape_pct']:>8.2f} "
              f"{m['rmse_pct']:>8.2f} {m['bias_pct']:>+8.2f} "
              f"{m['endpoint_dev_pct']:>+9.2f}%")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def yearly_deviation(
    code: str,
    train_start: int,
    train_end: int,
    test_end: int,
    shrinkage: float,
    region: str = "HIC",
) -> pd.DataFrame:
    """Return a per-year DataFrame of projected, actual, and deviation per
    sector. Useful for plotting and spotting when the elasticity assumption
    breaks down (regime change, crisis years)."""
    raw = load_country(code)
    hist = build_hist_from(raw, train_start, train_end)
    proj = build_projected_drivers(raw, train_end, test_end)
    cfg = MacroConfig(
        region=region,
        horizon_year=test_end,
        estimation_shrinkage=shrinkage,
        verbose=False,
    )
    try:
        out = run_macro_module(hist, proj, cfg)
    except Exception:
        return pd.DataFrame()

    actual = raw["sgdp"]
    proj_sgdp = out.sgdp
    rows = []
    for y in range(train_end + 1, test_end + 1):
        a_row = actual[actual["Year"] == y]
        p_row = proj_sgdp[proj_sgdp["Year"] == y]
        if a_row.empty or p_row.empty:
            continue
        a_row = a_row.iloc[0]
        p_row = p_row.iloc[0]
        for s in ["primary", "secondary", "tertiary"]:
            col = f"SGDP_{s}"
            rows.append({
                "country": code,
                "shrinkage": shrinkage,
                "year": y,
                "sector": s,
                "actual": float(a_row[col]),
                "projected": float(p_row[col]),
                "dev_pct": float((p_row[col] - a_row[col]) / a_row[col] * 100),
            })
    return pd.DataFrame(rows)


def discover_countries() -> list[str]:
    """Return the country codes present in DATA_DIR with all 4 CSVs non-empty
    for gdp_pop, sgdp, sinv (iRate may be missing — module tolerates that)."""
    codes: list[str] = []
    for p in sorted(DATA_DIR.glob("*_gdp_pop.csv")):
        code = p.name.split("_")[0]
        # Skip if any of the three mandatory series is empty
        ok = True
        for key in ("gdp_pop", "sgdp", "sinv"):
            f = DATA_DIR / f"{code}_{key}.csv"
            if not f.exists() or f.stat().st_size < 10:
                ok = False
                break
        if ok:
            codes.append(code)
    return codes


# Eurostat 2-letter codes -> WB iso3 used in the WDI country table
_EUROSTAT_TO_ISO3 = {
    "AT": "AUT", "BE": "BEL", "BG": "BGR", "CY": "CYP", "CZ": "CZE",
    "DE": "DEU", "DK": "DNK", "EE": "EST", "EL": "GRC", "ES": "ESP",
    "FI": "FIN", "FR": "FRA", "HR": "HRV", "HU": "HUN", "IE": "IRL",
    "IT": "ITA", "LT": "LTU", "LU": "LUX", "LV": "LVA", "MT": "MLT",
    "NL": "NLD", "PL": "POL", "PT": "PRT", "RO": "ROU", "SE": "SWE",
    "SI": "SVN", "SK": "SVK", "UK": "GBR", "NO": "NOR", "CH": "CHE",
}


def region_for_eurostat_code(code: str) -> str:
    """Look up the MITICA region for a Eurostat 2-letter country code.

    Reads ``wdi_data/countries.csv`` if available; falls back to "HIC" for
    any country we cannot classify. Returns "HIC" or "HIC_TRANS" for the
    EU-27 + UK panel.
    """
    countries_csv = DATA_DIR.parent / "wdi_data" / "countries.csv"
    fallback = "HIC"
    if not countries_csv.exists():
        return fallback
    iso3 = _EUROSTAT_TO_ISO3.get(code)
    if iso3 is None:
        return fallback
    df = pd.read_csv(countries_csv)
    row = df[df["iso3"] == iso3]
    if row.empty:
        return fallback
    r = row.iloc[0]["mitica_region"]
    return r if isinstance(r, str) else fallback


def main() -> None:
    countries = discover_countries()
    train_start = 1995
    train_end = 2005   # 11 years of history
    test_end = 2024    # 19 years of out-of-sample

    print(f"\n=== European backtest ===")
    print(f"  Training window: {train_start}-{train_end}  ({train_end - train_start + 1} years)")
    print(f"  Test window:     {train_end+1}-{test_end}  ({test_end - train_end} years)")
    print(f"  Countries ({len(countries)}): {countries}")

    out_dir = Path("scripts/macro_validation/results")
    out_dir.mkdir(parents=True, exist_ok=True)

    forms = ("log_log", "kuznets_chenery", "kuznets_chenery_quad")
    shrinkages = (0.3, 0.5, 0.7)  # narrowed: 0.0 = OLS chaos confirmed before
    summary_rows = []
    status_log: dict[str, list[str]] = {}

    # Pre-compute the MITICA region per country once (uses the WDI-based
    # HIC / HIC_TRANS stratification). This is the key change vs the
    # previous "everyone is HIC" assignment.
    region_by_code = {code: region_for_eurostat_code(code) for code in countries}
    print("\n  Region assignment (HIC = mature, HIC_TRANS = transitioning):")
    for code in countries:
        print(f"    {code:<4} -> {region_by_code[code]}")

    for form in forms:
        for shrink in shrinkages:
            print(f"\n  --- form={form}  shrink={shrink} ---")
            for code in countries:
                r = evaluate_country(
                    code,
                    train_start=train_start,
                    train_end=train_end,
                    test_end=test_end,
                    shrinkage=shrink,
                    region=region_by_code[code],
                    b2_form=form,
                )
                status_log.setdefault(r.get("status", "unknown"), []).append(
                    f"{code}@{form}@{shrink}"
                )
                if r.get("status") == "ok":
                    for s, m in r["metrics"].items():
                        summary_rows.append({
                            "country": code,
                            "form": form,
                            "shrinkage": shrink,
                            "sector": s,
                            **m,
                        })

    # Status summary
    print(f"\n  --- Status summary ---")
    for st, items in status_log.items():
        print(f"    {st}: {len(items)}")

    if not summary_rows:
        return

    # Attach the region assignment we used so we can subset.
    for row in summary_rows:
        row["region"] = region_by_code.get(row["country"], "UNK")

    summary = pd.DataFrame(summary_rows)
    summary_path = out_dir / f"summary_{train_start}_{train_end}_{test_end}.csv"
    summary.to_csv(summary_path, index=False)
    print(f"\n  Wrote summary metrics to {summary_path}")

    # ---- HIC vs HIC_TRANS sub-pool breakdown ----
    print(f"\n  =============================================================")
    print(f"  Sub-pool breakdown — does each country get a better fit under")
    print(f"  the prior of its own sub-pool?")
    print(f"  =============================================================")
    for sub in ("HIC", "HIC_TRANS"):
        sub_summary = summary[summary["region"] == sub]
        n_countries = sub_summary["country"].nunique()
        print(f"\n  {sub}  ({n_countries} countries, priors = {sub}):")
        print(f"  Median MAPE % at lambda=0.5:")
        print(f"    {'sector':<10}  {'LL':>8} {'KC':>8} {'KCQ':>8}")
        for sec in ("primary", "secondary", "tertiary"):
            row = f"    {sec:<10}"
            for f in forms:
                m = sub_summary[(sub_summary["sector"] == sec)
                                & (sub_summary["form"] == f)
                                & (sub_summary["shrinkage"] == 0.5)
                                ]["mape_pct"].median()
                row += f"  {m:>8.2f}"
            print(row)

    # ---- three-way form comparison ----
    print(f"\n  =============================================================")
    print(f"  Form comparison — median MAPE % across countries")
    print(f"  =============================================================")
    print(f"\n  Median MAPE % (lower is better)")
    hdr = f"  {'sector':<10}  {'shrink':>6}"
    for f in forms:
        hdr += f"  {f:>22}"
    print(hdr)
    for sec in ["primary", "secondary", "tertiary"]:
        for sh in shrinkages:
            row = f"  {sec:<10}  {sh:>6}"
            for f in forms:
                m = summary[(summary["sector"] == sec)
                            & (summary["form"] == f)
                            & (summary["shrinkage"] == sh)]["mape_pct"].median()
                row += f"  {m:>22.2f}"
            print(row)

    print(f"\n  Median signed endpoint dev % (closer to 0 is better)")
    hdr = f"  {'sector':<10}  {'shrink':>6}"
    for f in forms:
        hdr += f"  {f:>22}"
    print(hdr)
    for sec in ["primary", "secondary", "tertiary"]:
        for sh in shrinkages:
            row = f"  {sec:<10}  {sh:>6}"
            for f in forms:
                m = summary[(summary["sector"] == sec)
                            & (summary["form"] == f)
                            & (summary["shrinkage"] == sh)
                            ]["endpoint_dev_pct"].median()
                row += f"  {m:>+21.2f}%"
            print(row)


if __name__ == "__main__":
    main()
