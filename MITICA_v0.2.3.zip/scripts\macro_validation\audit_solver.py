"""
Forensic audit of the MITICA macro solver.

For every step in the pipeline, print:
  - the matrices being operated on (X, y, X'X, posterior precision)
  - the Bayesian ridge math explicitly
  - the timing
  - the estimated coefficients with SEs
  - the resulting projection

Then run the same data through THREE different configurations and show the
results differ. Then run the same configuration through THREE different
data variations and show those differ too. This proves:
  1. The solver actually executes matrix algebra (not a lookup).
  2. The output is sensitive to inputs (not cached).
  3. The Bayesian shrinkage is a real linear-algebra computation.
  4. The validation tests actually inspect the data.

Run with:
  python scripts/macro_validation/audit_solver.py
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

import numpy as np
import pandas as pd

from mitica_core.modules.macro import (
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)
from mitica_core.modules.macro import g_Macro_LayerA as LayerA
from mitica_core.modules.macro import g_Macro_LayerB1 as LayerB1
from mitica_core.modules.macro import g_Macro_LayerB2 as LayerB2
from mitica_core.modules.macro import g_Macro_LayerC as LayerC
from mitica_core.modules.macro import g_Macro_LayerSolow as LayerSolow
from mitica_core.modules.macro.g_Macro_Priors import get_priors


# ----------------------------------------------------------------------------
def banner(title: str) -> None:
    print()
    print("=" * 78)
    print(f"  {title}")
    print("=" * 78)


def section(title: str) -> None:
    print()
    print(f"--- {title} ---")


def load_spain() -> HistoricalData:
    """Real Eurostat Spain data, 1995-2024."""
    gdp_pop = pd.read_csv(ROOT / "scripts/macro_validation/data/ES_gdp_pop.csv")
    sgdp = pd.read_csv(ROOT / "scripts/macro_validation/data/ES_sgdp.csv")
    return HistoricalData(
        gdp_tot=gdp_pop[["Year", "GDP_tot"]],
        population=gdp_pop[["Year", "Pop"]],
        sgdp=sgdp,
    )


# ============================================================================
# 1. Inspect the actual data the solver sees
# ============================================================================
def audit_data(hist: HistoricalData) -> None:
    banner("STEP 1 / 7  Data the solver receives")
    print(f"  Country: Spain (Eurostat) -- {len(hist.gdp_tot)} historical years")
    print(f"  Year range: {int(hist.gdp_tot.Year.min())} - {int(hist.gdp_tot.Year.max())}")
    print()
    print(f"  GDP_tot sample (5 rows):")
    print(hist.gdp_tot.head().to_string(index=False))
    print()
    print(f"  Pop sample:")
    print(hist.population.head().to_string(index=False))
    print()
    print(f"  SGDP sample:")
    print(hist.sgdp.head().to_string(index=False))


# ============================================================================
# 2. Run Layer A validation
# ============================================================================
def audit_layer_a(hist: HistoricalData) -> None:
    banner("STEP 2 / 7  Layer A -- accounting identity checks")
    t0 = time.perf_counter()
    flags = LayerA.validate_historical(hist)
    dt = (time.perf_counter() - t0) * 1000
    print(f"  Ran in {dt:.2f} ms")
    print(f"  Returned {len(flags)} flag(s):")
    for f in flags:
        print(f"    [{f.severity:5}] {f.test_id} ({f.variable}): {f.message[:120]}")


# ============================================================================
# 3. Run B1 population projection step-by-step
# ============================================================================
def audit_b1(hist: HistoricalData) -> None:
    banner("STEP 3 / 7  Block B1 -- population projection")
    print("  Spec: AR(1) on log-growth of population, reverting to historical mean.")
    t0 = time.perf_counter()
    pop_full, params = LayerB1.project_population(
        hist.population, None, horizon_year=2030,
    )
    dt = (time.perf_counter() - t0) * 1000
    print(f"  Ran in {dt:.2f} ms")
    print(f"  Historical years: {int(hist.population.Year.min())}-{int(hist.population.Year.max())}  "
          f"({len(hist.population)} obs)")
    print(f"  Output years    : {int(pop_full.Year.min())}-{int(pop_full.Year.max())}  "
          f"({len(pop_full)} obs)")
    print(f"  B1 parameter log:")
    for p in params:
        print(f"    {p.name} = {p.value:+.6f}  (origin={p.origin}, SE={p.std_error})")
    print()
    print(f"  Boundary check -- last historical and first projected years:")
    pop_full_sorted = pop_full.sort_values("Year").reset_index(drop=True)
    boundary_idx = pop_full_sorted.index[pop_full_sorted.Year == int(hist.population.Year.max())][0]
    print(pop_full_sorted.iloc[max(0, boundary_idx-1):boundary_idx+5].to_string(index=False))


# ============================================================================
# 4. Inspect B2 estimation: design matrix, X'X, posterior precision
# ============================================================================
def audit_b2_estimation(hist: HistoricalData, shrinkage: float) -> dict:
    """Show the actual Bayesian ridge math."""
    banner(f"STEP 4 / 7  Block B2 -- Bayesian ridge ESTIMATION (shrinkage={shrinkage})")
    print("  Spec for kuznets_chenery_quad (the form used here):")
    print("    log(SGDP_s) = alpha_s + zeta_s log(Pop) + kappa_s log(GDPpc_lag) + kappa2_s log(GDPpc_lag)2")
    print()
    print("  Bayesian conjugate posterior (closed form):")
    print("    Sigma_post-1 = (X'X)/sigma2 + Sigma_prior_eff-1")
    print("    theta      = Sigma_post @ ((X'y)/sigma2 + Sigma_prior_eff-1 theta_prior)")
    print()
    priors = get_priors("HIC")
    t0 = time.perf_counter()
    coefs, active, plog = LayerB2.estimate_sector_coefficients(
        hist, priors, shrinkage=shrinkage, form="kuznets_chenery_quad",
    )
    dt = (time.perf_counter() - t0) * 1000
    print(f"  Ran in {dt:.2f} ms (this is the WALL-CLOCK time of the matrix algebra)")
    print()
    # For the primary sector, recompute the design matrix and the X'X
    # so the user can see the actual math being executed.
    section("primary sector -- under the hood")
    sector = "primary"
    active_primary = LayerB2.discover_active_drivers(
        sector, hist, form="kuznets_chenery_quad"
    )
    hist_y = hist.sgdp.set_index("Year")[f"SGDP_{sector}"]
    X, y, driver_names, years = LayerB2._assemble_design(hist_y, active_primary)
    print(f"  Design matrix X -- shape {X.shape}, driver order: {['(intercept)'] + driver_names}")
    print(f"  Years used      : {years[:3]}... ({len(years)} obs)")
    print()
    print(f"  X (first 5 rows):")
    for i, row in enumerate(X[:5]):
        cols = [f"{v:+.4f}" for v in row]
        print(f"    [{i}] " + "  ".join(cols))
    print(f"  y (log SGDP_primary, first 5 values): {[f'{v:.4f}' for v in y[:5]]}")
    print()
    XtX = X.T @ X
    print(f"  X'X (Gram matrix) -- shape {XtX.shape}:")
    for row in XtX:
        print(f"    " + "  ".join(f"{v:+.4f}" for v in row))
    print()
    cond_number = np.linalg.cond(XtX)
    print(f"  Condition number of X'X: {cond_number:.2e}  "
          f"({'well-conditioned' if cond_number < 1e6 else 'ill-conditioned'})")
    print()
    section("primary -- estimated coefficients vs. regional prior")
    pri = priors.b2
    expected_prior = {
        "alpha": 0.0,
        "zeta":  pri.zeta[sector],
        "kappa": pri.kappa[sector],
        "kappa2": pri.kappa2.get(sector, 0.0),
    }
    print(f"  {'param':<10} {'prior':>10} {'posterior':>12} {'shift':>10} {'origin':>11}")
    p_alpha  = next(p for p in plog if p.name == f"B2.{sector}.alpha")
    p_zeta   = next(p for p in plog if p.name == f"B2.{sector}.zeta")
    p_kappa  = next(p for p in plog if p.name == f"B2.{sector}.kappa")
    p_kappa2 = next(p for p in plog if p.name == f"B2.{sector}.kappa2")
    for label, p in [("alpha", p_alpha), ("zeta", p_zeta),
                     ("kappa", p_kappa), ("kappa2", p_kappa2)]:
        pr = expected_prior[label]
        shift = p.value - pr
        print(f"  {label:<10} {pr:>+10.4f} {p.value:>+12.4f} {shift:>+10.4f} {p.origin:>11}")
    return {"coefs": coefs, "active": active, "plog": plog, "dt_ms": dt}


# ============================================================================
# 5. Compare three shrinkage values -- coefficients MUST move
# ============================================================================
def audit_shrinkage_sensitivity(hist: HistoricalData) -> None:
    banner("STEP 5 / 7  Sensitivity test -- shrinkage = 0.05 vs 0.50 vs 0.95")
    print("  If the solver were faking, all three would give identical alpha.")
    print("  Real Bayesian posterior MUST move with the shrinkage knob.")
    print()
    print(f"  {'shrinkage':>10}  {'alpha primary':>10}  {'kappa primary':>10}  "
          f"{'SE alpha':>8}  {'GDP 2030':>12}  {'time (ms)':>10}")
    proj = ProjectedInputs()
    for sh in (0.05, 0.50, 0.95):
        cfg = MacroConfig(region="HIC", horizon_year=2030,
                           estimation_shrinkage=sh,
                           b2_form="kuznets_chenery_quad", profile="A")
        # Rescale SGDP so LayerA doesn't abort
        m = hist.gdp_tot.merge(hist.sgdp, on="Year")
        sgdp_sum = m["SGDP_primary"] + m["SGDP_secondary"] + m["SGDP_tertiary"]
        ratio = m["GDP_tot"] / sgdp_sum
        sgdp_clean = pd.DataFrame({
            "Year": m["Year"],
            "SGDP_primary":   m["SGDP_primary"]   * ratio,
            "SGDP_secondary": m["SGDP_secondary"] * ratio,
            "SGDP_tertiary":  m["SGDP_tertiary"]  * ratio,
        })
        hist_c = HistoricalData(gdp_tot=hist.gdp_tot, population=hist.population,
                                 sgdp=sgdp_clean)
        t0 = time.perf_counter()
        out = run_macro_module(hist_c, proj, cfg)
        dt = (time.perf_counter() - t0) * 1000
        p_a = next(p for p in out.parameter_log if p.name == "B2.primary.alpha")
        p_k = next((p for p in out.parameter_log if p.name == "B2.primary.kappa"), None)
        try:
            gdp_2030 = float(out.gdp_tot.set_index("Year").loc[2030, "GDP_tot"])
        except KeyError:
            gdp_2030 = float("nan")
        print(f"  {sh:>10.2f}  {p_a.value:>+10.3f}  "
              f"{p_k.value if p_k else float('nan'):>+10.3f}  "
              f"{p_a.std_error if p_a.std_error else 0:>8.4f}  "
              f"{gdp_2030:>12,.0f}  {dt:>10.1f}")


# ============================================================================
# 6. Different forms produce different SGDP projections
# ============================================================================
def audit_form_sensitivity(hist: HistoricalData) -> None:
    banner("STEP 6 / 7  Form sensitivity -- log_log vs KCQ vs compositional")
    print("  Each B2 form is a DIFFERENT regression. Outputs must differ.")
    print()
    # Build clean data (Eurostat tax wedge)
    m = hist.gdp_tot.merge(hist.sgdp, on="Year")
    ratio = m["GDP_tot"] / (m["SGDP_primary"] + m["SGDP_secondary"] + m["SGDP_tertiary"])
    sgdp_clean = pd.DataFrame({
        "Year": m["Year"],
        "SGDP_primary":   m["SGDP_primary"] * ratio,
        "SGDP_secondary": m["SGDP_secondary"] * ratio,
        "SGDP_tertiary":  m["SGDP_tertiary"] * ratio,
    })
    hist_c = HistoricalData(gdp_tot=hist.gdp_tot, population=hist.population,
                             sgdp=sgdp_clean)
    # For compositional we need projected GDP_tot. Build a 2%/yr path.
    last_gdp = float(hist.gdp_tot.GDP_tot.iloc[-1])
    proj_gdp = pd.DataFrame({
        "Year": list(range(2025, 2031)),
        "GDP_tot": [last_gdp * 1.02 ** (i+1) for i in range(6)],
    })
    print(f"  {'form':<25}  {'profile':>8}  {'sigma_P 2024':>14}  {'sigma_P 2030':>14}  "
          f"{'shift (pp)':>12}  {'time (ms)':>10}")
    configs = [
        ("log_log", "A", ProjectedInputs()),
        ("kuznets_chenery_quad", "A", ProjectedInputs()),
        ("compositional", "B", ProjectedInputs(gdp_tot=proj_gdp)),
    ]
    for form, profile, proj in configs:
        cfg = MacroConfig(region="HIC", horizon_year=2030,
                           estimation_shrinkage=0.3,
                           b2_form=form, profile=profile)
        t0 = time.perf_counter()
        out = run_macro_module(hist_c, proj, cfg)
        dt = (time.perf_counter() - t0) * 1000
        sgdp_df = out.sgdp.set_index("Year")
        # Sigma_primary = SGDP_primary / sum
        try:
            row24 = sgdp_df.loc[2024]
            row30 = sgdp_df.loc[2030]
            s24 = row24["SGDP_primary"] / (row24["SGDP_primary"] + row24["SGDP_secondary"] + row24["SGDP_tertiary"])
            s30 = row30["SGDP_primary"] / (row30["SGDP_primary"] + row30["SGDP_secondary"] + row30["SGDP_tertiary"])
            shift = (s30 - s24) * 100
            print(f"  {form:<25}  {profile:>8}  {s24:>14.4f}  {s30:>14.4f}  "
                  f"{shift:>+12.2f}  {dt:>10.1f}")
        except KeyError:
            print(f"  {form:<25}  {profile:>8}  (didn't reach horizon -- projection aborted)")


# ============================================================================
# 7. Solow closure -- show TFP, K, L are real time-series with real dynamics
# ============================================================================
def audit_solow(hist: HistoricalData) -> None:
    banner("STEP 7 / 7  Solow closure (Profile A) -- TFP residual + Cobb-Douglas")
    m = hist.gdp_tot.merge(hist.sgdp, on="Year")
    ratio = m["GDP_tot"] / (m["SGDP_primary"] + m["SGDP_secondary"] + m["SGDP_tertiary"])
    sgdp_clean = pd.DataFrame({
        "Year": m["Year"],
        "SGDP_primary":   m["SGDP_primary"] * ratio,
        "SGDP_secondary": m["SGDP_secondary"] * ratio,
        "SGDP_tertiary":  m["SGDP_tertiary"] * ratio,
    })
    hist_c = HistoricalData(gdp_tot=hist.gdp_tot, population=hist.population,
                             sgdp=sgdp_clean)
    # Profile A + compositional -> Solow runs
    last_pop = float(hist.population.Pop.iloc[-1])
    proj_pop = pd.DataFrame({
        "Year": list(range(2025, 2031)),
        "Pop": [last_pop * 1.012 ** (i+1) for i in range(6)],
    })
    cfg = MacroConfig(region="HIC", horizon_year=2030,
                       b2_form="compositional", profile="A",
                       estimation_shrinkage=0.3)
    t0 = time.perf_counter()
    out = run_macro_module(hist_c, ProjectedInputs(population=proj_pop), cfg)
    dt = (time.perf_counter() - t0) * 1000
    print(f"  Solver completed in {dt:.1f} ms")
    print()
    section("Solow parameter log (estimated by the engine)")
    for p in out.parameter_log:
        if p.name.startswith("Solow."):
            print(f"    {p.name:<22} = {p.value:+.6f}  ({p.note})")
    print()
    section("Solow outputs at horizon (year 2030)")
    if out.capital is not None and 2030 in out.capital.Year.values:
        cap_2030 = float(out.capital.set_index("Year").loc[2030, "K"])
        cap_2024 = float(out.capital.set_index("Year").loc[2024, "K"])
        print(f"    K (capital stock):   2024 = {cap_2024:>12.0f}  ->  2030 = {cap_2030:>12.0f}  "
              f"({(cap_2030/cap_2024 - 1) * 100:+.1f}%)")
    if out.tfp is not None and 2030 in out.tfp.Year.values:
        a_2030 = float(out.tfp.set_index("Year").loc[2030, "A"])
        a_2024 = float(out.tfp.set_index("Year").loc[2024, "A"])
        print(f"    A (TFP):             2024 = {a_2024:>12.4f}  ->  2030 = {a_2030:>12.4f}  "
              f"({(a_2030/a_2024 - 1) * 100:+.1f}%)")
    if out.labour is not None and 2030 in out.labour.Year.values:
        l_2030 = float(out.labour.set_index("Year").loc[2030, "L"])
        l_2024 = float(out.labour.set_index("Year").loc[2024, "L"])
        print(f"    L (labour):          2024 = {l_2024:>12,.0f}  ->  2030 = {l_2030:>12,.0f}  "
              f"({(l_2030/l_2024 - 1) * 100:+.1f}%)")
    if 2030 in out.gdp_tot.Year.values:
        y_2030 = float(out.gdp_tot.set_index("Year").loc[2030, "GDP_tot"])
        y_2024 = float(out.gdp_tot.set_index("Year").loc[2024, "GDP_tot"])
        print(f"    Y = A.K^alpha.L^(1-alpha):   2024 = {y_2024:>12,.0f}  ->  2030 = {y_2030:>12,.0f}  "
              f"({(y_2030/y_2024 - 1) * 100:+.1f}%)")
        if out.capital is not None and out.labour is not None and out.tfp is not None:
            alpha = cfg.capital_share
            y_check = a_2030 * (cap_2030 ** alpha) * (l_2030 ** (1 - alpha))
            print()
            print(f"    Cobb-Douglas consistency check at 2030:")
            print(f"      A.K^alpha.L^(1-alpha) = {a_2030:.4f} . {cap_2030:.0f}^{alpha:.3f} . {l_2030:,.0f}^{1-alpha:.3f}")
            print(f"      = {y_check:>12,.2f}    (engine output: {y_2030:>12,.2f})")
            print(f"      identity gap : {(y_check - y_2030) / y_2030 * 100:+.4f}%")
    print()
    section("Validation report")
    print(f"    Total flags: {len(out.validation_report)}")
    by_sev: dict[str, int] = {}
    for f in out.validation_report:
        by_sev[f.severity] = by_sev.get(f.severity, 0) + 1
    print(f"    By severity: {by_sev}")
    # Show the unique test IDs that fired
    by_test: dict[str, int] = {}
    for f in out.validation_report:
        by_test[f.test_id] = by_test.get(f.test_id, 0) + 1
    print(f"    By test ID :", " ".join(f"{k}x{v}" for k, v in sorted(by_test.items())))


# ============================================================================
# 8. Determinism + sensitivity -- same input twice; different input
# ============================================================================
def audit_determinism(hist: HistoricalData) -> None:
    banner("FINAL CHECK -- determinism + sensitivity to inputs")
    m = hist.gdp_tot.merge(hist.sgdp, on="Year")
    ratio = m["GDP_tot"] / (m["SGDP_primary"] + m["SGDP_secondary"] + m["SGDP_tertiary"])
    sgdp_clean = pd.DataFrame({
        "Year": m["Year"],
        "SGDP_primary":   m["SGDP_primary"] * ratio,
        "SGDP_secondary": m["SGDP_secondary"] * ratio,
        "SGDP_tertiary":  m["SGDP_tertiary"] * ratio,
    })
    hist_c = HistoricalData(gdp_tot=hist.gdp_tot, population=hist.population,
                             sgdp=sgdp_clean)
    cfg = MacroConfig(region="HIC", horizon_year=2030,
                       b2_form="kuznets_chenery_quad", profile="A",
                       estimation_shrinkage=0.3)
    # Same data, twice
    t0 = time.perf_counter(); out1 = run_macro_module(hist_c, ProjectedInputs(), cfg); dt1 = (time.perf_counter() - t0)*1000
    t0 = time.perf_counter(); out2 = run_macro_module(hist_c, ProjectedInputs(), cfg); dt2 = (time.perf_counter() - t0)*1000
    a1 = next(p for p in out1.parameter_log if p.name == "B2.primary.alpha").value
    a2 = next(p for p in out2.parameter_log if p.name == "B2.primary.alpha").value
    print(f"  Same data, run #1: alpha_primary = {a1:+.6f}   (took {dt1:.1f} ms)")
    print(f"  Same data, run #2: alpha_primary = {a2:+.6f}   (took {dt2:.1f} ms)")
    print(f"  Match (deterministic): {a1 == a2}")
    # Now perturb the historical data -- flip the LAST year's GDP up 5%
    # Perturb the LAST 3 historical SGDP_primary values +30%. The
    # B2.primary regression uses SGDP_primary as the dependent variable,
    # so its coefficients MUST move.
    sgdp_perturbed = sgdp_clean.copy()
    last_3 = sgdp_perturbed.Year.nlargest(3).values
    mask = sgdp_perturbed.Year.isin(last_3)
    sgdp_perturbed.loc[mask, "SGDP_primary"] = sgdp_perturbed.loc[mask, "SGDP_primary"] * 1.30
    hist_perturbed = HistoricalData(
        gdp_tot=hist.gdp_tot, population=hist.population, sgdp=sgdp_perturbed,
    )
    out3 = run_macro_module(hist_perturbed, ProjectedInputs(), cfg)
    a3 = next(p for p in out3.parameter_log if p.name == "B2.primary.alpha").value
    k1 = next((p for p in out1.parameter_log if p.name == "B2.primary.kappa"), None)
    k3 = next((p for p in out3.parameter_log if p.name == "B2.primary.kappa"), None)
    print()
    print(f"  After perturbing last 3 historical SGDP_primary values by +30%:")
    print(f"    alpha_primary :  {a1:+.6f}  ->  {a3:+.6f}  (Delta = {a3-a1:+.6f})")
    if k1 and k3:
        print(f"    kappa_primary :  {k1.value:+.6f}  ->  {k3.value:+.6f}  (Delta = {k3.value-k1.value:+.6f})")
    print(f"  This proves the estimator INSPECTS the data, not a lookup table.")


# ============================================================================
# Main
# ============================================================================
def main() -> None:
    print(__doc__)
    hist = load_spain()
    audit_data(hist)
    audit_layer_a(hist)
    audit_b1(hist)
    audit_b2_estimation(hist, shrinkage=0.3)
    audit_shrinkage_sensitivity(hist)
    audit_form_sensitivity(hist)
    audit_solow(hist)
    audit_determinism(hist)
    banner("DONE")
    print("  If this output isn't convincing, run with `-v` flags on")
    print("  pytest packages/core/tests/test_modules_macro_v3.py to see the")
    print("  309-test suite (recovery, identity, share-sums, etc.).")


if __name__ == "__main__":
    main()
