"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertCircle,
  Car,
  Check,
  CheckCircle2,
  Info,
  Pencil,
  Play,
  Plus,
  Trash2,
  X,
} from "lucide-react";

import {
  api,
  type TransportLever,
  type TransportPAM,
  type TransportResult,
  type TransportRunRequest,
  type TransportSegment,
  type TransportValidationFlag,
  type MacroDevGroup,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { cn } from "@/lib/utils";

// Same scenario palette as the energy page (WoM navy / measures teal / WAM earth).
const SCENARIO_COLORS: Record<string, string> = {
  WoM: "#1A2438",
  WEM: "#147A6E",
  WAM: "#8a7d5a",
};
const SCEN_ORDER = ["WoM", "WEM", "WAM"];

const LEVER_LABELS: Record<TransportLever, string> = {
  ev_sales_push: "EV sales push",
  fleet_renewal: "Fleet renewal (efficiency)",
  biofuel_blend: "Biofuel blend (CO₂ only)",
  modal_shift: "Modal shift (avoided vkm)",
  direct_reduction: "Direct reduction (kt series)",
};

const LEVER_HINTS: Record<TransportLever, string> = {
  ev_sales_push:
    "EV / e-bus / e-moped deployment enters through fleet turnover: the sales share ramps from the start year to the target year and propagates into the stock via cohorts.",
  fleet_renewal:
    "Efficiency gain on new vehicles (and optionally a share of the existing fleet), entering through turnover.",
  biofuel_blend:
    "Blend share of biofuel in road fuel. Affects CO₂ only — CH₄/N₂O are unchanged.",
  modal_shift:
    "Avoided vehicle-kilometres (shift to public/active/rail modes), as a % of segment activity.",
  direct_reduction:
    "Explicit mitigation series in kt CO₂-eq per year — for measures you have already quantified elsewhere.",
};

// Segment ↔ CRT 1A3b sub-code mapping.
const SEGMENT_LABELS: Record<TransportSegment, string> = {
  passenger_cars: "Passenger cars (1A3bi)",
  freight_light: "Light-duty freight (1A3bii)",
  freight_heavy_bus: "Heavy freight + buses (1A3biii)",
  two_three_wheelers: "Two/three-wheelers (1A3biv)",
};
const SEGMENT_ORDER: TransportSegment[] = [
  "passenger_cars",
  "freight_light",
  "freight_heavy_bus",
  "two_three_wheelers",
];
const SEGMENT_COLORS: Record<string, string> = {
  passenger_cars: "#147A6E",
  freight_light: "#5b6dcd",
  freight_heavy_bus: "#1A2438",
  two_three_wheelers: "#c97064",
};

const DEV_GROUP_LABELS: Record<MacroDevGroup, string> = {
  L: "L · Low income",
  LM: "LM · Lower-middle income",
  UM: "UM · Upper-middle income",
  H: "H · High income",
};

const TIER_HINTS: Record<string, string> = {
  T1: "fuel × emission factor",
  T2: "cohort fleet × intensity",
  T3: "distance-based (vkm)",
};

export default function TransportModulePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const qc = useQueryClient();

  const [horizon, setHorizon] = useState<string>("2050");
  const [devGroup, setDevGroup] = useState<MacroDevGroup | "">("");

  const stored = useQuery<TransportResult>({
    queryKey: ["transport-result", id],
    queryFn: () => api.getTransportResult(id),
    retry: false, // 404 until the first run
  });

  const run = useMutation({
    mutationFn: (): Promise<TransportResult> => {
      const body: TransportRunRequest = {
        horizon_year: Number(horizon) || 2050,
        scenarios: ["WoM", "WEM", "WAM"],
        ...(devGroup ? { dev_group: devGroup } : {}),
      };
      return api.runTransport(id, body);
    },
    onSuccess: () => {
      void stored.refetch();
      // has_transport_result flips on the project → refresh stepper/overview.
      void qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const result: TransportResult | undefined = run.data ?? stored.data;

  return (
    <div className="space-y-8">
      {/* ---- Header ---- */}
      <div>
        <div className="mb-2 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-rose-700">
            <Car className="h-5 w-5" />
          </div>
          <div>
            <div className="eyebrow">Module · SI-006 · CRT 1A3b</div>
            <h2 className="font-serif text-2xl font-[460]">Transport module (road)</h2>
          </div>
        </div>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Projection of <em>road transport</em> (CRT 1A3b, reported under sub-codes
          1A3bi–iv) on an ASIF spine — Activity × Structure × Intensity × Fuel —
          over a cohort fleet, faithful to{" "}
          <code className="rounded bg-muted px-1 font-mono">TRANSPORT_DESIGN.md</code>.
          The WoM baseline is the income spine validated by backtest on 188
          countries (median MAPE 14.2%); WEM/WAM are your PAMs computed as
          mini-scenarios on the module physics through 5 levers: EV sales push
          (EV / e-bus / e-moped deployment through fleet turnover), fleet renewal
          (efficiency), biofuel blending (CO₂ only), modal shift (avoided vkm)
          and direct reduction (explicit kt series). Drivers (GDP per capita,
          population) auto-pull from the Macro module result; road-CO₂ history
          auto-pulls from the project inventory (1A3b, falling back to 1A3).
          Activating the module on a project overrides ANNALIST for ONLY the 1A3b road-transport
          lines. Every other category in the inventory still projects with ANNALIST using your
          proxies.
        </p>
      </div>

      {/* ---- 1. PAMs ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">1. Measures (PAMs)</CardTitle>
        </CardHeader>
        <CardContent>
          <TransportPamEditor projectId={id} />
        </CardContent>
      </Card>

      {/* ---- 2. Run ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">2. Run the projection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label>Horizon year</Label>
              <Input
                type="number"
                min={2025}
                max={2100}
                value={horizon}
                onChange={(e) => setHorizon(e.target.value)}
              />
            </div>
            <div>
              <Label>Development group (override)</Label>
              <select
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={devGroup}
                onChange={(e) => setDevGroup(e.target.value as MacroDevGroup | "")}
              >
                <option value="">Auto — project income group, else GDP-pc</option>
                {(Object.keys(DEV_GROUP_LABELS) as MacroDevGroup[]).map((g) => (
                  <option key={g} value={g}>
                    {DEV_GROUP_LABELS[g]}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-[11px] text-muted-foreground">
                Selects the motorisation / activity priors. On auto the run uses
                the project&apos;s income group (project overview, from the World
                Bank classification); the GDP-pc fallback is currency-sensitive.
              </p>
            </div>
            <div className="self-end">
              <Button onClick={() => run.mutate()} disabled={run.isPending} className="w-full">
                <Play className="mr-2 h-4 w-4" />
                {run.isPending ? "Projecting…" : "Run WoM + WEM + WAM"}
              </Button>
            </div>
          </div>

          {run.error && (
            <p className="text-sm text-destructive">{(run.error as Error).message}</p>
          )}
          {run.isSuccess && (
            <p className="inline-flex items-center gap-1.5 text-sm text-primary">
              <CheckCircle2 className="h-4 w-4" /> Projection complete — horizon{" "}
              {run.data.horizon_year} · dev group {run.data.dev_group}
            </p>
          )}

          {result && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span
                className="rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 font-mono text-[11px] text-primary"
                title={TIER_HINTS[result.tier] ?? ""}
              >
                tier {result.tier}
                {TIER_HINTS[result.tier] ? ` · ${TIER_HINTS[result.tier]}` : ""}
              </span>
              {Object.entries(result.resolution_log).map(([k, v]) => (
                <span
                  key={k}
                  className="rounded-full border border-border bg-muted px-2 py-0.5 font-mono text-[11px] text-muted-foreground"
                >
                  {k}: {v}
                </span>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---- 3. Results ---- */}
      {result && <TransportResults result={result} />}
    </div>
  );
}

// ============================================================================
// Results — narrative summary, validation panel, scenario chart,
// by-segment stack, PAM mitigation bars.
// ============================================================================

function yearsOf(result: TransportResult): number[] {
  const set = new Set<number>();
  for (const m of Object.values(result.scenario_totals)) {
    for (const y of Object.keys(m)) set.add(Number(y));
  }
  return Array.from(set).sort((a, b) => a - b);
}

function orderedScenarios(result: TransportResult): string[] {
  return Object.keys(result.scenario_totals).sort(
    (a, b) =>
      (SCEN_ORDER.indexOf(a) + 1 || 99) - (SCEN_ORDER.indexOf(b) + 1 || 99),
  );
}

function TransportResults({ result }: { result: TransportResult }) {
  const years = yearsOf(result);
  const scenarios = orderedScenarios(result);

  const totalTraces = scenarios.map((scen) => {
    const m = result.scenario_totals[scen] ?? {};
    return {
      x: years,
      y: years.map((y) => m[String(y)] ?? null),
      type: "scatter" as const,
      mode: "lines+markers" as const,
      name: scen,
      line: { color: SCENARIO_COLORS[scen] ?? "#666", width: 2 },
    };
  });

  return (
    <div className="space-y-6">
      <TransportNarrativeSummary result={result} />
      <TransportValidationPanel report={result.validation_report ?? []} />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Scenario comparison — total road transport emissions (kt CO₂-eq)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PlotlyChart
            height={340}
            data={totalTraces}
            layout={{
              yaxis: { title: "kt CO₂-eq" },
              xaxis: { title: "Year" },
              legend: { orientation: "h" },
            }}
          />
        </CardContent>
      </Card>

      <SegmentBreakdown result={result} />
      <PamMitigationChart result={result} />
    </div>
  );
}

// ----- Narrative summary (deterministic from the result; no LLM) -------------

function TransportNarrativeSummary({ result }: { result: TransportResult }) {
  const years = yearsOf(result);
  if (years.length === 0) return null;
  const scenarios = orderedScenarios(result);
  // Effective horizon: the drivers (macro projection) may stop short of the
  // requested horizon — report at the last projected year in that case.
  const horizon = Math.min(result.horizon_year, years[years.length - 1]);
  const yKey = String(horizon);

  const at = (scen: string): number | null =>
    result.scenario_totals[scen]?.[yKey] ?? null;

  const wom = at("WoM");
  const wem = at("WEM");
  const wam = at("WAM");
  const wamPct = wom && wom > 0 && wam !== null ? (1 - wam / wom) * 100 : null;

  return (
    <Card>
      <CardContent className="py-3.5">
        <p className="text-sm leading-relaxed text-foreground">
          <span className="font-medium">
            Transport module · CRT 1A3b, {scenarios.length} scenario
            {scenarios.length === 1 ? "" : "s"} ({scenarios.join(", ")}), horizon{" "}
            {horizon}
            {horizon < result.horizon_year
              ? ` (drivers end before the requested ${result.horizon_year})`
              : ""}
            , resolution tier {result.tier}
            {TIER_HINTS[result.tier] ? ` (${TIER_HINTS[result.tier]})` : ""},
            dev group {result.dev_group}.
          </span>{" "}
          {wom !== null && (
            <>
              WoM emissions at {horizon}:{" "}
              <span className="font-mono">{wom.toFixed(0)}</span> kt CO₂-eq.
            </>
          )}
          {wem !== null && (
            <>
              {" "}WEM reaches <span className="font-mono">{wem.toFixed(0)}</span> kt.
            </>
          )}
          {wam !== null && (
            <>
              {" "}WAM reaches <span className="font-mono">{wam.toFixed(0)}</span> kt
              {wamPct !== null && (
                <>
                  {" "}(
                  <span className="font-mono">
                    {wamPct >= 0 ? "−" : "+"}
                    {Math.abs(wamPct).toFixed(1)}%
                  </span>{" "}
                  vs WoM)
                </>
              )}
              .
            </>
          )}
        </p>
      </CardContent>
    </Card>
  );
}

// ----- TR-* validation panel (mirrors the energy module's panel) -------------

function TransportValidationPanel({ report }: { report: TransportValidationFlag[] }) {
  const amber = report.filter((f) => f.severity === "amber").length;
  const info = report.filter((f) => f.severity === "info").length;
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">Validation summary</CardTitle>
        <div className="flex gap-2 text-xs">
          <span className="rounded-full border border-amber-600/40 bg-amber-600/10 px-2 py-0.5 text-amber-700">
            {amber} amber
          </span>
          <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
            {info} info
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <p className="mb-3 text-[11px] text-muted-foreground">
          Engine never fires red — it informs, the user decides.{" "}
          <strong>TR-01</strong> horizon sanity · <strong>TR-02</strong> growth
          band vs the income spine · <strong>TR-03</strong> input integrity
          (drivers + road-CO₂ history) · <strong>TR-04</strong> PAM after the
          horizon.
        </p>
        {report.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No flags raised — all plausibility checks passed.
          </p>
        ) : (
          <ul className="divide-y divide-border text-sm">
            {report.map((f, i) => (
              <li key={i} className="flex items-start gap-3 py-2.5">
                {f.severity === "amber" ? (
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" aria-hidden />
                ) : (
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                )}
                <div className="flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="font-mono text-xs text-muted-foreground">{f.test_id}</span>
                    <span className="text-sm font-medium">{f.variable}</span>
                  </div>
                  <p className="whitespace-pre-line text-xs text-muted-foreground">{f.message}</p>
                  {f.proposed_action && (
                    <p className="mt-1.5 text-xs text-foreground/90">
                      <span className="font-medium text-foreground">What to do: </span>
                      {f.proposed_action}
                    </p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// ----- Stacked-by-segment chart ----------------------------------------------

function SegmentBreakdown({ result }: { result: TransportResult }) {
  const scenarios = orderedScenarios(result);
  const [scen, setScen] = useState<string>(scenarios[0] ?? "WoM");
  const years = yearsOf(result);

  const segMap = result.by_segment[scen] ?? {};
  const segs = [
    ...SEGMENT_ORDER.filter((s) => s in segMap),
    ...Object.keys(segMap).filter((s) => !SEGMENT_ORDER.includes(s as TransportSegment)),
  ];

  const stacked = segs.map((seg) => ({
    x: years,
    y: years.map((y) => segMap[seg]?.[String(y)] ?? 0),
    name: SEGMENT_LABELS[seg as TransportSegment] ?? seg,
    type: "bar" as const,
    marker: { color: SEGMENT_COLORS[seg] ?? "#8a7d5a" },
  }));

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">By-segment stack — {scen}</CardTitle>
        <div className="flex overflow-hidden rounded-sm border border-border text-xs">
          {scenarios.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setScen(s)}
              className={cn(
                "px-3 py-1",
                s === scen
                  ? "bg-primary font-medium text-primary-foreground"
                  : "bg-card text-muted-foreground hover:bg-muted",
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={300}
          data={stacked}
          layout={{
            barmode: "stack",
            yaxis: { title: "kt CO₂-eq" },
            xaxis: { title: "Year" },
            legend: { orientation: "h", y: -0.25 },
          }}
        />
        <p className="mt-2 text-[11px] text-muted-foreground">
          Segments map to CRT sub-codes 1A3bi–iv. The macro-driven activity sets
          each segment&apos;s path; PAMs act on the segment they target.
        </p>
      </CardContent>
    </Card>
  );
}

// ----- PAM mitigation at horizon (horizontal bars) -----------------------------

function PamMitigationChart({ result }: { result: TransportResult }) {
  const years = yearsOf(result);
  // Effective horizon — see TransportNarrativeSummary.
  const horizon = years.length
    ? Math.min(result.horizon_year, years[years.length - 1])
    : result.horizon_year;

  // Prefer WAM (cumulative measure set), fall back to WEM.
  const scen =
    result.pam_mitigation["WAM"] && Object.keys(result.pam_mitigation["WAM"]).length > 0
      ? "WAM"
      : "WEM";
  const perPam = result.pam_mitigation[scen] ?? {};

  const entries = Object.entries(perPam)
    .map(([name, series]) => {
      const yearKeys = Object.keys(series).map(Number).sort((a, b) => a - b);
      const atHorizon =
        series[String(horizon)] ??
        (yearKeys.length ? series[String(yearKeys[yearKeys.length - 1])] : 0);
      return { name, kt: atHorizon ?? 0 };
    })
    // Ascending → largest bar renders at the top of the horizontal chart.
    .sort((a, b) => a.kt - b.kt);

  if (entries.length === 0) return null;

  const trace = {
    x: entries.map((e) => e.kt),
    y: entries.map((e) => e.name),
    type: "bar" as const,
    orientation: "h" as const,
    marker: { color: SCENARIO_COLORS[scen] },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">
          PAM mitigation at {horizon} — {scen} (kt CO₂-eq)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={Math.max(200, 60 + entries.length * 36)}
          data={[trace]}
          layout={{
            margin: { l: 200, r: 20, t: 10, b: 40 },
            xaxis: { title: "kt CO₂-eq mitigated" },
            showlegend: false,
          }}
        />
        <p className="mt-2 text-[11px] text-muted-foreground">
          Per-measure mitigation wedge at the horizon year, computed as a
          mini-scenario on the module physics (not a static R × M formula).
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// PAM editor — CRUD against /transport/pams. The form adapts its fields to
// the selected lever.
// ============================================================================

function pamParamSummary(p: TransportPAM): string {
  switch (p.lever) {
    case "ev_sales_push":
      return p.ev_target_sales_share != null
        ? `EV sales share → ${(p.ev_target_sales_share * 100).toFixed(0)}%`
        : "EV sales share";
    case "fleet_renewal": {
      const eff =
        p.efficiency_gain_pct != null ? `−${p.efficiency_gain_pct}% fuel/vkm` : "efficiency";
      const share =
        p.affected_fleet_share != null
          ? ` on ${(p.affected_fleet_share * 100).toFixed(0)}% of fleet`
          : "";
      return eff + share;
    }
    case "biofuel_blend": {
      const share = p.bio_share != null ? `${(p.bio_share * 100).toFixed(0)}% bio` : "blend";
      const ratio = p.bio_ef_ratio != null ? ` · EF ratio ${p.bio_ef_ratio}` : "";
      return share + ratio;
    }
    case "modal_shift":
      return p.activity_reduction_pct != null
        ? `−${p.activity_reduction_pct}% vkm`
        : "avoided vkm";
    case "direct_reduction": {
      const n = Object.keys(p.annual_kt ?? {}).length;
      return `${n} year${n === 1 ? "" : "s"} of explicit kt`;
    }
  }
}

function TransportPamEditor({ projectId }: { projectId: string }) {
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const pams = useQuery<TransportPAM[]>({
    queryKey: ["transport-pams", projectId],
    queryFn: () => api.listTransportPAMs(projectId),
    retry: false,
  });

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["transport-pams", projectId] });
  };

  const create = useMutation({
    mutationFn: (body: TransportPAM) => api.createTransportPAM(projectId, body),
    onSuccess: () => {
      invalidate();
      setCreating(false);
    },
  });
  const update = useMutation({
    mutationFn: ({ id, body }: { id: string; body: Partial<TransportPAM> }) =>
      api.updateTransportPAM(projectId, id, body),
    onSuccess: () => {
      invalidate();
      setEditingId(null);
    },
  });
  const del = useMutation({
    mutationFn: (pamId: string) => api.deleteTransportPAM(projectId, pamId),
    onSuccess: invalidate,
  });

  const rows = pams.data ?? [];
  const editingPam = editingId ? rows.find((p) => p.id === editingId) ?? null : null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Each measure is one of the 5 levers, applied to a scenario (WEM or
          WAM) and optionally a fleet segment. Re-run the projection after
          editing to see the effect.
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setCreating(true);
            setEditingId(null);
          }}
          disabled={creating}
        >
          <Plus className="mr-1 h-3 w-3" /> Add PAM
        </Button>
      </div>

      {(creating || editingPam) && (
        <TransportPamForm
          key={editingPam?.id ?? "new"}
          initial={editingPam}
          saving={create.isPending || update.isPending}
          onCancel={() => {
            setCreating(false);
            setEditingId(null);
          }}
          onSave={(body) => {
            if (editingPam?.id) update.mutate({ id: editingPam.id, body });
            else create.mutate(body);
          }}
        />
      )}

      <div className="overflow-hidden rounded-sm border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-1.5 text-left">Scenario</th>
              <th className="px-3 py-1.5 text-left">Lever</th>
              <th className="px-3 py-1.5 text-left">Segment</th>
              <th className="px-3 py-1.5 text-right">Years</th>
              <th className="px-3 py-1.5 text-left">Parameters</th>
              <th className="px-3 py-1.5 text-left">Name</th>
              <th className="px-3 py-1.5 text-right"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id ?? `${p.name}-${p.lever}-${p.start_year}`} className="border-t border-border">
                <td className="px-3 py-1.5">
                  <span
                    className={
                      p.scenario === "WAM"
                        ? "rounded bg-amber-700/10 px-1.5 py-0.5 text-xs text-amber-800"
                        : "rounded bg-primary/10 px-1.5 py-0.5 text-xs text-primary"
                    }
                  >
                    {p.scenario}
                  </span>
                </td>
                <td className="px-3 py-1.5 text-xs">{LEVER_LABELS[p.lever] ?? p.lever}</td>
                <td className="px-3 py-1.5 text-xs text-muted-foreground">
                  {p.segment ? SEGMENT_LABELS[p.segment] ?? p.segment : "All road"}
                </td>
                <td className="px-3 py-1.5 text-right font-mono text-xs">
                  {p.start_year}
                  {p.target_year ? `→${p.target_year}` : ""}
                </td>
                <td className="px-3 py-1.5 font-mono text-xs">{pamParamSummary(p)}</td>
                <td className="px-3 py-1.5 text-xs text-muted-foreground">{p.name}</td>
                <td className="px-3 py-1.5 text-right">
                  <div className="flex justify-end gap-1">
                    <button
                      type="button"
                      aria-label="Edit PAM"
                      className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"
                      disabled={!p.id || del.isPending}
                      onClick={() => {
                        setEditingId(p.id ?? null);
                        setCreating(false);
                      }}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      aria-label="Delete PAM"
                      className="rounded p-1 text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-50"
                      disabled={!p.id || del.isPending}
                      onClick={() => {
                        if (p.id && confirm(`Delete PAM "${p.name}"?`)) del.mutate(p.id);
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-4 text-center text-xs text-muted-foreground">
                  {pams.isError
                    ? "Could not load PAMs — is the transport backend running?"
                    : 'No measures yet. Click "Add PAM" to create one — without PAMs, WEM/WAM coincide with WoM.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {(create.error || update.error || del.error) && (
        <p className="text-xs text-destructive">
          {(create.error as Error | null)?.message ??
            (update.error as Error | null)?.message ??
            (del.error as Error | null)?.message}
        </p>
      )}
    </div>
  );
}

// ----- Lever-adaptive form -----------------------------------------------------

function parseAnnualKt(text: string): Record<string, number> | null {
  const out: Record<string, number> = {};
  for (const raw of text.split(/\n+/)) {
    const line = raw.trim();
    if (!line) continue;
    const parts = line.split(/[\s,:=]+/).filter(Boolean);
    if (parts.length !== 2) return null;
    const year = Number(parts[0]);
    const kt = Number(parts[1]);
    if (!Number.isInteger(year) || year < 1990 || year > 2150 || !Number.isFinite(kt)) {
      return null;
    }
    out[String(year)] = kt;
  }
  return Object.keys(out).length > 0 ? out : null;
}

function annualKtToText(m: Record<string, number> | null | undefined): string {
  if (!m) return "";
  return Object.entries(m)
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([y, v]) => `${y} ${v}`)
    .join("\n");
}

function TransportPamForm({
  initial,
  saving,
  onSave,
  onCancel,
}: {
  initial: TransportPAM | null;
  saving: boolean;
  onSave: (body: TransportPAM) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [scenario, setScenario] = useState<"WEM" | "WAM">(initial?.scenario ?? "WEM");
  const [lever, setLever] = useState<TransportLever>(initial?.lever ?? "ev_sales_push");
  const [segment, setSegment] = useState<TransportSegment | "">(initial?.segment ?? "");
  const [startYear, setStartYear] = useState<string>(String(initial?.start_year ?? new Date().getFullYear() + 1));
  const [targetYear, setTargetYear] = useState<string>(
    initial?.target_year != null ? String(initial.target_year) : "",
  );
  const [evShare, setEvShare] = useState<string>(
    initial?.ev_target_sales_share != null ? String(initial.ev_target_sales_share) : "",
  );
  const [effGain, setEffGain] = useState<string>(
    initial?.efficiency_gain_pct != null ? String(initial.efficiency_gain_pct) : "",
  );
  const [fleetShare, setFleetShare] = useState<string>(
    initial?.affected_fleet_share != null ? String(initial.affected_fleet_share) : "",
  );
  const [bioShare, setBioShare] = useState<string>(
    initial?.bio_share != null ? String(initial.bio_share) : "",
  );
  const [bioEfRatio, setBioEfRatio] = useState<string>(
    initial?.bio_ef_ratio != null ? String(initial.bio_ef_ratio) : "",
  );
  const [actReduction, setActReduction] = useState<string>(
    initial?.activity_reduction_pct != null ? String(initial.activity_reduction_pct) : "",
  );
  const [annualKtText, setAnnualKtText] = useState<string>(annualKtToText(initial?.annual_kt));

  const num = (s: string): number | null => (s.trim() === "" ? null : Number(s));

  // Single validation pass → { body } or { error }.
  const check = useMemo((): { body?: TransportPAM; error?: string } => {
    if (name.trim().length === 0) return { error: "Give the measure a name." };
    const sy = Number(startYear);
    if (!Number.isInteger(sy) || sy < 1990 || sy > 2150) {
      return { error: "Start year must be a year between 1990 and 2150." };
    }
    const ty = num(targetYear);
    if (ty !== null && (!Number.isInteger(ty) || ty < sy)) {
      return { error: "Target year must be ≥ start year." };
    }

    // FE-13: explicitly null every lever-specific param, then set only the
    // ones belonging to the selected lever. PATCH merges fields server-side,
    // so switching lever would otherwise leave stale cross-lever params stored.
    const base: TransportPAM = {
      ...(initial?.id ? { id: initial.id } : {}),
      name: name.trim(),
      scenario,
      lever,
      segment: segment === "" ? null : segment,
      start_year: sy,
      target_year: ty,
      ev_target_sales_share: null,
      efficiency_gain_pct: null,
      affected_fleet_share: null,
      bio_share: null,
      bio_ef_ratio: null,
      activity_reduction_pct: null,
      annual_kt: null,
    };

    switch (lever) {
      case "ev_sales_push": {
        if (segment === "") return { error: "EV sales push needs a fleet segment." };
        const v = num(evShare);
        if (v === null || !(v > 0 && v <= 1)) {
          return { error: "EV target sales share must be a fraction in (0, 1]." };
        }
        return { body: { ...base, ev_target_sales_share: v } };
      }
      case "fleet_renewal": {
        const v = num(effGain);
        if (v === null || !(v > 0 && v <= 100)) {
          return { error: "Efficiency gain must be a % in (0, 100]." };
        }
        const fs = num(fleetShare);
        if (fs !== null && !(fs > 0 && fs <= 1)) {
          return { error: "Affected fleet share must be a fraction in (0, 1] (or blank)." };
        }
        return { body: { ...base, efficiency_gain_pct: v, affected_fleet_share: fs } };
      }
      case "biofuel_blend": {
        const v = num(bioShare);
        if (v === null || !(v > 0 && v <= 1)) {
          return { error: "Biofuel share must be a fraction in (0, 1]." };
        }
        const r = num(bioEfRatio);
        if (r !== null && !(r >= 0 && r <= 1)) {
          return { error: "Bio EF ratio must be in [0, 1] (or blank for the default)." };
        }
        // null bio_ef_ratio = engine default (and clears any stale value).
        return { body: { ...base, bio_share: v, bio_ef_ratio: r } };
      }
      case "modal_shift": {
        const v = num(actReduction);
        if (v === null || !(v > 0 && v <= 100)) {
          return { error: "Activity reduction must be a % in (0, 100]." };
        }
        return { body: { ...base, activity_reduction_pct: v } };
      }
      case "direct_reduction": {
        const series = parseAnnualKt(annualKtText);
        if (!series) {
          return {
            error: 'Enter at least one "year value" line, e.g. "2030 120" (kt CO₂-eq per year).',
          };
        }
        return { body: { ...base, annual_kt: series } };
      }
    }
  }, [
    name, scenario, lever, segment, startYear, targetYear,
    evShare, effGain, fleetShare, bioShare, bioEfRatio, actReduction,
    annualKtText, initial?.id,
  ]);

  const selectCls =
    "h-9 w-full rounded-md border border-input bg-background px-2 text-sm";

  return (
    <div className="space-y-3 rounded-sm border border-primary/30 bg-primary/5 p-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <Label>Name</Label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. National EV purchase incentive"
          />
        </div>
        <div>
          <Label>Scenario</Label>
          <select
            className={selectCls}
            value={scenario}
            onChange={(e) => setScenario(e.target.value as "WEM" | "WAM")}
          >
            <option value="WEM">WEM — existing measure</option>
            <option value="WAM">WAM — additional measure</option>
          </select>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        <div className="sm:col-span-2">
          <Label>Lever</Label>
          <select
            className={selectCls}
            value={lever}
            onChange={(e) => setLever(e.target.value as TransportLever)}
          >
            {(Object.keys(LEVER_LABELS) as TransportLever[]).map((l) => (
              <option key={l} value={l}>
                {LEVER_LABELS[l]}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <Label>
            Segment{lever === "ev_sales_push" ? " (required)" : " (optional)"}
          </Label>
          <select
            className={selectCls}
            value={segment}
            onChange={(e) => setSegment(e.target.value as TransportSegment | "")}
          >
            <option value="">All road segments</option>
            {SEGMENT_ORDER.map((s) => (
              <option key={s} value={s}>
                {SEGMENT_LABELS[s]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">{LEVER_HINTS[lever]}</p>

      <div className="grid gap-3 sm:grid-cols-4">
        <div>
          <Label>Start year</Label>
          <Input type="number" value={startYear} onChange={(e) => setStartYear(e.target.value)} />
        </div>
        {lever !== "direct_reduction" && (
          <div>
            <Label>Target year (optional)</Label>
            <Input
              type="number"
              value={targetYear}
              onChange={(e) => setTargetYear(e.target.value)}
              placeholder="ramp end"
            />
          </div>
        )}

        {lever === "ev_sales_push" && (
          <div>
            <Label>EV sales share at target (0–1)</Label>
            <Input
              type="number"
              step="any"
              min={0}
              max={1}
              value={evShare}
              onChange={(e) => setEvShare(e.target.value)}
              placeholder="e.g. 0.5"
            />
          </div>
        )}

        {lever === "fleet_renewal" && (
          <>
            <div>
              <Label>Efficiency gain (%)</Label>
              <Input
                type="number"
                step="any"
                value={effGain}
                onChange={(e) => setEffGain(e.target.value)}
                placeholder="e.g. 15"
              />
            </div>
            <div>
              <Label>Affected fleet share (0–1, optional)</Label>
              <Input
                type="number"
                step="any"
                min={0}
                max={1}
                value={fleetShare}
                onChange={(e) => setFleetShare(e.target.value)}
                placeholder="blank = new sales only"
              />
            </div>
          </>
        )}

        {lever === "biofuel_blend" && (
          <>
            <div>
              <Label>Biofuel share (0–1)</Label>
              <Input
                type="number"
                step="any"
                min={0}
                max={1}
                value={bioShare}
                onChange={(e) => setBioShare(e.target.value)}
                placeholder="e.g. 0.1"
              />
            </div>
            <div>
              <Label>Bio EF ratio (optional)</Label>
              <Input
                type="number"
                step="any"
                min={0}
                max={1}
                value={bioEfRatio}
                onChange={(e) => setBioEfRatio(e.target.value)}
                placeholder="blank = default"
              />
            </div>
          </>
        )}

        {lever === "modal_shift" && (
          <div>
            <Label>Activity reduction (% of vkm)</Label>
            <Input
              type="number"
              step="any"
              value={actReduction}
              onChange={(e) => setActReduction(e.target.value)}
              placeholder="e.g. 5"
            />
          </div>
        )}
      </div>

      {lever === "direct_reduction" && (
        <div>
          <Label>Annual mitigation series (one &quot;year value&quot; per line, kt CO₂-eq)</Label>
          <textarea
            value={annualKtText}
            onChange={(e) => setAnnualKtText(e.target.value)}
            rows={4}
            placeholder={"2030 120\n2035 250\n2040 300"}
            className="mt-1 w-full rounded-md border border-input bg-background px-2 py-1.5 font-mono text-xs"
          />
        </div>
      )}

      {check.error && <p className="text-xs text-destructive">{check.error}</p>}

      <div className="flex justify-end gap-2">
        <Button variant="outline" size="sm" onClick={onCancel} disabled={saving}>
          <X className="mr-1 h-3 w-3" /> Cancel
        </Button>
        <Button
          size="sm"
          disabled={!check.body || saving}
          onClick={() => check.body && onSave(check.body)}
        >
          <Check className="mr-1 h-3 w-3" />
          {saving ? "Saving…" : initial ? "Save changes" : "Add measure"}
        </Button>
      </div>
    </div>
  );
}
