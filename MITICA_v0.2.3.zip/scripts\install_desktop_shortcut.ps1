# Creates a "MITICA Next.lnk" shortcut on the user's Desktop that launches
# scripts\start.cmd via cmd /c. Double-click -> API + Web up in production
# mode, browser opens automatically.
#
# Run from PowerShell:
#   powershell -ExecutionPolicy Bypass -File scripts\install_desktop_shortcut.ps1

$ErrorActionPreference = "Stop"

$root     = Split-Path -Parent $PSScriptRoot
$startCmd = Join-Path $root "scripts\start.cmd"
$icon     = "$env:SystemRoot\System32\shell32.dll,13"   # Generic app icon
$desktop  = [Environment]::GetFolderPath("Desktop")
$lnkPath  = Join-Path $desktop "MITICA Next.lnk"

$wsh      = New-Object -ComObject WScript.Shell
$shortcut = $wsh.CreateShortcut($lnkPath)
$shortcut.TargetPath       = "$env:SystemRoot\System32\cmd.exe"
$shortcut.Arguments        = "/c `"$startCmd`""
$shortcut.WorkingDirectory = $root
$shortcut.IconLocation     = $icon
$shortcut.Description      = "Launch MITICA Next (API + Web) in production mode"
$shortcut.Save()

Write-Host ""
Write-Host "[MITICA] Created shortcut:" -ForegroundColor Green
Write-Host "   $lnkPath"
Write-Host ""
Write-Host "Double-click it to start. The browser will open automatically once"
Write-Host "the API and the Web frontend are up."
Write-Host ""
