"""Fresh Eurostat download for the EU-27 v4 macro backtest.

One query per dataset (all EU-27 at once), reshaped to long, split per
country, and written as ONE tidy CSV per country under ``eurostat_v4/``:

    Year, GDP_tot, Pop, SGDP_primary, SGDP_secondary, SGDP_tertiary, GFCF_total

Everything is constant-2015-price (chain-linked volumes, CLV15_MEUR) except
population (persons, 1 Jan). These are the variables the macro module's
``HistoricalData`` consumes (the economic core + the B0 investment channel).

Datasets (cross-checked against the Eurostat data browser, CC BY 4.0):
* ``nama_10_gdp``  - GDP (B1GQ) and total GFCF (P51G), CLV15_MEUR
* ``nama_10_a10``  - sectoral gross value added (B1G by NACE), CLV15_MEUR
* ``demo_pjan``    - population on 1 January (sex=T, age=TOTAL)

NACE rev2 -> MITICA 3-sector map:
* primary   = A
* secondary = B-E (industry) + F (construction)
* tertiary  = G-T (services, all remaining aggregates)
"""

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import pandas as pd
import eurostat

warnings.filterwarnings("ignore", category=FutureWarning)

OUT_DIR = Path(__file__).resolve().parent / "eurostat_v4"

# Eurostat 2-letter geo codes for the EU-27 (EL = Greece).
EU27 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR",
    "DE", "EL", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL",
    "PL", "PT", "RO", "SK", "SI", "ES", "SE",
]

NACE_TO_SECTOR = {
    "A":   "primary",
    "B-E": "secondary",
    "F":   "secondary",
    "G-I": "tertiary",
    "G-J": "tertiary",
    "J":   "tertiary",
    "K":   "tertiary",
    "L":   "tertiary",
    "M_N": "tertiary",
    "O-Q": "tertiary",
    "R-U": "tertiary",
}
# The non-overlapping set that tiles GVA exactly once (avoid double counting:
# B-E already includes C; G-I/J/K/L/M_N/O-Q/R-U tile services without G-J).
NACE_KEEP = {"A", "B-E", "F", "G-I", "J", "K", "L", "M_N", "O-Q", "R-U"}


def _to_long(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    df = df.rename(columns={"geo\\TIME_PERIOD": "geo"})
    year_cols = [c for c in df.columns if str(c).isdigit()]
    id_cols = [c for c in df.columns if c not in year_cols]
    long = df.melt(id_vars=id_cols, value_vars=year_cols,
                   var_name="year", value_name="value")
    long["year"] = long["year"].astype(str).str.lstrip("A").astype(int)
    return long.dropna(subset=["value"])


def _fetch(dataset: str, filters: dict) -> pd.DataFrame:
    print(f"  [api] {dataset}  {filters}", flush=True)
    long = _to_long(eurostat.get_data_df(dataset, filter_pars=filters))
    print(f"        -> {len(long):,} rows", flush=True)
    return long


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"=== Eurostat v4 download — EU-27 ===\n")

    gdp = _fetch("nama_10_gdp", {"geo": EU27, "unit": ["CLV15_MEUR"],
                                 "na_item": ["B1GQ"]})
    gfcf = _fetch("nama_10_gdp", {"geo": EU27, "unit": ["CLV15_MEUR"],
                                  "na_item": ["P51G"]})
    pop = _fetch("demo_pjan", {"geo": EU27, "sex": ["T"], "age": ["TOTAL"]})
    gva = _fetch("nama_10_a10", {"geo": EU27, "unit": ["CLV15_MEUR"],
                                 "na_item": ["B1G"]})

    gva = gva[gva["nace_r2"].isin(NACE_KEEP)].copy()
    gva["sector"] = gva["nace_r2"].map(NACE_TO_SECTOR)

    n_ok = 0
    for cc in EU27:
        g = gdp[gdp["geo"] == cc][["year", "value"]].rename(columns={"value": "GDP_tot"})
        i = gfcf[gfcf["geo"] == cc][["year", "value"]].rename(columns={"value": "GFCF_total"})
        p = pop[pop["geo"] == cc][["year", "value"]].rename(columns={"value": "Pop"})
        s = gva[gva["geo"] == cc]
        if g.empty or p.empty or s.empty:
            print(f"  {cc}: MISSING core series — skipped")
            continue
        sa = (s.groupby(["year", "sector"])["value"].sum().unstack("sector")
              .rename(columns=lambda c: f"SGDP_{c}").reset_index())
        df = g.merge(p, on="year", how="inner").merge(sa, on="year", how="inner")
        df = df.merge(i, on="year", how="left")  # GFCF optional
        df = df.rename(columns={"year": "Year"}).sort_values("Year").reset_index(drop=True)
        need = ["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"]
        df = df.dropna(subset=["GDP_tot", "Pop"] + need)
        df.to_csv(OUT_DIR / f"{cc}.csv", index=False)
        yrs = df["Year"]
        print(f"  {cc}: {int(yrs.min())}-{int(yrs.max())} ({len(df)} pts)  "
              f"GFCF={'yes' if df['GFCF_total'].notna().any() else 'no'}")
        n_ok += 1

    print(f"\nWrote {n_ok}/27 country files to {OUT_DIR}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
