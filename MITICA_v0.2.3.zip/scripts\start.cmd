@echo off
rem ============================================================================
rem MITICA Next - production launcher.
rem
rem Works in two modes:
rem   INSTALLED mode: Python lives in ..\tools\python\ (portable, no .venv)
rem   DEV mode:       Python lives in .venv\ (standard virtualenv)
rem
rem Usage:
rem   scripts\start.cmd           (or double-click the "MITICA Next" desktop icon)
rem ============================================================================

setlocal EnableDelayedExpansion
set ROOT=%~dp0..
for %%i in ("%ROOT%") do set ROOT=%%~fi
pushd "%ROOT%"

rem --- pre-flight check: Python ------------------------------------------------
rem Accept portable Python (installed mode) OR .venv (dev mode)
set PYTHON_OK=0
if exist "%ROOT%\..\tools\python\python.exe" set PYTHON_OK=1
if exist "%ROOT%\.venv\Scripts\python.exe"   set PYTHON_OK=1

if "%PYTHON_OK%"=="0" (
    echo.
    echo  ERROR: Python not found.
    echo  Expected: tools\python\python.exe  (installed mode^)
    echo       or:  .venv\Scripts\python.exe  (dev mode^)
    echo.
    echo  Run scripts\install.cmd to set up the dev environment.
    echo.
    pause
    popd
    endlocal
    exit /b 1
)

rem --- pre-flight check: frontend build ----------------------------------------
if not exist "apps\web\.next\BUILD_ID" (
    echo.
    echo  ERROR: apps\web\.next is missing. The Next production build did not run.
    echo         Re-run scripts\install.cmd  (or  cd apps\web ^&^& pnpm build^).
    echo.
    pause
    popd
    endlocal
    exit /b 1
)

rem --- free the ports if something is left running ----------------------------
echo [start] Checking ports 8000 + 3000 ...
call "%~dp0stop.cmd" >nul 2>nul

rem --- launch API in its own window -------------------------------------------
echo [start] Launching API on http://127.0.0.1:8000 ...
start "MITICA API" cmd /k call "%~dp0_run_api_prod.cmd"

rem --- short pause so the API binds before the web tries to proxy to it -------
ping -n 3 127.0.0.1 >nul

rem --- launch Web in its own window -------------------------------------------
echo [start] Launching Web on http://localhost:3000 ...
start "MITICA Web" cmd /k call "%~dp0_run_web_prod.cmd"

rem --- background browser opener (waits for :3000 then opens the page) --------
start "" /min cmd /c call "%~dp0open_browser.cmd"

echo.
echo ============================================================================
echo  MITICA Next is starting.
echo.
echo    Web UI    http://localhost:3000      (browser will open automatically)
echo    API docs  http://127.0.0.1:8000/api/v1/docs
echo.
echo  Close the two windows or run scripts\stop.cmd to stop.
echo ============================================================================
echo.

popd
endlocal
exit /b 0
