"""v4 macro backtest on the EU-27 Eurostat panel — per-variable error.

Design (true out-of-sample, flow F3 — the model projects from history alone):
  1. T_end = last common year of the country's series.
  2. T_split = T_end - H ; train on years <= T_split.
  3. Project T_split+1 .. T_end (the last H=5 years) with EMPTY ProjectedInputs
     — the engine estimates GDP, Population AND the sectoral structure itself.
  4. Compare the estimate against the OBSERVED value of every model variable:
       - GDP_tot       : MAPE on the level (market prices, comparable).
       - Pop           : MAPE on the level.
       - GDP_per_cap   : MAPE on the level (the income path, the model's core).
       - sectoral split: percentage-point gap of the projected share vs the
         observed GVA share, per sector (primary/secondary/tertiary). Shares —
         not GVA levels — because the model's SGDP output is share x GDP (market
         prices) while observed GVA is basic prices; only the COMPOSITION is
         comparable. This is exactly what the B2-EC error-correction governs.

Units: Eurostat is constant-2015 EUR (CLV15_MEUR). The B2-EC income norm is
calibrated in constant-2015 USD/cap, so every monetary series is scaled by the
2015 average EUR->USD rate (1.1095) before being fed to the engine. This is a
uniform scalar: it leaves MAPE, shares and I/Y invariant, and only places the
income on the right point of the Chenery-Syrquin norm curve.

Config mirrors the canonical v4 WB backtest: region from the MITICA
classification (HIC / HIC_TRANS), dev_group = H (all EU-27 are high income).
Outputs go to results/eurostat_v4/.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA = Path(__file__).resolve().parent / "eurostat_v4"
OUTDIR = Path(__file__).resolve().parent / "results" / "eurostat_v4"

H = 5                  # project the last 5 years
MIN_TRAIN = 12         # require >= this many training years
# The v4 structure projection is CURRENCY-INVARIANT (it depends only on real
# per-capita growth, not the absolute income level), so Eurostat's native
# constant-EUR-millions are fed as-is — no USD conversion needed. SCALE is kept
# as a knob only to prove invariance (results are identical for any value).
SCALE = 1.0
SECTORS = ["primary", "secondary", "tertiary"]

# Eurostat 2-letter geo -> (country name, MITICA region). dev_group = "H" for
# all EU-27 (World Bank high income).
EU27_META = {
    "AT": ("Austria", "HIC"),        "BE": ("Belgium", "HIC"),
    "BG": ("Bulgaria", "HIC_TRANS"), "HR": ("Croatia", "HIC_TRANS"),
    "CY": ("Cyprus", "HIC"),         "CZ": ("Czechia", "HIC_TRANS"),
    "DK": ("Denmark", "HIC"),        "EE": ("Estonia", "HIC_TRANS"),
    "FI": ("Finland", "HIC"),        "FR": ("France", "HIC"),
    "DE": ("Germany", "HIC"),        "EL": ("Greece", "HIC"),
    "HU": ("Hungary", "HIC_TRANS"),  "IE": ("Ireland", "HIC"),
    "IT": ("Italy", "HIC"),          "LV": ("Latvia", "HIC_TRANS"),
    "LT": ("Lithuania", "HIC_TRANS"),"LU": ("Luxembourg", "HIC"),
    "MT": ("Malta", "HIC_TRANS"),    "NL": ("Netherlands", "HIC"),
    "PL": ("Poland", "HIC_TRANS"),   "PT": ("Portugal", "HIC_TRANS"),
    "RO": ("Romania", "HIC_TRANS"),  "SK": ("Slovakia", "HIC_TRANS"),
    "SI": ("Slovenia", "HIC_TRANS"), "ES": ("Spain", "HIC"),
    "SE": ("Sweden", "HIC"),
}


def _load(cc: str) -> pd.DataFrame | None:
    p = DATA / f"{cc}.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p)
    df = df.dropna(subset=["GDP_tot", "Pop"] + [f"SGDP_{s}" for s in SECTORS])
    return df.sort_values("Year").reset_index(drop=True)


def _shares(row) -> dict:
    tot = sum(float(row[f"SGDP_{s}"]) for s in SECTORS)
    return {s: float(row[f"SGDP_{s}"]) / tot for s in SECTORS}


def run_country(cc: str, t_end_force: int | None = None) -> dict | None:
    df = _load(cc)
    if df is None or df.empty:
        return None
    name, region = EU27_META[cc]
    yrs = df["Year"].astype(int).tolist()
    t_end = max(yrs) if t_end_force is None else t_end_force
    if t_end not in yrs:
        return {"cc": cc, "error": f"t_end {t_end} not in series"}
    t_split = t_end - H
    test_years = [y for y in range(t_split + 1, t_end + 1) if y in yrs]
    if len(test_years) < H:
        return {"cc": cc, "error": f"only {len(test_years)} test years"}
    train = df[df["Year"] <= t_split].copy()
    if len(train) < MIN_TRAIN:
        return {"cc": cc, "error": f"only {len(train)} training years"}

    # Scale monetary series to absolute constant-2015 USD for the income norm.
    g = train[["Year", "GDP_tot"]].copy()
    g["GDP_tot"] *= SCALE
    sg = train[["Year"] + [f"SGDP_{s}" for s in SECTORS]].copy()
    for s in SECTORS:
        sg[f"SGDP_{s}"] *= SCALE

    hist = HistoricalData(
        gdp_tot=g.reset_index(drop=True),
        population=train[["Year", "Pop"]].reset_index(drop=True),
        sgdp=sg.reset_index(drop=True),
    )
    cfg = MacroConfig(region=region, dev_group="H", horizon_year=t_end,
                      validate_historical=False, verbose=False)
    try:
        out = run_macro_module(hist, ProjectedInputs(), cfg)
    except Exception as e:  # pragma: no cover — diagnostic
        return {"cc": cc, "error": str(e)[:120]}

    obs = df.set_index("Year")
    p_gdp = out.gdp_tot.set_index("Year")["GDP_tot"] / SCALE  # back to MEUR
    p_pop = out.population.set_index("Year")["Pop"]
    p_sgdp = out.sgdp.set_index("Year")

    # --- per-variable errors over the H test years ---
    def _mape(proj: pd.Series, obs_col: str) -> float:
        return float(np.mean([abs(proj[y] - obs.at[y, obs_col]) / abs(obs.at[y, obs_col])
                              for y in test_years]))

    mape_gdp = _mape(p_gdp, "GDP_tot")
    # signed mean pct error (bias): negative => model under-projects the level
    mpe_gdp = float(np.mean([(p_gdp[y] - obs.at[y, "GDP_tot"]) / abs(obs.at[y, "GDP_tot"])
                             for y in test_years]))
    mape_pop = _mape(p_pop, "Pop")
    # GDP per capita (both in EUR/person now)
    pc_proj = pd.Series({y: (p_gdp[y] * 1e6) / p_pop[y] for y in test_years})
    pc_obs = {y: (obs.at[y, "GDP_tot"] * 1e6) / obs.at[y, "Pop"] for y in test_years}
    mape_pc = float(np.mean([abs(pc_proj[y] - pc_obs[y]) / abs(pc_obs[y]) for y in test_years]))

    # sectoral share deviation (pp): mean over the window, and at the horizon
    dev_win = {s: [] for s in SECTORS}
    for y in test_years:
        o_sh = _shares(obs.loc[y])
        p_sh = _shares(p_sgdp.loc[y])
        for s in SECTORS:
            dev_win[s].append(abs(p_sh[s] - o_sh[s]) * 100.0)
    dev_mean = {s: float(np.mean(dev_win[s])) for s in SECTORS}
    o_sh_h = _shares(obs.loc[t_end]); p_sh_h = _shares(p_sgdp.loc[t_end])
    dev_h = {s: abs(p_sh_h[s] - o_sh_h[s]) * 100.0 for s in SECTORS}

    # per-year detail for the "cuadro macro" export (in observed EUR units)
    detail = []
    for y in test_years:
        o_sh = _shares(obs.loc[y]); p_sh = _shares(p_sgdp.loc[y])
        detail.append({
            "cc": cc, "name": name, "region": region, "Year": y,
            "GDP_obs": obs.at[y, "GDP_tot"], "GDP_proj": float(p_gdp[y]),
            "Pop_obs": obs.at[y, "Pop"], "Pop_proj": float(p_pop[y]),
            "GDPpc_obs": pc_obs[y], "GDPpc_proj": float(pc_proj[y]),
            **{f"shareObs_{s}": o_sh[s] for s in SECTORS},
            **{f"shareProj_{s}": p_sh[s] for s in SECTORS},
        })

    return {
        "summary": {
            "cc": cc, "name": name, "region": region,
            "n_train": len(train), "t_split": t_split, "t_end": t_end,
            "mape_gdp": mape_gdp, "mpe_gdp": mpe_gdp,
            "mape_pop": mape_pop, "mape_gdppc": mape_pc,
            "dev_pp_primary": dev_mean["primary"],
            "dev_pp_secondary": dev_mean["secondary"],
            "dev_pp_tertiary": dev_mean["tertiary"],
            "devH_pp_primary": dev_h["primary"],
            "devH_pp_secondary": dev_h["secondary"],
            "devH_pp_tertiary": dev_h["tertiary"],
        },
        "detail": detail,
    }


def _agg(df: pd.DataFrame, label: str) -> None:
    if df.empty:
        print(f"  {label:<22} (none)")
        return
    print(f"  {label:<22} n={len(df):<2}  "
          f"GDP MAPE med={df.mape_gdp.median():5.1%} p90={df.mape_gdp.quantile(.9):5.1%} "
          f"bias={df.mpe_gdp.median():+5.1%} | "
          f"Pop med={df.mape_pop.median():5.1%} | "
          f"GDPpc med={df.mape_gdppc.median():5.1%} | "
          f"|dShare| sec med={df.dev_pp_secondary.median():4.1f}pp ter={df.dev_pp_tertiary.median():4.1f}pp")


def _run_window(t_end_force: int | None, tag: str) -> pd.DataFrame:
    rows, details, errs = [], [], []
    for cc in EU27_META:
        r = run_country(cc, t_end_force=t_end_force)
        if r is None:
            errs.append({"cc": cc, "error": "no data file"}); continue
        if "error" in r:
            errs.append(r); continue
        rows.append(r["summary"]); details.extend(r["detail"])
    summ = pd.DataFrame(rows)
    det = pd.DataFrame(details)
    summ.to_csv(OUTDIR / f"summary_by_country_{tag}.csv", index=False)
    det.to_csv(OUTDIR / f"cuadro_macro_detail_{tag}.csv", index=False)
    win = (f"{int(summ.t_split.min())+1}-{int(summ.t_end.max())}"
           if not summ.empty else "?")
    print(f"\n### Window '{tag}'  (test years ~{win}; project last {H}y, flow F3) "
          f"— scored {len(summ)}/27, {len(errs)} skipped")
    for e in errs:
        print(f"    [skip] {e['cc']}: {e['error']}")
    _agg(summ, "EU-27 (all)")
    _agg(summ[summ.region == "HIC"], "HIC (Western)")
    _agg(summ[summ.region == "HIC_TRANS"], "HIC_TRANS (catch-up)")
    return summ


def main() -> int:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    print("=== v4 EU-27 Eurostat backtest — per-variable error ===")
    # Headline: the last 5 available years (trains through the 2020 COVID
    # trough → projects the V-recovery; expect a downward GDP bias).
    summ = _run_window(None, "last5")
    # Robustness: a pre-pandemic window (project 2015-2019) isolates model
    # skill from the COVID-trough anchoring artifact.
    _run_window(2019, "prepandemic")
    # The canonical deliverable filenames point at the headline window.
    summ.to_csv(OUTDIR / "summary_by_country.csv", index=False)
    pd.read_csv(OUTDIR / "cuadro_macro_detail_last5.csv").to_csv(
        OUTDIR / "cuadro_macro_detail.csv", index=False)
    print(f"\nWrote per-window CSVs + canonical headline copies to {OUTDIR}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
