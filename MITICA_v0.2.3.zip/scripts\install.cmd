@echo off
rem ============================================================================
rem MITICA Next — one-shot install script (Windows).
rem
rem Idempotent. Runs end-to-end on a clean Windows 10/11 machine:
rem   1. Verifies (or installs via winget) Python 3.12+
rem   2. Verifies (or installs via winget) Node.js 20 LTS
rem   3. Enables corepack so pnpm is available without a global npm install
rem   4. Creates project-local .venv with the Python deps
rem   5. Installs the Node deps via pnpm
rem   6. Builds the Next frontend in production mode
rem   7. Generates sample data if missing
rem   8. Creates a desktop shortcut to start.cmd
rem
rem Usage:
rem   scripts\install.cmd
rem
rem Re-running is safe — already-done steps are skipped quickly.
rem ============================================================================

setlocal EnableExtensions EnableDelayedExpansion
set ROOT=%~dp0..
pushd "%ROOT%"

echo.
echo ============================================================================
echo  MITICA Next - install
echo  Working from %CD%
echo ============================================================================
echo.

rem ---------------------------------------------------------------------------
rem Step 1: Python 3.12+
rem ---------------------------------------------------------------------------
echo [1/8] Checking Python ^>= 3.11 ...
set PYTHON_OK=0
for /f "delims=" %%v in ('python --version 2^>nul') do (
    echo       found: %%v
    set PYTHON_OK=1
)
if %PYTHON_OK%==0 (
    echo       Python not detected on PATH.
    call :ensure_winget || goto fail
    echo.
    echo       The installer will now run "winget install Python.Python.3.12".
    set /p answer=      Proceed? [Y/n]:
    if /i "!answer!"=="n" (
        echo       Aborted. Install Python 3.12 manually from https://python.org and re-run.
        goto fail
    )
    winget install --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
    if errorlevel 1 (
        echo       winget install failed. Install Python 3.12 manually and re-run.
        goto fail
    )
    rem Refresh PATH for this session so the new python.exe is reachable
    call :refresh_path
)

rem ---------------------------------------------------------------------------
rem Step 2: Node.js 20+
rem ---------------------------------------------------------------------------
echo [2/8] Checking Node.js ^>= 20 ...
set NODE_OK=0
for /f "delims=" %%v in ('node --version 2^>nul') do (
    echo       found: %%v
    set NODE_OK=1
)
if %NODE_OK%==0 (
    echo       Node.js not detected on PATH.
    call :ensure_winget || goto fail
    echo.
    echo       The installer will now run "winget install OpenJS.NodeJS.LTS".
    set /p answer=      Proceed? [Y/n]:
    if /i "!answer!"=="n" (
        echo       Aborted. Install Node.js 20 LTS manually from https://nodejs.org and re-run.
        goto fail
    )
    winget install --id OpenJS.NodeJS.LTS --silent --accept-source-agreements --accept-package-agreements
    if errorlevel 1 (
        echo       winget install failed. Install Node.js 20 LTS manually and re-run.
        goto fail
    )
    call :refresh_path
)

rem ---------------------------------------------------------------------------
rem Step 3: corepack + pnpm
rem ---------------------------------------------------------------------------
echo [3/8] Enabling corepack for pnpm ...
where pnpm >nul 2>nul
if errorlevel 1 (
    call corepack enable >nul 2>nul
    if errorlevel 1 (
        echo       corepack enable failed. Falling back to: npm install -g pnpm
        call npm install -g pnpm
        if errorlevel 1 goto fail
    )
)
for /f "delims=" %%v in ('pnpm --version 2^>nul') do echo       pnpm: %%v

rem ---------------------------------------------------------------------------
rem Step 4: Python venv
rem ---------------------------------------------------------------------------
echo [4/8] Creating .venv ...
if exist ".venv\Scripts\python.exe" (
    echo       already present, skipping.
) else (
    python -m venv .venv
    if errorlevel 1 goto fail
)
set PY=%CD%\.venv\Scripts\python.exe

rem ---------------------------------------------------------------------------
rem Step 5: Python deps
rem ---------------------------------------------------------------------------
echo [5/8] Installing Python deps ^(mitica_core + mitica_api + runtime^) ...
"%PY%" -m pip install --upgrade pip --quiet
"%PY%" -m pip install -e packages\core -e packages\api --quiet
if errorlevel 1 goto fail
"%PY%" -m pip install --quiet ^
    fastapi "uvicorn[standard]" aiosqlite sqlalchemy python-multipart ^
    pydantic pydantic-settings pandas numpy scipy scikit-learn statsmodels ^
    pmdarima openpyxl xlsxwriter
if errorlevel 1 goto fail

echo       verifying imports ...
"%PY%" -c "from mitica_api.main import app; print('       API routes:', len(app.routes))"
if errorlevel 1 goto fail

rem ---------------------------------------------------------------------------
rem Step 6: Node deps
rem ---------------------------------------------------------------------------
echo [6/8] Installing web deps via pnpm ...
if exist "apps\web\node_modules\next" (
    echo       node_modules already present, skipping pnpm install.
) else (
    call pnpm install
    if errorlevel 1 goto fail
)

rem ---------------------------------------------------------------------------
rem Step 7: production build
rem ---------------------------------------------------------------------------
echo [7/8] Building Next.js frontend ^(production mode^) ...
if exist "apps\web\.next\BUILD_ID" (
    echo       .next/BUILD_ID found - skipping rebuild ^(delete it to force^).
) else (
    pushd apps\web
    call pnpm build
    set BUILD_RC=!errorlevel!
    popd
    if !BUILD_RC! neq 0 goto fail
)

rem ---------------------------------------------------------------------------
rem Step 8: sample data + desktop shortcut
rem ---------------------------------------------------------------------------
echo [8/8] Generating sample data + desktop shortcut ...
if not exist "sample_data\inventory.xlsx" (
    "%PY%" sample_data\generate.py
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_desktop_shortcut.ps1" >nul 2>nul
if errorlevel 1 (
    echo       Could not create desktop shortcut ^(non-fatal^).
) else (
    echo       Desktop shortcut created: "MITICA Next.lnk"
)

rem ---------------------------------------------------------------------------
echo.
echo ============================================================================
echo  Install complete.
echo.
echo  To start MITICA:
echo      scripts\start.cmd                ^(or double-click the desktop icon^)
echo.
echo  To stop MITICA:
echo      scripts\stop.cmd
echo.
echo  Open in your browser:
echo      http://localhost:3000
echo ============================================================================
echo.
popd
endlocal
exit /b 0


rem ============================================================================
rem  Subroutines
rem ============================================================================

:ensure_winget
where winget >nul 2>nul
if errorlevel 1 (
    echo.
    echo       winget is not available on this machine. You need Windows 10 1809+
    echo       or Windows 11 with the Microsoft Store update. Install winget from
    echo       https://aka.ms/getwinget then re-run this script.
    exit /b 1
)
exit /b 0

:refresh_path
rem Re-import PATH from the registry so winget-installed binaries are visible
rem without restarting the terminal. A bit hacky but works for setup scripts.
for /f "tokens=2*" %%a in ('reg query "HKCU\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "USR_PATH=%%b"
for /f "tokens=2*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul ^| findstr /i "Path"') do set "SYS_PATH=%%b"
set "PATH=%SYS_PATH%;%USR_PATH%"
exit /b 0


:fail
echo.
echo ============================================================================
echo  Install FAILED. Scroll up for the first error.
echo  Common fixes:
echo    - Re-run with admin rights if winget complains about permissions.
echo    - Ensure you have an internet connection (pip + pnpm need it).
echo    - On a corporate proxy, set HTTPS_PROXY before running.
echo ============================================================================
echo.
popd
endlocal
exit /b 1
