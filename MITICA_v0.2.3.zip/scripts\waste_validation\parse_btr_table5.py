"""Parse CRT Table5 (Sectoral report for WASTE) → per-country 5A/5B/5C/5D series.

Extends parse_btr_1a1a.py's proven idea to sheet ``Table5``. For every
year-workbook in each CRT zip it extracts, from the sector-5 table, the
top-level rows 5.A / 5.B / 5.C / 5.D (and "5. Total waste") with their per-gas
masses (CO2, CH4, N2O, in kt), then converts to **AR4 CO2-eq** (CH4=25, N2O=298
— MITICA convention, so the comparison against the module is GWP-consistent).

Output: scripts/waste_validation/data/btr/{ISO}_table5.csv (long: iso, year,
cat, co2_kt, ch4_kt, n2o_kt, co2eq_ar4_kt; cat in {5,5A,5B,5C,5D}). Notation
keys (NO/NE/NA/IE/C) → empty → 0 in the CO2-eq sum.

Year always from the sheet header cell (top-right), never the filename.

DATA-HONESTY (printed, never silently fixed):
1. Σ(5A+5B+5C+5D) CO2-eq vs the "5. Total waste" CO2-eq row, per year (5E/5F are
   memo/other — expected near-zero gap; mismatches listed).
2. 2 spot-checks per country: a CH4 cell re-read from the raw sheet at the
   recorded (row,col) with a fresh openpyxl load, compared to the parsed value.

Run: .venv\\Scripts\\python.exe scripts\\waste_validation\\parse_btr_table5.py
"""
from __future__ import annotations

import csv
import io
import re
import zipfile
from pathlib import Path

import openpyxl

BTR = (Path(__file__).resolve().parents[2] / "scripts" / "energy_validation"
       / "data" / "btr")
OUT_DIR = Path(__file__).parent / "data" / "btr"
ISOS = ["BRA", "CHL", "COL", "EGY", "GEO", "IDN", "KAZ", "TUR"]

SHEET = "Table5"
NOTATION = {"NO", "NE", "NA", "IE", "C", "IO", "FX"}
GWP_AR4 = {"CO2": 1.0, "CH4": 25.0, "N2O": 298.0}

# top-level category label patterns (exclude the 5.A.1 / 5.B.2 drill-downs)
CAT_PATTERNS = {
    "5":  re.compile(r"^\s*5\.\s+Total waste", re.I),
    "5A": re.compile(r"^\s*5\.A\.\s", re.I),
    "5B": re.compile(r"^\s*5\.B\.\s", re.I),
    "5C": re.compile(r"^\s*5\.C\.\s", re.I),
    "5D": re.compile(r"^\s*5\.D\.\s", re.I),
}


def num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    parts = {p.strip().upper() for p in s.split(",")}
    if parts and parts <= NOTATION:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def parse_sheet(ws):
    """Return (year, {cat: {'co2','ch4','n2o','_row','_ch4_col'}})."""
    rows = [[getattr(c, "value", None) for c in r]
            for r in ws.iter_rows(max_row=60, max_col=14)]
    # year from header (scan first 5 rows, all cols)
    year = None
    for r in rows[:5]:
        for v in r:
            if isinstance(v, (int, float)) and 1989 <= int(v) <= 2030:
                year = int(v)
            elif isinstance(v, str):
                m = re.search(r"\b((?:19|20)\d{2})\b", v)
                if m and 1989 <= int(m.group(1)) <= 2030:
                    year = int(m.group(1))
            if year:
                break
        if year:
            break
    # gas columns from the header row containing CO2/CH4/N2O
    co2_col = ch4_col = n2o_col = None
    for r in rows:
        for j, v in enumerate(r):
            s = str(v or "").strip().upper()
            if s == "CO2":
                co2_col = j
            elif s == "CH4":
                ch4_col = j
            elif s == "N2O":
                n2o_col = j
        if co2_col is not None and ch4_col is not None and n2o_col is not None:
            break
    if None in (co2_col, ch4_col, n2o_col):
        return year, None
    # category rows
    out: dict[str, dict] = {}
    for i, r in enumerate(rows):
        for cat, pat in CAT_PATTERNS.items():
            if cat in out:
                continue
            for v in r:
                if isinstance(v, str) and pat.match(v):
                    out[cat] = {
                        "co2": num(rows[i][co2_col]),
                        "ch4": num(rows[i][ch4_col]),
                        "n2o": num(rows[i][n2o_col]),
                        "_row": i + 1,
                        "_ch4_col": ch4_col + 1,
                    }
                    break
    return year, (out or None)


def co2eq(rec: dict) -> float:
    return (GWP_AR4["CO2"] * (rec.get("co2") or 0.0)
            + GWP_AR4["CH4"] * (rec.get("ch4") or 0.0)
            + GWP_AR4["N2O"] * (rec.get("n2o") or 0.0))


def parse_zip(iso: str, zpath: Path):
    z = zipfile.ZipFile(zpath)
    records, coords, problems = [], {}, []
    members = sorted(n for n in z.namelist()
                     if n.lower().endswith(".xlsx") and "~$" not in n)
    for name in members:
        wb = openpyxl.load_workbook(io.BytesIO(z.read(name)),
                                    read_only=True, data_only=True)
        if SHEET not in wb.sheetnames:
            problems.append(f"{name}: sheet {SHEET} missing")
            wb.close()
            continue
        year, data = parse_sheet(wb[SHEET])
        wb.close()
        if year is None or data is None:
            problems.append(f"{name}: year={year} data={'ok' if data else 'MISSING'}")
            continue
        for cat, rec in data.items():
            records.append((iso, year, cat, rec.get("co2"), rec.get("ch4"),
                            rec.get("n2o"), co2eq(rec)))
            coords[(year, cat)] = (name, rec["_row"], rec["_ch4_col"], rec.get("ch4"))
    return records, coords, problems


def validate_totals(iso, records) -> list[str]:
    by_year: dict[int, dict[str, float]] = {}
    for _iso, year, cat, _co2, _ch4, _n2o, ceq in records:
        by_year.setdefault(year, {})[cat] = ceq
    msgs = []
    for year in sorted(by_year):
        d = by_year[year]
        if "5" not in d:
            continue
        s = sum(d.get(c, 0.0) for c in ("5A", "5B", "5C", "5D"))
        tot = d["5"]
        tol = max(2.0, abs(tot) * 0.02)
        if abs(s - tot) > tol:
            msgs.append(f"{iso} {year}: Σ(5A-5D)={s:.1f} vs total={tot:.1f} "
                        f"(gap {s - tot:+.1f} kt CO2-eq AR4)")
    return msgs


def spot_check(iso, zpath, coords) -> list[str]:
    cands = sorted(k for k, v in coords.items() if v[3] is not None)
    if not cands:
        return [f"{iso}: NO non-null CH4 to spot-check"]
    picks = [cands[0], cands[-1]]
    if picks[0] == picks[1]:
        picks = picks[:1]
    z = zipfile.ZipFile(zpath)
    msgs = []
    for key in picks:
        member, row, col, parsed = coords[key]
        wb = openpyxl.load_workbook(io.BytesIO(z.read(member)),
                                    read_only=True, data_only=True)
        ws = wb[SHEET]
        raw = None
        for r in ws.iter_rows(min_row=row, max_row=row, min_col=col, max_col=col):
            raw = r[0].value
        wb.close()
        cell = f"{openpyxl.utils.get_column_letter(col)}{row}"
        ok = (isinstance(raw, (int, float))
              and abs(float(raw) - parsed) <= max(1e-9, abs(parsed) * 1e-9))
        msgs.append(f"{iso} {key[0]} {key[1]:>3s} CH4  sheet!{cell} raw={raw!r} "
                    f"csv={parsed!r}  {'OK' if ok else 'MISMATCH'}")
    return msgs


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    all_mism, all_prob, all_spot = [], [], []
    for iso in ISOS:
        zpath = BTR / f"{iso}_CRT.zip"
        if not zpath.exists():
            all_prob.append(f"{iso}: zip missing")
            print(f"{iso}: ZIP MISSING", flush=True)
            continue
        records, coords, problems = parse_zip(iso, zpath)
        all_prob += [f"{iso}: {p}" for p in problems]
        out = OUT_DIR / f"{iso}_table5.csv"
        with open(out, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["iso", "year", "cat", "co2_kt", "ch4_kt", "n2o_kt",
                        "co2eq_ar4_kt"])
            for r in sorted(records, key=lambda x: (x[1], x[2])):
                w.writerow(r)
        years = sorted({r[1] for r in records})
        mism = validate_totals(iso, records)
        all_mism += mism
        all_spot += spot_check(iso, zpath, coords)
        print(f"{iso}: {len(records)} rows, years {years[0]}-{years[-1]} "
              f"(n={len(years)}), total-mismatches {len(mism)}, "
              f"problems {len(problems)} -> {out.name}", flush=True)

    print("\n=== TOTAL-SUM MISMATCHES (Σ5A-5D vs '5. Total waste', AR4) ===")
    print("\n".join(all_mism) if all_mism else "none")
    print("\n=== WORKBOOK PROBLEMS ===")
    print("\n".join(all_prob) if all_prob else "none")
    print("\n=== SPOT-CHECKS (fresh raw re-read of a CH4 cell) ===")
    print("\n".join(all_spot))


if __name__ == "__main__":
    main()
