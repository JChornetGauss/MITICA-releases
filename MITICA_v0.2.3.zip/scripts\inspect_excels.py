"""Dump the real shape of MITICA-style Excels so we can fix the extractor."""

from __future__ import annotations

import sys
from pathlib import Path

import openpyxl


def dump(path: str, max_rows: int = 8, max_cols: int = 14):
    p = Path(path)
    if not p.exists():
        print(f"!! MISSING: {p}")
        return
    try:
        wb = openpyxl.load_workbook(p, data_only=True, read_only=True)
    except Exception as e:
        print(f"!! LOAD ERROR {p.name}: {e}")
        return
    print(f"\n=== {p.name}  ({p.stat().st_size / 1024:.1f} KB) ===")
    for sn in wb.sheetnames:
        ws = wb[sn]
        dim = f"{ws.max_column}x{ws.max_row}"
        print(f"  sheet={sn!r}  {dim}")
        rows_iter = ws.iter_rows(min_row=1, max_row=max_rows, max_col=max_cols, values_only=True)
        for i, row in enumerate(rows_iter, start=1):
            shown = [str(v)[:28] if v is not None else "" for v in row]
            print(f"    R{i:>2}: " + " | ".join(shown))


if __name__ == "__main__":
    for arg in sys.argv[1:]:
        dump(arg)
