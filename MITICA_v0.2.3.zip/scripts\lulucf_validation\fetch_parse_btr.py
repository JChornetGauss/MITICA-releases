"""
fetch_parse_btr.py — download each resolved CRT zip, parse its LULUCF Table 4
for every year, then DISCARD the extracted files (the zips are 30-100 MB each).
Accumulate the compact per-country series into _btr_series.json.

Download recipe (no cookie / no prime needed): browser UA + referer fetches the
static /sites/default/files/resource/*.zip straight through Incapsula.

Run repeatedly: it merges any new resolved-URL workflow outputs and skips
countries already in the cache.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

_HERE = Path(__file__).resolve()
_SCRIPTS = _HERE.parent
_CORE_SRC = _HERE.parents[2] / "packages" / "core" / "src"
for p in (str(_CORE_SRC), str(_SCRIPTS)):
    if p not in sys.path:
        sys.path.insert(0, p)
import crt_lulucf_reader as rdr  # noqa: E402
import _country_iso3  # noqa: E402

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_COOKIE = "/tmp/btr_cookie.txt"
_CACHE = _SCRIPTS / "_btr_series.json"


def _prime() -> None:
    subprocess.run(["curl", "-s", "--max-time", "30", "-c", _COOKIE, "-A", _UA,
                    "https://unfccc.int/", "-o", os.devnull], check=False)


def _fetch(url: str, out: str) -> tuple[bool, str]:
    """Download with primed cookie + referer; retry with backoff on 403/rate-limit."""
    code = ""
    for attempt in range(4):
        r = subprocess.run(
            ["curl", "-s", "--max-time", "300", "-b", _COOKIE, "-c", _COOKIE, "-A", _UA,
             "-H", "Referer: https://unfccc.int/first-biennial-transparency-reports",
             "-L", url, "-o", out, "-w", "%{http_code} %{size_download}"],
            capture_output=True, text=True)
        code = r.stdout.strip()
        if zipfile.is_zipfile(out):
            return True, code
        time.sleep(12 * (attempt + 1))
        _prime()
    return False, code
_TASKS = Path(r"C:\Users\juanl\AppData\Local\Temp\claude\C--Users-juanl-Documents-Claude-MITICA-project\7868ed16-21a2-40a8-939f-80df90d085ef\tasks")
_OUTFILES = ["win471f5t.output", "wompzxl84.output", "wzt822kik.output", "w2tf53wqc.output"]


def _load_urls() -> list[dict]:
    seen, out = set(), []
    for name in _OUTFILES:
        of = _TASKS / name
        if not of.exists():
            continue
        raw = of.read_text(encoding="utf-8")
        m = re.search(r"\[\s*\{.*\}\s*\]", raw, re.S)
        if not m:
            continue
        for d in json.loads(m.group(0)):
            u = (d.get("url") or "").strip()
            if u.endswith(".zip") and u not in seen:
                seen.add(u)
                out.append({"country": d["country"], "url": u})
    return out


def _iso(url: str) -> str:
    fn = url.rsplit("/", 1)[-1].replace("%20", " ").replace("%2520", " ")
    m = re.match(r"\s*([A-Za-z]{3})[-_ ]", fn)
    return m.group(1).upper() if m else re.sub(r"[^A-Za-z]", "", fn)[:3].upper()


def _year_from_name(fname: str) -> int | None:
    ys = [int(y) for y in re.findall(r"(?<!\d)(19[89]\d|20[0-2]\d)(?!\d)", fname)
          if 1989 <= int(y) <= 2023]
    return min(ys) if ys else None


def parse_dir(d: Path) -> dict:
    series: dict[str, dict] = {}
    for f in d.rglob("*.xlsx"):
        if f.name.startswith("~$"):
            continue
        try:
            r = rdr.read_table4(str(f))
        except Exception:
            continue
        if not r:
            continue
        year = r["year"] or _year_from_name(f.name)
        if year is None:
            continue
        cats = {c: rdr.co2eq(g) for c, g in r["categories"].items()}
        gases = sorted({gas for g in r["categories"].values()
                        for gas, v in g.items() if abs(v) > 1e-6})
        rec = dict(cats)
        rec["_total"] = rdr.co2eq(r["reported_total"]) if r["reported_total"] else None
        rec["_gases"] = gases
        # Real per-category land (kha) from Table 4.1 'Final area' — lets the
        # model run for countries not in MITICA's refDB.
        try:
            lr = rdr.read_table41_land(str(f), year_override=year)
            if lr and lr.get("land"):
                rec["_land"] = {k: round(v, 3) for k, v in lr["land"].items()}
        except Exception:
            pass
        if str(year) not in series or len([k for k in rec if not k.startswith("_")]) >= \
                len([k for k in series[str(year)] if not k.startswith("_")]):
            series[str(year)] = rec
    return series


def main() -> int:
    cache = json.loads(_CACHE.read_text(encoding="utf-8", errors="replace")) if _CACHE.exists() else {}
    urls = _load_urls()
    print(f"{len(urls)} resolved URLs; {len(cache)} already cached")
    _prime()
    print("primed cookie.")
    ok = fail = 0
    for d in urls:
        url, country = d["url"], d["country"]
        iso = _country_iso3.iso3(country) or _iso(url)
        if iso in cache:
            continue
        tmpzip = tempfile.mktemp(suffix=".zip")
        good, code = _fetch(url, tmpzip)
        time.sleep(3)  # be polite — avoid the rate-limit burst flag
        if not good:
            print(f"  FAIL  {iso:4} {country[:22]:22}  ({code})")
            fail += 1
            if os.path.exists(tmpzip):
                os.remove(tmpzip)
            continue
        exdir = Path(tempfile.mkdtemp())
        try:
            with zipfile.ZipFile(tmpzip) as z:
                z.extractall(exdir)
            series = parse_dir(exdir)
            if series:
                cache[iso] = {"country": country, "series": series}
                yrs = sorted(int(y) for y in series)
                ncat = max((len([k for k in series[str(y)] if not k.startswith("_")])
                            for y in yrs), default=0)
                print(f"  OK    {iso:4} {country[:22]:22}  {len(yrs)}yr {yrs[0]}-{yrs[-1]} maxcat={ncat}")
                ok += 1
                _CACHE.write_text(json.dumps(cache, ensure_ascii=True), encoding="utf-8")  # incremental save
            else:
                print(f"  NODATA {iso:4} {country[:22]:22} (no Table4)")
                fail += 1
        except Exception as e:
            print(f"  ERR   {iso:4} {country[:22]:22}  {type(e).__name__}: {str(e)[:40]}")
            fail += 1
        finally:
            shutil.rmtree(exdir, ignore_errors=True)
            if os.path.exists(tmpzip):
                os.remove(tmpzip)
    print(f"=== OK={ok} FAIL={fail} | cache now has {len(cache)} countries ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
