"""Export the EU-27 Eurostat v4 backtest to a single formatted workbook.

Reads the CSVs produced by v4_eurostat_backtest.py and writes
results/eurostat_v4/MITICA_v4_EU27_backtest.xlsx with sheets:
  - Metodologia : what was estimated, units, windows, caveats
  - Resumen      : per-country per-variable error (headline window 2021-25)
  - Resumen_prepandemia : the same for the 2015-19 robustness window
  - Agregados    : EU-27 / HIC / HIC_TRANS medians & p90 per variable
  - Cuadro_macro : projected vs observed per country-year (the deliverable)
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

R = Path(__file__).resolve().parent / "results" / "eurostat_v4"
OUT = R / "MITICA_v4_EU27_backtest.xlsx"

HDR = Font(bold=True, color="FFFFFF")
HDR_FILL = PatternFill("solid", fgColor="305496")
TITLE = Font(bold=True, size=13)


def _agg_table(summ: pd.DataFrame) -> pd.DataFrame:
    rows = []
    groups = [("EU-27 (todos)", summ),
              ("HIC (occidental)", summ[summ.region == "HIC"]),
              ("HIC_TRANS (convergencia)", summ[summ.region == "HIC_TRANS"])]
    for label, df in groups:
        if df.empty:
            continue
        rows.append({
            "Grupo": label, "n": len(df),
            "GDP MAPE mediana": df.mape_gdp.median(),
            "GDP MAPE p90": df.mape_gdp.quantile(0.9),
            "GDP sesgo (mediana)": df.mpe_gdp.median(),
            "Poblacion MAPE mediana": df.mape_pop.median(),
            "GDP/capita MAPE mediana": df.mape_gdppc.median(),
            "Estructura |Δ| secundario (pp)": df.dev_pp_secondary.median(),
            "Estructura |Δ| terciario (pp)": df.dev_pp_tertiary.median(),
        })
    return pd.DataFrame(rows)


def _style_header(ws, ncols: int, row: int = 1) -> None:
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = HDR
        cell.fill = HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _autofit(ws, widths: dict[int, int] | None = None) -> None:
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        if widths and col[0].column in widths:
            ws.column_dimensions[letter].width = widths[col[0].column]
            continue
        m = max((len(str(c.value)) for c in col if c.value is not None), default=10)
        ws.column_dimensions[letter].width = min(max(m + 2, 10), 42)


def main() -> int:
    last5 = pd.read_csv(R / "summary_by_country_last5.csv")
    prep = pd.read_csv(R / "summary_by_country_prepandemic.csv")
    detail = pd.read_csv(R / "cuadro_macro_detail_last5.csv")

    with pd.ExcelWriter(OUT, engine="openpyxl") as xl:
        # ---- Metodologia ----
        meth = pd.DataFrame({"MITICA v4 — Backtest EU-27 sobre Eurostat": [
            "",
            "QUE SE ESTIMA",
            "Para cada pais de la UE-27: se entrena el modelo v4 con la historia hasta el ano T-5",
            "y se PROYECTAN los ultimos 5 anos SOLO con el modelo (flujo F3, ProjectedInputs vacio):",
            "el modelo estima GDP, Poblacion y la estructura sectorial a partir de su propia historia.",
            "Se compara la estimacion contra el dato OBSERVADO de cada variable.",
            "",
            "VARIABLES Y METRICA DE ERROR",
            "  GDP_tot      : MAPE sobre el nivel (precios de mercado, comparable)",
            "  Poblacion    : MAPE sobre el nivel",
            "  GDP/capita   : MAPE sobre el nivel (la senda de renta, nucleo del modelo)",
            "  Estructura   : desviacion en puntos porcentuales (pp) de la cuota proyectada vs la",
            "                 cuota observada de VAB, por sector. Se comparan CUOTAS, no niveles,",
            "                 porque el VAB (precios basicos) no suma el GDP (precios de mercado).",
            "  Sesgo (MPE)  : error porcentual medio con signo; negativo = el modelo INFRAproyecta.",
            "",
            "DATOS (Eurostat, CC BY 4.0, precios constantes 2015)",
            "  nama_10_gdp  : GDP (B1GQ) e inversion total GFCF (P51G), CLV15_MEUR",
            "  nama_10_a10  : VAB sectorial (B1G por NACE rev2) -> primario/secundario/terciario",
            "  demo_pjan    : poblacion a 1 de enero",
            "  Las series monetarias se escalan por 1.1095 (EUR->USD medio 2015) para situar la",
            "  renta en la curva-norma (Chenery-Syrquin) calibrada en USD; es un escalar uniforme:",
            "  no altera MAPE, cuotas ni I/Y.",
            "",
            "VENTANAS",
            "  'Resumen' (titular): ultimos 5 anos disponibles = 2021-2025. Entrena hasta 2020,",
            "     que es el valle COVID -> proyecta la recuperacion en V desde el minimo, de ahi",
            "     un sesgo sistematico a la baja (~ -5%).",
            "  'Resumen_prepandemia': proyecta 2015-2019 (entrena hasta 2014). Aisla la pericia del",
            "     modelo del artefacto de anclaje COVID -> error mucho menor y practicamente sin sesgo.",
            "",
            "CONFIGURACION: region segun clasificacion MITICA (HIC / HIC_TRANS); grupo de desarrollo",
            "  = H (toda la UE-27 es renta alta). Modelo = run_macro_module (v4, sin Solow).",
        ]})
        meth.to_excel(xl, sheet_name="Metodologia", index=False)

        # ---- Resumen (headline) ----
        def _summary_view(df: pd.DataFrame) -> pd.DataFrame:
            v = df.copy()
            v = v.rename(columns={
                "cc": "ISO", "name": "Pais", "region": "Region",
                "n_train": "Anos entren.", "t_split": "Ultimo entren.", "t_end": "Horizonte",
                "mape_gdp": "GDP MAPE", "mpe_gdp": "GDP sesgo",
                "mape_pop": "Pob MAPE", "mape_gdppc": "GDP/cap MAPE",
                "dev_pp_secondary": "Sec |Δ|pp", "dev_pp_tertiary": "Ter |Δ|pp",
                "dev_pp_primary": "Prim |Δ|pp",
            })
            cols = ["ISO", "Pais", "Region", "Anos entren.", "Ultimo entren.", "Horizonte",
                    "GDP MAPE", "GDP sesgo", "Pob MAPE", "GDP/cap MAPE",
                    "Prim |Δ|pp", "Sec |Δ|pp", "Ter |Δ|pp"]
            return v[cols].sort_values("GDP MAPE", ascending=False)

        _summary_view(last5).to_excel(xl, sheet_name="Resumen", index=False)
        _summary_view(prep).to_excel(xl, sheet_name="Resumen_prepandemia", index=False)

        # ---- Agregados ----
        agg = pd.concat([
            _agg_table(last5).assign(Ventana="2021-2025 (titular)"),
            _agg_table(prep).assign(Ventana="2015-2019 (pre-pandemia)"),
        ])
        agg = agg[["Ventana"] + [c for c in agg.columns if c != "Ventana"]]
        agg.to_excel(xl, sheet_name="Agregados", index=False)

        # ---- Cuadro macro (projected vs observed) ----
        d = detail.copy()
        d["GDP_err_%"] = (d.GDP_proj / d.GDP_obs - 1.0)
        d["Pop_err_%"] = (d.Pop_proj / d.Pop_obs - 1.0)
        for s in ("primary", "secondary", "tertiary"):
            d[f"share_{s}_obs"] = d[f"shareObs_{s}"]
            d[f"share_{s}_proj"] = d[f"shareProj_{s}"]
        cm = d[["cc", "name", "region", "Year",
                "GDP_obs", "GDP_proj", "GDP_err_%",
                "Pop_obs", "Pop_proj", "Pop_err_%",
                "GDPpc_obs", "GDPpc_proj",
                "share_secondary_obs", "share_secondary_proj",
                "share_tertiary_obs", "share_tertiary_proj"]]
        cm = cm.rename(columns={"cc": "ISO", "name": "Pais", "region": "Region",
                                "Year": "Ano"})
        cm.to_excel(xl, sheet_name="Cuadro_macro", index=False)

    # ---- formatting pass ----
    import openpyxl
    wb = openpyxl.load_workbook(OUT)

    # Metodologia: title + width
    ws = wb["Metodologia"]
    ws["A1"].font = TITLE
    ws.column_dimensions["A"].width = 95

    pct1 = "0.0%"
    pct_signed = "+0.0%;-0.0%"
    for sheet in ("Resumen", "Resumen_prepandemia"):
        ws = wb[sheet]
        _style_header(ws, ws.max_column)
        ws.freeze_panes = "A2"
        for r in range(2, ws.max_row + 1):
            for cidx, fmt in (("G", pct1), ("H", pct_signed), ("I", pct1), ("J", pct1)):
                ws[f"{cidx}{r}"].number_format = fmt
            for cidx in ("K", "L", "M"):
                ws[f"{cidx}{r}"].number_format = "0.0"
        _autofit(ws, {2: 16, 3: 12})

    ws = wb["Agregados"]
    _style_header(ws, ws.max_column)
    for r in range(2, ws.max_row + 1):
        for c in range(4, ws.max_column + 1):
            head = str(ws.cell(row=1, column=c).value)
            if "pp" in head:
                ws.cell(row=r, column=c).number_format = "0.0"
            elif "sesgo" in head:
                ws.cell(row=r, column=c).number_format = pct_signed
            else:
                ws.cell(row=r, column=c).number_format = pct1
    _autofit(ws)

    ws = wb["Cuadro_macro"]
    _style_header(ws, ws.max_column)
    ws.freeze_panes = "E2"
    hdr = {ws.cell(row=1, column=c).value: c for c in range(1, ws.max_column + 1)}
    for r in range(2, ws.max_row + 1):
        for name in ("GDP_obs", "GDP_proj", "Pop_obs", "Pop_proj", "GDPpc_obs", "GDPpc_proj"):
            ws.cell(row=r, column=hdr[name]).number_format = "#,##0"
        for name in ("GDP_err_%", "Pop_err_%"):
            ws.cell(row=r, column=hdr[name]).number_format = pct_signed
        for name in ("share_secondary_obs", "share_secondary_proj",
                     "share_tertiary_obs", "share_tertiary_proj"):
            ws.cell(row=r, column=hdr[name]).number_format = "0.0%"
    _autofit(ws, {2: 16})

    wb.save(OUT)
    print(f"Wrote {OUT}")
    print(f"  sheets: {wb.sheetnames}")
    print(f"  Cuadro_macro rows: {len(detail)}  countries: {detail['cc'].nunique()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
