"""F-gases empirical audit — 4 archetype countries × IPCC Tier 1 vs Tier 2.

Builds realistic-ish synthetic country profiles (population + sales
scaled from real refrigeration/AC market statistics), runs the
MITICA cohort-accurate Tier 2 cascade for BaU + WAM scenarios, and
benchmarks against an IPCC Tier 1 estimate computed independently.

The four archetypes are chosen to stress different regions of the
Kigali schedule + replacement strategy:

1. **Spain (ESP)** — Non-Article 5 mature EU economy. Slow population
   growth; EU MAC Directive already in force; HFC-32 + HFO-1234yf
   adoption ahead of schedule.
2. **Vietnam (VNM)** — Article 5 group 1, fast-growing AC market in
   tropical Asia. Major exposure to R410A → HFC-32 transition.
3. **Maldives (MDV)** — Article 5 group 1 SIDS. Tiny absolute
   emissions but high per-capita; very high AC penetration; coastal.
4. **United Arab Emirates (ARE)** — Article 5 group 2 (high-ambient).
   Heavy AC use, slower Kigali schedule, oil-economy buying power.

Tier 1 reference
----------------
IPCC 2006 Vol 3 Ch 7 Tier 1 is the "default-method" simplification:
country reports HFC consumption (kt/year) and applies a single
emission factor of 1.0 (entire consumption emitted in the year of
import = a "potential emissions" assumption). Tier 2 (what MITICA
does) explicitly tracks stock + lifetime + leakage + decommissioning,
giving the **time-shifted** "actual emissions" estimate.

Tier 1 systematically OVER-estimates near-term emissions and
UNDER-estimates long-term emissions (because gas locked in equipment
leaks out gradually for L years after import). The audit quantifies
this gap.

Usage
-----
    python scripts/fgases_audit.py

Exit codes:
    0 — all 4 countries run cleanly with no anomalous outputs
    1 — at least one country produced an unexpected result (negative
        emissions, Tier 1 vs Tier 2 ratio outside [0.5, 5.0], etc.)
"""

from __future__ import annotations

import sys

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")   # type: ignore[union-attr]

from mitica_core.modules.fgases import (
    GWP100_AR4,
    FGasesConfig,
    FGasesProjectedInputs,
    FGasesSystem,
    SubsectorHistory,
    build_kigali_phi,
    infer_kigali_group,
    run_fgases_module,
)
from mitica_core.modules.fgases.priors import (
    DEFAULT_INITIAL_CHARGE_KG,
    DEFAULT_K_STOCK,
    DEFAULT_LIFETIME_YEARS,
)
from mitica_core.modules.fgases.schemas import SUBSECTOR_TO_CRT


# ---------------------------------------------------------------------------
# Archetype country setups
# ---------------------------------------------------------------------------

ARCHETYPES = [
    {
        "label": "Spain",
        "iso": "ESP",
        "pop_2023_m": 48.0,
        # Annual unit sales per million inhabitants (calibrated to EU
        # 2023 market reports for HVAC&R). Drives the cohort size.
        "sales_pmi": {
            "split_residential_ac":     30_000,   # units / M inhab / yr
            "car_ac":                    22_000,
            "domestic_refrigeration":    12_000,
            "centralised_supermarket":       4,
            "condensing_units":            300,
            "stand_alone_refrigeration":   600,
            "ac_chillers":                  12,
        },
        "growth_pct_yr": 0.5,   # AC stock growth annual
        # Historical refrigerant mix at 2023 (pre-WAM). Spain is
        # ahead of the curve due to EU MAC Directive (2017) and the
        # EU F-gas Regulation (2014, revised 2024).
        "phi_2023": {
            "split_residential_ac":   {"R410A": 0.55, "HFC-32": 0.40, "HCFC-22": 0.05},
            "car_ac":                 {"HFC-134a": 0.70, "HFO-1234yf": 0.30},
            "domestic_refrigeration": {"HC-600a": 0.90, "HFC-134a": 0.10},
            "centralised_supermarket": {"R404A": 0.20, "HFC-134a": 0.40, "R-744": 0.40},
            "condensing_units":       {"HFC-134a": 0.50, "R404A": 0.30, "HFC-32": 0.20},
            "stand_alone_refrigeration": {"HC-600a": 0.60, "HFC-134a": 0.40},
            "ac_chillers":            {"HFC-134a": 0.85, "HFO-1234ze": 0.15},
        },
    },
    {
        "label": "Vietnam",
        "iso": "VNM",
        "pop_2023_m": 99.0,
        "sales_pmi": {
            # Fast-growing tropical AC market; sales-per-capita already
            # comparable to mid-income economies and rising fast.
            "split_residential_ac":     50_000,
            "car_ac":                    8_000,
            "domestic_refrigeration":    18_000,
            "centralised_supermarket":       2,
            "condensing_units":            400,
            "stand_alone_refrigeration":   500,
            "ac_chillers":                   8,
        },
        "growth_pct_yr": 4.0,   # very fast growth
        "phi_2023": {
            "split_residential_ac":   {"R410A": 0.45, "HCFC-22": 0.40, "HFC-32": 0.15},
            "car_ac":                 {"HFC-134a": 0.95, "HFO-1234yf": 0.05},
            "domestic_refrigeration": {"HFC-134a": 0.65, "HC-600a": 0.35},
            "centralised_supermarket": {"HFC-134a": 0.80, "R404A": 0.20},
            "condensing_units":       {"HFC-134a": 0.70, "R404A": 0.30},
            "stand_alone_refrigeration": {"HFC-134a": 0.70, "HC-600a": 0.30},
            "ac_chillers":            {"HFC-134a": 0.95, "HCFC-22": 0.05},
        },
    },
    {
        "label": "Maldives",
        "iso": "MDV",
        "pop_2023_m": 0.52,
        "sales_pmi": {
            # SIDS, extremely high AC penetration per capita due to
            # year-round 30°C+ temperatures and tourism infrastructure.
            "split_residential_ac":    100_000,
            "car_ac":                    4_000,
            "domestic_refrigeration":   25_000,
            "centralised_supermarket":      10,
            "condensing_units":            800,
            "stand_alone_refrigeration": 1_500,
            "ac_chillers":                  25,
        },
        "growth_pct_yr": 3.0,
        "phi_2023": {
            "split_residential_ac":   {"R410A": 0.65, "HCFC-22": 0.20, "HFC-32": 0.15},
            "car_ac":                 {"HFC-134a": 1.00},
            "domestic_refrigeration": {"HFC-134a": 0.80, "HC-600a": 0.20},
            "centralised_supermarket": {"R404A": 0.50, "HFC-134a": 0.50},
            "condensing_units":       {"HFC-134a": 0.55, "R404A": 0.45},
            "stand_alone_refrigeration": {"HFC-134a": 0.75, "HC-600a": 0.25},
            "ac_chillers":            {"HFC-134a": 0.85, "R410A": 0.15},
        },
    },
    {
        "label": "UAE",
        "iso": "ARE",
        "pop_2023_m": 9.4,
        "sales_pmi": {
            # Extreme AC use — high-ambient climate, oil-economy
            # purchasing power, very large per-capita AC stock.
            "split_residential_ac":    120_000,
            "car_ac":                   40_000,
            "domestic_refrigeration":   18_000,
            "centralised_supermarket":      15,
            "condensing_units":          1_200,
            "stand_alone_refrigeration": 2_000,
            "ac_chillers":                  60,
            "process_chillers":              5,
        },
        "growth_pct_yr": 2.5,
        "phi_2023": {
            "split_residential_ac":   {"R410A": 0.80, "HCFC-22": 0.10, "HFC-32": 0.10},
            "car_ac":                 {"HFC-134a": 1.00},
            "domestic_refrigeration": {"HFC-134a": 0.70, "HC-600a": 0.30},
            "centralised_supermarket": {"R404A": 0.40, "HFC-134a": 0.55, "R-744": 0.05},
            "condensing_units":       {"HFC-134a": 0.50, "R404A": 0.40, "HFC-32": 0.10},
            "stand_alone_refrigeration": {"HFC-134a": 0.80, "HC-600a": 0.20},
            "ac_chillers":            {"HFC-134a": 0.90, "HFO-1234ze": 0.10},
            "process_chillers":       {"HFC-134a": 1.00},
        },
    },
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def build_system(
    arch: dict, horizon: int = 2050,
) -> tuple[FGasesSystem, FGasesProjectedInputs]:
    """Synthesise an FGasesSystem + matching FGasesProjectedInputs.

    History spans 2010-2023; sales projection 2024-`horizon` lives on
    FGasesProjectedInputs so the engine's `last_historical_year()`
    correctly returns 2023 (not the horizon) and the projection
    cascade kicks in.
    """
    pop_m = arch["pop_2023_m"]
    g = arch["growth_pct_yr"] / 100.0
    years_hist = list(range(2010, 2024))
    years_proj = list(range(2024, horizon + 1))
    subs: list[SubsectorHistory] = []
    sales_proj_by_sub: dict[str, dict[int, float]] = {}
    for sub_name, sales_pmi in arch["sales_pmi"].items():
        sales_2023 = sales_pmi * pop_m
        L = DEFAULT_LIFETIME_YEARS.get(sub_name, 15)
        stock_ratio = L * 0.6
        sales_hist = {y: sales_2023 * (1 + g) ** (y - 2023) for y in years_hist}
        stock_hist = {y: sales_hist[y] * stock_ratio for y in years_hist}
        subs.append(SubsectorHistory(
            name=sub_name,
            sales_units=sales_hist,
            stock_units=stock_hist,
            initial_charge_kg=DEFAULT_INITIAL_CHARGE_KG.get(sub_name, 0.0),
            lifetime_years=L,
            recovery_rate=0.0,
        ))
        sales_proj_by_sub[sub_name] = {
            y: sales_2023 * (1 + g) ** (y - 2023) for y in years_proj
        }
    # phi (historical only): hold the 2023 mix back through 2010-2023.
    # The Kigali default takes over for projection years (under WAM).
    phi_hist: dict[str, dict[str, dict[int, float]]] = {}
    for sub_name, mix_2023 in arch["phi_2023"].items():
        for gas, frac in mix_2023.items():
            phi_hist.setdefault(sub_name, {})[gas] = {y: frac for y in years_hist}
    system = FGasesSystem(
        country_code=arch["iso"],
        subsectors=subs,
        refrigerant_distribution=phi_hist,
    )
    projected = FGasesProjectedInputs(sales_projected=sales_proj_by_sub)
    return system, projected


def stitched_sales(
    system: FGasesSystem,
    projected: FGasesProjectedInputs,
    sub_name: str,
    year: int,
) -> float:
    """Helper for Tier 1: sales at ``year`` honouring both system's
    historical sales and projected.sales_projected overrides."""
    for sub in system.subsectors:
        if sub.name == sub_name:
            v = sub.sales_units.get(year)
            if v is not None:
                return v
            break
    return projected.sales_projected.get(sub_name, {}).get(year, 0.0)


def tier1_emissions(
    system: FGasesSystem,
    projected: FGasesProjectedInputs,
    year: int,
    phi_override: dict[str, dict[str, dict[int, float]]] | None = None,
) -> float:
    """IPCC Tier 1 = total HFC consumption × GWP, summed across
    gases. "Consumption" ≈ sales × IC × ϕ in this year (proxy for
    imports). This is the "potential emissions" assumption: every
    kg charged into new equipment in year T is reported as emitted
    in year T.

    ``phi_override`` lets the caller switch refrigerant mixes per
    scenario (e.g. use Kigali ϕ for the WAM-equivalent Tier 1).

    Returns kt CO2-eq.
    """
    total = 0.0
    last_hist = system.last_historical_year()
    for sub in system.subsectors:
        ic = sub.initial_charge_kg
        if ic <= 0:
            continue
        sales = stitched_sales(system, projected, sub.name, year)
        if sales <= 0:
            continue
        phi_source = (phi_override or {}).get(sub.name) \
            or system.refrigerant_distribution.get(sub.name, {})
        for gas, ys in phi_source.items():
            phi = ys.get(year, ys.get(last_hist, 0.0))
            kg = sales * ic * phi
            gwp = GWP100_AR4.get(gas, 0.0)
            total += kg * gwp / 1_000_000.0
    return total


# ---------------------------------------------------------------------------
# Audit run
# ---------------------------------------------------------------------------


def run_audit() -> int:
    print("=" * 78)
    print("F-gases module audit — 4 archetype countries × IPCC Tier 1 vs Tier 2")
    print("=" * 78)
    any_anomaly = False

    summary_rows: list[tuple] = []

    for arch in ARCHETYPES:
        iso = arch["iso"]
        kigali_group = infer_kigali_group(iso)
        print(f"\n### {arch['label']} ({iso}) — Kigali group: {kigali_group}")
        system, projected = build_system(arch, horizon=2050)
        out = run_fgases_module(
            system,
            projected=projected,
            config=FGasesConfig(
                horizon_year=2050,
                kigali_group=kigali_group,
                apply_kigali_default=True,
            ),
        )
        totals = out.scenario_totals_kt_co2eq()

        print(f"  Sub-applications:  {len(system.subsectors)}")
        print(f"  Last hist year:    {system.last_historical_year()}")
        print(f"  Validation flags:  {len(out.validation_report)}")
        for f in out.validation_report:
            print(f"    [{f.severity}] {f.test_id}: {f.message[:100]}")

        # Build a Kigali ϕ projection so Tier 1 has a WAM variant too
        kigali_phi = build_kigali_phi(
            baseline_phi=system.refrigerant_distribution,
            last_hist_year=2023, horizon_year=2050, group=kigali_group,
        )

        # Print BaU vs WAM at milestone years + Tier 1 reference (both
        # BaU phi and WAM phi)
        print(f"\n  {'Year':>4s} | {'T2 BaU':>9s} | {'T2 WAM':>9s} | "
              f"{'WAM-vs-BaU':>10s} | {'T1 BaU':>9s} | {'T1 WAM':>9s} | "
              f"{'T2/T1 BaU':>10s}")
        for year in [2023, 2025, 2030, 2035, 2040, 2050]:
            bau = totals.get("BaU", {}).get(year, 0)
            wam = totals.get("WAM", {}).get(year, 0)
            abat = (1 - wam / bau) * 100 if bau > 0 else 0
            t1_bau = tier1_emissions(system, projected, year)
            t1_wam = tier1_emissions(system, projected, year, phi_override=kigali_phi)
            ratio = (bau / t1_bau) if t1_bau > 0 else float("inf")
            print(f"  {year:>4d} | {bau:>9.1f} | {wam:>9.1f} | "
                  f"{abat:>+9.1f}% | {t1_bau:>9.1f} | {t1_wam:>9.1f} | "
                  f"{ratio:>9.2f}")
            # Flag suspicious ratios (Tier 2 should be within 0.3-2.0× of
            # Tier 1 in any year; large deviations suggest a bug).
            if t1_bau > 0 and (ratio < 0.3 or ratio > 2.0):
                print(f"    ⚠ Tier 2 vs Tier 1 BaU ratio outside [0.3, 2.0] "
                      f"at year {year} ({ratio:.2f})")
                any_anomaly = True

        # CRT breakdown (per 2F1a/b/d/e/f line at 2030, BaU)
        print(f"\n  CRT 2F breakdown at 2030 (BaU, kt CO2-eq):")
        crt_2030: dict[str, float] = {}
        row_2030_bau = next((r for r in out.emissions
                              if r.year == 2030 and r.scenario == "BaU"), None)
        if row_2030_bau:
            for (sub, gas), kt in row_2030_bau.kt_co2eq.items():
                code = SUBSECTOR_TO_CRT.get(sub, "2F1other")
                crt_2030[code] = crt_2030.get(code, 0.0) + kt
            for code in sorted(crt_2030):
                print(f"    {code}: {crt_2030[code]:>8.1f}")
            print(f"    {'TOTAL':>5s}: {sum(crt_2030.values()):>8.1f}")

        # Capture for summary
        bau_2030 = totals.get("BaU", {}).get(2030, 0)
        wam_2050 = totals.get("WAM", {}).get(2050, 0)
        bau_2050 = totals.get("BaU", {}).get(2050, 0)
        summary_rows.append((
            arch["label"], iso, kigali_group, bau_2030,
            bau_2050, wam_2050,
            (1 - wam_2050 / bau_2050) * 100 if bau_2050 > 0 else 0,
        ))

    # Final summary
    print(f"\n{'=' * 78}\nSUMMARY\n{'=' * 78}")
    print(f"{'Country':10s}  {'ISO':3s}  {'Kigali group':18s}  "
          f"{'BaU 2030':>9s}  {'BaU 2050':>9s}  {'WAM 2050':>9s}  "
          f"{'Abat':>6s}")
    for r in summary_rows:
        print(f"{r[0]:10s}  {r[1]:3s}  {r[2]:18s}  "
              f"{r[3]:>9.1f}  {r[4]:>9.1f}  {r[5]:>9.1f}  {r[6]:>+5.1f}%")

    # Methodology comparison commentary
    print(f"\n{'=' * 78}\nTier 1 vs Tier 2 commentary\n{'=' * 78}")
    print(
        "\n"
        "  Tier 1 (IPCC default) ≈ Consumption × GWP, attributed to the\n"
        "  year of import. This is the 'potential emissions' assumption:\n"
        "  every kg of HFC imported in year T emits in year T as if it\n"
        "  were immediately released.\n"
        "\n"
        "  Tier 2 (this module) ≈ Cohort mass balance: a kg of HFC\n"
        "  imported in year T enters equipment, leaks k_s%/yr for L years,\n"
        "  and at end-of-life releases the residual × (1−R). Total kg\n"
        "  emitted ≈ Tier 1, but smeared across the L+1 year window.\n"
        "\n"
        "  Where Tier 2 adds value over Tier 1:\n"
        "    1. Time profile: Tier 1 reports the import-year burst;\n"
        "       Tier 2 spreads it (matters for NDC interim targets).\n"
        "    2. Stock-leakage tracking: lets you separate manufacturing\n"
        "       vs in-service vs decommissioning emissions for the CRT.\n"
        "    3. Kigali scenarios: limits are placed on IMPORTS, but the\n"
        "       in-service stock keeps emitting older gases for L years\n"
        "       after the swap — Tier 2 captures this hangover correctly.\n"
        "    4. Recovery accounting: only Tier 2 lets a country claim\n"
        "       reduced decommissioning emissions from end-of-life recovery\n"
        "       programmes.\n"
        "\n"
        "  Where Tier 1 is sufficient:\n"
        "    - Aggregate national HFC consumption × GWP for headline 2F\n"
        "      totals when the only available data is the Montreal Protocol\n"
        "      Article 7 import report.\n"
        "    - First-pass BTR / NIR submission for small economies.\n"
    )

    return 1 if any_anomaly else 0


if __name__ == "__main__":
    sys.exit(run_audit())
