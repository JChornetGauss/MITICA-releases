#!/usr/bin/env bash
# Download + extract BTR1 CRT zips listed in _btr_urls.tsv (country<TAB>url).
# Uses the proven Incapsula-bypass: prime a session cookie on unfccc.int, then
# fetch each /sites/default/files/resource/*.zip reusing the cookie + a referer.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
DST="$HERE/_btr_crt"
TSV="$HERE/_btr_urls.tsv"
CJ="/tmp/unfccc_cj.txt"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
mkdir -p "$DST"

# prime cookie
curl -s --max-time 30 -c "$CJ" -A "$UA" -H "Accept-Language: en-US,en;q=0.9" \
  "https://unfccc.int/" -o /dev/null
echo "primed cookie."

ok=0; fail=0
while IFS=$'\t' read -r country url; do
  url="${url%$'\r'}"; country="${country%$'\r'}"
  [ -z "${url:-}" ] && continue
  case "$url" in *.zip) ;; *) echo "skip (no zip): $country"; continue;; esac
  fname="$(basename "$url")"
  iso="$(echo "$fname" | cut -c1-3 | tr '[:lower:]' '[:upper:]')"
  out="/tmp/btr_${iso}.zip"
  curl -s --max-time 180 -b "$CJ" -c "$CJ" -A "$UA" \
    -H "Accept: application/zip,application/octet-stream,*/*" \
    -H "Accept-Language: en-US,en;q=0.9" \
    -H "Referer: https://unfccc.int/first-biennial-transparency-reports" \
    -L "$url" -o "$out" -w "%{http_code} %{size_download}" > /tmp/_dlstat 2>/dev/null
  read -r code size < /tmp/_dlstat
  # valid zip?
  if [ "$code" = "200" ] && head -c2 "$out" 2>/dev/null | grep -q "PK"; then
    edir="$DST/$iso"
    rm -rf "$edir"; mkdir -p "$edir"
    if python -c "import zipfile,sys; zipfile.ZipFile('$out').extractall('$edir')" 2>/dev/null; then
      nx=$(find "$edir" -iname "*.xlsx" | wc -l)
      echo "OK  $iso  ($country)  ${size}B  ${nx} xlsx"
      ok=$((ok+1))
    else
      echo "BAD-ZIP $iso ($country)"; fail=$((fail+1))
    fi
    rm -f "$out"
  else
    echo "FAIL $iso ($country) http=$code size=$size"
    fail=$((fail+1))
  fi
done < "$TSV"
echo "=== downloaded OK=$ok FAIL=$fail ==="
