"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Info,
  Pencil,
  Play,
  Plus,
  Recycle,
  Trash2,
  X,
} from "lucide-react";

import {
  api,
  type MacroDevGroup,
  type WasteCategory,
  type WasteClimateZone,
  type WasteLever,
  type WastePAM,
  type WasteResult,
  type WasteRunRequest,
  type WasteValidationFlag,
  type WasteWWSystem,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { cn } from "@/lib/utils";

// Same scenario palette as the energy/transport pages.
const SCENARIO_COLORS: Record<string, string> = {
  WoM: "#1A2438",
  WEM: "#147A6E",
  WAM: "#8a7d5a",
};
const SCEN_ORDER = ["WoM", "WEM", "WAM"];

const LEVER_LABELS: Record<WasteLever, string> = {
  diversion: "Diversion from landfill",
  gas_recovery: "Landfill gas recovery",
  composting_shift: "Composting shift (5A → 5B)",
  ww_treatment_upgrade: "Wastewater treatment upgrade",
  direct_reduction: "Direct reduction (kt series)",
};

const LEVER_HINTS: Record<WasteLever, string> = {
  diversion:
    "Diverts a share of FUTURE waste deposition away from landfill. 5A methane falls with the multi-decade FOD lag — the pre-diversion stock keeps decaying.",
  gas_recovery:
    "Ramps methane recovery to a target share of GENERATED landfill CH₄. Acts on generation, not stock — 5A falls immediately.",
  composting_shift:
    "Moves a share of future deposition from landfill (5A, falls with lag) to biological treatment (5B, rises immediately at the composting EFs).",
  ww_treatment_upgrade:
    "Shifts a population share to a cleaner wastewater system — the weighted MCF falls and the 5D domestic CH₄ line falls with it.",
  direct_reduction:
    "Explicit mitigation series in kt CO₂-eq per year — for measures you have already quantified elsewhere. Clamped at zero.",
};

const CATEGORY_LABELS: Record<string, string> = {
  "5A": "5A · Solid waste disposal (FOD)",
  "5B": "5B · Biological treatment",
  "5C": "5C · Incineration & open burning",
  "5D": "5D · Wastewater treatment",
};
const CATEGORY_ORDER = ["5A", "5B", "5C", "5D"];
const CATEGORY_COLORS: Record<string, string> = {
  "5A": "#1A2438",
  "5B": "#147A6E",
  "5C": "#c97064",
  "5D": "#5b6dcd",
};

const WW_SYSTEM_LABELS: Record<WasteWWSystem, string> = {
  none_sea: "No treatment / sea discharge (MCF 0.1)",
  septic: "Septic tank (MCF 0.5)",
  latrine: "Latrine (MCF 0.5)",
  anaerobic: "Anaerobic digester / lagoon (MCF 0.8)",
  aerobic: "Centralised aerobic (MCF 0.03)",
};

const CLIMATE_LABELS: Record<WasteClimateZone, string> = {
  boreal_dry: "Boreal / dry (slow decay, k=0.05)",
  temperate_wet: "Temperate wet (k=0.09)",
  tropical_dry: "Tropical dry (k=0.085)",
  tropical_wet: "Tropical wet (fast decay, k=0.17)",
};

const DEV_GROUP_LABELS: Record<MacroDevGroup, string> = {
  L: "L · Low income",
  LM: "LM · Lower-middle income",
  UM: "UM · Upper-middle income",
  H: "H · High income",
};

const TIER_HINTS: Record<string, string> = {
  T1: "income/climate prior",
  T2: "own-inventory anchored",
  T3: "own enrichments",
};

export default function WasteModulePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const qc = useQueryClient();

  const [horizon, setHorizon] = useState<string>("2050");
  const [climate, setClimate] = useState<WasteClimateZone | "">("");
  const [incomeGroup, setIncomeGroup] = useState<MacroDevGroup | "">("");

  const stored = useQuery<WasteResult>({
    queryKey: ["waste-result", id],
    queryFn: () => api.getWasteResult(id),
    retry: false, // 404 until the first run
  });

  const run = useMutation({
    mutationFn: (): Promise<WasteResult> => {
      const body: WasteRunRequest = {
        horizon_year: Number(horizon) || 2050,
        scenarios: ["WoM", "WEM", "WAM"],
        ...(climate ? { climate_zone: climate } : {}),
        ...(incomeGroup ? { income_group: incomeGroup } : {}),
      };
      return api.runWaste(id, body);
    },
    onSuccess: () => {
      void stored.refetch();
      // has_waste_result flips on the project → refresh stepper/overview.
      void qc.invalidateQueries({ queryKey: ["project", id] });
    },
  });

  const result: WasteResult | undefined = run.data ?? stored.data;

  return (
    <div className="space-y-8">
      {/* ---- Header ---- */}
      <div>
        <div className="mb-2 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-emerald-700">
            <Recycle className="h-5 w-5" />
          </div>
          <div>
            <div className="eyebrow">Module · SI-007 · CRT 5A–5D</div>
            <h2 className="font-serif text-2xl font-[460]">Waste module</h2>
          </div>
        </div>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Projection of the <em>waste sector</em> (CRT 5A solid-waste disposal,
          5B biological treatment, 5C incineration, 5D wastewater) on the IPCC
          2006 equations, faithful to{" "}
          <code className="rounded bg-muted px-1 font-mono">WASTE_DESIGN.md</code>.
          The heart is the 5A first-order-decay (FOD) model: landfill methane
          comes from decades of accumulated deposition, so diversion and
          composting measures bite with a multi-decade lag — exactly what a
          static R × M formula cannot represent. The WoM anchors to your
          reported inventory per category (the base year reproduces it
          exactly); WEM/WAM are your PAMs computed as mini-scenarios on the
          module physics through 5 levers. Drivers (population, GDP per capita)
          auto-pull from the Macro module result; the 5A–5D history auto-pulls
          from the project inventory (falling back to the 5 aggregate).
          Activating the module on a project overrides ANNALIST for ONLY its own
          categories (CRT-5: 5A–5D). Every other category in the inventory still
          projects with ANNALIST using your proxies.
        </p>
      </div>

      {/* ---- 1. PAMs ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">1. Measures (PAMs)</CardTitle>
        </CardHeader>
        <CardContent>
          <WastePamEditor projectId={id} />
        </CardContent>
      </Card>

      {/* ---- 2. Run ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">2. Run the projection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-4">
            <div>
              <Label>Horizon year</Label>
              <Input
                type="number"
                min={2025}
                max={2100}
                value={horizon}
                onChange={(e) => setHorizon(e.target.value)}
              />
            </div>
            <div>
              <Label>Climate zone</Label>
              <select
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={climate}
                onChange={(e) => setClimate(e.target.value as WasteClimateZone | "")}
              >
                <option value="">Temperate wet (default)</option>
                {(Object.keys(CLIMATE_LABELS) as WasteClimateZone[]).map((z) => (
                  <option key={z} value={z}>
                    {CLIMATE_LABELS[z]}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-[11px] text-muted-foreground">
                Sets the bulk-MSW decay rate k of the 5A FOD model.
              </p>
            </div>
            <div>
              <Label>Income group (override)</Label>
              <select
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={incomeGroup}
                onChange={(e) => setIncomeGroup(e.target.value as MacroDevGroup | "")}
              >
                <option value="">Auto — project income group, else GDP-pc</option>
                {(Object.keys(DEV_GROUP_LABELS) as MacroDevGroup[]).map((g) => (
                  <option key={g} value={g}>
                    {DEV_GROUP_LABELS[g]}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-[11px] text-muted-foreground">
                Selects the generation / treatment-mix priors. On auto the run
                uses the project&apos;s income group (project overview, from the
                World Bank classification); the GDP-pc fallback is
                currency-sensitive.
              </p>
            </div>
            <div className="self-end">
              <Button onClick={() => run.mutate()} disabled={run.isPending} className="w-full">
                <Play className="mr-2 h-4 w-4" />
                {run.isPending ? "Projecting…" : "Run WoM + WEM + WAM"}
              </Button>
            </div>
          </div>

          {run.error && (
            <p className="text-sm text-destructive">{(run.error as Error).message}</p>
          )}
          {run.isSuccess && (
            <p className="inline-flex items-center gap-1.5 text-sm text-primary">
              <CheckCircle2 className="h-4 w-4" /> Projection complete — horizon{" "}
              {run.data.horizon_year} · income group {run.data.income_group} ·{" "}
              {run.data.climate_zone}
            </p>
          )}

          {result && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span
                className="rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 font-mono text-[11px] text-primary"
                title={TIER_HINTS[result.tier] ?? ""}
              >
                tier {result.tier}
                {TIER_HINTS[result.tier] ? ` · ${TIER_HINTS[result.tier]}` : ""}
              </span>
              {Object.entries(result.resolution_log).map(([k, v]) => (
                <span
                  key={k}
                  className="rounded-full border border-border bg-muted px-2 py-0.5 font-mono text-[11px] text-muted-foreground"
                >
                  {k}: {v}
                </span>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---- 3. Results ---- */}
      {result && <WasteResults result={result} />}
    </div>
  );
}

// ============================================================================
// Results — narrative summary, validation panel, scenario chart,
// by-category stack, PAM mitigation bars.
// ============================================================================

function yearsOf(result: WasteResult): number[] {
  const set = new Set<number>();
  for (const m of Object.values(result.scenario_totals)) {
    for (const y of Object.keys(m)) set.add(Number(y));
  }
  return Array.from(set).sort((a, b) => a - b);
}

function orderedScenarios(result: WasteResult): string[] {
  return Object.keys(result.scenario_totals).sort(
    (a, b) =>
      (SCEN_ORDER.indexOf(a) + 1 || 99) - (SCEN_ORDER.indexOf(b) + 1 || 99),
  );
}

function WasteResults({ result }: { result: WasteResult }) {
  const years = yearsOf(result);
  const scenarios = orderedScenarios(result);

  const totalTraces = scenarios.map((scen) => {
    const m = result.scenario_totals[scen] ?? {};
    return {
      x: years,
      y: years.map((y) => m[String(y)] ?? null),
      type: "scatter" as const,
      mode: "lines+markers" as const,
      name: scen,
      line: { color: SCENARIO_COLORS[scen] ?? "#666", width: 2 },
    };
  });

  return (
    <div className="space-y-6">
      <WasteNarrativeSummary result={result} />
      <WasteValidationPanel report={result.validation_report ?? []} />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Scenario comparison — total waste-sector emissions (kt CO₂-eq)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PlotlyChart
            height={340}
            data={totalTraces}
            layout={{
              yaxis: { title: "kt CO₂-eq" },
              xaxis: { title: "Year" },
              legend: { orientation: "h" },
            }}
          />
        </CardContent>
      </Card>

      <CategoryBreakdown result={result} />
      <PamMitigationChart result={result} />
    </div>
  );
}

// ----- Narrative summary (deterministic from the result; no LLM) -------------

function WasteNarrativeSummary({ result }: { result: WasteResult }) {
  const years = yearsOf(result);
  if (years.length === 0) return null;
  const scenarios = orderedScenarios(result);
  // Effective horizon: the drivers (macro projection) may stop short of the
  // requested horizon — report at the last projected year in that case.
  const horizon = Math.min(result.horizon_year, years[years.length - 1]);
  const yKey = String(horizon);

  const at = (scen: string): number | null =>
    result.scenario_totals[scen]?.[yKey] ?? null;

  const wom = at("WoM");
  const wem = at("WEM");
  const wam = at("WAM");
  const wamPct = wom && wom > 0 && wam !== null ? (1 - wam / wom) * 100 : null;
  const cats = CATEGORY_ORDER.filter((c) => c in (result.by_category["WoM"] ?? {}));

  return (
    <Card>
      <CardContent className="py-3.5">
        <p className="text-sm leading-relaxed text-foreground">
          <span className="font-medium">
            Waste module · CRT {cats.length > 0 ? cats.join("+") : "5"},{" "}
            {scenarios.length} scenario
            {scenarios.length === 1 ? "" : "s"} ({scenarios.join(", ")}), horizon{" "}
            {horizon}
            {horizon < result.horizon_year
              ? ` (drivers end before the requested ${result.horizon_year})`
              : ""}
            , resolution tier {result.tier}
            {TIER_HINTS[result.tier] ? ` (${TIER_HINTS[result.tier]})` : ""},
            income group {result.income_group}, {result.climate_zone}.
          </span>{" "}
          {wom !== null && (
            <>
              WoM emissions at {horizon}:{" "}
              <span className="font-mono">{wom.toFixed(0)}</span> kt CO₂-eq.
            </>
          )}
          {wem !== null && (
            <>
              {" "}WEM reaches <span className="font-mono">{wem.toFixed(0)}</span> kt.
            </>
          )}
          {wam !== null && (
            <>
              {" "}WAM reaches <span className="font-mono">{wam.toFixed(0)}</span> kt
              {wamPct !== null && (
                <>
                  {" "}(
                  <span className="font-mono">
                    {wamPct >= 0 ? "−" : "+"}
                    {Math.abs(wamPct).toFixed(1)}%
                  </span>{" "}
                  vs WoM)
                </>
              )}
              .
            </>
          )}
        </p>
      </CardContent>
    </Card>
  );
}

// ----- WS-* validation panel (mirrors the transport module's panel) ----------

function WasteValidationPanel({ report }: { report: WasteValidationFlag[] }) {
  const amber = report.filter((f) => f.severity === "amber").length;
  const info = report.filter((f) => f.severity === "info").length;
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">Validation summary</CardTitle>
        <div className="flex gap-2 text-xs">
          <span className="rounded-full border border-amber-600/40 bg-amber-600/10 px-2 py-0.5 text-amber-700">
            {amber} amber
          </span>
          <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
            {info} info
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <p className="mb-3 text-[11px] text-muted-foreground">
          Engine never fires red — it informs, the user decides.{" "}
          <strong>WS-01</strong> horizon sanity · <strong>WS-02</strong> growth
          band · <strong>WS-03</strong> input integrity (drivers) ·{" "}
          <strong>WS-04</strong> anchor residual vs the inventory ·{" "}
          <strong>WS-05</strong> PAM with no effect.
        </p>
        {report.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No flags raised — all plausibility checks passed.
          </p>
        ) : (
          <ul className="divide-y divide-border text-sm">
            {report.map((f, i) => (
              <li key={i} className="flex items-start gap-3 py-2.5">
                {f.severity === "amber" ? (
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" aria-hidden />
                ) : (
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                )}
                <div className="flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="font-mono text-xs text-muted-foreground">{f.test_id}</span>
                    <span className="text-sm font-medium">{f.variable}</span>
                  </div>
                  <p className="whitespace-pre-line text-xs text-muted-foreground">{f.message}</p>
                  {f.proposed_action && (
                    <p className="mt-1.5 text-xs text-foreground/90">
                      <span className="font-medium text-foreground">What to do: </span>
                      {f.proposed_action}
                    </p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// ----- Stacked-by-category chart ----------------------------------------------

function CategoryBreakdown({ result }: { result: WasteResult }) {
  const scenarios = orderedScenarios(result);
  const [scen, setScen] = useState<string>(scenarios[0] ?? "WoM");
  const years = yearsOf(result);

  const catMap = result.by_category[scen] ?? {};
  const cats = [
    ...CATEGORY_ORDER.filter((c) => c in catMap),
    ...Object.keys(catMap).filter((c) => !CATEGORY_ORDER.includes(c)),
  ];

  const stacked = cats.map((cat) => ({
    x: years,
    y: years.map((y) => catMap[cat]?.[String(y)] ?? 0),
    name: CATEGORY_LABELS[cat] ?? cat,
    type: "bar" as const,
    marker: { color: CATEGORY_COLORS[cat] ?? "#8a7d5a" },
  }));

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">By-category stack — {scen}</CardTitle>
        <div className="flex overflow-hidden rounded-sm border border-border text-xs">
          {scenarios.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setScen(s)}
              className={cn(
                "px-3 py-1",
                s === scen
                  ? "bg-primary font-medium text-primary-foreground"
                  : "bg-card text-muted-foreground hover:bg-muted",
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={300}
          data={stacked}
          layout={{
            barmode: "stack",
            yaxis: { title: "kt CO₂-eq" },
            xaxis: { title: "Year" },
            legend: { orientation: "h", y: -0.25 },
          }}
        />
        <p className="mt-2 text-[11px] text-muted-foreground">
          The module projects whichever CRT-5 categories your inventory
          reports; each one anchors to its reported series at the base year.
        </p>
      </CardContent>
    </Card>
  );
}

// ----- PAM mitigation at horizon (horizontal bars) -----------------------------

function PamMitigationChart({ result }: { result: WasteResult }) {
  const years = yearsOf(result);
  // Effective horizon — see WasteNarrativeSummary.
  const horizon = years.length
    ? Math.min(result.horizon_year, years[years.length - 1])
    : result.horizon_year;

  // Prefer WAM (cumulative measure set), fall back to WEM.
  const scen =
    result.pam_mitigation["WAM"] && Object.keys(result.pam_mitigation["WAM"]).length > 0
      ? "WAM"
      : "WEM";
  const perPam = result.pam_mitigation[scen] ?? {};

  const entries = Object.entries(perPam)
    .map(([name, series]) => {
      const yearKeys = Object.keys(series).map(Number).sort((a, b) => a - b);
      const atHorizon =
        series[String(horizon)] ??
        (yearKeys.length ? series[String(yearKeys[yearKeys.length - 1])] : 0);
      return { name, kt: atHorizon ?? 0 };
    })
    // Ascending → largest bar renders at the top of the horizontal chart.
    .sort((a, b) => a.kt - b.kt);

  if (entries.length === 0) return null;

  const trace = {
    x: entries.map((e) => e.kt),
    y: entries.map((e) => e.name),
    type: "bar" as const,
    orientation: "h" as const,
    marker: { color: SCENARIO_COLORS[scen] },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">
          PAM mitigation at {horizon} — {scen} (kt CO₂-eq)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={Math.max(200, 60 + entries.length * 36)}
          data={[trace]}
          layout={{
            margin: { l: 200, r: 20, t: 10, b: 40 },
            xaxis: { title: "kt CO₂-eq mitigated" },
            showlegend: false,
          }}
        />
        <p className="mt-2 text-[11px] text-muted-foreground">
          Per-measure mitigation wedge at the horizon year, computed as a
          mini-scenario on the module physics (the 5A FOD lag, the 5D MCF
          shift) — not a static R × M formula.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// PAM editor — CRUD against /waste/pams. The form adapts its fields to
// the selected lever.
// ============================================================================

function pamParamSummary(p: WastePAM): string {
  switch (p.lever) {
    case "diversion":
      return p.diversion_frac != null
        ? `−${(p.diversion_frac * 100).toFixed(0)}% future deposition`
        : "deposition diverted";
    case "gas_recovery":
      return p.recovery_target != null
        ? `recovery → ${(p.recovery_target * 100).toFixed(0)}% of generated CH₄`
        : "CH₄ recovery";
    case "composting_shift":
      return p.composting_frac != null
        ? `${(p.composting_frac * 100).toFixed(0)}% of deposition → 5B`
        : "composting";
    case "ww_treatment_upgrade": {
      const share =
        p.ww_share_shifted != null
          ? `${(p.ww_share_shifted * 100).toFixed(0)}% of pop`
          : "pop share";
      const sys = p.ww_target_system
        ? ` → ${p.ww_target_system}`
        : " → aerobic";
      return share + sys;
    }
    case "direct_reduction": {
      const n = Object.keys(p.annual_kt ?? {}).length;
      const cat = p.category ?? "5A";
      return `${n} year${n === 1 ? "" : "s"} of explicit kt on ${cat}`;
    }
  }
}

function WastePamEditor({ projectId }: { projectId: string }) {
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const pams = useQuery<WastePAM[]>({
    queryKey: ["waste-pams", projectId],
    queryFn: () => api.listWastePAMs(projectId),
    retry: false,
  });

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["waste-pams", projectId] });
  };

  const create = useMutation({
    mutationFn: (body: WastePAM) => api.createWastePAM(projectId, body),
    onSuccess: () => {
      invalidate();
      setCreating(false);
    },
  });
  const update = useMutation({
    mutationFn: ({ id, body }: { id: string; body: Partial<WastePAM> }) =>
      api.updateWastePAM(projectId, id, body),
    onSuccess: () => {
      invalidate();
      setEditingId(null);
    },
  });
  const del = useMutation({
    mutationFn: (pamId: string) => api.deleteWastePAM(projectId, pamId),
    onSuccess: invalidate,
  });

  const rows = pams.data ?? [];
  const editingPam = editingId ? rows.find((p) => p.id === editingId) ?? null : null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Each measure is one of the 5 levers, applied to a scenario (WEM or
          WAM). Re-run the projection after editing to see the effect.
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setCreating(true);
            setEditingId(null);
          }}
          disabled={creating}
        >
          <Plus className="mr-1 h-3 w-3" /> Add PAM
        </Button>
      </div>

      {(creating || editingPam) && (
        <WastePamForm
          key={editingPam?.id ?? "new"}
          initial={editingPam}
          saving={create.isPending || update.isPending}
          onCancel={() => {
            setCreating(false);
            setEditingId(null);
          }}
          onSave={(body) => {
            if (editingPam?.id) update.mutate({ id: editingPam.id, body });
            else create.mutate(body);
          }}
        />
      )}

      <div className="overflow-hidden rounded-sm border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-1.5 text-left">Scenario</th>
              <th className="px-3 py-1.5 text-left">Lever</th>
              <th className="px-3 py-1.5 text-right">Years</th>
              <th className="px-3 py-1.5 text-left">Parameters</th>
              <th className="px-3 py-1.5 text-left">Name</th>
              <th className="px-3 py-1.5 text-right"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id ?? `${p.name}-${p.lever}-${p.start_year}`} className="border-t border-border">
                <td className="px-3 py-1.5">
                  <span
                    className={
                      p.scenario === "WAM"
                        ? "rounded bg-amber-700/10 px-1.5 py-0.5 text-xs text-amber-800"
                        : "rounded bg-primary/10 px-1.5 py-0.5 text-xs text-primary"
                    }
                  >
                    {p.scenario}
                  </span>
                </td>
                <td className="px-3 py-1.5 text-xs">{LEVER_LABELS[p.lever] ?? p.lever}</td>
                <td className="px-3 py-1.5 text-right font-mono text-xs">
                  {p.start_year}
                  {p.target_year ? `→${p.target_year}` : ""}
                </td>
                <td className="px-3 py-1.5 font-mono text-xs">{pamParamSummary(p)}</td>
                <td className="px-3 py-1.5 text-xs text-muted-foreground">{p.name}</td>
                <td className="px-3 py-1.5 text-right">
                  <div className="flex justify-end gap-1">
                    <button
                      type="button"
                      aria-label="Edit PAM"
                      className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"
                      disabled={!p.id || del.isPending}
                      onClick={() => {
                        setEditingId(p.id ?? null);
                        setCreating(false);
                      }}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      aria-label="Delete PAM"
                      className="rounded p-1 text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-50"
                      disabled={!p.id || del.isPending}
                      onClick={() => {
                        if (p.id && confirm(`Delete PAM "${p.name}"?`)) del.mutate(p.id);
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3 py-4 text-center text-xs text-muted-foreground">
                  {pams.isError
                    ? "Could not load PAMs — is the backend running?"
                    : 'No measures yet. Click "Add PAM" to create one — without PAMs, WEM/WAM coincide with WoM.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {(create.error || update.error || del.error) && (
        <p className="text-xs text-destructive">
          {(create.error as Error | null)?.message ??
            (update.error as Error | null)?.message ??
            (del.error as Error | null)?.message}
        </p>
      )}
    </div>
  );
}

// ----- Lever-adaptive form -----------------------------------------------------

function parseAnnualKt(text: string): Record<string, number> | null {
  const out: Record<string, number> = {};
  for (const raw of text.split(/\n+/)) {
    const line = raw.trim();
    if (!line) continue;
    const parts = line.split(/[\s,:=]+/).filter(Boolean);
    if (parts.length !== 2) return null;
    const year = Number(parts[0]);
    const kt = Number(parts[1]);
    if (!Number.isInteger(year) || year < 1990 || year > 2150 || !Number.isFinite(kt)) {
      return null;
    }
    out[String(year)] = kt;
  }
  return Object.keys(out).length > 0 ? out : null;
}

function annualKtToText(m: Record<string, number> | null | undefined): string {
  if (!m) return "";
  return Object.entries(m)
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([y, v]) => `${y} ${v}`)
    .join("\n");
}

function WastePamForm({
  initial,
  saving,
  onSave,
  onCancel,
}: {
  initial: WastePAM | null;
  saving: boolean;
  onSave: (body: WastePAM) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [scenario, setScenario] = useState<"WEM" | "WAM">(initial?.scenario ?? "WEM");
  const [lever, setLever] = useState<WasteLever>(initial?.lever ?? "diversion");
  const [startYear, setStartYear] = useState<string>(String(initial?.start_year ?? new Date().getFullYear() + 1));
  const [targetYear, setTargetYear] = useState<string>(
    initial?.target_year != null ? String(initial.target_year) : "",
  );
  const [diversionFrac, setDiversionFrac] = useState<string>(
    initial?.diversion_frac != null ? String(initial.diversion_frac) : "",
  );
  const [recoveryTarget, setRecoveryTarget] = useState<string>(
    initial?.recovery_target != null ? String(initial.recovery_target) : "",
  );
  const [compostingFrac, setCompostingFrac] = useState<string>(
    initial?.composting_frac != null ? String(initial.composting_frac) : "",
  );
  const [wwTargetSystem, setWwTargetSystem] = useState<WasteWWSystem>(
    initial?.ww_target_system ?? "aerobic",
  );
  const [wwShareShifted, setWwShareShifted] = useState<string>(
    initial?.ww_share_shifted != null ? String(initial.ww_share_shifted) : "",
  );
  const [category, setCategory] = useState<WasteCategory>(initial?.category ?? "5A");
  const [annualKtText, setAnnualKtText] = useState<string>(annualKtToText(initial?.annual_kt));

  const num = (s: string): number | null => (s.trim() === "" ? null : Number(s));

  // Single validation pass → { body } or { error }.
  const check = useMemo((): { body?: WastePAM; error?: string } => {
    if (name.trim().length === 0) return { error: "Give the measure a name." };
    const sy = Number(startYear);
    if (!Number.isInteger(sy) || sy < 1990 || sy > 2150) {
      return { error: "Start year must be a year between 1990 and 2150." };
    }
    const ty = num(targetYear);
    if (ty !== null && (!Number.isInteger(ty) || ty < sy)) {
      return { error: "Target year must be ≥ start year." };
    }

    // FE-13: explicitly null every lever-specific param, then set only the
    // ones belonging to the selected lever. PATCH merges fields server-side,
    // so switching lever would otherwise leave stale cross-lever params stored.
    const base: WastePAM = {
      ...(initial?.id ? { id: initial.id } : {}),
      name: name.trim(),
      scenario,
      lever,
      start_year: sy,
      target_year: ty,
      diversion_frac: null,
      recovery_target: null,
      composting_frac: null,
      ww_target_system: null,
      ww_share_shifted: null,
      annual_kt: null,
      category: null,
    };

    const frac = (s: string, label: string): { v?: number; error?: string } => {
      const v = num(s);
      if (v === null || !(v > 0 && v <= 1)) {
        return { error: `${label} must be a fraction in (0, 1].` };
      }
      return { v };
    };

    switch (lever) {
      case "diversion": {
        const r = frac(diversionFrac, "Diversion share");
        if (r.error) return { error: r.error };
        return { body: { ...base, diversion_frac: r.v } };
      }
      case "gas_recovery": {
        const r = frac(recoveryTarget, "Recovery target");
        if (r.error) return { error: r.error };
        return { body: { ...base, recovery_target: r.v } };
      }
      case "composting_shift": {
        const r = frac(compostingFrac, "Composting share");
        if (r.error) return { error: r.error };
        return { body: { ...base, composting_frac: r.v } };
      }
      case "ww_treatment_upgrade": {
        const r = frac(wwShareShifted, "Population share shifted");
        if (r.error) return { error: r.error };
        return {
          body: { ...base, ww_target_system: wwTargetSystem, ww_share_shifted: r.v },
        };
      }
      case "direct_reduction": {
        const series = parseAnnualKt(annualKtText);
        if (!series) {
          return {
            error: 'Enter at least one "year value" line, e.g. "2030 120" (kt CO₂-eq per year).',
          };
        }
        return { body: { ...base, annual_kt: series, category } };
      }
    }
  }, [
    name, scenario, lever, startYear, targetYear,
    diversionFrac, recoveryTarget, compostingFrac,
    wwTargetSystem, wwShareShifted, category,
    annualKtText, initial?.id,
  ]);

  const selectCls =
    "h-9 w-full rounded-md border border-input bg-background px-2 text-sm";

  return (
    <div className="space-y-3 rounded-sm border border-primary/30 bg-primary/5 p-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <Label>Name</Label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Organic waste diversion programme"
          />
        </div>
        <div>
          <Label>Scenario</Label>
          <select
            className={selectCls}
            value={scenario}
            onChange={(e) => setScenario(e.target.value as "WEM" | "WAM")}
          >
            <option value="WEM">WEM — existing measure</option>
            <option value="WAM">WAM — additional measure</option>
          </select>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label>Lever</Label>
          <select
            className={selectCls}
            value={lever}
            onChange={(e) => setLever(e.target.value as WasteLever)}
          >
            {(Object.keys(LEVER_LABELS) as WasteLever[]).map((l) => (
              <option key={l} value={l}>
                {LEVER_LABELS[l]}
              </option>
            ))}
          </select>
        </div>
        {lever === "direct_reduction" && (
          <div>
            <Label>Target category</Label>
            <select
              className={selectCls}
              value={category}
              onChange={(e) => setCategory(e.target.value as WasteCategory)}
            >
              {CATEGORY_ORDER.map((c) => (
                <option key={c} value={c}>
                  {CATEGORY_LABELS[c]}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <p className="text-[11px] text-muted-foreground">{LEVER_HINTS[lever]}</p>

      <div className="grid gap-3 sm:grid-cols-4">
        <div>
          <Label>Start year</Label>
          <Input type="number" value={startYear} onChange={(e) => setStartYear(e.target.value)} />
        </div>
        {lever !== "direct_reduction" && (
          <div>
            <Label>Target year (optional)</Label>
            <Input
              type="number"
              value={targetYear}
              onChange={(e) => setTargetYear(e.target.value)}
              placeholder="ramp end"
            />
          </div>
        )}

        {lever === "diversion" && (
          <div>
            <Label>Diverted share of deposition (0–1)</Label>
            <Input
              type="number"
              step="any"
              min={0}
              max={1}
              value={diversionFrac}
              onChange={(e) => setDiversionFrac(e.target.value)}
              placeholder="e.g. 0.3"
            />
          </div>
        )}

        {lever === "gas_recovery" && (
          <div>
            <Label>Recovery target (0–1 of generated CH₄)</Label>
            <Input
              type="number"
              step="any"
              min={0}
              max={1}
              value={recoveryTarget}
              onChange={(e) => setRecoveryTarget(e.target.value)}
              placeholder="e.g. 0.5"
            />
          </div>
        )}

        {lever === "composting_shift" && (
          <div>
            <Label>Composted share of deposition (0–1)</Label>
            <Input
              type="number"
              step="any"
              min={0}
              max={1}
              value={compostingFrac}
              onChange={(e) => setCompostingFrac(e.target.value)}
              placeholder="e.g. 0.2"
            />
          </div>
        )}

        {lever === "ww_treatment_upgrade" && (
          <>
            <div>
              <Label>Target treatment system</Label>
              <select
                className={selectCls}
                value={wwTargetSystem}
                onChange={(e) => setWwTargetSystem(e.target.value as WasteWWSystem)}
              >
                {(Object.keys(WW_SYSTEM_LABELS) as WasteWWSystem[]).map((s) => (
                  <option key={s} value={s}>
                    {WW_SYSTEM_LABELS[s]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Population share shifted (0–1)</Label>
              <Input
                type="number"
                step="any"
                min={0}
                max={1}
                value={wwShareShifted}
                onChange={(e) => setWwShareShifted(e.target.value)}
                placeholder="e.g. 0.25"
              />
            </div>
          </>
        )}
      </div>

      {lever === "direct_reduction" && (
        <div>
          <Label>Annual mitigation series (one &quot;year value&quot; per line, kt CO₂-eq)</Label>
          <textarea
            value={annualKtText}
            onChange={(e) => setAnnualKtText(e.target.value)}
            rows={4}
            placeholder={"2030 120\n2035 250\n2040 300"}
            className="mt-1 w-full rounded-md border border-input bg-background px-2 py-1.5 font-mono text-xs"
          />
        </div>
      )}

      {check.error && <p className="text-xs text-destructive">{check.error}</p>}

      <div className="flex justify-end gap-2">
        <Button variant="outline" size="sm" onClick={onCancel} disabled={saving}>
          <X className="mr-1 h-3 w-3" /> Cancel
        </Button>
        <Button
          size="sm"
          disabled={!check.body || saving}
          onClick={() => check.body && onSave(check.body)}
        >
          <Check className="mr-1 h-3 w-3" />
          {saving ? "Saving…" : initial ? "Save changes" : "Add measure"}
        </Button>
      </div>
    </div>
  );
}
