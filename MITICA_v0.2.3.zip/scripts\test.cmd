@echo off
rem MITICA Next — run all tests (core + web typecheck).
pushd "%~dp0.."
call pnpm test
popd
