"""BTR (non-Annex-I) real-data backtest of the Waste module (SI-007) — C2 tier 2.

Eight Parties whose CRT zips are on disk: BRA CHL COL EGY GEO IDN KAZ TUR.
Same protocol as the EU panel: train ≤2018, project 2019–2022 with OBSERVED
drivers (population, gdp_pc) as projected inputs, score WoM vs the reported CRT
Table5 series (converted to AR4 CO2-eq — matching the module).

Per category (5A/5B/5C/5D) and the sector total (Σ of the modelled categories vs
Σ of the SAME observed categories): MAPE + signed bias over 2019–2022. The
per-category anchor reproduces the 2018 level exactly; the TREND is scored.

Realistic input rule (same as EU): feed a category only if its 2018 base year
is > 0 (an all-zero / notation-key series carries no level to anchor and trips
the engine's scale<=0 guard — see WASTE_BACKTEST.md).

DATA: scripts/waste_validation/data/btr/{ISO}_table5.csv (parsed by
parse_btr_table5.py) + WDI pop.csv / gdp_const_usd.csv.

Run: .venv\\Scripts\\python.exe scripts\\waste_validation\\btr_waste_backtest.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.waste import (  # noqa: E402
    WasteConfig,
    WasteInputs,
    run_waste_module,
)

T5_DIR = Path(__file__).parent / "data" / "btr"
WDI = ROOT / "scripts" / "energy_validation" / "data" / "wdi"
OUT = Path(__file__).parent / "results"

TRAIN_END = 2018
SCORE_YEARS = list(range(2019, 2023))   # CRT through 2022
ISOS = ["BRA", "CHL", "COL", "EGY", "GEO", "IDN", "KAZ", "TUR"]

# IPCC climate zone for the 5A bulk-k (documented assignment; only affects FOD
# curvature, not the anchored level — see WASTE_BACKTEST.md).
CLIMATE = {
    "BRA": "tropical_wet", "CHL": "temperate_wet", "COL": "tropical_wet",
    "EGY": "tropical_dry", "GEO": "temperate_wet", "IDN": "tropical_wet",
    "KAZ": "boreal_dry", "TUR": "temperate_wet",
}


def mape_bias(model: dict[int, float], obs: dict[int, float]):
    apes, errs = [], []
    for y in SCORE_YEARS:
        if y not in obs or y not in model:
            continue
        o = obs[y]
        if o == 0:
            continue
        pe = (model[y] - o) / o * 100.0
        apes.append(abs(pe))
        errs.append(pe)
    if not apes:
        return np.nan, np.nan, 0
    return float(np.mean(apes)), float(np.mean(errs)), len(apes)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    pop = pd.read_csv(WDI / "pop.csv")
    gdp = pd.read_csv(WDI / "gdp_const_usd.csv")

    detail, summary = [], []
    for iso in ISOS:
        try:
            t5 = pd.read_csv(T5_DIR / f"{iso}_table5.csv")
            obs = {}
            for cat in ("5A", "5B", "5C", "5D"):
                d = t5[t5.cat == cat]
                obs[cat] = {int(r.year): float(r.co2eq_ar4_kt) for r in d.itertuples()}

            p = pop[pop.iso3 == iso].set_index("year")["value"].to_dict()
            g = gdp[gdp.iso3 == iso].set_index("year")["value"].to_dict()
            gdp_pc = {y: g[y] / p[y] for y in p if y in g and p[y] > 0}
            if not gdp_pc:
                raise ValueError("no overlapping pop/gdp years")

            inv, skipped = {}, []
            for cat in ("5A", "5B", "5C", "5D"):
                hist = {y: v for y, v in obs[cat].items() if y <= TRAIN_END}
                if hist.get(TRAIN_END, 0.0) > 0:
                    inv[cat] = hist
                else:
                    skipped.append(cat)
            if not inv:
                raise ValueError("no category with positive 2018 base year")

            yrs = [y for y in p if 1990 <= y <= 2022]
            inp = WasteInputs(
                country_code=iso,
                population={y: p[y] for y in yrs},
                gdp_pc={y: gdp_pc[y] for y in gdp_pc if 1990 <= y <= 2022},
                inventory=inv,
            )
            cfg = WasteConfig(horizon_year=2022, climate_zone=CLIMATE[iso],
                              scenarios=("WoM",))
            out = run_waste_module(inp, cfg)

            model_cat = {c: {} for c in inv}
            for r in out.rows:
                bc = r.by_category()
                for c in inv:
                    if c in bc:
                        model_cat[c][r.year] = bc[c]

            row = {"iso": iso, "climate": CLIMATE[iso],
                   "income": out.income_group, "tier": out.tier}
            for cat in ("5A", "5B", "5C", "5D"):
                if cat in inv:
                    m, b, n = mape_bias(model_cat[cat], obs[cat])
                    row[f"mape_{cat}"] = m
                    row[f"bias_{cat}"] = b
                    detail.append({"iso": iso, "cat": cat, "mape": m, "bias": b,
                                   "n": n})
                else:
                    row[f"mape_{cat}"] = np.nan
                    row[f"bias_{cat}"] = np.nan

            model_tot = {y: sum(model_cat[c].get(y, 0.0) for c in inv) for y in SCORE_YEARS}
            obs_tot = {y: sum(obs[c].get(y, 0.0) for c in inv if y in obs[c]) for y in SCORE_YEARS}
            mt, bt, _ = mape_bias(model_tot, obs_tot)
            row["mape_tot"] = mt
            row["bias_tot"] = bt
            row["fed_cats"] = "+".join(inv)
            row["skipped"] = "+".join(skipped)
            allv = [v for r in out.rows for v in r.kt_co2eq.values()]
            row["finite"] = bool(np.all(np.isfinite(allv))) if allv else True
            row["nonneg"] = all(v >= 0 for v in allv)
            row["n_flags"] = len(out.validation_report)
            summary.append(row)
            print(f"{iso} ({out.income_group},{CLIMATE[iso][:4]}): tot MAPE {mt:6.1f}% "
                  f"bias {bt:+6.1f}%  | 5A {row['mape_5A']:6.1f}% 5D {row['mape_5D']:6.1f}% "
                  f"| fed {row['fed_cats']} skip[{row['skipped']}]")
        except Exception as exc:  # noqa: BLE001
            print(f"{iso}: FAILED — {exc}")
            summary.append({"iso": iso, "error": str(exc)})

    det = pd.DataFrame(detail)
    summ = pd.DataFrame(summary)
    det.to_csv(OUT / "btr_by_category.csv", index=False)
    summ.to_csv(OUT / "btr_summary.csv", index=False)

    ok = summ.dropna(subset=["mape_tot"]) if "mape_tot" in summ else pd.DataFrame()
    print(f"\n=== BTR panel (n={len(ok)} countries) ===")
    for col in ("mape_tot", "mape_5A", "mape_5B", "mape_5C", "mape_5D"):
        if col in ok and ok[col].notna().any():
            print(f"  {col:9s} median {ok[col].median():6.1f}%   "
                  f"p90 {ok[col].quantile(0.9):6.1f}%   n={ok[col].notna().sum()}")
    for col in ("bias_tot", "bias_5A", "bias_5D"):
        if col in ok and ok[col].notna().any():
            print(f"  {col:9s} median {ok[col].median():+6.1f}%")
    print(f"\nwrote {OUT / 'btr_summary.csv'}\nwrote {OUT / 'btr_by_category.csv'}")


if __name__ == "__main__":
    main()
