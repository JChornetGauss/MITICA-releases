@echo off
rem MITICA Next — nuclear reset. Kill processes, wipe caches, wipe DB, keep deps.
pushd "%~dp0.."

echo [MITICA reset] stopping anything on :8000 / :3000 ...
node scripts\stop.mjs

echo [MITICA reset] wiping caches ...
node scripts\clean.mjs

echo [MITICA reset] wiping data\mitica.db (project state) ...
if exist "data\mitica.db" del /q "data\mitica.db"

echo.
echo [MITICA reset] done. Run:  scripts\dev.cmd
echo.
popd
