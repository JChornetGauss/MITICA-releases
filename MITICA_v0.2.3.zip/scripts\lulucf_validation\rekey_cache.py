"""Re-key _btr_series.json by country name -> ISO3 (fixes filename-derived key
collisions like the several 'CRT'-prefixed files). Then report which resolved
countries are still missing so a follow-up fetch can grab them."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

_HERE = Path(__file__).resolve()
sys.path.insert(0, str(_HERE.parent))
import _country_iso3  # noqa: E402

_CACHE = _HERE.parent / "_btr_series.json"
_TASKS = Path(r"C:\Users\juanl\AppData\Local\Temp\claude\C--Users-juanl-Documents-Claude-MITICA-project\7868ed16-21a2-40a8-939f-80df90d085ef\tasks")
_OUTFILES = ["win471f5t.output", "wompzxl84.output", "wzt822kik.output", "w2tf53wqc.output"]


def resolved_countries() -> set[str]:
    out = set()
    for n in _OUTFILES:
        f = _TASKS / n
        if not f.exists():
            continue
        m = re.search(r"\[\s*\{.*\}\s*\]", f.read_text(encoding="utf-8"), re.S)
        if m:
            for d in json.loads(m.group(0)):
                if (d.get("url") or "").strip().endswith(".zip"):
                    out.add(d["country"])
    return out


def main():
    cache = json.loads(_CACHE.read_text(encoding="utf-8"))
    new = {}
    for k, e in cache.items():
        nk = _country_iso3.iso3(e.get("country", "")) or k
        if nk in new:
            # keep the one with more category coverage
            old = new[nk]
            def ncat(x):
                return max((len([c for c in x["series"][y] if not c.startswith("_")])
                            for y in x["series"]), default=0)
            if ncat(e) <= ncat(old):
                continue
        new[nk] = e
    _CACHE.write_text(json.dumps(new, ensure_ascii=False))
    present = {e["country"] for e in new.values()}
    missing = sorted(resolved_countries() - present)
    print(f"re-keyed: {len(cache)} -> {len(new)} unique ISO3")
    print(f"countries present: {len(present)}")
    print(f"MISSING ({len(missing)}): {', '.join(missing)}")


if __name__ == "__main__":
    main()
