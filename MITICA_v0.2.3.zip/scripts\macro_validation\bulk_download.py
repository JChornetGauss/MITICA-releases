"""One-shot bulk download of Eurostat data for all EU-27 countries.

Runs ONE query per dataset (not one per country), splits the response into
per-country DataFrames, and saves to ``scripts/macro_validation/data/<CC>_<key>.csv``.

After this script is run once, ``run_backtest.py`` reads exclusively from
local CSVs and never touches the Eurostat API again. This avoids the
flakiness of per-country API loops.

Datasets fetched
----------------
* ``nama_10_gdp``   - GDP (B1GQ, CLV15_MEUR)
* ``nama_10_a10``   - sectoral GVA (B1G by NACE, CLV15_MEUR)
* ``nama_10_a64_p5``- sectoral GFCF (P51G by NACE, CLV15_MEUR)
* ``demo_pjan``     - population on 1 Jan (sex=T, age=TOTAL)
* ``irt_lt_mcby_a`` - long-term government bond yield (annual)
"""

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import pandas as pd

import eurostat

warnings.filterwarnings("ignore", category=FutureWarning)

# EU-27 + optional comparators (UK, NO, CH)
EU27 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR",
    "DE", "EL", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL",
    "PL", "PT", "RO", "SK", "SI", "ES", "SE",
]
EXTRA = ["UK", "NO", "CH"]  # for sensitivity, may not have full coverage
ALL_COUNTRIES = EU27 + EXTRA

YEAR_MIN = 1990
YEAR_MAX = 2024

OUT_DIR = Path("scripts/macro_validation/data")

NACE_TO_SECTOR = {
    "A":     "primary",
    "B-E":   "secondary",
    "C":     "secondary",
    "F":     "secondary",
    "G-I":   "tertiary",
    "G-J":   "tertiary",
    "J":     "tertiary",
    "K":     "tertiary",
    "L":     "tertiary",
    "M_N":   "tertiary",
    "O-Q":   "tertiary",
    "R-U":   "tertiary",
}


def _to_long(df: pd.DataFrame) -> pd.DataFrame:
    """Reshape Eurostat wide DataFrame (one col per year) to long format.

    Eurostat's pandas client returns the country dimension under the column
    ``geo\\TIME_PERIOD`` (a relic of the SDMX TSV format). We normalise that
    to ``geo`` so the rest of the script can use a stable column name.
    """
    if df is None or df.empty:
        return pd.DataFrame()
    df = df.rename(columns={"geo\\TIME_PERIOD": "geo"})
    year_cols = [c for c in df.columns if str(c).isdigit()]
    if not year_cols:
        year_cols = [c for c in df.columns if isinstance(c, str) and c[1:].isdigit()]
    id_cols = [c for c in df.columns if c not in year_cols]
    long = df.melt(id_vars=id_cols, value_vars=year_cols,
                   var_name="year", value_name="value")
    long["year"] = long["year"].astype(str).str.lstrip("A").astype(int)
    long = long.dropna(subset=["value"])
    long = long[(long["year"] >= YEAR_MIN) & (long["year"] <= YEAR_MAX)]
    return long


def _fetch(dataset: str, filters: dict) -> pd.DataFrame:
    print(f"  [api] {dataset}  filters={ {k: f'{len(v)} values' for k,v in filters.items()} }",
          flush=True)
    df = eurostat.get_data_df(dataset, filter_pars=filters)
    long = _to_long(df)
    print(f"        -> {len(long):,} rows after reshape", flush=True)
    return long


# ---------------------------------------------------------------------------
# Per-dataset extractors operating on the bulk frame
# ---------------------------------------------------------------------------


def split_gdp_pop(gdp_long: pd.DataFrame, pop_long: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """For each country code, build {Year, GDP_tot, Pop} from the bulk frames."""
    out: dict[str, pd.DataFrame] = {}
    gdp_long = gdp_long.rename(columns={"value": "GDP_tot"})
    pop_long = pop_long.rename(columns={"value": "Pop"})
    for code in ALL_COUNTRIES:
        g = gdp_long[gdp_long["geo"] == code][["year", "GDP_tot"]]
        p = pop_long[pop_long["geo"] == code][["year", "Pop"]]
        if g.empty or p.empty:
            continue
        merged = g.merge(p, on="year", how="inner").sort_values("year")
        merged = merged.rename(columns={"year": "Year"}).reset_index(drop=True)
        out[code] = merged
    return out


def split_sectoral(long: pd.DataFrame, prefix: str) -> dict[str, pd.DataFrame]:
    """Aggregate NACE r2 codes to {primary, secondary, tertiary} per country."""
    out: dict[str, pd.DataFrame] = {}
    long = long.copy()
    long["sector"] = long["nace_r2"].map(NACE_TO_SECTOR)
    long = long.dropna(subset=["sector"])
    for code, g in long.groupby("geo"):
        if code not in ALL_COUNTRIES:
            continue
        agg = g.groupby(["year", "sector"])["value"].sum().unstack("sector")
        agg.columns = [f"{prefix}_{c}" for c in agg.columns]
        agg = agg.reset_index().rename(columns={"year": "Year"})
        out[code] = agg.sort_values("Year").reset_index(drop=True)
    return out


def split_irate(long: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Annual long-term bond yield per country."""
    out: dict[str, pd.DataFrame] = {}
    for code, g in long.groupby("geo"):
        if code not in ALL_COUNTRIES:
            continue
        agg = g.groupby("year")["value"].mean().reset_index()
        agg = agg.rename(columns={"year": "Year", "value": "iRate"})
        out[code] = agg.sort_values("Year").reset_index(drop=True)
    return out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print(f"=== Bulk Eurostat download for {len(ALL_COUNTRIES)} countries "
          f"({YEAR_MIN}-{YEAR_MAX}) ===\n")
    print(f"Countries: {ALL_COUNTRIES}\n")

    # GDP
    print("[1/5] GDP (nama_10_gdp)")
    gdp = _fetch("nama_10_gdp", {
        "geo": ALL_COUNTRIES,
        "unit": ["CLV15_MEUR"],
        "na_item": ["B1GQ"],
    })

    # Population
    print("\n[2/5] Population (demo_pjan)")
    pop = _fetch("demo_pjan", {
        "geo": ALL_COUNTRIES,
        "sex": ["T"],
        "age": ["TOTAL"],
    })

    # Sectoral GVA
    print("\n[3/5] Sectoral GVA (nama_10_a10)")
    sgva = _fetch("nama_10_a10", {
        "geo": ALL_COUNTRIES,
        "unit": ["CLV15_MEUR"],
        "na_item": ["B1G"],
    })

    # Sectoral GFCF
    print("\n[4/5] Sectoral GFCF (nama_10_a64_p5)")
    try:
        sgfcf = _fetch("nama_10_a64_p5", {
            "geo": ALL_COUNTRIES,
            "unit": ["CLV15_MEUR"],
            "asset10": ["N11G"],
        })
    except Exception as e:
        print(f"  [warn] nama_10_a64_p5 failed: {e}")
        sgfcf = pd.DataFrame()

    # Interest rate — irt_lt_mcby_a rejects NO. Filter out countries known
    # to be missing from this dataset; the macro module tolerates absent
    # iRate (falls back to the prior for delta_s).
    print("\n[5/5] Long-term bond yield (irt_lt_mcby_a)")
    irate_countries = [c for c in ALL_COUNTRIES if c not in {"NO", "CH"}]
    try:
        irate = _fetch("irt_lt_mcby_a", {"geo": irate_countries})
    except Exception as e:
        print(f"  [warn] irt_lt_mcby_a failed: {e}")
        irate = pd.DataFrame()

    # ---- Split and save ----
    print("\n=== Splitting and saving per-country CSVs ===")
    gdp_pop = split_gdp_pop(gdp, pop) if not gdp.empty and not pop.empty else {}
    sgdp    = split_sectoral(sgva, "SGDP") if not sgva.empty else {}
    sinv    = split_sectoral(sgfcf, "SInv") if not sgfcf.empty else {}
    irates  = split_irate(irate) if not irate.empty else {}

    n_full = 0
    n_partial = 0
    for code in ALL_COUNTRIES:
        present = []
        for key, mapping in [
            ("gdp_pop", gdp_pop),
            ("sgdp",    sgdp),
            ("sinv",    sinv),
            ("irate",   irates),
        ]:
            df = mapping.get(code)
            if df is None or df.empty:
                # Write an empty stub so load_country() does not crash
                pd.DataFrame().to_csv(OUT_DIR / f"{code}_{key}.csv", index=False)
                continue
            df.to_csv(OUT_DIR / f"{code}_{key}.csv", index=False)
            present.append(key)
        if len(present) == 4:
            n_full += 1
            status = "FULL"
        elif present:
            n_partial += 1
            status = f"PARTIAL ({','.join(present)})"
        else:
            status = "EMPTY"
        print(f"  {code:<3}  {status}")

    print(f"\nWrote CSVs to {OUT_DIR}/")
    print(f"  Full coverage: {n_full}  partial: {n_partial}  "
          f"missing: {len(ALL_COUNTRIES) - n_full - n_partial}")


if __name__ == "__main__":
    sys.exit(main())
