@echo off
rem Helper invoked by dev.cmd — runs the web dev server in its own window.

set ROOT=%~dp0..
cd /d "%ROOT%\apps\web"
title MITICA Web
echo [MITICA Web] starting Next.js on http://localhost:3000 ...

rem Drop production build artefacts if they exist — they cause the classic
rem "Cannot find module './NNN.js'" error when pnpm dev re-hydrates the cache.
if exist ".next\BUILD_ID" (
    echo [MITICA Web] stale production build detected in .next — cleaning.
    rmdir /s /q ".next"
)

echo.
pnpm dev
echo.
echo [MITICA Web] dev server exited. Press any key to close this window.
pause >nul
