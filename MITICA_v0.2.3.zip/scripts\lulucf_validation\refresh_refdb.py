"""
refresh_refdb.py
================

Re-pull FAO FRA + FAOSTAT data and re-seal a new LULUCF refDB vintage.

**Phase L8 v1.0 STATUS — documented stub.**

The shipped refDB (``v2026_1.json``) was populated by hand from public
knowledge of FRA 2020 + FAOSTAT. A future iteration will wire up the
actual API clients here. For now this script:

1. Prints the documented refresh procedure.
2. Loads the current vintage to verify it parses.
3. Exits.

When implemented, the refresh flow will be:

    a) Pull FRA per-country forest area + stock + increment from
       https://fra-data.fao.org/api/v1/...
    b) Pull FAOSTAT wood removals, fertiliser, lime, urea per country.
    c) Pull mean annual temperature per country (WorldClim or similar).
    d) Pull mean burned area from MODIS / Global Forest Watch.
    e) Pull organic-soil extent from Global Peatlands Database.
    f) Build the new JSON keeping the SAME schema as v2026_1.
    g) Bump the version (v2026_1 -> v2026_2), seal with today's date,
       update the ``sources`` list, write to
       ``refdb/v{YEAR}_{N}.json``, archive the previous vintage under
       ``refdb/archive/``.

The schema must stay stable. Schema-breaking changes warrant a
version_major bump (v2027_1) plus a migration note.

Usage::

    python scripts/lulucf_validation/refresh_refdb.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
REFDB_DIR = REPO_ROOT / "packages" / "core" / "src" / "mitica_core" / "modules" / "lulucf" / "refdb"


def main() -> int:
    # Force UTF-8 stdout on Windows (the docstring contains non-ASCII).
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass
    print("=" * 70)
    print("LULUCF refDB refresh -- Phase L8 v1.0 stub")
    print("=" * 70)
    print()
    print(__doc__)
    print()
    print(f"refdb dir: {REFDB_DIR}")

    if not REFDB_DIR.exists():
        print(f"  -> ERROR: directory does not exist.")
        return 1

    vintages = sorted(REFDB_DIR.glob("v*.json"))
    print(f"  Vintages found: {[p.stem for p in vintages]}")

    if not vintages:
        print("  -> ERROR: no vintages shipped.")
        return 1

    # Verify the latest vintage parses
    latest = vintages[-1]
    print(f"\nVerifying {latest.name} ...")
    try:
        with latest.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as e:
        print(f"  -> ERROR: invalid JSON: {e}")
        return 2

    countries = data.get("countries", {})
    ipcc = data.get("ipcc_defaults", {})
    regional = data.get("regional_priors", {})

    print(f"  version:       {data.get('version')}")
    print(f"  sealed_at:     {data.get('sealed_at')}")
    print(f"  countries:     {len(countries)} ({', '.join(sorted(countries.keys()))})")
    print(f"  ipcc blocks:   {len(ipcc)}")
    print(f"  regions:       {len(regional)} ({', '.join(sorted(regional.keys()))})")
    print(f"  sources:       {len(data.get('sources', []))}")

    print("\nNo data fetched (stub). To refresh, implement the steps in the")
    print("module docstring above, write a new v*.json, and archive the")
    print("previous vintage under refdb/archive/.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
