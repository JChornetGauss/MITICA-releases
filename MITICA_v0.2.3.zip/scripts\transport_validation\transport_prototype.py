"""
transport_prototype.py — empirical stress-test of the MITICA transport model.

Purpose: prove (or break) the central claim of the SI-006 design — *the same
model is robust across users with different data availability* — using REAL data
(OWID/Climate Watch transport CO2 + WDI GDP-per-cápita & population), not prose.

Model (ASIF, reduced to what real data validates = total road/transport CO2):

    co2pc(gdppc, year) = γ · exp(α · exp(β · gdppc_k)) · exp(-δ·(year-2000))
    CO2(year)          = co2pc · Pop

  * The Gompertz term γ·exp(α·exp(β·gdppc)) is the motorization/activity income
    response (saturates at high income) — Dargay-Gately-Sommer shape.
  * The exp(-δ·t) term is the intensity/efficiency decline over time.
  * This is the Tier-1 aggregate spine; the PC/freight split (motorization for
    passenger, industry for freight) is tested separately (improvement analysis).

Resolution cascade = the personas (same model, different data → which params come
from the GLOBAL prior vs the country's own history):

  P1  Tier-1 (data-poor): only the calibration-period CO2 anchor + GDP/Pop.
       γ,α,β,δ from the GLOBAL prior (fit leave-one-out on the other countries);
       a single multiplicative `scale` from the anchor.
  P2  Tier-2 (own history): scale + a country efficiency/level adjustment fit to
       the country's own calibration-period series; income shape from the prior.
  P4  Tier-3 (full fit): γ,α,β,δ,scale all fit to the country's own history.

Backtest: calibrate on years ≤ CUTOFF, project years > CUTOFF from real GDP/Pop,
compare to real CO2 → MAPE. Ablation: P1 vs P4 (does the data-poor floor track
the data-rich fit?).
"""
from __future__ import annotations

import sys
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

PANEL = "scripts/transport_validation/data/panel.csv"
CUTOFF = 2012          # calibrate ≤2012, project 2013-2023
FOCUS = ["DEU", "ESP", "NOR", "MEX", "BRA", "THA", "IND", "VNM", "KEN", "ETH"]


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

def _gompertz_logco2pc(X, lng, a, b, d):
    """log(co2pc) = ln γ + α·exp(β·gdppc_k) − δ·(year−2000)."""
    gdppc_k, year = X
    return lng + a * np.exp(b * gdppc_k) - d * (year - 2000.0)


def income_group(gdp_pc: float) -> str:
    """World Bank FY24 income-class thresholds (current USD), used to group the
    prior by development phase (the macro-v4 grouping lesson)."""
    if gdp_pc < 1086:
        return "L"
    if gdp_pc < 4256:
        return "LM"
    if gdp_pc < 13206:
        return "UM"
    return "H"


def fit_global(df: pd.DataFrame) -> dict:
    """Fit the global income→transport-CO2pc relationship on a pooled panel."""
    g = df["gdp_pc"].to_numpy() / 1000.0
    yr = df["Year"].to_numpy().astype(float)
    y = np.log((df["transport_co2e_t"] / df["pop"]).to_numpy())
    p0 = [np.log(np.median(np.exp(y))), -3.0, -0.25, 0.005]
    bounds = ([-20, -50, -5, -0.1], [20, -1e-6, -1e-6, 0.1])
    try:
        popt, _ = curve_fit(_gompertz_logco2pc, (g, yr), y, p0=p0,
                            bounds=bounds, maxfev=20000)
    except Exception:
        popt = np.array(p0)
    return dict(lng=popt[0], a=popt[1], b=popt[2], d=popt[3])


def predict(params: dict, gdppc: np.ndarray, year: np.ndarray, pop: np.ndarray,
            scale: float = 1.0) -> np.ndarray:
    lnco2pc = _gompertz_logco2pc((gdppc / 1000.0, year.astype(float)),
                                 params["lng"], params["a"], params["b"], params["d"])
    return scale * np.exp(lnco2pc) * pop


# ---------------------------------------------------------------------------
# Personas (the resolution cascade)
# ---------------------------------------------------------------------------

# Shrinkage strength: weight on the country's own fit is n/(n+k). Bigger k ⇒
# more pull to the global prior (used for the data-leaner Tier-2 persona).
K_P2 = 18.0    # Tier-2: a multi-year inventory, but lean on the prior
K_P4 = 6.0     # Tier-3: data-rich, the country's own fit dominates
K_GROUP = 12.0  # group-curvature shrinkage to global: wg = n_group/(n_group+K)


def _shrink(country_pred: np.ndarray, prior_pred: np.ndarray, n: int, k: float) -> np.ndarray:
    """Prediction-space shrinkage (the macro-v4 lesson): blend the country's own
    projection with the prior floor, weighted by series length w=n/(n+k). As the
    country's data shrinks, the projection cedes to the prior → graceful
    degradation, so 'more data' can never do worse than the floor."""
    w = n / (n + k)
    return np.exp(w * np.log(country_pred) + (1.0 - w) * np.log(prior_pred))


def run_persona(persona: str, hist: pd.DataFrame, fut: pd.DataFrame,
                floor_h: np.ndarray, floor_f: np.ndarray) -> np.ndarray:
    """Return projected CO2 for `fut` years under the given data persona,
    calibrating only on `hist`. ``floor_h``/``floor_f`` are the (scale-1) PRIOR
    predictions on the hist/fut years — already blended group↔global upstream."""
    gdppc_h, yr_h = hist["gdp_pc"].to_numpy(), hist["Year"].to_numpy()
    co2_h = hist["transport_co2e_t"].to_numpy()
    gdppc_f, yr_f = fut["gdp_pc"].to_numpy(), fut["Year"].to_numpy()
    n = len(hist)

    # P1 floor = prior shape + single multiplicative anchor scale.
    scaleP1 = float(np.median(co2_h / floor_h))
    floorP1_f = scaleP1 * floor_f
    if persona == "P1":
        return floorP1_f

    if persona == "P2":
        # Own scale + bounded efficiency adjustment δ' on top of the prior floor,
        # then SHRINK to the floor.
        def f(X, lnscale, ddelta):
            base, yy = X
            return np.log(base) + lnscale - ddelta * (yy - 2000.0)
        try:
            popt, _ = curve_fit(f, (floor_h, yr_h), np.log(co2_h),
                                p0=[0.0, 0.0], maxfev=20000)
        except Exception:
            popt = [0.0, 0.0]
        country_f = np.exp(np.log(floor_f) + popt[0] - popt[1] * (yr_f - 2000.0))
        return _shrink(country_f, floorP1_f, n, K_P2)

    if persona == "P4":
        # Data-rich, but the income-response CURVATURE is NOT re-estimated per
        # country — a single country's narrow income range can't identify a
        # saturation curve (the macro-norm lesson). On top of the prior floor the
        # country fits only IDENTIFIABLE local terms: level (lnscale), efficiency
        # trend (ddelta), and a local income tilt (lam); then SHRINKS to the floor
        # with a small k (country dominates).
        lngdp_h = np.log(gdppc_h)
        ref = float(np.mean(lngdp_h))

        def f(X, lnscale, ddelta, lam):
            base, yy, lg = X
            return np.log(base) + lnscale - ddelta * (yy - 2000.0) + lam * (lg - ref)
        try:
            popt, _ = curve_fit(f, (floor_h, yr_h, lngdp_h), np.log(co2_h),
                                p0=[0.0, 0.0, 0.0], maxfev=20000)
        except Exception:
            popt = [0.0, 0.0, 0.0]
        country_f = np.exp(np.log(floor_f) + popt[0] - popt[1] * (yr_f - 2000.0)
                           + popt[2] * (np.log(gdppc_f) - ref))
        return _shrink(country_f, floorP1_f, n, K_P4)

    raise ValueError(persona)


def mape(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(np.mean(np.abs((pred - actual) / actual)) * 100.0)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    panel = pd.read_csv(PANEL)
    focus = [c for c in FOCUS if c in set(panel.iso3)]

    # classify every country by its calibration-period mean GDP-pc
    grp_of = {}
    for c in panel.iso3.unique():
        s = panel[(panel.iso3 == c) & (panel.Year <= CUTOFF)]
        if len(s):
            grp_of[c] = income_group(float(s["gdp_pc"].mean()))
    panel = panel.assign(grp=panel.iso3.map(grp_of))

    print(f"=== MITICA transport prototype — persona backtest ===")
    print(f"calibrate ≤{CUTOFF}, project {CUTOFF+1}-2023 | {len(focus)} countries")
    print("prior = leave-one-out fit within the country's income group (global fallback)\n")
    print(f"{'iso3':<5}{'grp':>4}{'gdp_pc':>10}{'P1g MAPE':>10}{'P1 MAPE':>9}{'P2 MAPE':>9}{'P4 MAPE':>9}{'hz P1g':>9}")

    rows = []
    for c in focus:
        sub = panel[panel.iso3 == c].sort_values("Year")
        hist = sub[sub.Year <= CUTOFF]
        fut = sub[sub.Year > CUTOFF]
        if len(hist) < 6 or len(fut) < 3:
            continue
        grp = grp_of.get(c)
        gh = (hist["gdp_pc"].to_numpy(), hist["Year"].to_numpy(), hist["pop"].to_numpy())
        gf = (fut["gdp_pc"].to_numpy(), fut["Year"].to_numpy(), fut["pop"].to_numpy())

        # GLOBAL prior (leave-one-out)
        prior_glob = fit_global(panel[panel.iso3 != c])
        floor_glob_h = predict(prior_glob, *gh, scale=1.0)
        floor_glob_f = predict(prior_glob, *gf, scale=1.0)

        # GROUP-curvature prior SHRUNK to global by group population (macro-v4):
        # well-populated groups (LM/UM) use their own slope; thin/narrow groups
        # (L/H) lean global → no blow-up on atypical members (India in L).
        grp_df = panel[(panel.grp == grp) & (panel.iso3 != c)]
        n_grp = grp_df.iso3.nunique()
        prior_gcur = fit_global(grp_df) if n_grp >= 5 else prior_glob
        wg = n_grp / (n_grp + K_GROUP)
        floor_h = np.exp(wg * np.log(predict(prior_gcur, *gh, 1.0)) + (1 - wg) * np.log(floor_glob_h))
        floor_f = np.exp(wg * np.log(predict(prior_gcur, *gf, 1.0)) + (1 - wg) * np.log(floor_glob_f))

        actual = fut["transport_co2e_t"].to_numpy()
        # P1 = global-prior floor; P1g/P2/P4 = blended group↔global floor
        res = {"P1": mape(actual, run_persona("P1", hist, fut, floor_glob_h, floor_glob_f)),
               "P1g": mape(actual, run_persona("P1", hist, fut, floor_h, floor_f)),
               "P2": mape(actual, run_persona("P2", hist, fut, floor_h, floor_f)),
               "P4": mape(actual, run_persona("P4", hist, fut, floor_h, floor_f))}
        predP1g = run_persona("P1", hist, fut, floor_h, floor_f)
        hz = (predP1g[-1] - actual[-1]) / actual[-1] * 100.0
        print(f"{c:<5}{grp:>4}{fut['gdp_pc'].iloc[-1]:>10,.0f}"
              f"{res['P1g']:>10.1f}{res['P1']:>9.1f}{res['P2']:>9.1f}{res['P4']:>9.1f}{hz:>8.1f}%")
        rows.append(dict(iso3=c, grp=grp, **{f"mape_{k}": v for k, v in res.items()}, hz_P1g=hz))

    r = pd.DataFrame(rows)
    print("\n=== summary (median / p90 MAPE across countries) ===")
    for k in ("P1", "P1g", "P2", "P4"):
        col = r[f"mape_{k}"]
        print(f"  {k:<4}: median {col.median():.1f}%  p90 {col.quantile(0.9):.1f}%  max {col.max():.1f}%")
    print("\nGrouping effect (P1 global → P1g group prior):")
    print(f"  median MAPE: {r['mape_P1'].median():.1f}% → {r['mape_P1g'].median():.1f}%")
    fast = r[r.grp.isin(["LM", "UM"])]
    if len(fast):
        print(f"  fast-growers (LM/UM) median: {fast['mape_P1'].median():.1f}% → {fast['mape_P1g'].median():.1f}%")
    print("\nRobustness — best persona per country (does more data help?):")
    print(f"  P1g median {r['mape_P1g'].median():.1f}% · P2 {r['mape_P2'].median():.1f}% · P4 {r['mape_P4'].median():.1f}%")
    worst = r.sort_values('mape_P4', ascending=False).head(3)
    print(f"  worst residual (P4): {', '.join(f'{w.iso3} {w.mape_P4:.0f}%' for _, w in worst.iterrows())}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
