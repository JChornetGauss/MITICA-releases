"use client";

import React, { use, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import * as XLSX from "xlsx";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  Activity,
  Play,
  AlertCircle,
  CheckCircle2,
  Info,
  Wand2,
  ChevronDown,
  ChevronRight,
  Lock,
} from "lucide-react";

// Tests whose red severity blocks the projection because they catch
// input-data integrity violations (Layer A T1 identities + D2.1
// positivity + D2.2 share bounds). These are the only tests that fire
// red under the v3 severity policy — all judgment tests cap at amber.
// Visualised in the UI with a Lock icon and "Blocks projection" tag so
// the user can distinguish "must fix" from "worth a look".
function isBlockingTest(testId: string): boolean {
  return testId === "T1" || testId === "D2.1" || testId === "D2.2";
}

import {
  api,
  type B3Form,
  type B5Form,
  type B6Form,
  type MacroDevGroup,
  type MacroFormsCatalog,
  type MacroRegion,
  type MacroResult,
  type MacroRunRequest,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import type { Data } from "plotly.js-dist-min";
import { cn } from "@/lib/utils";

// ----- CSV parse helpers -----

function parseYVCsv(text: string): { year: number; value: number }[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !/^(year|#)/i.test(l))
    .map((l) => l.split(/[,;\t\s]+/).filter(Boolean))
    .filter((parts) => parts.length >= 2)
    .map((parts) => ({ year: Number(parts[0]), value: Number(parts[1]) }))
    .filter((r) => Number.isFinite(r.year) && Number.isFinite(r.value));
}

function parseSGDPCsv(
  text: string,
): { year: number; primary: number; secondary: number; tertiary: number }[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !/^(year|#)/i.test(l))
    .map((l) => l.split(/[,;\t\s]+/).filter(Boolean))
    .filter((parts) => parts.length >= 4)
    .map((parts) => ({
      year: Number(parts[0]),
      primary: Number(parts[1]),
      secondary: Number(parts[2]),
      tertiary: Number(parts[3]),
    }))
    .filter(
      (r) =>
        Number.isFinite(r.year) &&
        Number.isFinite(r.primary) &&
        Number.isFinite(r.secondary) &&
        Number.isFinite(r.tertiary),
    );
}

// Sectoral energy demand (6 columns): year + the macro module's 6 energy
// sectors. Optional — used to calibrate the energy block on real data.
function parseSEDCsv(text: string): {
  year: number;
  primary: number;
  manufacturing: number;
  construction: number;
  services: number;
  transport_pass: number;
  transport_freight: number;
}[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !/^(year|#)/i.test(l))
    .map((l) => l.split(/[,;\t\s]+/).filter(Boolean))
    .filter((parts) => parts.length >= 7)
    .map((parts) => ({
      year: Number(parts[0]),
      primary: Number(parts[1]),
      manufacturing: Number(parts[2]),
      construction: Number(parts[3]),
      services: Number(parts[4]),
      transport_pass: Number(parts[5]),
      transport_freight: Number(parts[6]),
    }))
    .filter((r) => Object.values(r).every((v) => Number.isFinite(v)));
}

// M-03: fuel shares in long format — one cell per row, "year sector fuel
// share", whitespace/comma/semicolon/tab tolerant. The engine vocabulary
// (mirrored from the backend's FuelShareRow pattern constraints):
const FUEL_SHARE_SECTORS: string[] = [
  "primary",
  "manufacturing",
  "construction",
  "services",
  "transport_pass",
  "transport_freight",
  "households",
];
const FUEL_SHARE_FUELS: string[] = [
  "electricity",
  "gas",
  "oil_products",
  "solids",
  "biomass",
  "heat",
];

// Lenient long-format parser. Returns the valid rows plus a list of
// human-readable issues (unknown tokens, out-of-range shares, malformed
// lines) so the UI can warn live and refuse to submit garbage — the
// backend 422s on the same conditions, but with a less helpful message.
function parseFuelSharesLong(text: string): {
  rows: { year: number; sector: string; fuel: string; share: number }[];
  issues: string[];
} {
  const rows: { year: number; sector: string; fuel: string; share: number }[] = [];
  const issues: string[] = [];
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i].trim();
    if (!l || /^(year|#)/i.test(l)) continue;
    const parts = l.split(/[,;\t\s]+/).filter(Boolean);
    if (parts.length < 4) {
      issues.push(
        `line ${i + 1}: expected 4 columns (year sector fuel share), got ${parts.length}`,
      );
      continue;
    }
    const year = Number(parts[0]);
    const sector = parts[1].toLowerCase();
    const fuel = parts[2].toLowerCase();
    const share = Number(parts[3]);
    if (!Number.isFinite(year)) {
      issues.push(`line ${i + 1}: year '${parts[0]}' is not a number`);
      continue;
    }
    if (!FUEL_SHARE_SECTORS.includes(sector)) {
      issues.push(
        `line ${i + 1}: unknown sector '${parts[1]}' — valid: ${FUEL_SHARE_SECTORS.join(", ")}`,
      );
      continue;
    }
    if (!FUEL_SHARE_FUELS.includes(fuel)) {
      issues.push(
        `line ${i + 1}: unknown fuel '${parts[2]}' — valid: ${FUEL_SHARE_FUELS.join(", ")}`,
      );
      continue;
    }
    if (!Number.isFinite(share)) {
      issues.push(`line ${i + 1}: share '${parts[3]}' is not a number`);
      continue;
    }
    if (share < 0 || share > 1) {
      issues.push(
        `line ${i + 1}: share ${share} outside [0, 1] — use fractions (0.45), not percentages`,
      );
      continue;
    }
    rows.push({ year, sector, fuel, share });
  }
  return { rows, issues };
}

// Client-side courtesy mirror of the engine's per-(year, sector) sum checks
// (1% tolerance, like Layer A). Historical: every group must sum to 1 (red
// T1 aborts the run otherwise). Projected pins may be PARTIAL (the engine
// renormalises the remaining fuels into the residual, design §6.6) — only
// over-commit (Σ > 1) and a complete 6-fuel group that does not sum to 1
// are flagged.
function fuelShareSumWarnings(
  rows: { year: number; sector: string; fuel: string; share: number }[],
  mode: "historical" | "projected",
): string[] {
  const groups = new Map<string, { sum: number; count: number }>();
  for (const r of rows) {
    const k = `${r.year} ${r.sector}`;
    const g = groups.get(k) ?? { sum: 0, count: 0 };
    g.sum += r.share;
    g.count += 1;
    groups.set(k, g);
  }
  const out: string[] = [];
  for (const [k, g] of groups) {
    if (mode === "historical") {
      if (Math.abs(g.sum - 1) > 0.01) {
        out.push(`${k}: shares sum to ${g.sum.toFixed(3)} — must sum to 1`);
      }
    } else if (g.sum > 1.01) {
      out.push(`${k}: pinned shares sum to ${g.sum.toFixed(3)} > 1 (over-commit)`);
    } else if (
      g.count >= FUEL_SHARE_FUELS.length &&
      Math.abs(g.sum - 1) > 0.01
    ) {
      out.push(
        `${k}: all ${FUEL_SHARE_FUELS.length} fuels pinned but shares sum to ${g.sum.toFixed(3)} — a complete mix must sum to 1`,
      );
    }
  }
  return out;
}

// G3 (UX audit): linearly interpolate missing years inside a CSV. Works
// with any shape that has "year" as the first numeric column; trailing
// columns are interpolated independently. Header rows (lines starting
// with "year" or "#") are preserved verbatim. Returns the rewritten
// CSV plus the count of newly inserted rows.
function interpolateGapsCsv(text: string): { text: string; filled: number } {
  type Row = { year: number; values: number[] };
  const lines = text.split(/\r?\n/);
  const headerLines: string[] = [];
  const rows: Row[] = [];
  for (const raw of lines) {
    const l = raw.trim();
    if (!l) continue;
    if (/^(year|#)/i.test(l)) {
      headerLines.push(raw);
      continue;
    }
    const parts = l.split(/[,;\t\s]+/).filter(Boolean);
    if (parts.length < 2) continue;
    const year = Number(parts[0]);
    const values = parts.slice(1).map(Number);
    if (!Number.isFinite(year) || values.some((v) => !Number.isFinite(v))) {
      continue;
    }
    rows.push({ year, values });
  }
  if (rows.length < 2) return { text, filled: 0 };
  rows.sort((a, b) => a.year - b.year);
  const ncols = rows[0].values.length;
  if (rows.some((r) => r.values.length !== ncols)) {
    // Inconsistent column count — refuse to interpolate rather than
    // produce garbage.
    return { text, filled: 0 };
  }
  const out: Row[] = [];
  let filled = 0;
  for (let i = 0; i < rows.length; i++) {
    out.push(rows[i]);
    if (i === rows.length - 1) break;
    const a = rows[i];
    const b = rows[i + 1];
    const gap = b.year - a.year;
    if (gap <= 1) continue;
    for (let k = 1; k < gap; k++) {
      const t = k / gap;
      out.push({
        year: a.year + k,
        values: a.values.map((va, idx) => va + t * (b.values[idx] - va)),
      });
      filled += 1;
    }
  }
  if (filled === 0) return { text, filled: 0 };
  // Re-emit using the same number formatting as the most-precise input
  // value would have been displayed at; use up to 4 decimals.
  const fmt = (v: number) =>
    Number.isInteger(v) ? v.toFixed(0) : v.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
  const body = out
    .map((r) => [r.year.toFixed(0), ...r.values.map(fmt)].join(","))
    .join("\n");
  const result = headerLines.length > 0 ? headerLines.join("\n") + "\n" + body : body;
  return { text: result, filled };
}


// G1 (UX audit): convert Profile D's "target shares" SGDP CSV plus a
// projected GDP_tot anchor CSV into absolute SGDP rows the backend
// understands. Auto-detects fractions vs percentages (any value above
// 1.5 → percentages → divide by 100). Validates row-sum within 5% of 1.
// Throws a human-readable Error on the first problem.
function sharesToAbsoluteSgdp(
  sharesCsv: string,
  anchorCsv: string,
): { year: number; primary: number; secondary: number; tertiary: number }[] {
  const shareRows = parseSGDPCsv(sharesCsv);
  if (shareRows.length === 0) {
    throw new Error("Share-mode SGDP file is empty.");
  }
  const anchor = parseYVCsv(anchorCsv);
  if (anchor.length === 0) {
    throw new Error(
      "GDP_tot anchor is required in share-mode. Add a projected GDP_tot file.",
    );
  }

  // Auto-detect units: if anything is > 1.5, treat all values as percentages.
  const flat = shareRows.flatMap((r) => [r.primary, r.secondary, r.tertiary]);
  const asPercent = flat.some((v) => v > 1.5);
  const scale = asPercent ? 100 : 1;

  const anchorByYear = new Map<number, number>();
  anchor.forEach((r) => anchorByYear.set(r.year, r.value));

  return shareRows.map((r) => {
    const sumScaled = (r.primary + r.secondary + r.tertiary) / scale;
    if (Math.abs(sumScaled - 1) > 0.05) {
      throw new Error(
        `Share row for ${r.year} sums to ${(sumScaled * 100).toFixed(1)}% — `
        + "must be within 5% of 100%.",
      );
    }
    const anchorY = anchorByYear.get(r.year);
    if (anchorY == null) {
      throw new Error(
        `GDP_tot anchor missing for year ${r.year}. Add a matching row in the GDP_tot anchor file.`,
      );
    }
    return {
      year: r.year,
      primary: (r.primary / scale) * anchorY,
      secondary: (r.secondary / scale) * anchorY,
      tertiary: (r.tertiary / scale) * anchorY,
    };
  });
}

// ----- Demo data (synthetic LAC-like country) -----

const DEMO = {
  gdp: Array.from({ length: 18 }, (_, i) => ({
    year: 2005 + i,
    value: 100 + i * 4.7,
  })),
  pop: Array.from({ length: 18 }, (_, i) => ({
    year: 2005 + i,
    value: 10_000_000 + i * 150_000,
  })),
  sgdp: Array.from({ length: 18 }, (_, i) => {
    const gdp = 100 + i * 4.7;
    const prim = 0.14 * gdp - i * 0.05;
    const sec = 0.33 * gdp + i * 0.1;
    return {
      year: 2005 + i,
      primary: prim,
      secondary: sec,
      tertiary: gdp - prim - sec,
    };
  }),
  projGdp: [{ year: 2030, value: 230 }],
};

function toCsv(rows: { year: number; value: number }[]): string {
  return rows.map((r) => `${r.year},${r.value}`).join("\n");
}
function sgdpToCsv(
  rows: { year: number; primary: number; secondary: number; tertiary: number }[],
): string {
  return rows
    .map(
      (r) =>
        `${r.year},${r.primary.toFixed(2)},${r.secondary.toFixed(2)},${r.tertiary.toFixed(2)}`,
    )
    .join("\n");
}

// ----- Page -----

export default function MacroModulePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);

  // Configuration state
  const [region, setRegion] = useState<MacroRegion>("HIC");
  const [horizon, setHorizon] = useState<number>(2030);
  const [shrinkage, setShrinkage] = useState<number>(0.5);
  // Auto/Manual mode for functional forms. Auto (default) hides the form
  // selectors and applies the empirically-validated regional defaults
  // when the user clicks Run. Manual exposes the four selectors so an
  // expert user can override.
  const [formsMode, setFormsMode] = useState<"auto" | "manual">("auto");
  const [showAdvancedCalib, setShowAdvancedCalib] = useState<boolean>(false);
  // v4: optional development-phase group override. null → the engine derives
  // it from the region. There is no B2 functional-form switch in v4.
  const [devGroup, setDevGroup] = useState<MacroDevGroup | null>(null);
  const [b3Form, setB3Form] = useState<B3Form>("constant");
  const [b5Form, setB5Form] = useState<B5Form>("log_log");
  const [b6Form, setB6Form] = useState<B6Form>("log_log");

  // Historical CSV state (always required for any profile)
  const [gdpCsv, setGdpCsv] = useState<string>("");
  const [popCsv, setPopCsv] = useState<string>("");
  const [sgdpCsv, setSgdpCsv] = useState<string>("");
  // Optional economic lever: total investment (GFCF). Historical sets the I/Y
  // norm; a projected path lifts/lowers growth via the I/Y channel (B0). The two
  // work as a pair, so they live together (historical here, projected below).
  const [invTotalCsv, setInvTotalCsv] = useState<string>("");
  const [showInvestment, setShowInvestment] = useState<boolean>(false);
  // Optional energy inputs (historical). All fully optional — the energy block
  // runs from regional priors when these are blank.
  const [sedCsv, setSedCsv] = useState<string>("");
  const [sedHhCsv, setSedHhCsv] = useState<string>("");
  const [tedCsv, setTedCsv] = useState<string>("");
  const [showEnergy, setShowEnergy] = useState<boolean>(false);
  // M-03: optional fuel mix per sector, long format ("year sector fuel
  // share" rows). Historical text calibrates the logistic projection;
  // the second (smaller) text pins future-year cells, applied after the
  // logistic projection with the remaining fuels renormalised (§6.6).
  const [fuelSharesText, setFuelSharesText] = useState<string>("");
  const [projFuelSharesText, setProjFuelSharesText] = useState<string>("");
  const [showFuelShares, setShowFuelShares] = useState<boolean>(false);
  // Projection CSV state — what the user actually pins for the horizon.
  // All fields are optional; the engine auto-detects its internal path
  // from whatever the user supplies and projects the rest.
  const [projGdpCsv, setProjGdpCsv] = useState<string>("");
  const [projPopCsv, setProjPopCsv] = useState<string>("");
  const [projSgdpCsv, setProjSgdpCsv] = useState<string>("");
  const [projInvTotalCsv, setProjInvTotalCsv] = useState<string>("");
  const [projTedCsv, setProjTedCsv] = useState<string>("");
  // G1 (UX audit): users supplying sectoral GDP often have target SHARES
  // (e.g. 75% tertiary by 2030 from a Decarbonisation Plan) rather than
  // absolute SGDP values. When mode="shares" the user fills three share
  // columns and a GDP_tot anchor; we multiply them client-side before
  // sending.
  const [sgdpInputMode, setSgdpInputMode] =
    useState<"absolute" | "shares">("absolute");
  const [sgdpShareError, setSgdpShareError] = useState<string | null>(null);

  // Catalogue for dropdowns + recommendations
  const catalog = useQuery<MacroFormsCatalog>({
    queryKey: ["macro-forms-catalog"],
    queryFn: () => api.getMacroFormsCatalog(),
    staleTime: 5 * 60 * 1000,
  });

  // Existing result, if any
  const existing = useQuery<MacroResult>({
    queryKey: ["macro-result", id],
    queryFn: () => api.getMacroResult(id),
    retry: false,
  });

  // In Auto mode the four functional forms come from the regional
  // recommendation (the "Apply recommended" button's payload). The user
  // never sees them in the configurator but the result pills surface
  // which form was actually used.
  const effectiveForms = useMemo(() => {
    if (formsMode === "manual") {
      return { b3: b3Form, b5: b5Form, b6: b6Form };
    }
    const rec = catalog.data?.recommended_by_region?.[region];
    return rec ?? { b3: b3Form, b5: b5Form, b6: b6Form };
  }, [formsMode, region, b3Form, b5Form, b6Form, catalog.data]);

  // Run telemetry: how long the last run took on the wire. Visible so the
  // user perceives that something computed (otherwise the sub-second
  // response feels like it was cached).
  const [runDurationMs, setRunDurationMs] = useState<number | null>(null);
  const [runFinishedAt, setRunFinishedAt] = useState<Date | null>(null);

  // Run mutation
  const run = useMutation({
    mutationFn: async () => {
      const body: MacroRunRequest = {
        region,
        horizon_year: horizon,
        shrinkage,
        // v4: the development group sets the B0 growth + B2-EC priors. null →
        // the engine derives it from the region. There is no profile and no
        // B2 form switch — the engine auto-detects its flow (F1/F2/F3) from
        // whichever projected inputs the user supplied.
        dev_group: devGroup,
        b3_form: effectiveForms.b3,
        b5_form: effectiveForms.b5,
        b6_form: effectiveForms.b6,
        gdp_tot: parseYVCsv(gdpCsv),
        population: parseYVCsv(popCsv),
        sgdp: parseSGDPCsv(sgdpCsv),
      };
      // Audit fix: tell the user upfront if a mandatory series parsed
      // to zero rows. Without this guard the backend just errors out
      // and the user sees a generic 422 without knowing which CSV is
      // malformed.
      if (body.gdp_tot.length === 0) {
        throw new Error(
          "Historical GDP_tot is empty after parsing. Check that the "
          + "CSV has at least one row in 'year, value' format.",
        );
      }
      if (body.population.length === 0) {
        throw new Error(
          "Historical population is empty after parsing. Check the CSV.",
        );
      }
      if (body.sgdp.length === 0) {
        throw new Error(
          "Historical SGDP is empty after parsing. Expected four "
          + "columns: year, primary, secondary, tertiary.",
        );
      }
      // Projection inputs — every field is optional. Whatever the user
      // fills gets serialised; the engine auto-detects its internal path
      // and projects the rest.
      if (projGdpCsv.trim()) body.proj_gdp_tot = parseYVCsv(projGdpCsv);
      if (projPopCsv.trim()) body.proj_population = parseYVCsv(projPopCsv);
      // G1 (UX audit): in share-mode, convert the sectoral GDP shares ×
      // GDP_tot anchor into absolute SGDP rows before sending. The
      // backend only ever sees absolute values.
      if (sgdpInputMode === "shares" && projSgdpCsv.trim()) {
        try {
          const abs = sharesToAbsoluteSgdp(projSgdpCsv, projGdpCsv);
          if (abs.length > 0) body.proj_sgdp = abs;
          setSgdpShareError(null);
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          setSgdpShareError(msg);
          throw new Error(msg);
        }
      } else if (projSgdpCsv.trim()) {
        body.proj_sgdp = parseSGDPCsv(projSgdpCsv);
      }
      // Optional investment lever (historical sets the I/Y norm; projected lifts
      // or lowers growth via B0's I/Y channel).
      if (invTotalCsv.trim()) body.inv_total = parseYVCsv(invTotalCsv);
      if (projInvTotalCsv.trim()) body.proj_inv_total = parseYVCsv(projInvTotalCsv);
      // Energy is fully optional. Historical SED / SED_hh calibrate the energy
      // block; a historical TED anchors it to the observed total; a projected
      // TED is honored as the energy scenario and split across the macro-driven
      // composition (benchmarked vs the model's bottom-up WoM via U3).
      if (sedCsv.trim()) body.sed = parseSEDCsv(sedCsv);
      if (sedHhCsv.trim()) body.sed_hh = parseYVCsv(sedHhCsv);
      if (tedCsv.trim()) body.ted = parseYVCsv(tedCsv);
      if (projTedCsv.trim()) body.proj_ted = parseYVCsv(projTedCsv);
      // M-03: fuel shares (long format). Refuse to submit rows the backend
      // would 422 on (unknown tokens, out-of-range shares) — the live hint
      // below the textarea lists the same issues. The per-(year, sector)
      // Σ = 1 identity stays the engine's job (red T1 in the validation
      // report aborts the run server-side).
      if (fuelSharesText.trim()) {
        const { rows, issues } = parseFuelSharesLong(fuelSharesText);
        if (issues.length > 0) {
          throw new Error(`Historical fuel shares: ${issues[0]}`);
        }
        if (rows.length === 0) {
          throw new Error(
            "Historical fuel shares parsed to zero rows. Expected long "
            + "format: year sector fuel share (one cell per row).",
          );
        }
        body.fuel_shares = rows;
      }
      if (projFuelSharesText.trim()) {
        const { rows, issues } = parseFuelSharesLong(projFuelSharesText);
        if (issues.length > 0) {
          throw new Error(`Projected fuel-share pins: ${issues[0]}`);
        }
        if (rows.length === 0) {
          throw new Error(
            "Projected fuel-share pins parsed to zero rows. Expected long "
            + "format: year sector fuel share (one cell per row).",
          );
        }
        body.proj_fuel_shares = rows;
      }
      const t0 = performance.now();
      const out = await api.runMacro(id, body);
      setRunDurationMs(performance.now() - t0);
      setRunFinishedAt(new Date());
      return out;
    },
    onSuccess: () => existing.refetch(),
  });

  // Detect whether the displayed result is the one just computed by this
  // browser session, or a leftover from a previous run that was persisted
  // server-side. We surface this to avoid the "charts appeared before I
  // uploaded anything" confusion.
  const isCachedResult = !run.isSuccess && !!existing.data;

  // Clear persisted result on the backend + reset local state.
  const clearMutation = useMutation({
    mutationFn: () => api.clearMacroResult(id),
    onSuccess: () => {
      run.reset();
      setRunDurationMs(null);
      setRunFinishedAt(null);
      existing.refetch();
    },
  });

  function applyRecommended() {
    if (!catalog.data) return;
    const r = catalog.data.recommended_by_region[region];
    if (!r) return;
    setB3Form(r.b3);
    setB5Form(r.b5);
    setB6Form(r.b6);
  }

  function fillDemo() {
    setGdpCsv(toCsv(DEMO.gdp));
    setPopCsv(toCsv(DEMO.pop));
    setSgdpCsv(sgdpToCsv(DEMO.sgdp));
    setProjGdpCsv(toCsv(DEMO.projGdp));
    setHorizon(2030);
  }

  const result: MacroResult | undefined = run.data ?? existing.data ?? undefined;
  const regions: MacroRegion[] =
    catalog.data?.regions ?? ["LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS"];

  return (
    <div className="space-y-8">
      <Header />

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Configuration</CardTitle>
          <Button size="sm" variant="outline" onClick={fillDemo}>
            Use demo data
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label>Region (prior)</Label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value as MacroRegion)}
                className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
              >
                {regions.map((r) => (
                  <option key={r} value={r}>
                    {r}
                    {catalog.data?.region_descriptions?.[r]
                      ? ` — ${catalog.data.region_descriptions[r]}`
                      : ""}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Horizon year</Label>
              <Input
                type="number"
                value={horizon}
                onChange={(e) => setHorizon(Number(e.target.value))}
              />
            </div>
            <div>
              <Label id="forms-mode-label">Functional forms mode</Label>
              <div
                className="flex gap-1 rounded-md border border-input bg-background p-1"
                role="group"
                aria-labelledby="forms-mode-label"
              >
                <button
                  type="button"
                  onClick={() => setFormsMode("auto")}
                  aria-pressed={formsMode === "auto"}
                  className={cn(
                    "flex-1 rounded px-2 py-1 text-xs transition-colors",
                    formsMode === "auto"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                  title="System picks the empirically-validated regional defaults"
                >
                  Auto
                </button>
                <button
                  type="button"
                  onClick={() => setFormsMode("manual")}
                  aria-pressed={formsMode === "manual"}
                  className={cn(
                    "flex-1 rounded px-2 py-1 text-xs transition-colors",
                    formsMode === "manual"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                  title="Override per-block functional forms manually"
                >
                  Manual
                </button>
              </div>
              <p className="mt-1 text-[10.5px] leading-tight text-muted-foreground">
                Auto = use regional defaults for {region}.
                Manual = override B3/B5/B6 forms below.
              </p>
            </div>
          </div>

          {/* Form selectors — only visible in Manual mode */}
          {formsMode === "manual" && (
            <div className="rounded-md border border-border bg-card/40 p-4">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium">Functional forms (manual override)</h3>
                  <p className="text-xs text-muted-foreground">
                    Each block can use the legacy log-log or a structural
                    alternative. See the technical report for the rationale.
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={applyRecommended}
                  disabled={!catalog.data}
                  title="Apply the empirically-validated default for the selected region"
                >
                  <Wand2 className="mr-2 h-3.5 w-3.5" />
                  Apply recommended for {region}
                </Button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <FormSelect
                  label="B3 (primary split)"
                  value={b3Form}
                  onChange={(v) => setB3Form(v as B3Form)}
                  catalog={catalog.data?.forms.b3}
                />
                <FormSelect
                  label="B5 (sectoral energy)"
                  value={b5Form}
                  onChange={(v) => setB5Form(v as B5Form)}
                  catalog={catalog.data?.forms.b5}
                />
                <FormSelect
                  label="B6 (residential energy)"
                  value={b6Form}
                  onChange={(v) => setB6Form(v as B6Form)}
                  catalog={catalog.data?.forms.b6}
                />
              </div>
            </div>
          )}

          {/* Advanced calibration — collapsed by default. Houses the
              Bayesian shrinkage knob which is too jargon-heavy for most
              users. Default 0.5 stays unless the user touches it. */}
          <div>
            <button
              type="button"
              onClick={() => setShowAdvancedCalib((v) => !v)}
              aria-expanded={showAdvancedCalib}
              className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
            >
              {showAdvancedCalib ? (
                <ChevronDown className="h-3.5 w-3.5" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5" />
              )}
              Advanced calibration (Bayesian shrinkage)
            </button>
            {showAdvancedCalib && (
              <div className="mt-3 rounded-md border border-border bg-card/40 p-4">
                <Label>
                  Prior shrinkage λ:{" "}
                  <span className="font-mono">{shrinkage.toFixed(2)}</span>
                  <span className="ml-2 text-xs font-normal text-muted-foreground">
                    {shrinkage <= 0.1
                      ? "(country data dominate; near-OLS)"
                      : shrinkage <= 0.4
                      ? "(country data lead, regional prior nudges)"
                      : shrinkage <= 0.6
                      ? "(balanced — recommended default)"
                      : shrinkage <= 0.85
                      ? "(regional prior leads)"
                      : "(prior only — country data ignored)"}
                  </span>
                </Label>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={shrinkage}
                  onChange={(e) => setShrinkage(Number(e.target.value))}
                  className="mt-1 w-full"
                />
                <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
                  <span>0 = country data</span>
                  <span>0.5 = balanced</span>
                  <span>1 = regional prior</span>
                </div>
                <p className="mt-2 text-[11px] leading-tight text-muted-foreground">
                  Controls how strongly the country&apos;s own historical
                  data overrides the regional prior in the Bayesian fit.
                  Reduce for countries with long, clean histories;
                  raise for very short or noisy series.
                </p>

                <div className="mt-4 border-t border-border pt-3">
                  <Label htmlFor="devgroup">
                    Development group (income class)
                    <span className="ml-2 text-xs font-normal text-muted-foreground">
                      sets the growth &amp; structural-norm priors
                    </span>
                  </Label>
                  <select
                    id="devgroup"
                    value={devGroup ?? ""}
                    onChange={(e) =>
                      setDevGroup((e.target.value || null) as MacroDevGroup | null)
                    }
                    className="mt-1 w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  >
                    <option value="">Auto (derive from region)</option>
                    {(catalog.data?.dev_groups.options ?? ["L", "LM", "UM", "H"]).map(
                      (g) => (
                        <option key={g} value={g}>
                          {g} — {catalog.data?.dev_groups.descriptions?.[g] ?? g}
                        </option>
                      ),
                    )}
                  </select>
                  <p className="mt-2 text-[11px] leading-tight text-muted-foreground">
                    The World-Bank income class whose calibrated per-capita
                    growth and Chenery-Syrquin structural norm the engine uses.
                    Leave on Auto to derive it from the region.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Pointer to step 1 (Upload) where users grab the templates */}
          <div className="rounded-md border border-primary/30 bg-primary/5 p-3 text-xs">
            <p className="text-foreground">
              <span className="font-medium">Don&apos;t have macro CSVs yet?</span>{" "}
              The standard templates (GDP, Population, sectoral GDP, energy,
              fuel mix, livestock) are on step 1 of the workflow. Go to{" "}
              <Link
                href={`/projects/${id}/upload`}
                className="text-primary underline-offset-2 hover:underline"
              >
                1 · Upload
              </Link>
              {" "}to download the Excel templates, fill them with your
              country&apos;s data, save them as CSV (Save As → CSV UTF-8),
              and paste / upload them below.
            </p>
          </div>

          {/* === Section 1: Historical inputs (always required) === */}
          <div className="rounded-md border border-border bg-card/40 p-4">
            <h3 className="mb-1 text-sm font-medium">
              Historical inputs · always required
            </h3>
            <p className="mb-3 text-xs text-muted-foreground">
              Past years of the country's macro data. The engine uses these
              to estimate country-specific coefficients (Bayesian-shrunk to
              the regional prior).
            </p>
            <div className="grid gap-4 md:grid-cols-2">
              <CsvField
                label="GDP_tot (historical)"
                helper="Two columns: year, total GDP. One row per year."
                value={gdpCsv}
                onChange={setGdpCsv}
                projectId={id}
              />
              <CsvField
                label="Population (historical)"
                helper="Two columns: year, population."
                value={popCsv}
                onChange={setPopCsv}
                projectId={id}
              />
              <CsvField
                label="SGDP (historical)"
                helper="Four columns: year, primary, secondary, tertiary. Sum should be close to GDP_tot (Eurostat-style wedge up to 10% accepted)."
                value={sgdpCsv}
                onChange={setSgdpCsv}
                projectId={id}
                rows={8}
              />
            </div>

            {/* Optional economic lever: total investment (GFCF). Historical sets
                the country's I/Y norm; pair it with a projected path below to
                lift/lower projected growth. */}
            <div className="mt-4">
              <button
                type="button"
                onClick={() => setShowInvestment((v) => !v)}
                aria-expanded={showInvestment}
                className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
              >
                {showInvestment ? (
                  <ChevronDown className="h-3.5 w-3.5" />
                ) : (
                  <ChevronRight className="h-3.5 w-3.5" />
                )}
                Optional: investment (a higher planned investment-to-GDP than your
                history lifts projected growth)
              </button>
              {showInvestment && (
                <div className="mt-3">
                  <CsvField
                    label="Total investment / GFCF (historical)"
                    helper="Two columns: year, gross fixed capital formation (same currency as GDP). Optional — sets your historical investment-to-GDP norm. To move projected growth, also pin a projected investment path below."
                    value={invTotalCsv}
                    onChange={setInvTotalCsv}
                    projectId={id}
                    rows={5}
                  />
                </div>
              )}
            </div>

            {/* Optional energy inputs (historical). Fully optional — without
                them the energy block runs from regional priors. With sectoral
                SED it is calibrated on the country's data; a historical TED
                anchors it to the observed total. */}
            <div className="mt-4">
              <button
                type="button"
                onClick={() => setShowEnergy((v) => !v)}
                aria-expanded={showEnergy}
                className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
              >
                {showEnergy ? (
                  <ChevronDown className="h-3.5 w-3.5" />
                ) : (
                  <ChevronRight className="h-3.5 w-3.5" />
                )}
                Optional: energy (calibrate the energy block on your data instead
                of regional priors)
              </button>
              {showEnergy && (
                <div className="mt-3 grid gap-4 md:grid-cols-2">
                  <CsvField
                    label="Sectoral energy demand — SED (historical)"
                    helper="Seven columns: year, primary, manufacturing, construction, services, transport_pass, transport_freight (same energy unit throughout — ktoe / TJ / PJ). Optional — calibrates the energy block on your data."
                    value={sedCsv}
                    onChange={setSedCsv}
                    projectId={id}
                    rows={6}
                  />
                  <CsvField
                    label="Residential energy — SED_hh (historical)"
                    helper="Two columns: year, residential energy demand (same unit as SED, excluding passenger transport)."
                    value={sedHhCsv}
                    onChange={setSedHhCsv}
                    projectId={id}
                    rows={6}
                  />
                  <CsvField
                    label="Total energy demand — TED (historical)"
                    helper="Two columns: year, total final energy demand (= Σ sectors + residential, incl. transport; same unit). Optional — anchors the energy block to your observed total; cross-checked against the sectoral sum."
                    value={tedCsv}
                    onChange={setTedCsv}
                    projectId={id}
                    rows={6}
                  />
                </div>
              )}
            </div>

            {/* M-03: optional fuel mix per sector. Long-format paste grid —
                7 sectors × 6 fuels makes a wide table impractical, so one
                textarea takes "year sector fuel share" rows (historical),
                and a second smaller one takes future-year pins. */}
            <div className="mt-4">
              <button
                type="button"
                onClick={() => setShowFuelShares((v) => !v)}
                aria-expanded={showFuelShares}
                className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
              >
                {showFuelShares ? (
                  <ChevronDown className="h-3.5 w-3.5" />
                ) : (
                  <ChevronRight className="h-3.5 w-3.5" />
                )}
                Optional: fuel shares (the fuel mix of each sector&apos;s energy
                demand — historical mix + future-year pins)
              </button>
              {showFuelShares && (
                <div className="mt-3">
                  <p className="mb-3 text-[11px] leading-snug text-muted-foreground">
                    Long format, one cell per row:{" "}
                    <code className="rounded-sm bg-muted px-1 font-mono">
                      year sector fuel share
                    </code>{" "}
                    (spaces, commas or tabs — e.g.{" "}
                    <code className="rounded-sm bg-muted px-1 font-mono">
                      2020 services electricity 0.42
                    </code>
                    ). Shares are fractions in [0, 1].
                    <br />
                    Sectors:{" "}
                    <span className="font-mono">{FUEL_SHARE_SECTORS.join(" · ")}</span>
                    <br />
                    Fuels:{" "}
                    <span className="font-mono">{FUEL_SHARE_FUELS.join(" · ")}</span>
                  </p>
                  <div className="grid gap-4 md:grid-cols-2">
                    <FuelSharesField
                      label="Fuel shares (historical)"
                      helper="The observed mix. Each (year, sector) you supply must sum to 1 — the engine's T1 check aborts the run otherwise. Sectors/years you leave out are projected from defaults."
                      mode="historical"
                      value={fuelSharesText}
                      onChange={setFuelSharesText}
                      rows={8}
                    />
                    <FuelSharesField
                      label="Fuel-share pins (projected)"
                      helper="Future-year cells you want to fix (e.g. an electrification target). Applied after the engine's logistic projection; the remaining fuels are renormalised into the residual, so partial pins are fine — just don't pin more than 1 in total per (year, sector)."
                      mode="projected"
                      value={projFuelSharesText}
                      onChange={setProjFuelSharesText}
                      rows={5}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* === Section 2: Projected paths (all optional) === */}
          <div className="rounded-md border border-border bg-card/40 p-4">
            <h3 className="mb-1 text-sm font-medium">
              Projected paths · optional — fill only what you have; the
              engine projects the rest
            </h3>
            <p className="mb-3 text-xs text-muted-foreground">
              Pin any future path your country has already decided (a GDP
              target, a demographic projection, an investment plan…).
              Anything you leave blank is projected for you from the
              historical data. The engine works out which path to follow
              from whatever you supply — there is nothing else to choose.
            </p>
            <ProjectionInputs
              projectId={id}
              sgdpInputMode={sgdpInputMode}
              setSgdpInputMode={setSgdpInputMode}
              sgdpShareError={sgdpShareError}
              fields={{
                projGdpCsv, setProjGdpCsv,
                projPopCsv, setProjPopCsv,
                projSgdpCsv, setProjSgdpCsv,
                projInvTotalCsv, setProjInvTotalCsv,
                projTedCsv, setProjTedCsv,
              }}
            />
          </div>

          <div className="flex items-center gap-3">
            <Button
              onClick={() => run.mutate()}
              disabled={run.isPending || !gdpCsv.trim()}
            >
              <Play className="mr-2 h-4 w-4" />
              {run.isPending ? "Running & validating…" : "Run & validate"}
            </Button>
            {run.error && (
              <span className="text-sm text-destructive">
                {(run.error as Error).message}
              </span>
            )}
            {run.isSuccess && (
              <span className="inline-flex items-center gap-1.5 text-sm text-primary">
                <CheckCircle2 className="h-4 w-4" /> Run complete — results
                and validation are below
              </span>
            )}
          </div>
          {/* Audit §5c: "What Run does" mini-explainer — keep the single
              Run button (faster than a multi-step wizard) but tell users
              what the engine actually does so the sub-second response
              doesn't feel like nothing happened. */}
          <WhatRunDoes />
        </CardContent>
      </Card>

      {result && (
        <MacroResults
          result={result}
          horizon={horizon}
          projectId={id}
          runDurationMs={runDurationMs}
          runFinishedAt={runFinishedAt}
          isCachedResult={isCachedResult}
          onClear={() => clearMutation.mutate()}
          onRevalidate={() => run.mutate()}
          revalidatePending={run.isPending}
          clearPending={clearMutation.isPending}
        />
      )}
    </div>
  );
}

// ----- UI bits -----

function Header() {
  return (
    <div>
      <div className="mb-2 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-indigo-600">
          <Activity className="h-5 w-5" />
        </div>
        <div>
          <div className="eyebrow">Module · SI-002</div>
          <h2 className="font-serif text-2xl font-[460]">Macroeconomic module</h2>
        </div>
      </div>
      <p className="max-w-3xl text-sm text-muted-foreground">
        Provide historical GDP, Population and sectoral GDP (primary /
        secondary / tertiary). Optionally fix a projected path. Select the
        functional form per block, or apply the empirically validated default
        for the selected region. The module detects the flow (F1 / F2 / F3),
        estimates parameters with Bayesian shrinkage toward the (calibrated
        or stylised) regional priors, and returns the projected series plus a
        validation report.
      </p>
    </div>
  );
}

// Contextual help shown below the profile selector. Tells the user
// what they need to upload for the selected profile and how compositional
// B2 interacts with each profile.
// Audit §5c: collapsible "What Run does" explainer below the Run
// button. The audit recommended keeping a single Run button instead of
// a 3-step wizard (Estimate → Project → Validate) for speed, but
// adding a small panel explaining what the engine actually does so
// users don't perceive the sub-second response as "nothing happened".
function WhatRunDoes() {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-3">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        {open ? (
          <ChevronDown className="h-3.5 w-3.5" />
        ) : (
          <ChevronRight className="h-3.5 w-3.5" />
        )}
        What does &ldquo;Run macro module&rdquo; actually do?
      </button>
      {open && (
        <ol className="ml-5 mt-2 list-decimal space-y-1.5 text-xs text-muted-foreground">
          <li>
            <strong className="text-foreground">Validate inputs.</strong>{" "}
            Layer A checks national-accounts identities (Σ_s SGDP = GDP,
            I = I^priv + G^I, and T1: each year × sector&apos;s fuel shares
            sum to 1). A red here aborts; an amber proceeds.
          </li>
          <li>
            <strong className="text-foreground">Estimate parameters.</strong>{" "}
            Bayesian ridge with shrinkage λ pulls each B-block toward
            the regional prior. Origin tagged per parameter:{" "}
            <em>estimated</em> = your data dominated;{" "}
            <em>adjusted</em> = balanced; <em>calibrated</em> = prior
            dominated.
          </li>
          <li>
            <strong className="text-foreground">Project the cascade.</strong>{" "}
            B1 population → B0 PIB per cápita (own-growth reversion) → B2
            sectoral structure (error-correction toward the income norm)
            → B3 primary split → B4 livestock heads → B5 sectoral energy →
            B6 residential energy → derived (GDP/cap, intensity).
          </li>
          <li>
            <strong className="text-foreground">Run Layer C / D / T0 / D5 checks.</strong>{" "}
            ~30 plausibility tests on the projected paths. Reds (Layer
            A + D2.1 + D2.2) block; ambers inform; info flags are
            nudges. All carry a <em>What to do</em> suggestion.
          </li>
          <li>
            <strong className="text-foreground">Persist + return.</strong>{" "}
            The full payload (series + parameter log + validation
            report + ANNALIST proxies) is saved server-side and
            rendered below.
          </li>
        </ol>
      )}
    </div>
  );
}


// Projected-path input fields. Every field is optional — the user pins
// only the paths their country has already decided; the engine projects
// the rest and auto-detects which internal path to follow. Population is
// always offered (UN WPP is the canonical source).
function ProjectionInputs({
  projectId,
  sgdpInputMode,
  setSgdpInputMode,
  sgdpShareError,
  fields,
}: {
  projectId: string;
  sgdpInputMode: "absolute" | "shares";
  setSgdpInputMode: (m: "absolute" | "shares") => void;
  sgdpShareError: string | null;
  fields: {
    projGdpCsv: string; setProjGdpCsv: (v: string) => void;
    projPopCsv: string; setProjPopCsv: (v: string) => void;
    projSgdpCsv: string; setProjSgdpCsv: (v: string) => void;
    projInvTotalCsv: string; setProjInvTotalCsv: (v: string) => void;
    projTedCsv: string; setProjTedCsv: (v: string) => void;
  };
}) {
  const sharesMode = sgdpInputMode === "shares";
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <CsvField
        label="Projected GDP (total)"
        helper="If your country has an aspirational GDP target, paste/upload it. Leave blank to let the engine project GDP."
        value={fields.projGdpCsv}
        onChange={fields.setProjGdpCsv}
        projectId={projectId}
        rows={5}
      />
      <CsvField
        label="Projected population"
        helper="If you have a demographic projection (e.g. UN WPP), paste/upload it. Leave blank to let the engine project population."
        value={fields.projPopCsv}
        onChange={fields.setProjPopCsv}
        projectId={projectId}
        rows={5}
      />
      {/* P3 (UX): the absolute-vs-shares choice is only relevant once the user
          is actually entering projected sectoral GDP — show it contextually,
          not as a standalone question when there is no sectoral GDP at all. */}
      {fields.projSgdpCsv.trim() && (
      <div className="md:col-span-2 mb-1 flex flex-wrap items-center gap-2 text-xs">
        <span id="sgdp-input-mode-label" className="font-medium text-foreground">
          Is your projected sectoral GDP in:
        </span>
        <div
          className="flex gap-1 rounded-md border border-input bg-background p-1"
          role="group"
          aria-labelledby="sgdp-input-mode-label"
        >
          <button
            type="button"
            onClick={() => setSgdpInputMode("absolute")}
            aria-pressed={sgdpInputMode === "absolute"}
            className={cn(
              "rounded px-2 py-0.5 transition-colors",
              sgdpInputMode === "absolute"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            I have absolute values
          </button>
          <button
            type="button"
            onClick={() => setSgdpInputMode("shares")}
            aria-pressed={sgdpInputMode === "shares"}
            className={cn(
              "rounded px-2 py-0.5 transition-colors",
              sgdpInputMode === "shares"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            I have target shares
          </button>
        </div>
        <span className="text-muted-foreground">
          {sharesMode
            ? "Your shares are multiplied by the projected GDP path to recover absolute sectoral GDP. Shares may be fractions (0.75) or percentages (75)."
            : "Sectoral GDP rows are absolute values in the same currency as historical GDP."}
        </span>
      </div>
      )}
      <div>
        <CsvField
          label={
            sharesMode
              ? "Projected sectoral GDP — target shares"
              : "Projected sectoral GDP (primary / secondary / tertiary)"
          }
          helper={
            sharesMode
              ? "Four columns: year, primary share, secondary share, tertiary share. Each row should sum to 1 (or 100). Needs the projected GDP path above as the anchor. Leave blank to let the engine project sectoral GDP."
              : "Four columns: year, primary, secondary, tertiary. Leave blank to let the engine project sectoral GDP."
          }
          value={fields.projSgdpCsv}
          onChange={fields.setProjSgdpCsv}
          projectId={projectId}
          rows={5}
        />
        {sgdpShareError && (
          <p className="mt-1 text-xs text-destructive">
            {sgdpShareError}
          </p>
        )}
      </div>
      <CsvField
        label="Projected total investment / GFCF"
        helper="Two columns: year, gross fixed capital formation. If its implied investment-to-GDP runs above your historical norm, projected growth rises (bounded by the plausible band); below it, growth eases. Leave blank to ignore the investment channel."
        value={fields.projInvTotalCsv}
        onChange={fields.setProjInvTotalCsv}
        projectId={projectId}
        rows={5}
      />
      <CsvField
        label="Projected total energy demand — TED"
        helper="Two columns: year, total final energy demand (incl. transport; same unit as your historical energy). If you have a national / IEA energy scenario, paste it here: the engine honors it exactly and splits it across the macro-driven sectoral mix, then flags how its energy intensity (TED/GDP) compares to the model's own. Leave blank to let the engine project energy bottom-up."
        value={fields.projTedCsv}
        onChange={fields.setProjTedCsv}
        projectId={projectId}
        rows={5}
      />
    </div>
  );
}

function FormSelect({
  label,
  value,
  onChange,
  catalog,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  catalog?: { options: string[]; descriptions: Record<string, string> };
}) {
  const options = catalog?.options ?? [value];
  const desc = catalog?.descriptions?.[value];
  return (
    <div>
      <Label className="text-xs">{label}</Label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
      >
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
      {desc && (
        <p className="mt-1 text-[10.5px] leading-tight text-muted-foreground">
          {desc}
        </p>
      )}
    </div>
  );
}

function CsvField({
  label,
  helper,
  value,
  onChange,
  projectId,
  rows = 6,
}: {
  label: string;
  helper?: string;
  value: string;
  onChange: (v: string) => void;
  projectId: string;
  rows?: number;
}) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [interpStatus, setInterpStatus] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);

  function handleInterpolate() {
    const { text, filled } = interpolateGapsCsv(value);
    if (filled === 0) {
      setInterpStatus("No gaps detected — series is already contiguous.");
      return;
    }
    onChange(text);
    setInterpStatus(
      `Filled ${filled} missing year${filled === 1 ? "" : "s"} via linear interpolation.`,
    );
  }

  async function handleFile(file: File) {
    setFileError(null);
    const name = file.name.toLowerCase();
    if (name.endsWith(".csv") || name.endsWith(".txt") || name.endsWith(".tsv")) {
      const text = await file.text();
      onChange(text);
      return;
    }
    if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
      // MITICA templates are distributed as Excel. Parse server-side: the
      // backend is robust to header rows, locale decimal commas and blank
      // rows, and returns a clean comma-separated CSV with a "Year"
      // header (skipped downstream by the /^year/i regex).
      try {
        const { csv } = await api.parseMacroExcel(projectId, file);
        onChange(csv);
      } catch (e) {
        setFileError(
          `Could not read ${file.name}: ${(e as Error).message}. ` +
            `Try saving as CSV (Save As → CSV UTF-8) and uploading that.`
        );
      }
      return;
    }
    setFileError(`Unsupported file type: ${file.name}. Use .csv, .tsv, or .xlsx.`);
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <Label>{label}</Label>
        <div className="flex items-center gap-2 text-[11px]">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            aria-label={`Upload file for ${label}`}
            className="text-primary hover:underline"
          >
            Upload file
          </button>
          {value.trim() && (
            <button
              type="button"
              onClick={handleInterpolate}
              aria-label={`Interpolate missing years in ${label}`}
              className="text-primary hover:underline"
              title="Linearly interpolate missing years inside the existing range"
            >
              Interpolate gaps
            </button>
          )}
          {value.trim() && (
            <button
              type="button"
              onClick={() => { onChange(""); setInterpStatus(null); }}
              aria-label={`Clear ${label}`}
              className="text-muted-foreground hover:text-destructive"
              title="Clear this field"
            >
              clear
            </button>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.tsv,.txt,.xlsx,.xls"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
            // reset so picking the same file again re-fires onChange
            e.target.value = "";
          }}
        />
      </div>
      {helper && <p className="mb-1 text-[11px] text-muted-foreground">{helper}</p>}
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        placeholder="Click 'Upload file' above, or paste:&#10;2005, 123.4&#10;2006, 130.1"
        className="w-full resize-y rounded-md border border-input bg-background px-2 py-1.5 font-mono text-xs"
      />
      {value.trim() && (
        <p className="mt-0.5 text-[10px] text-muted-foreground">
          {value.split("\n").filter((l) => l.trim()).length} rows loaded
        </p>
      )}
      {interpStatus && (
        <p className="mt-0.5 text-[10px] text-foreground/70">{interpStatus}</p>
      )}
      {fileError && (
        <p className="mt-0.5 text-[11px] text-destructive">{fileError}</p>
      )}
    </div>
  );
}

// M-03: dedicated paste field for the long-format fuel shares. Deliberately
// NOT CsvField: the server-side Excel parser coerces every non-year column
// to numeric (it is built for year-value grids), which would destroy the
// sector/fuel string columns — so uploads here are plain-text only, and the
// "interpolate gaps" action (also numeric-only) is not offered. Below the
// textarea a live hint shows what parsed, plus a client-side courtesy
// mirror of the engine's per-(year, sector) sum checks (the backend still
// validates — red T1 aborts the run).
function FuelSharesField({
  label,
  helper,
  mode,
  value,
  onChange,
  rows = 6,
}: {
  label: string;
  helper: string;
  mode: "historical" | "projected";
  value: string;
  onChange: (v: string) => void;
  rows?: number;
}) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileError, setFileError] = useState<string | null>(null);

  const parsed = useMemo(() => parseFuelSharesLong(value), [value]);
  const sumWarnings = useMemo(
    () => fuelShareSumWarnings(parsed.rows, mode),
    [parsed.rows, mode],
  );
  const nYears = useMemo(
    () => new Set(parsed.rows.map((r) => r.year)).size,
    [parsed.rows],
  );
  const nSectors = useMemo(
    () => new Set(parsed.rows.map((r) => r.sector)).size,
    [parsed.rows],
  );

  async function handleFile(file: File) {
    setFileError(null);
    const name = file.name.toLowerCase();
    if (name.endsWith(".csv") || name.endsWith(".txt") || name.endsWith(".tsv")) {
      onChange(await file.text());
      return;
    }
    setFileError(
      `Unsupported file type: ${file.name}. Fuel shares accept .csv/.tsv/.txt `
      + "only (save your Excel sheet as CSV first — the columns must stay "
      + "year, sector, fuel, share).",
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <Label>{label}</Label>
        <div className="flex items-center gap-2 text-[11px]">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            aria-label={`Upload file for ${label}`}
            className="text-primary hover:underline"
          >
            Upload file
          </button>
          {value.trim() && (
            <button
              type="button"
              onClick={() => onChange("")}
              aria-label={`Clear ${label}`}
              className="text-muted-foreground hover:text-destructive"
              title="Clear this field"
            >
              clear
            </button>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.tsv,.txt"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
            e.target.value = "";
          }}
        />
      </div>
      <p className="mb-1 text-[11px] text-muted-foreground">{helper}</p>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        placeholder={
          "Paste long-format rows:\n2019 services electricity 0.40\n2019 services gas 0.25\n2019 services oil_products 0.20\n2019 services solids 0.05\n2019 services biomass 0.07\n2019 services heat 0.03"
        }
        className="w-full resize-y rounded-md border border-input bg-background px-2 py-1.5 font-mono text-xs"
      />
      {value.trim() && (
        <p className="mt-0.5 text-[10px] text-muted-foreground">
          {parsed.rows.length} cell{parsed.rows.length === 1 ? "" : "s"} parsed
          {parsed.rows.length > 0 && (
            <> · {nYears} year{nYears === 1 ? "" : "s"} · {nSectors} sector{nSectors === 1 ? "" : "s"}</>
          )}
        </p>
      )}
      {parsed.issues.length > 0 && (
        <div className="mt-1 space-y-0.5 text-[11px] text-destructive">
          {parsed.issues.slice(0, 4).map((iss, i) => (
            <p key={i}>{iss}</p>
          ))}
          {parsed.issues.length > 4 && (
            <p>… and {parsed.issues.length - 4} more.</p>
          )}
        </div>
      )}
      {sumWarnings.length > 0 && (
        <div className="mt-1 rounded-md border border-amber-600/40 bg-amber-600/10 p-2 text-[11px]">
          <p className="font-medium text-amber-900 dark:text-amber-200">
            {mode === "historical"
              ? "Shares don't sum to 1 — the run will abort (red T1) until fixed:"
              : "Pin check:"}
          </p>
          {sumWarnings.slice(0, 4).map((w, i) => (
            <p key={i} className="text-foreground/80">{w}</p>
          ))}
          {sumWarnings.length > 4 && (
            <p className="text-foreground/80">
              … and {sumWarnings.length - 4} more (year, sector) groups.
            </p>
          )}
        </div>
      )}
      {fileError && (
        <p className="mt-0.5 text-[11px] text-destructive">{fileError}</p>
      )}
    </div>
  );
}

// ----- Results view -----

function MacroResults({
  result,
  horizon,
  projectId,
  runDurationMs,
  runFinishedAt,
  isCachedResult,
  onClear,
  onRevalidate,
  revalidatePending,
  clearPending,
}: {
  result: MacroResult;
  horizon: number;
  projectId: string;
  runDurationMs: number | null;
  runFinishedAt: Date | null;
  isCachedResult: boolean;
  onClear: () => void;
  onRevalidate: () => void;
  revalidatePending: boolean;
  clearPending: boolean;
}) {
  // Detect projection abort: the engine returns historical data unchanged
  // when Layer A historical validation fails red. Surface this prominently.
  const maxYearOut = useMemo(() => {
    return Math.max(...result.gdp_tot.map((r) => r.Year));
  }, [result]);
  // Compare against the horizon the run was actually executed with — the
  // page-level `horizon` state may have drifted since (false "aborted" banner).
  const aborted = maxYearOut < (result.horizon_year ?? horizon);
  const redFlags = useMemo(
    () => result.validation_report.filter((f) => f.severity === "red"),
    [result],
  );

  const gdpSeries = useMemo(() => {
    const years = result.gdp_tot.map((r) => r.Year);
    const values = result.gdp_tot.map((r) => r.GDP_tot);
    return { years, values };
  }, [result]);

  const popSeries = useMemo(() => {
    const years = result.population.map((r) => r.Year);
    const values = result.population.map((r) => r.Pop);
    return { years, values };
  }, [result]);

  const sgdpShares = useMemo(() => {
    // Audit fix: only emit rows where all three SGDP values are
    // finite AND the total is positive. Previously we used `|| 1` as
    // a divide-by-zero fallback, which silently produced "shares"
    // that didn't sum to 100 when the row had any NaN.
    return result.sgdp
      .map((r) => {
        const p = r.SGDP_primary;
        const s = r.SGDP_secondary;
        const t = r.SGDP_tertiary;
        if (!Number.isFinite(p) || !Number.isFinite(s) || !Number.isFinite(t)) {
          return null;
        }
        const tot = p + s + t;
        if (tot <= 0) return null;
        return {
          year: r.Year as number,
          primary: (p / tot) * 100,
          secondary: (s / tot) * 100,
          tertiary: (t / tot) * 100,
        };
      })
      .filter((r): r is {
        year: number;
        primary: number;
        secondary: number;
        tertiary: number;
      } => r != null);
  }, [result]);

  return (
    <div className="space-y-6">
      {/* Cached-result banner. Shows when the page loaded a result from
          a previous /run that was persisted server-side — the user did
          not just compute it. Explains where the graphs come from and
          gives a Clear button to start over. */}
      {isCachedResult && (
        <div className="flex items-start gap-3 rounded-md border border-amber-600/40 bg-amber-600/10 p-3">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
          <div className="flex-1 text-xs">
            <p className="font-medium text-amber-900 dark:text-amber-200">
              Showing the result of a previous run on this project.
            </p>
            <p className="mt-0.5 text-foreground/80">
              The graphs and tables below come from a Macro run that was
              already saved server-side for this project. Use{" "}
              <span className="font-medium">Clear results</span> to discard
              them and start over, or{" "}
              <span className="font-medium">Validate results</span> to
              re-run the full pipeline with whatever data you have entered
              in the form above.
            </p>
          </div>
          <div className="flex shrink-0 flex-col gap-1.5">
            <Button
              size="sm"
              variant="outline"
              onClick={onRevalidate}
              disabled={revalidatePending}
            >
              {revalidatePending ? "Validating…" : "Validate results"}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={onClear}
              disabled={clearPending}
            >
              {clearPending ? "Clearing…" : "Clear results"}
            </Button>
          </div>
        </div>
      )}

      {/* Abort banner: appears prominently when the engine could not project
          because historical validation fired red. */}
      {aborted && (
        <div className="rounded-md border-2 border-destructive bg-destructive/10 p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-destructive">
                Projection aborted — historical data failed validation
              </h3>
              <p className="mt-1 text-xs text-foreground/80">
                The engine returned the historical series unchanged because
                Layer A identity tests fired red on the inputs. Output stops
                at year <span className="font-mono">{maxYearOut}</span>
                {" — the horizon was "}
                <span className="font-mono">{horizon}</span>. Fix the issues
                listed below and re-run.
              </p>
              {redFlags.length > 0 && (
                <ul className="mt-2 space-y-2 text-xs text-foreground/90">
                  {redFlags.slice(0, 5).map((f, i) => (
                    <li key={i} className="flex gap-2">
                      {isBlockingTest(f.test_id) ? (
                        <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-destructive" />
                      ) : (
                        <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-destructive" />
                      )}
                      <span className="font-mono text-destructive/80">
                        {f.test_id}
                      </span>
                      <div className="flex-1">
                        <p className="whitespace-pre-line">{f.message}</p>
                        {f.proposed_action && (
                          <p className="mt-0.5">
                            <span className="font-medium">What to do: </span>
                            {f.proposed_action}
                          </p>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 1 — Headline: the projection at a glance + plain-language narrative. */}
      {!aborted && <HeadlineProjection result={result} />}

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">GDP_tot & Population</CardTitle>
          </CardHeader>
          <CardContent>
            <PlotlyChart
              height={280}
              data={[
                {
                  x: gdpSeries.years,
                  y: gdpSeries.values,
                  type: "scatter",
                  mode: "lines+markers",
                  name: "GDP_tot",
                  line: { color: "#147A6E", width: 2 },
                },
                {
                  x: popSeries.years,
                  y: popSeries.values,
                  type: "scatter",
                  mode: "lines",
                  name: "Population",
                  yaxis: "y2",
                  line: { color: "#5b6dcd", width: 2, dash: "dot" },
                },
              ]}
              layout={{
                yaxis: { title: "GDP" },
                yaxis2: { overlaying: "y", side: "right", title: "Pop" },
              }}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sectoral GDP shares (%)</CardTitle>
          </CardHeader>
          <CardContent>
            <PlotlyChart
              height={280}
              data={[
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.primary),
                  name: "Primary",
                  type: "scatter",
                  stackgroup: "one",
                  line: { color: "#8a7d5a" },
                },
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.secondary),
                  name: "Secondary",
                  type: "scatter",
                  stackgroup: "one",
                  line: { color: "#147A6E" },
                },
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.tertiary),
                  name: "Tertiary",
                  type: "scatter",
                  stackgroup: "one",
                  line: { color: "#1A2438" },
                },
              ]}
              layout={{ yaxis: { ticksuffix: "%" } }}
            />
          </CardContent>
        </Card>
      </div>

      {/* v4: the country's structure vs the income norm (the Chenery-Syrquin
          attractor target). The gap shows how far the country sits from the
          "typical" structure at its income — and the v4 model deliberately
          lets it keep its own trajectory (weak attractor φ). */}
      {result.structure_norm && result.structure_norm.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Sectoral structure vs development norm
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              Solid = the country&apos;s projected shares · dashed = the
              Chenery-Syrquin development norm, anchored on the country&apos;s own
              structure and shifted by its real per-capita growth (so it is the
              same in any currency). A persistent gap means the country&apos;s own
              trajectory dominates the weak attractor φ (e.g. an industrialised
              economy staying above the norm).
            </p>
          </CardHeader>
          <CardContent>
            <PlotlyChart
              height={300}
              data={[
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.primary),
                  name: "Primary (country)", type: "scatter", mode: "lines",
                  line: { color: "#8a7d5a", width: 2 },
                },
                {
                  x: result.structure_norm.map((r) => r.Year),
                  y: result.structure_norm.map((r) => r.primary * 100),
                  name: "Primary (norm)", type: "scatter", mode: "lines",
                  line: { color: "#8a7d5a", width: 1.5, dash: "dot" },
                },
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.secondary),
                  name: "Secondary (country)", type: "scatter", mode: "lines",
                  line: { color: "#147A6E", width: 2 },
                },
                {
                  x: result.structure_norm.map((r) => r.Year),
                  y: result.structure_norm.map((r) => r.secondary * 100),
                  name: "Secondary (norm)", type: "scatter", mode: "lines",
                  line: { color: "#147A6E", width: 1.5, dash: "dot" },
                },
                {
                  x: sgdpShares.map((r) => r.year),
                  y: sgdpShares.map((r) => r.tertiary),
                  name: "Tertiary (country)", type: "scatter", mode: "lines",
                  line: { color: "#1A2438", width: 2 },
                },
                {
                  x: result.structure_norm.map((r) => r.Year),
                  y: result.structure_norm.map((r) => r.tertiary * 100),
                  name: "Tertiary (norm)", type: "scatter", mode: "lines",
                  line: { color: "#1A2438", width: 1.5, dash: "dot" },
                },
              ]}
              layout={{ yaxis: { ticksuffix: "%", title: "Share" } }}
            />
          </CardContent>
        </Card>
      )}

      {/* 3 — The deliverable: proxy series for ANNALIST + one-click exports. */}
      {!aborted && <ProxiesDeliverable result={result} projectId={projectId} />}

      {/* 4 — Validation as context (flow-aware status + collapsible detail). */}
      <ValidationContext report={result.validation_report} flow={result.flow_detected} />

      {/* 5 — Advanced methodological outputs, collapsed by default. */}
      {!aborted && <AdvancedOutputs result={result} />}

      {/* 6 — Slim run-meta strip + run actions. */}
      <RunMetaStrip
        result={result}
        runDurationMs={runDurationMs}
        runFinishedAt={runFinishedAt}
        onRevalidate={onRevalidate}
        onClear={onClear}
        revalidatePending={revalidatePending}
        clearPending={clearPending}
      />
    </div>
  );
}

// G2 (UX audit): deterministic plain-language summary of the run. The
// user gets this immediately, before having to scroll through pills,
// parameter logs and validation panels.
//
// The summary always covers:
//   1. Region + projection window.
//   2. GDP growth over the projection window (CAGR).
//   3. The single largest sectoral-share shift.
//   4. Flag counts (red / amber).
//
// Everything is computed deterministically from the result payload — no
// LLM, no API calls.
function NarrativeSummary({ result }: { result: MacroResult }) {
  const summary = useMemo(() => {
    const horizon = result.horizon_year;
    const lastHist = result.last_historical_year ?? null;

    // GDP growth over the projection window
    const gdpByYear = new Map<number, number>();
    result.gdp_tot.forEach((r) => {
      gdpByYear.set(r.Year as number, r.GDP_tot as number);
    });
    let gdpStartYr: number | null = null;
    let gdpEndYr: number | null = null;
    let cagr: number | null = null;
    if (lastHist != null && gdpByYear.has(lastHist) && gdpByYear.has(horizon)) {
      const y0 = gdpByYear.get(lastHist)!;
      const yH = gdpByYear.get(horizon)!;
      const n = horizon - lastHist;
      if (n > 0 && y0 > 0 && yH > 0) {
        cagr = Math.pow(yH / y0, 1 / n) - 1;
        gdpStartYr = lastHist;
        gdpEndYr = horizon;
      }
    }

    // Largest sectoral share shift (percentage points)
    let shareNote: string | null = null;
    if (lastHist != null && result.sgdp.length > 0) {
      const at = (year: number) => result.sgdp.find((r) => r.Year === year);
      const rowStart = at(lastHist);
      const rowEnd = at(horizon);
      if (rowStart && rowEnd) {
        const sumStart =
          (rowStart.SGDP_primary || 0) +
          (rowStart.SGDP_secondary || 0) +
          (rowStart.SGDP_tertiary || 0);
        const sumEnd =
          (rowEnd.SGDP_primary || 0) +
          (rowEnd.SGDP_secondary || 0) +
          (rowEnd.SGDP_tertiary || 0);
        if (sumStart > 0 && sumEnd > 0) {
          const sectors = ["primary", "secondary", "tertiary"] as const;
          const shifts = sectors.map((s) => {
            const colName = `SGDP_${s}` as const;
            const a = (rowStart[colName] as number) / sumStart;
            const b = (rowEnd[colName] as number) / sumEnd;
            return { sector: s, delta: b - a };
          });
          // Sector with the largest absolute change
          shifts.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
          const top = shifts[0];
          const sign = top.delta >= 0 ? "+" : "−";
          shareNote = `${top.sector} share ${sign}${Math.abs(top.delta * 100).toFixed(1)} pp`;
        }
      }
    }

    // Flag counts
    let red = 0;
    let amber = 0;
    result.validation_report.forEach((f) => {
      if (f.severity === "red") red += 1;
      else if (f.severity === "amber") amber += 1;
    });

    return {
      region: result.region,
      lastHist,
      horizon,
      cagr,
      gdpStartYr,
      gdpEndYr,
      shareNote,
      red,
      amber,
    };
  }, [result]);

  // Sentence 1: scope.
  const scope =
    summary.lastHist != null
      ? `Region ${summary.region}, projecting from ${summary.lastHist + 1} to ${summary.horizon}.`
      : `Region ${summary.region}, horizon ${summary.horizon}.`;

  // Sentence 2: GDP and structural shift.
  const growthSentence =
    summary.cagr != null && summary.gdpStartYr != null
      ? `GDP grows at ${(summary.cagr * 100).toFixed(2)}%/yr (compound) from ${summary.gdpStartYr} to ${summary.gdpEndYr}.`
      : "GDP path produced.";
  const structuralSentence = summary.shareNote
    ? ` Largest structural shift: ${summary.shareNote}.`
    : "";

  // Validation is its own section (and only appears when the user pinned
  // projected inputs that need a look) — the narrative stays about the
  // projection itself.
  return (
    <p className="text-sm leading-relaxed text-foreground">
      <span className="font-medium">{scope}</span>{" "}
      {growthSentence}
      {structuralSentence}
    </p>
  );
}


// ---------------------------------------------------------------------------
// P5 redesign — results lead with the projection; validation is context.
// ---------------------------------------------------------------------------

function StatCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-md border border-border bg-card/40 p-3">
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className="mt-1 text-xl font-semibold tabular-nums text-foreground">{value}</div>
      {sub && <div className="mt-0.5 text-[11px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

// Headline: the projection at a glance — four key numbers + the plain-language
// narrative. This is the lead of the results, before any validation.
function HeadlineProjection({ result }: { result: MacroResult }) {
  const s = useMemo(() => {
    const horizon = result.horizon_year;
    const lastHist = result.last_historical_year ?? null;
    const pcByYear = new Map<number, number>();
    (result.derived ?? []).forEach((r) => {
      const v = r["GDP_per_cap"];
      if (typeof r.Year === "number" && typeof v === "number" && Number.isFinite(v)) {
        pcByYear.set(r.Year, v);
      }
    });
    const pcHorizon = pcByYear.get(horizon) ?? null;
    let pcCagr: number | null = null;
    if (lastHist != null && pcByYear.has(lastHist) && pcHorizon != null) {
      const y0 = pcByYear.get(lastHist)!;
      const n = horizon - lastHist;
      if (n > 0 && y0 > 0 && pcHorizon > 0) pcCagr = Math.pow(pcHorizon / y0, 1 / n) - 1;
    }
    let shift: { sector: string; delta: number } | null = null;
    if (lastHist != null && result.sgdp.length > 0) {
      const at = (yr: number) => result.sgdp.find((r) => r.Year === yr);
      const a = at(lastHist);
      const b = at(horizon);
      if (a && b) {
        const sa = (a.SGDP_primary || 0) + (a.SGDP_secondary || 0) + (a.SGDP_tertiary || 0);
        const sb = (b.SGDP_primary || 0) + (b.SGDP_secondary || 0) + (b.SGDP_tertiary || 0);
        if (sa > 0 && sb > 0) {
          const sectors = ["primary", "secondary", "tertiary"] as const;
          const shifts = sectors.map((sec) => ({
            sector: sec,
            delta: (b[`SGDP_${sec}`] as number) / sb - (a[`SGDP_${sec}`] as number) / sa,
          }));
          shifts.sort((x, y) => Math.abs(y.delta) - Math.abs(x.delta));
          shift = shifts[0];
        }
      }
    }
    return { horizon, lastHist, pcHorizon, pcCagr, shift };
  }, [result]);

  // FE-11: v4 is currency-invariant — GDP arrives in whatever unit the user
  // uploaded, so no "$" prefix; the unit is named in the card's sub-label.
  const fmtPerCap = (v: number) => Math.round(v).toLocaleString();
  const scope =
    s.lastHist != null
      ? `${result.region} · projected ${s.lastHist + 1}–${s.horizon}`
      : `${result.region} · horizon ${s.horizon}`;

  return (
    <Card>
      <CardContent className="py-4">
        <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
          {scope}
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            label="GDP per cápita (horizon)"
            value={s.pcHorizon != null ? fmtPerCap(s.pcHorizon) : "—"}
            sub={`year ${s.horizon} · per capita (your GDP currency)`}
          />
          <StatCard
            label="GDP/cápita growth"
            value={s.pcCagr != null ? `${(s.pcCagr * 100).toFixed(1)} %/yr` : "—"}
            sub="compound, over the projection"
          />
          <StatCard
            label="Largest structural shift"
            value={s.shift ? `${s.shift.delta >= 0 ? "+" : "−"}${Math.abs(s.shift.delta * 100).toFixed(1)} pp` : "—"}
            sub={s.shift ? `${s.shift.sector} share` : "—"}
          />
          <StatCard
            label="Development phase"
            value={String(result.dev_group ?? "—")}
            sub={result.phi != null ? `structure attractor φ ${result.phi.toFixed(3)}` : ""}
          />
        </div>
        <div className="mt-3 border-t border-border/60 pt-3">
          <NarrativeSummary result={result} />
        </div>
      </CardContent>
    </Card>
  );
}

// The deliverable: the proxy series the Integration module (ANNALIST) consumes,
// plus the one-click exports (the proxies + validation spreadsheet and reports).
function ProxiesDeliverable({ result, projectId }: { result: MacroResult; projectId: string }) {
  function printablePdf() {
    const html = buildHtmlReport(result, projectId);
    const w = window.open("", "_blank");
    if (!w) {
      alert("Pop-up blocked. Allow pop-ups for this site to use Print to PDF.");
      return;
    }
    w.document.open();
    w.document.write(html);
    w.document.close();
    setTimeout(() => {
      try { w.focus(); w.print(); } catch { /* user can still print manually */ }
    }, 300);
  }
  function downloadMarkdown() {
    const md = buildMarkdownReport(result, projectId);
    const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    downloadBlob(md, "text/markdown;charset=utf-8",
      `mitica-macro-report-${projectId.slice(0, 8)}-${ts}.md`);
  }
  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-3">
        <div>
          <CardTitle className="text-base">Proxies for ANNALIST — the deliverable</CardTitle>
          <p className="mt-1 text-xs text-muted-foreground">
            These {result.annalist_proxies_index.length} series (history → horizon)
            are what the Integration module feeds to ANNALIST for the WoM forecast.
            Export them with the full validation log for review.
          </p>
        </div>
        <div className="flex shrink-0 flex-wrap justify-end gap-2">
          <Button
            size="sm"
            onClick={() => exportProxiesValidationXlsx(result, projectId)}
            title="Download an .xlsx with every proxy series (history → horizon) and the full validation report"
          >
            Export proxies + validation (.xlsx)
          </Button>
          <Button size="sm" variant="outline" onClick={printablePdf}>Print to PDF</Button>
          <Button size="sm" variant="outline" onClick={downloadMarkdown}>Report .md</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-1.5">
          {result.annalist_proxies_index.map((k) => (
            <code key={k} className="rounded-sm bg-muted px-2 py-0.5 font-mono text-[11px]">{k}</code>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Validation as CONTEXT — a status line (flow-aware: in F3 the model's own
// projection is plausible by construction, so info notes are context, not
// warnings) above a collapsible per-test breakdown.
function ValidationContext({
  report, flow,
}: { report: MacroResult["validation_report"]; flow: string }) {
  const [open, setOpen] = useState(false);
  const c = useMemo(() => {
    const o = { red: 0, amber: 0, info: 0 };
    report.forEach((f) => { if (f.severity in o) o[f.severity as keyof typeof o] += 1; });
    return o;
  }, [report]);

  // No flags → no validation section at all. In F3 (the model's own projection,
  // no user-pinned inputs) the backend emits no notes, so this renders nothing —
  // validation only appears when the user supplied projected inputs that need a
  // look (F1/F2) or when a blocking red fired.
  if (report.length === 0) return null;

  const isF3 = flow === "F3";
  let tone: "red" | "amber" | "ok";
  let title: string;
  let detail: string;
  if (c.red > 0) {
    tone = "red";
    title = `${c.red} blocking issue${c.red === 1 ? "" : "s"} — fix and re-run`;
    detail = "Layer-A integrity tests fired red; the projection cannot proceed until these are resolved.";
  } else if (c.amber > 0) {
    tone = "amber";
    title = `${c.amber} item${c.amber === 1 ? "" : "s"} to review`;
    // Surface the leading amber's own message (in F1/F2 this is U1 — "your
    // pinned path vs the model's projection") rather than a generic line.
    const lead = report.find((f) => f.severity === "amber");
    detail = lead?.message
      ?? "Your projected inputs sit outside the usual range — review them.";
  } else {
    tone = "ok";
    title = isF3
      ? "Projection is plausible"
      : "No issues — your inputs pass the coherence checks";
    detail = c.info > 0
      ? `${c.info} informational note${c.info === 1 ? "" : "s"} (context only — see the detail or the exported log).`
      : "All coherence checks passed.";
  }

  const Icon = tone === "red" ? AlertCircle : tone === "amber" ? Info : CheckCircle2;
  const toneCls =
    tone === "red" ? "border-destructive/40 bg-destructive/10 text-destructive"
      : tone === "amber" ? "border-amber-600/40 bg-amber-600/10 text-amber-700"
        : "border-emerald-600/40 bg-emerald-600/10 text-emerald-700";

  return (
    <Card>
      <CardContent className="py-3">
        <div className={cn("flex items-start gap-3 rounded-md border p-3", toneCls)}>
          <Icon className="mt-0.5 h-4 w-4 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-medium">{title}</p>
            <p className="mt-0.5 text-xs text-foreground/75">{detail}</p>
          </div>
          {report.length > 0 && (
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="shrink-0 text-xs text-foreground/70 underline-offset-2 hover:underline"
            >
              {open ? "Hide detail" : `Show detail (${report.length})`}
            </button>
          )}
        </div>
        {open && (
          <div className="mt-3">
            <ValidationPanel report={report} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Slim run-meta strip (replaces the pill wall + the old Run-details panel):
// the spec used + timing + parameter-origin counts, and the run actions.
function RunMetaStrip({
  result, runDurationMs, runFinishedAt, onRevalidate, onClear,
  revalidatePending, clearPending,
}: {
  result: MacroResult;
  runDurationMs: number | null;
  runFinishedAt: Date | null;
  onRevalidate: () => void;
  onClear: () => void;
  revalidatePending: boolean;
  clearPending: boolean;
}) {
  const origin = useMemo(() => {
    const o = { estimated: 0, adjusted: 0, calibrated: 0 };
    result.parameter_log.forEach((p) => { if (p.origin in o) o[p.origin as keyof typeof o] += 1; });
    return o;
  }, [result]);
  const bits: string[] = [
    `flow ${result.flow_detected}`,
    `${result.region}`,
    ...(result.dev_group ? [`group ${result.dev_group}`] : []),
    `horizon ${result.horizon_year}`,
    `params ${origin.estimated} est · ${origin.adjusted} adj · ${origin.calibrated} cal`,
    ...(runDurationMs != null ? [`ran in ${(runDurationMs / 1000).toFixed(2)}s`] : []),
    ...(runFinishedAt ? [runFinishedAt.toLocaleTimeString()] : []),
  ];
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-card/30 px-3 py-2">
      <p className="text-[11px] text-muted-foreground">{bits.join("  ·  ")}</p>
      <div className="flex shrink-0 gap-2">
        <Button size="sm" variant="outline" onClick={onRevalidate} disabled={revalidatePending}
          title="Re-run the full pipeline (projection + validation) with the inputs in the form">
          {revalidatePending ? "Validating…" : "Validate results"}
        </Button>
        <Button size="sm" variant="ghost" onClick={onClear} disabled={clearPending}
          title="Delete the stored result so you can start over">
          {clearPending ? "Clearing…" : "Clear results"}
        </Button>
      </div>
    </div>
  );
}


function buildMarkdownReport(result: MacroResult, projectId: string): string {
  const now = new Date().toISOString().replace("T", " ").slice(0, 19);
  const lines: string[] = [];
  lines.push(`# MITICA macro module — run report`);
  lines.push(``);
  lines.push(`- **Project ID**: \`${projectId}\``);
  lines.push(`- **Generated**: ${now} (browser local time)`);
  lines.push(`- **Region**: ${result.region}`);
  lines.push(`- **Development group (income class)**: ${result.dev_group ?? "(auto from region)"}`);
  lines.push(`- **Horizon**: ${result.horizon_year}`);
  lines.push(`- **Shrinkage λ**: ${result.shrinkage}`);
  lines.push(`- **Flow detected**: ${result.flow_detected}`);
  if (result.phi != null)
    lines.push(`- **Structural attractor φ**: ${result.phi.toFixed(3)}`);
  lines.push(``);
  lines.push(`## Model specification`);
  lines.push(``);
  lines.push(`| Block | Form |`);
  lines.push(`|---|---|`);
  lines.push(`| B0 — PIB per cápita | own-growth reversion (no capital, no TFP) |`);
  lines.push(`| B1 — Population | AR(1) on growth rate; reverts to historical mean (or user-supplied) |`);
  lines.push(`| B2 — Sectoral structure | error-correction toward the income norm (φ attractor) |`);
  lines.push(`| B3 — Primary split | ${result.b3_form} |`);
  lines.push(`| B5 — Sectoral energy | ${result.b5_form} |`);
  lines.push(`| B6 — Residential energy | ${result.b6_form} |`);
  lines.push(``);
  // v4 core equations
  lines.push(`### Core equations (v4)`);
  lines.push(``);
  lines.push("- **PIB per cápita (B0)**: `Δln y_t = (1−ρ)·ḡ + ρ·Δln y_{t−1}` "
    + "(+ `θ·(I/Y dev)` and a demographic-dividend term when supplied); "
    + "`PIB_t = y_t · Pob_t`. No capital, no TFP.");
  lines.push("- **Sectoral structure (B2-EC)**: `η_{j,t} = η_{j,t−1} + "
    + "ρ_η·Δη_{j,t−1} + φ·(η*_j(y,P) − η_{j,t−1})`, with `σ_s = softmax(η)`.");
  lines.push("- **Income norm**: `η*_j = α_j + β_j·ln y + γ_j·(ln y)² + μ_j·ln P` "
    + "(Chenery-Syrquin, calibrated on the WB panel). The attractor φ is "
    + "estimated per country and shrunk to the group prior — weak, so the "
    + "country's own trajectory dominates.");
  lines.push(``);
  // Estimated parameters
  lines.push(`## Parameter log`);
  lines.push(``);
  lines.push(`Provenance: \`estimated\` = country data dominate · \`adjusted\` = Bayesian compromise · \`calibrated\` = prior dominates.`);
  lines.push(``);
  lines.push(`| Name | Value | SE | Origin | Note |`);
  lines.push(`|---|---:|---:|---|---|`);
  for (const p of result.parameter_log) {
    const se = p.std_error != null ? p.std_error.toFixed(3) : "—";
    const note = (p.note ?? "").replace(/\|/g, "/");
    lines.push(
      `| \`${p.name}\` | ${p.value.toFixed(4)} | ${se} | ${p.origin} | ${note} |`,
    );
  }
  lines.push(``);

  // Validation summary
  lines.push(`## Validation summary`);
  lines.push(``);
  const sevCounts = { red: 0, amber: 0, info: 0 };
  result.validation_report.forEach((f) => {
    const k = f.severity as keyof typeof sevCounts;
    if (k in sevCounts) sevCounts[k]++;
  });
  lines.push(`- **Red flags**: ${sevCounts.red}`);
  lines.push(`- **Amber flags**: ${sevCounts.amber}`);
  lines.push(`- **Info flags**: ${sevCounts.info}`);
  lines.push(``);
  if (result.validation_report.length > 0) {
    lines.push(`| Test | Severity | Variable | Message |`);
    lines.push(`|---|---|---|---|`);
    for (const f of result.validation_report) {
      const msg = f.message.replace(/\|/g, "/").replace(/\n/g, " ");
      lines.push(`| ${f.test_id} | ${f.severity} | ${f.variable} | ${msg} |`);
    }
    lines.push(``);
  }

  // Final time series
  lines.push(`## Projected series`);
  lines.push(``);
  // GDP and Population
  lines.push(`### GDP_tot and Population`);
  lines.push(``);
  lines.push(`| Year | GDP_tot | Pop |`);
  lines.push(`|---:|---:|---:|`);
  const popByYear: Record<number, number> = {};
  for (const r of result.population) popByYear[r.Year] = r.Pop;
  for (const r of result.gdp_tot) {
    lines.push(`| ${r.Year} | ${r.GDP_tot.toFixed(2)} | ${(popByYear[r.Year] ?? 0).toFixed(0)} |`);
  }
  lines.push(``);
  // SGDP
  lines.push(`### Sectoral GDP`);
  lines.push(``);
  lines.push(`| Year | Primary | Secondary | Tertiary |`);
  lines.push(`|---:|---:|---:|---:|`);
  for (const r of result.sgdp) {
    lines.push(
      `| ${r.Year} | ${(r.SGDP_primary ?? 0).toFixed(2)} | ${(r.SGDP_secondary ?? 0).toFixed(2)} | ${(r.SGDP_tertiary ?? 0).toFixed(2)} |`,
    );
  }
  lines.push(``);
  // Sectoral energy
  if (result.sed && result.sed.length > 0) {
    lines.push(`### Sectoral energy demand`);
    lines.push(``);
    const keys = Object.keys(result.sed[0]).filter((k) => k !== "Year");
    lines.push(`| Year | ${keys.join(" | ")} |`);
    lines.push(`|---:|${keys.map(() => "---:").join("|")}|`);
    for (const r of result.sed) {
      const vals = keys.map((k) => (r[k] ?? 0).toFixed(2));
      lines.push(`| ${r.Year} | ${vals.join(" | ")} |`);
    }
    lines.push(``);
  }
  lines.push(`---`);
  lines.push(`*Report generated by MITICA macro module v4 — Gauss & UNFCCC Secretariat.*`);
  return lines.join("\n");
}

// Generic blob download helper.
function downloadBlob(content: string, mime: string, filename: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Export the ANNALIST proxies (each series from history through the selected
// horizon year) + the Layer-C/D validation results as a multi-sheet .xlsx, so
// the user can review every projected series and every flag in a spreadsheet.
// Three sheets: Summary (run metadata + flag counts), Proxies (Year × every
// proxy, with a historical/projected marker), Validation (one row per flag with
// its "What to do" action).
function exportProxiesValidationXlsx(result: MacroResult, projectId: string) {
  const proxies = result.annalist_proxies ?? {};
  const names = Object.keys(proxies).sort();
  const lastHist = result.last_historical_year ?? null;

  // Pivot proxies to Year × name.
  const byNameYear: Record<string, Record<number, number>> = {};
  const yearSet = new Set<number>();
  for (const name of names) {
    byNameYear[name] = {};
    for (const row of proxies[name] ?? []) {
      const yr = row["Year"];
      const valKey = Object.keys(row).find((k) => k !== "Year");
      if (yr == null || valKey == null) continue;
      yearSet.add(yr);
      byNameYear[name][yr] = row[valKey];
    }
  }
  const years = [...yearSet].sort((a, b) => a - b);

  const proxyRows = years.map((y) => {
    const row: Record<string, string | number> = {
      Year: y,
      period: lastHist != null ? (y <= lastHist ? "historical" : "projected") : "",
    };
    for (const name of names) {
      const v = byNameYear[name][y];
      if (v != null && Number.isFinite(v)) row[name] = v;
    }
    return row;
  });

  const valRows = result.validation_report.map((f) => ({
    severity: f.severity,
    test_id: f.test_id,
    variable: f.variable,
    message: f.message,
    what_to_do: f.proposed_action ?? "",
  }));

  const sev = (s: string) => result.validation_report.filter((f) => f.severity === s).length;
  const summaryRows = [
    { field: "project", value: projectId },
    { field: "region", value: result.region },
    { field: "development group", value: result.dev_group ?? "" },
    { field: "flow detected", value: result.flow_detected },
    { field: "attractor phi", value: result.phi ?? "" },
    { field: "shrinkage lambda", value: result.shrinkage },
    { field: "last historical year", value: lastHist ?? "" },
    { field: "horizon year", value: result.horizon_year },
    { field: "flags: red (blocking)", value: sev("red") },
    { field: "flags: amber (review)", value: sev("amber") },
    { field: "flags: info", value: sev("info") },
    { field: "exported", value: new Date().toISOString().slice(0, 19).replace("T", " ") },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(summaryRows), "Summary");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(proxyRows), "Proxies");
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(valRows.length ? valRows : [{ severity: "", test_id: "", variable: "", message: "no flags", what_to_do: "" }]),
    "Validation",
  );
  const out = XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
  const blob = new Blob([out], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  a.href = url;
  a.download = `mitica-macro-proxies-validation-${projectId.slice(0, 8)}-${ts}.xlsx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Build a self-contained HTML report. Opens in a new window and uses
// @media print so the user can click "Print → Save as PDF" to obtain a
// print-quality PDF without any extra library.
function buildHtmlReport(result: MacroResult, projectId: string): string {
  const now = new Date().toISOString().replace("T", " ").slice(0, 19);
  // Audit fix: full HTML escape (quotes included) so user-controlled
  // strings (parameter names, notes, validation messages) can't break
  // out of an attribute and inject script.
  const escape = (s: string) =>
    s
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  const fmt = (n: number, d = 2) =>
    isFinite(n) ? n.toLocaleString("en-US", { maximumFractionDigits: d }) : "—";

  const sevCounts = { red: 0, amber: 0, info: 0 };
  result.validation_report.forEach((f) => {
    const k = f.severity as keyof typeof sevCounts;
    if (k in sevCounts) sevCounts[k]++;
  });

  const b2eq: Record<string, string> = {
    log_log:
      "log(SGDP_s) = α_s + β_s · log(SInv_s) + γ_s · log(GFCF_pub_s) + ζ_s · log(Pop) + δ_s · r",
    kuznets_chenery:
      "log(SGDP_s) = … + κ_s · log(GDPpc<sub>t-1</sub>)  (linear Kuznets-Chenery shifter)",
    kuznets_chenery_quad:
      "log(SGDP_s) = … + κ_s · log(GDPpc<sub>t-1</sub>) + κ2_s · log(GDPpc<sub>t-1</sub>)²  (quadratic hump)",
    compositional:
      "η_j = α_j + β_j · log(y) + γ_j · (log y)² + μ_j · log(P) + ν_j · (t − t₀);  σ_s = softmax(η)",
  };

  const popByYear: Record<number, number> = {};
  result.population.forEach((r) => { popByYear[r.Year] = r.Pop; });

  const sgdpRows = result.sgdp
    .map((r) => `
      <tr>
        <td>${r.Year}</td>
        <td class="num">${fmt(r.SGDP_primary)}</td>
        <td class="num">${fmt(r.SGDP_secondary)}</td>
        <td class="num">${fmt(r.SGDP_tertiary)}</td>
      </tr>`)
    .join("");

  const gdpPopRows = result.gdp_tot
    .map((r) => `
      <tr>
        <td>${r.Year}</td>
        <td class="num">${fmt(r.GDP_tot)}</td>
        <td class="num">${fmt(popByYear[r.Year] ?? 0, 0)}</td>
      </tr>`)
    .join("");

  const paramRows = result.parameter_log
    .map((p) => `
      <tr>
        <td><code>${escape(p.name)}</code></td>
        <td class="num">${fmt(p.value, 4)}</td>
        <td class="num">${p.std_error != null ? fmt(p.std_error, 3) : "—"}</td>
        <td><span class="origin origin-${escape(p.origin)}">${escape(p.origin)}</span></td>
        <td class="muted">${escape(p.note ?? "")}</td>
      </tr>`)
    .join("");

  const flagRows = result.validation_report
    .map((f) => `
      <tr class="sev-${escape(f.severity)}">
        <td><code>${escape(f.test_id)}</code></td>
        <td>${escape(f.severity)}</td>
        <td>${escape(f.variable)}</td>
        <td>${escape(f.message)}</td>
      </tr>`)
    .join("");

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>MITICA macro report — ${escape(projectId.slice(0, 8))}</title>
<style>
  @page { size: A4; margin: 14mm 12mm 14mm 12mm; }
  body { font-family: -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
         color: #1a2438; line-height: 1.45; font-size: 12pt; max-width: 880px;
         margin: 0 auto; padding: 1.5em; }
  h1 { font-size: 1.6em; margin: 0 0 0.5em; color: #147A6E; border-bottom: 2px solid #147A6E; padding-bottom: 0.3em; }
  h2 { font-size: 1.25em; margin-top: 1.6em; color: #1A2438; border-bottom: 1px solid #ccc; padding-bottom: 0.2em; }
  h3 { font-size: 1.05em; margin-top: 1.2em; color: #1A2438; }
  table { border-collapse: collapse; width: 100%; margin: 0.5em 0; font-size: 10pt;
          page-break-inside: avoid; }
  th, td { border: 1px solid #d0d0d0; padding: 4px 8px; text-align: left; vertical-align: top; }
  th { background: #f2f2f2; font-weight: 600; }
  td.num { text-align: right; font-variant-numeric: tabular-nums; }
  code { font-family: "SF Mono", Consolas, monospace; font-size: 0.92em; background: #f5f5f5; padding: 1px 4px; border-radius: 3px; }
  .meta { background: #f9f9f9; border-left: 3px solid #147A6E; padding: 0.6em 1em; margin: 1em 0; }
  .meta dt { font-weight: 600; color: #555; display: inline-block; width: 130px; }
  .muted { color: #888; font-size: 0.9em; }
  .origin { padding: 1px 6px; border-radius: 8px; font-size: 0.85em; }
  .origin-estimated  { background: #e2f3ed; color: #147A6E; }
  .origin-adjusted   { background: #fdf5e2; color: #a07c12; }
  .origin-calibrated { background: #eee; color: #555; }
  .sev-red    td:nth-child(2) { color: #b00020; font-weight: 600; }
  .sev-amber  td:nth-child(2) { color: #c87900; font-weight: 600; }
  .sev-info   td:nth-child(2) { color: #555; }
  .print-only { display: none; }
  @media print {
    body { padding: 0; max-width: none; }
    .print-only { display: block; }
    .no-print { display: none; }
    h2 { page-break-after: avoid; }
    table { font-size: 8.5pt; }
  }
  .button-bar { display: flex; gap: 8px; margin: 0 0 1em; }
  .button { padding: 6px 12px; border: 1px solid #147A6E; background: #fff;
            color: #147A6E; border-radius: 4px; cursor: pointer; font-size: 0.9em; }
  .button:hover { background: #147A6E; color: #fff; }
</style>
</head>
<body>
  <div class="no-print button-bar">
    <button class="button" onclick="window.print()">Save as PDF (Ctrl+P)</button>
    <span style="font-size:0.85em;color:#555;align-self:center;">
      Use the browser&apos;s print dialog and choose &quot;Save as PDF&quot;.
    </span>
  </div>

  <h1>MITICA macro module — run report</h1>
  <div class="meta">
    <dl style="margin:0;">
      <dt>Project ID</dt> <dd style="display:inline;"><code>${escape(projectId)}</code></dd><br>
      <dt>Generated</dt>  <dd style="display:inline;">${escape(now)}</dd><br>
      <dt>Region</dt>     <dd style="display:inline;">${escape(result.region)}</dd><br>
      <dt>Income group</dt><dd style="display:inline;">${escape(result.dev_group ?? "(auto)")}</dd><br>
      <dt>Horizon</dt>    <dd style="display:inline;">${result.horizon_year}</dd><br>
      <dt>Shrinkage λ</dt><dd style="display:inline;">${result.shrinkage}</dd><br>
      <dt>Attractor φ</dt><dd style="display:inline;">${result.phi != null ? result.phi.toFixed(3) : "—"}</dd><br>
      <dt>Flow detected</dt><dd style="display:inline;">${escape(result.flow_detected)}</dd>
    </dl>
  </div>

  <h2>Model specification</h2>
  <table>
    <thead><tr><th>Block</th><th>Form</th></tr></thead>
    <tbody>
      <tr><td>B0 — PIB per cápita</td><td>own-growth reversion (no capital, no TFP)</td></tr>
      <tr><td>B1 — Population</td><td>AR(1) on growth rate; reverts to historical mean</td></tr>
      <tr><td>B2 — Sectoral structure</td><td>error-correction toward the income norm (φ attractor)</td></tr>
      <tr><td>B3 — Primary split</td><td><code>${escape(result.b3_form ?? "?")}</code></td></tr>
      <tr><td>B5 — Sectoral energy</td><td><code>${escape(result.b5_form ?? "?")}</code></td></tr>
      <tr><td>B6 — Residential energy</td><td><code>${escape(result.b6_form ?? "?")}</code></td></tr>
    </tbody>
  </table>
  <h3>Core equations (v4)</h3>
  <ul>
    <li><strong>PIB per cápita (B0):</strong> <code>Δln y<sub>t</sub> = (1−ρ)·ḡ + ρ·Δln y<sub>t−1</sub></code>; <code>PIB = y · Pob</code>.</li>
    <li><strong>Structure (B2-EC):</strong> <code>η<sub>j,t</sub> = η<sub>j,t−1</sub> + ρ<sub>η</sub>·Δη<sub>j,t−1</sub> + φ·(η*<sub>j</sub> − η<sub>j,t−1</sub>)</code>, <code>σ<sub>s</sub> = softmax(η)</code>.</li>
    <li><strong>Income norm:</strong> <code>η*<sub>j</sub> = α<sub>j</sub> + β<sub>j</sub>·ln y + γ<sub>j</sub>·(ln y)² + μ<sub>j</sub>·ln P</code> (Chenery-Syrquin).</li>
  </ul>

  <h2>Parameter log</h2>
  <p class="muted">Origin: <code>estimated</code> = country data dominate ·
     <code>adjusted</code> = Bayesian compromise ·
     <code>calibrated</code> = prior dominates.</p>
  <table>
    <thead><tr><th>Name</th><th>Value</th><th>SE</th><th>Origin</th><th>Note</th></tr></thead>
    <tbody>${paramRows}</tbody>
  </table>

  <h2>Validation summary</h2>
  <p>${sevCounts.red} red · ${sevCounts.amber} amber · ${sevCounts.info} info.</p>
  ${result.validation_report.length > 0 ? `
    <table>
      <thead><tr><th>Test</th><th>Sev</th><th>Variable</th><th>Message</th></tr></thead>
      <tbody>${flagRows}</tbody>
    </table>
  ` : `<p class="muted">No flags raised — all checks passed.</p>`}

  <h2>Projected series</h2>
  <h3>GDP and Population</h3>
  <table>
    <thead><tr><th>Year</th><th>GDP_tot</th><th>Pop</th></tr></thead>
    <tbody>${gdpPopRows}</tbody>
  </table>

  <h3>Sectoral GDP</h3>
  <table>
    <thead><tr><th>Year</th><th>Primary</th><th>Secondary</th><th>Tertiary</th></tr></thead>
    <tbody>${sgdpRows}</tbody>
  </table>

  <hr style="margin-top:2em;border:0;border-top:1px solid #ccc;">
  <p class="muted" style="text-align:center;">
    Report generated by MITICA macro module v4 — Gauss &amp; UNFCCC Secretariat.
  </p>
</body>
</html>`;
}

// Audit §5d (UX audit, "Output simplification by default"): collapse
// the methodological detail panels behind a single disclosure so
// newcomers see headline charts only. Power-users (Hiroshi, John)
// expand and get the full diagnostic surface.
function AdvancedOutputs({ result }: { result: MacroResult }) {
  const [open, setOpen] = useState(false);
  const hasDerived = !!(result.derived && result.derived.length > 0);
  const hasEnergy = !!(result.sed && result.sed.length > 0);
  const hasFuelMix = !!(result.fuel_shares && result.fuel_shares.length > 0);
  const hasHeads = !!(result.heads && result.heads.length > 0);
  const sections: string[] = [];
  if (hasDerived) sections.push("Derived (GDP/cap, energy intensity)");
  if (hasEnergy) sections.push("Energy demand");
  if (hasFuelMix) sections.push("Projected fuel mix");
  if (hasHeads) sections.push("Livestock heads");
  sections.push("Full parameter log");

  return (
    <div className="rounded-md border border-border">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="flex w-full items-center justify-between bg-muted/30 px-3 py-2.5 text-left text-sm hover:bg-muted/50"
      >
        <span>
          <span className="font-medium">Advanced outputs</span>
          <span className="ml-2 text-xs text-muted-foreground">
            {sections.join(" · ")}
          </span>
        </span>
        {open ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        )}
      </button>
      {open && (
        <div className="space-y-6 p-3">
          {hasDerived && <DerivedPanel result={result} />}
          {hasEnergy && <EnergyPanel result={result} />}
          {hasFuelMix && <FuelMixPanel result={result} />}
          {hasHeads && <LivestockPanel result={result} />}
          {/* G5+G6+G7: parameter log split into Methodology / Estimated /
              Calibrated fallback with SE footnote + inactive badges. */}
          <ParameterLogPanel result={result} />
        </div>
      )}
    </div>
  );
}


// G5 + G6 + G7 (UX audit Tier-3): structured parameter log.
//
// The flat parameter table doesn't distinguish methodology constants
// (norm coefficients, decision #5 — never change without a code edit)
// from country-data estimates (B1.gbar_Pop) from prior fallbacks (B5.*
// when no historical SED was supplied). Splitting them into three
// sections lets the user audit what their data actually drove vs what
// the methodology imposed.
//
// G6: where SE is missing (null), the panel renders a small footnote
// explaining the convention (intercept absorbs scale — only slopes are
// economically interpretable).
//
// G7: parameters whose B-block doesn't drive the operative projection
// path get an "(inactive)" badge. For Profile E the user supplies the
// full cascade output so B-block estimates are diagnostic only; for
// Profile D + compositional, B2.comp.* params feed the T12 diagnostic
// rather than the projected SGDP path.
type ParamSection = "methodology" | "estimated" | "calibrated_fallback";

function classifyParameter(
  p: MacroResult["parameter_log"][number],
): {
  section: ParamSection;
  inactive: boolean;
  inactive_reason?: string;
} {
  const note = (p.note ?? "").toLowerCase();
  // Methodology constants are fixed by design, not by data (their notes cite
  // a methodology decision). Everything else is estimated/adjusted vs the
  // calibrated-prior fallback. v4 has no profile-conditional inactive params.
  const isMethodology = note.includes("decision #");
  let section: ParamSection;
  if (isMethodology) {
    section = "methodology";
  } else if (p.origin === "estimated" || p.origin === "adjusted") {
    section = "estimated";
  } else {
    section = "calibrated_fallback";
  }
  return { section, inactive: false };
}


function ParameterLogPanel({ result }: { result: MacroResult }) {
  const groups = useMemo(() => {
    const out: Record<
      ParamSection,
      Array<{
        p: MacroResult["parameter_log"][number];
        inactive: boolean;
        reason?: string;
      }>
    > = {
      methodology: [],
      estimated: [],
      calibrated_fallback: [],
    };
    for (const p of result.parameter_log) {
      const { section, inactive, inactive_reason } = classifyParameter(p);
      out[section].push({ p, inactive, reason: inactive_reason });
    }
    return out;
  }, [result]);

  const totalMissingSE = result.parameter_log.filter(
    (p) => p.std_error == null,
  ).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Parameter log</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Origin tags:{" "}
          <code className="font-mono">estimated</code> = country data
          dominated ·{" "}
          <code className="font-mono">adjusted</code> = Bayesian
          compromise ·{" "}
          <code className="font-mono">calibrated</code> = prior dominates
          or methodology-fixed.
        </p>

        <ParameterSubTable
          title="Methodology constants"
          subtitle={
            "Fixed by the v4 design (income-norm coefficients, "
            + "error-correction structure). Not driven by your data; "
            + "changing them requires a code edit."
          }
          rows={groups.methodology}
        />
        <ParameterSubTable
          title="Estimated from your data"
          subtitle={
            "Posterior estimates where your country's history was long "
            + "enough to dominate or balance the regional prior."
          }
          rows={groups.estimated}
        />
        <ParameterSubTable
          title="Calibrated from regional priors"
          subtitle={
            "Defaulted to the regional prior because the corresponding "
            + "historical series was not supplied (or was too short to "
            + "identify). Raise λ toward 0 with country data to move "
            + "these to 'estimated'."
          }
          rows={groups.calibrated_fallback}
        />

        {totalMissingSE > 0 && (
          <p className="text-[11px] text-muted-foreground">
            <strong>About missing SE (—):</strong> intercept-type
            parameters use an uninformative prior, so their standard
            error is intentionally suppressed. They absorb scale; only
            slopes (β, γ, ζ, κ…) are economically interpretable. The
            same convention applies to compositional B2 reference-class
            constants.
          </p>
        )}
      </CardContent>
    </Card>
  );
}


function ParameterSubTable({
  title,
  subtitle,
  rows,
}: {
  title: string;
  subtitle: string;
  rows: Array<{
    p: MacroResult["parameter_log"][number];
    inactive: boolean;
    reason?: string;
  }>;
}) {
  if (rows.length === 0) {
    return (
      <div className="rounded border border-dashed border-border/60 p-3 text-xs text-muted-foreground">
        <span className="font-medium text-foreground/80">{title}</span> —
        none in this run.
      </div>
    );
  }
  return (
    <div>
      <div className="mb-1">
        <p className="text-xs font-medium text-foreground">
          {title}{" "}
          <span className="text-muted-foreground">({rows.length})</span>
        </p>
        <p className="text-[11px] text-muted-foreground">{subtitle}</p>
      </div>
      <div className="max-h-[220px] overflow-y-auto rounded border border-border">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-muted/60">
            <tr className="text-left">
              <th className="px-2 py-1.5 font-medium">Name</th>
              <th className="px-2 py-1.5 text-right font-medium">Value</th>
              <th className="px-2 py-1.5 text-right font-medium">SE</th>
              <th className="px-2 py-1.5 font-medium">Origin</th>
              <th className="px-2 py-1.5 font-medium">Note</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ p, inactive, reason }, i) => (
              <tr
                key={i}
                className={cn(
                  "border-t border-border/50",
                  inactive && "opacity-60",
                )}
              >
                <td className="px-2 py-1 font-mono">
                  {p.name}
                  {inactive && (
                    <span
                      className="ml-1.5 rounded border border-border bg-muted px-1 py-0.5 text-[9px] uppercase text-muted-foreground"
                      title={reason}
                    >
                      inactive
                    </span>
                  )}
                </td>
                <td className="px-2 py-1 text-right font-mono">
                  {p.value.toFixed(4)}
                </td>
                <td
                  className="px-2 py-1 text-right font-mono text-muted-foreground"
                  title={
                    p.std_error == null
                      ? "Intercept absorbs scale — SE suppressed by design"
                      : undefined
                  }
                >
                  {p.std_error != null ? p.std_error.toFixed(3) : "—"}
                </td>
                <td className="px-2 py-1">
                  <OriginBadge origin={p.origin} />
                </td>
                <td className="px-2 py-1 text-muted-foreground">
                  {p.note || ""}
                  {inactive && reason && (
                    <span className="block text-[10px] italic text-foreground/60">
                      {reason}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Derived series: GDP per capita and energy intensity (TED/Y).
function DerivedPanel({ result }: { result: MacroResult }) {
  const d = result.derived;
  // The model's bottom-up WoM TED is present only when the user pinned a
  // projected TED — overlay it on the intensity chart as the benchmark.
  const hasPinnedTed = !!(result.wom_ted && result.wom_ted.length > 0);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Derived series</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 md:grid-cols-2">
          <PlotlyChart
            height={250}
            data={[
              {
                x: d.map((r) => r.Year),
                y: d.map((r) => r.GDP_per_cap),
                type: "scatter", mode: "lines+markers",
                name: "GDP per capita",
                line: { color: "#147A6E", width: 2 },
              },
            ]}
            layout={{ title: { text: "GDP per capita", font: { size: 12 } } }}
          />
          {d.some((r) => r.Energy_intensity > 0) && (
            <PlotlyChart
              height={250}
              data={[
                {
                  x: d.map((r) => r.Year),
                  y: d.map((r) => r.Energy_intensity),
                  type: "scatter", mode: "lines",
                  name: hasPinnedTed ? "Your TED / GDP" : "TED / Y",
                  line: { color: "#b3613d", width: 2 },
                },
                // When the user pinned a projected TED, overlay the model's own
                // bottom-up WoM intensity so the decoupling assumption is visible
                // (U3 quantifies the gap in words).
                ...(hasPinnedTed
                  ? ([{
                      x: result.wom_ted!.map((r) => r.Year),
                      y: result.wom_ted!.map((r) => {
                        const g = d.find((row) => row.Year === r.Year)?.GDP_tot;
                        return g && g > 0 ? r.TED / g : null;
                      }),
                      type: "scatter", mode: "lines",
                      name: "Model bottom-up (WoM)",
                      line: { color: "#9aa0a6", width: 2, dash: "dot" },
                    }] as Data[])
                  : []),
              ]}
              layout={{
                title: {
                  text: hasPinnedTed
                    ? "Energy intensity (TED / GDP) — your path vs model"
                    : "Energy intensity (TED / GDP)",
                  font: { size: 12 },
                },
              }}
            />
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Sectoral energy demand: stacked area per sector.
// G4 (UX audit): visible warning when an output series was extrapolated
// from regional priors because the user did not upload any historical data.
// Same amber styling as the cached-result and validation banners.
function ExtrapolatedBadge({ label }: { label: string }) {
  return (
    <div className="mb-3 flex items-start gap-2 rounded-md border border-amber-600/40 bg-amber-600/10 p-2.5">
      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
      <div className="text-xs">
        <p className="font-medium text-amber-900 dark:text-amber-200">
          {label} extrapolated from regional defaults
        </p>
        <p className="mt-0.5 text-foreground/80">
          You did not upload historical data for this series, so the
          projection comes from the regional prior — not from your
          country's data. Do not publish these numbers without validating
          them against a national source.
        </p>
      </div>
    </div>
  );
}

function EnergyPanel({ result }: { result: MacroResult }) {
  const sed = result.sed;
  const sedExtrapolated = result.extrapolated_series?.sed === true;
  const sedHhExtrapolated = result.extrapolated_series?.sed_hh === true;
  const sectors = [
    { col: "SED_primary",           name: "Primary",            color: "#8a7d5a" },
    { col: "SED_manufacturing",     name: "Manufacturing",      color: "#b3613d" },
    { col: "SED_construction",      name: "Construction",       color: "#c4a163" },
    { col: "SED_services",          name: "Services",           color: "#147A6E" },
    { col: "SED_transport_pass",    name: "Transport (pass.)",  color: "#5b6dcd" },
    { col: "SED_transport_freight", name: "Transport (frght)",  color: "#1A2438" },
  ];
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Sectoral energy demand (SED)</CardTitle>
      </CardHeader>
      <CardContent>
        {sedExtrapolated && <ExtrapolatedBadge label="Sectoral energy demand" />}
        <PlotlyChart
          height={280}
          data={sectors.map((s) => ({
            x: sed.map((r) => r.Year),
            y: sed.map((r) => r[s.col] ?? 0),
            name: s.name,
            type: "scatter",
            stackgroup: "sed",
            line: { color: s.color },
          }))}
          layout={{
            yaxis: { title: "Energy demand (ktoe)" },
          }}
        />
        {result.sed_hh && result.sed_hh.length > 0 && (
          <div className="mt-4">
            {sedHhExtrapolated && (
              <ExtrapolatedBadge label="Residential energy demand" />
            )}
            <PlotlyChart
              height={220}
              data={[
                {
                  x: result.sed_hh.map((r) => r.Year),
                  y: result.sed_hh.map((r) => r.SED_hh),
                  type: "scatter", mode: "lines+markers",
                  name: "Residential",
                  line: { color: "#147A6E", width: 2 },
                },
              ]}
              layout={{
                title: { text: "Residential energy demand", font: { size: 12 } },
                yaxis: { title: "ktoe" },
              }}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// M-03: fuel mix per sector — historical rows as-is + the engine's logistic
// continuation (logit-space trend, renormalised to Σ = 1), with any
// user-pinned future cells honored exactly and the remaining fuels
// renormalised into the residual (§6.6). One sector at a time (7 sectors ×
// 6 fuels is unreadable in a single chart).
const FUEL_MIX_SERIES: { fuel: string; name: string; color: string }[] = [
  { fuel: "electricity",  name: "Electricity",  color: "#147A6E" },
  { fuel: "gas",          name: "Gas",          color: "#5b6dcd" },
  { fuel: "oil_products", name: "Oil products", color: "#b3613d" },
  { fuel: "solids",       name: "Solids",       color: "#1A2438" },
  { fuel: "biomass",      name: "Biomass",      color: "#8a7d5a" },
  { fuel: "heat",         name: "Heat",         color: "#c4a163" },
];

function FuelMixPanel({ result }: { result: MacroResult }) {
  const records = useMemo(
    () =>
      (result.fuel_shares ?? []).filter(
        (r) => r.Share != null && Number.isFinite(r.Share),
      ),
    [result],
  );
  // Sectors actually present in the payload, in the canonical order.
  const sectors = useMemo(() => {
    const present = new Set(records.map((r) => r.Sector));
    const ordered = FUEL_SHARE_SECTORS.filter((s) => present.has(s));
    // Defensive: keep any non-canonical sector names at the end rather
    // than silently dropping their data from the selector.
    for (const s of present) if (!ordered.includes(s)) ordered.push(s);
    return ordered;
  }, [records]);
  const [sector, setSector] = useState<string>(sectors[0] ?? "services");
  const active = sectors.includes(sector) ? sector : (sectors[0] ?? "");
  const extrapolated = result.extrapolated_series?.fuel_shares === true;

  const series = useMemo(() => {
    const sec = records.filter((r) => r.Sector === active);
    const years = Array.from(new Set(sec.map((r) => r.Year))).sort(
      (a, b) => a - b,
    );
    const byKey = new Map<string, number>();
    for (const r of sec) byKey.set(`${r.Year}|${r.Fuel}`, r.Share as number);
    return FUEL_MIX_SERIES.map((f) => ({
      ...f,
      x: years,
      y: years.map((y) => (byKey.get(`${y}|${f.fuel}`) ?? 0) * 100),
    }));
  }, [records, active]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Projected fuel mix</CardTitle>
        <p className="text-xs text-muted-foreground">
          Each fuel&apos;s share of the sector&apos;s energy demand. Beyond
          your last historical year, shares continue their recent trend as a
          logistic transition (bounded in 0–100%, saturating instead of
          crossing the bounds) and are renormalised to sum to 100%. Any
          future-year pins you provided are honored exactly, with the
          remaining fuels renormalised into the residual.
        </p>
      </CardHeader>
      <CardContent>
        {extrapolated && <ExtrapolatedBadge label="Fuel mix" />}
        <div className="mb-2 flex items-center gap-2">
          <Label htmlFor="fuelmix-sector" className="text-xs">
            Sector
          </Label>
          <select
            id="fuelmix-sector"
            value={active}
            onChange={(e) => setSector(e.target.value)}
            className="h-8 rounded-md border border-input bg-background px-2 text-xs"
          >
            {sectors.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
        <PlotlyChart
          height={280}
          data={series.map(
            (s) =>
              ({
                x: s.x,
                y: s.y,
                name: s.name,
                type: "scatter",
                stackgroup: "fuelmix",
                line: { color: s.color },
              }) as Data,
          )}
          layout={{ yaxis: { ticksuffix: "%", title: "Share of demand" } }}
        />
      </CardContent>
    </Card>
  );
}

// Livestock heads + crop/livestock value-added split.
function LivestockPanel({ result }: { result: MacroResult }) {
  const headsExtrapolated = result.extrapolated_series?.heads === true;
  const heads = result.heads.filter((r) => (r.Heads ?? 0) > 0);
  // No historical heads supplied → engine returns NaN-only series. Show a
  // placeholder card with the G4 warning instead of silently omitting the
  // panel, so the user knows livestock activity was not produced.
  if (headsExtrapolated) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Livestock heads (IPCC 3)</CardTitle>
        </CardHeader>
        <CardContent>
          <ExtrapolatedBadge label="Livestock heads" />
          <p className="text-xs text-foreground/70">
            Livestock activity was not projected because you did not upload
            historical heads data. To project IPCC 3 activity, supply a
            ‘heads’ series under optional historical inputs.
          </p>
        </CardContent>
      </Card>
    );
  }
  if (heads.length === 0) return null;
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Livestock heads (IPCC 3)</CardTitle>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={240}
          data={[
            {
              x: heads.map((r) => r.Year),
              y: heads.map((r) => r.Heads),
              type: "scatter", mode: "lines+markers",
              name: "Heads",
              line: { color: "#b3613d", width: 2 },
            },
          ]}
          layout={{ yaxis: { title: "heads" } }}
        />
      </CardContent>
    </Card>
  );
}

// Statistical validation summary. Replaces the flat flag list with:
//  - aggregate counts by severity
//  - per-test-family breakdown (T1-T12 vs Layer D1.x-D4.x)
//  - collapsible detail per group
function ValidationPanel({
  report,
}: {
  report: MacroResult["validation_report"];
}) {
  const stats = useMemo(() => {
    const out = {
      total: report.length,
      red: 0, amber: 0, info: 0,
      layerC: { red: 0, amber: 0, info: 0, items: [] as typeof report },
      layerD: { red: 0, amber: 0, info: 0, items: [] as typeof report },
      byTest: {} as Record<string, { count: number; severity: string }>,
    };
    for (const f of report) {
      const sev = f.severity as "red" | "amber" | "info";
      if (sev === "red") out.red++;
      else if (sev === "amber") out.amber++;
      else if (sev === "info") out.info++;
      const layer = /^D\d/.test(f.test_id) ? out.layerD : out.layerC;
      if (sev === "red") layer.red++;
      else if (sev === "amber") layer.amber++;
      else if (sev === "info") layer.info++;
      layer.items.push(f);
      const e = out.byTest[f.test_id] || { count: 0, severity: sev };
      e.count++;
      // Worst severity wins for the test id
      if (sev === "red" || (sev === "amber" && e.severity === "info")) {
        e.severity = sev;
      }
      out.byTest[f.test_id] = e;
    }
    return out;
  }, [report]);

  const [showC, setShowC] = useState(stats.red + stats.amber > 0);
  const [showD, setShowD] = useState(stats.layerD.red + stats.layerD.amber > 0);
  const blockingCount = useMemo(
    () => report.filter(
      (f) => f.severity === "red" && isBlockingTest(f.test_id),
    ).length,
    [report],
  );

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">Validation details</CardTitle>
        <div className="flex gap-2 text-xs">
          {blockingCount > 0 && (
            <span
              className="flex items-center gap-1 rounded-full border border-destructive bg-destructive/15 px-2 py-0.5 font-medium text-destructive"
              title="Layer A identity or numerical-impossibility failure — the projection cannot run honestly until the input data is fixed."
            >
              <Lock className="h-3 w-3" />
              {blockingCount} blocking
            </span>
          )}
          <span className="rounded-full border border-destructive/40 bg-destructive/10 px-2 py-0.5 text-destructive">
            {stats.red} red
          </span>
          <span className="rounded-full border border-amber-600/40 bg-amber-600/10 px-2 py-0.5 text-amber-700">
            {stats.amber} amber
          </span>
          <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
            {stats.info} info
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Severity legend — explains the policy so the user knows which
            reds they have to fix vs which ambers are judgment calls. */}
        <div className="rounded-md border border-border bg-muted/30 p-2.5 text-[11px] text-muted-foreground">
          <p>
            <Lock className="mr-1 inline h-3 w-3 text-destructive" />
            <strong className="text-foreground">Blocking (red)</strong> —
            Layer A T1 identities, D2.1 positivity, D2.2 share bounds. Data
            integrity violations; the projection cannot run honestly until
            the input is fixed.
          </p>
          <p className="mt-1">
            <AlertCircle className="mr-1 inline h-3 w-3 text-amber-600" />
            <strong className="text-foreground">Judgment (amber)</strong> —
            departures from typical patterns. The engine continues and
            produces all proxies; you decide whether the deviation matches
            your intent.
          </p>
        </div>

        {/* Summary grid */}
        <div className="grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
          <div className="rounded border border-border p-2.5">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Layer C (inputs T1-T12)
            </div>
            <div className="mt-1 font-mono text-base">
              {stats.layerC.red}R · {stats.layerC.amber}A · {stats.layerC.info}I
            </div>
          </div>
          <div className="rounded border border-border p-2.5">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Layer D (coherence)
            </div>
            <div className="mt-1 font-mono text-base">
              {stats.layerD.red}R · {stats.layerD.amber}A · {stats.layerD.info}I
            </div>
          </div>
          <div className="rounded border border-border p-2.5">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Unique tests fired
            </div>
            <div className="mt-1 font-mono text-base">
              {Object.keys(stats.byTest).length}
            </div>
          </div>
          <div className="rounded border border-border p-2.5">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Total flags
            </div>
            <div className="mt-1 font-mono text-base">{stats.total}</div>
          </div>
        </div>

        {/* Per-test counts */}
        {Object.keys(stats.byTest).length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {Object.entries(stats.byTest)
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([tid, e]) => (
                <span
                  key={tid}
                  className={cn(
                    "rounded border px-2 py-0.5 font-mono text-[11px]",
                    e.severity === "red"
                      ? "border-destructive/40 bg-destructive/10 text-destructive"
                      : e.severity === "amber"
                      ? "border-amber-600/40 bg-amber-600/10 text-amber-700"
                      : "border-border bg-muted text-muted-foreground",
                  )}
                  title={`${tid}: ${e.count} flag(s), worst severity = ${e.severity}`}
                >
                  {tid}
                  {e.count > 1 ? ` ×${e.count}` : ""}
                </span>
              ))}
          </div>
        )}

        {stats.total === 0 && (
          <p className="text-sm text-muted-foreground">
            No flags raised — all checks passed.
          </p>
        )}

        {/* Layer C details */}
        {stats.layerC.items.length > 0 && (
          <ValidationGroup
            title={`Layer C — input plausibility (T1-T12)  ·  ${stats.layerC.items.length} items`}
            items={stats.layerC.items}
            open={showC}
            onToggle={() => setShowC(!showC)}
          />
        )}
        {/* Layer D details */}
        {stats.layerD.items.length > 0 && (
          <ValidationGroup
            title={`Layer D — projection coherence (D1.x-D4.x)  ·  ${stats.layerD.items.length} items`}
            items={stats.layerD.items}
            open={showD}
            onToggle={() => setShowD(!showD)}
          />
        )}
      </CardContent>
    </Card>
  );
}

function ValidationGroup({
  title,
  items,
  open,
  onToggle,
}: {
  title: string;
  items: MacroResult["validation_report"];
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="rounded border border-border">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="flex w-full items-center justify-between bg-muted/40 px-3 py-2 text-left text-sm hover:bg-muted/60"
      >
        <span className="font-medium">{title}</span>
        {open ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        )}
      </button>
      {open && (
        <ul className="divide-y divide-border text-sm">
          {items.map((f, i) => {
            const blocking = f.severity === "red" && isBlockingTest(f.test_id);
            return (
              <li
                key={i}
                className={cn(
                  "flex items-start gap-3 px-3 py-2.5",
                  blocking &&
                    "border-l-4 border-l-destructive bg-destructive/[0.04]",
                )}
              >
                <SeverityIcon
                  severity={f.severity as "red" | "amber" | "info"}
                  blocking={blocking}
                />
                <div className="flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="font-mono text-xs text-muted-foreground">
                      {f.test_id}
                    </span>
                    <span className="text-sm font-medium">{f.variable}</span>
                    {blocking && (
                      <span
                        className="rounded border border-destructive/40 bg-destructive/10 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-destructive"
                        title="Layer A identity violation or numerical impossibility — the projection cannot run honestly until this is fixed in the input data."
                      >
                        Blocks projection
                      </span>
                    )}
                  </div>
                  <p className="whitespace-pre-line text-xs text-muted-foreground">
                    {f.message}
                  </p>
                  {/* G10 / G12 (UX audit): distinct "What to do" line so the
                      user is told the action, not just the diagnostic. */}
                  {f.proposed_action && (
                    <p className="mt-1.5 text-xs text-foreground/90">
                      <span className="font-medium text-foreground">
                        What to do:{" "}
                      </span>
                      {f.proposed_action}
                    </p>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function OriginBadge({ origin }: { origin: string }) {
  if (origin === "estimated")
    return (
      <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-medium text-emerald-800">
        estimated
      </span>
    );
  if (origin === "adjusted")
    return (
      <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-medium text-blue-800">
        adjusted
      </span>
    );
  return (
    <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-800">
      calibrated
    </span>
  );
}

function SeverityIcon({
  severity,
  blocking = false,
}: {
  severity: "red" | "amber" | "info";
  blocking?: boolean;
}) {
  // Audit fix: icon-only severity is colour-only signalling.
  // Wrap with an sr-only label so screen readers + colourblind users
  // can still tell red / amber / info / blocking apart. Decorative
  // icons get aria-hidden so they aren't announced twice.
  const label = blocking
    ? "Blocking red flag"
    : severity === "red"
      ? "Red flag"
      : severity === "amber"
        ? "Amber flag"
        : "Info flag";
  const iconEl =
    severity === "red"
      ? blocking
        ? <Lock className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden />
        : <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden />
      : severity === "amber"
        ? <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" aria-hidden />
        : <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />;
  return (
    <span role="img" aria-label={label} className="contents">
      {iconEl}
    </span>
  );
}
