"""
v4 macro STRUCTURE backtest on the World Bank panel.

For each eligible country, hold out the last PROJ_H years (target 2020-2024
where available), train the v4 engine on ALL prior history, and contrast the
projected sectoral structure (σ_primary/σ_secondary/σ_tertiary) with the
actual outturn. Two modes per country:

  * **F2 (pure structure)** — actual GDP_tot AND population are supplied over
    the horizon, so the ONLY thing the engine projects is the sectoral shares
    (B2-EC + the income norm + the fitted φ). This isolates the structure
    engine from GDP/population error → the cleanest measure of how the priors
    behave.
  * **F3 (full projection)** — GDP via B0 own-growth (actual population
    supplied to isolate B1); the realistic end-to-end test.

Per-country records (written to results/v4_structure_backtest.csv):
  identity, income group, region, history window, n_train, n_proj;
  fitted φ + n_ec (how much own-data vs the prior drove the attractor);
  F2: per-sector mean-abs share deviation (pp) over the window, final-year
      deviation (pp), and structural-TREND capture (sign agreement of the
      projected vs actual change in each share over the window);
  F3: GDP MAPE over the window.

Prints a full per-country table + group/EU aggregates. China excluded (per JL).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))

from mitica_core.modules.macro import (  # noqa: E402
    HistoricalData, MacroConfig, ProjectedInputs, run_macro_module,
)

DATA = Path(__file__).resolve().parent / "wdi_data"
OUT = Path(__file__).resolve().parent / "results" / "v4_structure_backtest.csv"

INCOME_MAP = {"LIC": "L", "LMC": "LM", "UMC": "UM", "HIC": "H"}
PROJ_H = int(sys.argv[1]) if len(sys.argv) > 1 else 5  # project the last H years
MIN_TRAIN = 12
VALID_REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")
EU27 = {
    "AUT", "BEL", "BGR", "HRV", "CYP", "CZE", "DNK", "EST", "FIN", "FRA",
    "DEU", "GRC", "HUN", "IRL", "ITA", "LVA", "LTU", "LUX", "MLT", "NLD",
    "POL", "PRT", "ROU", "SVK", "SVN", "ESP", "SWE",
}
SECT = ["SGDP_primary", "SGDP_secondary", "SGDP_tertiary"]


def _load(short: str) -> pd.DataFrame:
    return pd.read_csv(DATA / f"{short}.csv").rename(columns={"value": short})[
        ["iso3", "Year", short]]


def build_panel() -> pd.DataFrame:
    f = _load("GDP_tot")
    for s in ("Pop", "SGDP_primary", "SGDP_secondary", "SGDP_tertiary"):
        f = f.merge(_load(s), on=["iso3", "Year"], how="inner")
    c = pd.read_csv(DATA / "countries.csv")[
        ["iso3", "name", "wb_income", "mitica_region"]]
    f = f.merge(c, on="iso3", how="inner")
    for col in ("GDP_tot", "Pop", *SECT):
        f = f[f[col].notna() & (f[col] > 0)]
    f = f[f["mitica_region"].isin(VALID_REGIONS) & f["wb_income"].isin(INCOME_MAP)]
    return f.sort_values(["iso3", "Year"]).reset_index(drop=True)


def _shares_at(df_year_row) -> dict:
    tot = sum(df_year_row[s] for s in SECT)
    return {s: df_year_row[s] / tot for s in SECT}


def run_country(sub: pd.DataFrame) -> dict | None:
    yrs = sub["Year"].astype(int).tolist()
    t_end = max(yrs)
    t_split = t_end - PROJ_H
    proj_years = [y for y in range(t_split + 1, t_end + 1) if y in yrs]
    if len(proj_years) < PROJ_H:
        return None
    train = sub[sub["Year"] <= t_split]
    if len(train) < MIN_TRAIN:
        return None

    iso = sub["iso3"].iloc[0]
    grp = INCOME_MAP[sub["wb_income"].iloc[0]]
    region = sub["mitica_region"].iloc[0]
    hist = HistoricalData(
        gdp_tot=train[["Year", "GDP_tot"]].reset_index(drop=True),
        population=train[["Year", "Pop"]].reset_index(drop=True),
        sgdp=train[["Year", *SECT]].reset_index(drop=True),
    )
    fut = sub[(sub["Year"] > t_split) & (sub["Year"] <= t_end)]
    pop_fut = fut[["Year", "Pop"]].reset_index(drop=True)
    gdp_fut = fut[["Year", "GDP_tot"]].reset_index(drop=True)

    base = dict(region=region, dev_group=grp, horizon_year=t_end,
                validate_historical=False)
    rec: dict = {
        "iso3": iso, "name": sub["name"].iloc[0], "income": sub["wb_income"].iloc[0],
        "group": grp, "region": region, "is_eu": iso in EU27,
        "first_year": int(min(yrs)), "t_split": t_split, "t_end": t_end,
        "n_train": len(train), "n_proj": len(proj_years),
    }

    actual = sub.set_index("Year")
    a_sh_last_train = _shares_at(actual.loc[t_split])
    a_sh_end = _shares_at(actual.loc[t_end])

    # ---- F2: pure structure (pin GDP + population) ----
    try:
        out2 = run_macro_module(
            hist, ProjectedInputs(gdp_tot=gdp_fut, population=pop_fut),
            MacroConfig(**base))
    except Exception as e:  # pragma: no cover
        return {**rec, "error": str(e)[:80]}
    p2 = out2.sgdp.set_index("Year")
    phi = next((pp.value for pp in out2.parameter_log if pp.name == "B2EC.phi"), np.nan)
    n_ec = next((int(pp.note.split("n_ec=")[1].rstrip(")"))
                 for pp in out2.parameter_log if pp.name == "B2EC.phi"
                 and "n_ec=" in (pp.note or "")), -1)
    rec["phi_fit"] = float(phi)
    rec["n_ec"] = n_ec

    mae = {s: [] for s in SECT}
    for y in proj_years:
        a = _shares_at(actual.loc[y])
        pr = _shares_at(p2.loc[y])
        for s in SECT:
            mae[s].append(abs(pr[s] - a[s]))
    for s in SECT:
        rec[f"mae_pp_{s.split('_')[1]}"] = 100.0 * float(np.mean(mae[s]))
    p_sh_end = _shares_at(p2.loc[t_end])
    for s in SECT:
        rec[f"devfin_pp_{s.split('_')[1]}"] = 100.0 * abs(p_sh_end[s] - a_sh_end[s])

    # Structural-trend capture: did the model get the DIRECTION of change right?
    for s in SECT:
        a_chg = a_sh_end[s] - a_sh_last_train[s]
        p_chg = p_sh_end[s] - a_sh_last_train[s]
        # "captured" if same sign, or both essentially flat (<0.3pp)
        flat = abs(a_chg) < 0.003
        rec[f"trend_ok_{s.split('_')[1]}"] = bool(flat or (np.sign(a_chg) == np.sign(p_chg)))
        rec[f"a_chg_pp_{s.split('_')[1]}"] = 100.0 * a_chg
        rec[f"p_chg_pp_{s.split('_')[1]}"] = 100.0 * p_chg

    # actual + projected shares at horizon (for the report)
    for s in SECT:
        nm = s.split('_')[1]
        rec[f"a_sh_{nm}"] = 100.0 * a_sh_end[s]
        rec[f"p_sh_{nm}"] = 100.0 * p_sh_end[s]

    # ---- F3: full projection (GDP via B0) ----
    try:
        out3 = run_macro_module(hist, ProjectedInputs(population=pop_fut),
                                MacroConfig(**base))
        a_gdp = sub.set_index("Year")["GDP_tot"]
        p_gdp = out3.gdp_tot.set_index("Year")["GDP_tot"]
        rec["mape_gdp_f3"] = float(np.mean(
            [abs(a_gdp[y] - p_gdp[y]) / abs(a_gdp[y]) for y in proj_years]))
    except Exception:
        rec["mape_gdp_f3"] = np.nan

    return rec


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    panel = build_panel()
    rows, errs = [], []
    for _iso, sub in panel.groupby("iso3"):
        r = run_country(sub)
        if r is None:
            continue
        (errs if "error" in r else rows).append(r)
    df = pd.DataFrame(rows)
    df.to_csv(OUT, index=False)

    proj_lbl = f"last {PROJ_H}y"
    print(f"=== v4 STRUCTURE backtest (project {proj_lbl}, train all prior, "
          f"WB panel) ===")
    print(f"Scored {len(df)} countries; {len(errs)} errored.\n")

    # ---- aggregate helper ----
    def agg(d, label):
        if len(d) == 0:
            print(f"  {label:<26} (n=0)"); return
        print(f"  {label:<26} n={len(d):<3}  "
              f"σP MAE={d['mae_pp_primary'].median():4.1f}pp  "
              f"σS MAE={d['mae_pp_secondary'].median():4.1f}pp  "
              f"σT MAE={d['mae_pp_tertiary'].median():4.1f}pp  "
              f"trendS={d['trend_ok_secondary'].mean():3.0%}  "
              f"GDP MAPE(F3)={d['mape_gdp_f3'].median():4.1%}  "
              f"phi~{d['phi_fit'].median():.3f}")

    print("STRUCTURE accuracy — median absolute share deviation (pp), "
          "secondary-trend hit-rate, F3 GDP MAPE, median fitted phi:\n")
    agg(df[df["is_eu"]], "EU-27")
    for g in ("H", "UM", "LM", "L"):
        agg(df[(~df["is_eu"]) & (df["group"] == g)], f"{g} (non-EU)")
    agg(df, "ALL")

    print(f"\nWrote per-country results to {OUT.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
