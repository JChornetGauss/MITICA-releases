"""
crt_lulucf_reader.py
====================

Thin compatibility shim. The format-agnostic CRT/CRF table readers have been
promoted into the product at
``mitica_core.modules.lulucf.g_LULUCF_CRTReader`` (single source of truth).
This module re-exports them so the existing validation-harness scripts
(``fetch_parse_btr.py``, ``analyze_btr_cache.py``, etc.) keep working
unchanged via ``import crt_lulucf_reader as rdr``.

See ``packages/core/src/mitica_core/modules/lulucf/g_LULUCF_CRTReader.py``.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make the core package importable when this script is run standalone
# (the harness already inserts it, but keep the shim self-sufficient).
_CORE_SRC = Path(__file__).resolve().parents[2] / "packages" / "core" / "src"
if str(_CORE_SRC) not in sys.path:
    sys.path.insert(0, str(_CORE_SRC))

from mitica_core.modules.lulucf.g_LULUCF_CRTReader import (  # noqa: E402
    GWP_AR4,
    co2eq,
    read_table4,
    read_table41_land,
    read_table10_lulucf_series,
)

__all__ = [
    "GWP_AR4",
    "co2eq",
    "read_table4",
    "read_table41_land",
    "read_table10_lulucf_series",
]


if __name__ == "__main__":
    # Delegate the self-test to the module implementation.
    from mitica_core.modules.lulucf import g_LULUCF_CRTReader as _mod

    _mod.__name__ = "__main__"  # not strictly needed; the module's __main__
    # block already runs the China/Canada smoke test when executed directly.
    print("Run `python -m mitica_core.modules.lulucf.g_LULUCF_CRTReader` "
          "for the China/Canada smoke test.")
