"""One-shot bulk download of Eurostat Final Energy Consumption per sector
for all EU-27 countries (dataset ``nrg_bal_c``).

Mirrors ``bulk_download.py`` (GDP / Population / SInv / iRate) but for the
energy side. After running once, the SED backtest reads only the local
CSVs under ``scripts/macro_validation/data/<CC>_sed.csv``.

Mapping (Eurostat balance code -> MITICA energy sector):
  FC_OTH_AF_E     -> primary           (agriculture + forestry)
  FC_IND_E        -> manufacturing     (full industry; manuf+construction lumped
                                        because Eurostat does not separate
                                        construction from industry in nrg_bal_c)
  FC_OTH_CP_E     -> services          (commercial + public services)
  FC_TRA_E        -> transport         (road+rail+air+water lumped; we split
                                        into passenger / freight downstream
                                        using a country-invariant 0.7 / 0.3
                                        rule when validating the B5 module —
                                        same convention as v1.1s)
  FC_OTH_HH_E     -> households        (B6 residential, includes appliances
                                        + space heating + cooking)

Units: ktoe (CLV15 is energy, not currency).
"""

from __future__ import annotations

import warnings
from pathlib import Path

import pandas as pd

import eurostat

warnings.filterwarnings("ignore", category=FutureWarning)

EU27 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR",
    "DE", "EL", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL",
    "PL", "PT", "RO", "SK", "SI", "ES", "SE",
]
EXTRA = ["UK", "NO", "CH"]
ALL_COUNTRIES = EU27 + EXTRA

YEAR_MIN = 1990
YEAR_MAX = 2024

# Eurostat balance code -> our naming
BAL_TO_SECTOR = {
    "FC_OTH_AF_E":  "primary",
    "FC_IND_E":     "manufacturing",   # Eurostat does not separate construction
    "FC_OTH_CP_E":  "services",
    "FC_TRA_E":     "transport",       # passenger+freight lumped
    "FC_OTH_HH_E":  "households",
}

OUT_DIR = Path("scripts/macro_validation/data")


def _to_long(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    df = df.rename(columns={"geo\\TIME_PERIOD": "geo"})
    year_cols = [c for c in df.columns if str(c).isdigit()]
    if not year_cols:
        year_cols = [c for c in df.columns if isinstance(c, str) and c[1:].isdigit()]
    id_cols = [c for c in df.columns if c not in year_cols]
    long = df.melt(id_vars=id_cols, value_vars=year_cols,
                   var_name="year", value_name="value")
    long["year"] = long["year"].astype(str).str.lstrip("A").astype(int)
    long = long.dropna(subset=["value"])
    long = long[(long["year"] >= YEAR_MIN) & (long["year"] <= YEAR_MAX)]
    return long


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"=== Bulk SED download (nrg_bal_c) for {len(ALL_COUNTRIES)} countries "
          f"({YEAR_MIN}-{YEAR_MAX}) ===\n")

    # ONE fetch per balance code, all countries at once. Units = ktoe, energy
    # carrier = total (all fuels).
    sector_long: dict[str, pd.DataFrame] = {}
    # nrg_bal_c rejects CH; remove it from the fetch (we still write empty
    # stubs for it so downstream "discover_countries" stays consistent).
    fetch_countries = [c for c in ALL_COUNTRIES if c != "CH"]
    for code, sector_name in BAL_TO_SECTOR.items():
        print(f"  [api] nrg_bal_c  bal={code}  ({sector_name})", flush=True)
        try:
            raw = eurostat.get_data_df(
                "nrg_bal_c",
                filter_pars={
                    "geo": fetch_countries,
                    "unit": ["KTOE"],
                    "siec": ["TOTAL"],
                    "nrg_bal": [code],
                },
            )
        except Exception as e:
            print(f"        FAILED: {e}", flush=True)
            sector_long[sector_name] = pd.DataFrame()
            continue
        long = _to_long(raw)
        print(f"        -> {len(long):,} rows", flush=True)
        sector_long[sector_name] = long

    # Per-country pivot and save
    print("\n=== Splitting and saving per-country SED CSVs ===")
    n_full = 0
    n_partial = 0
    for cc in ALL_COUNTRIES:
        rows = pd.DataFrame()
        for sector_name, long in sector_long.items():
            if long.empty:
                continue
            sub = long[long["geo"] == cc][["year", "value"]]
            if sub.empty:
                continue
            sub = sub.rename(columns={"year": "Year", "value": f"SED_{sector_name}"})
            sub = sub.set_index("Year")
            if rows.empty:
                rows = sub
            else:
                rows = rows.join(sub, how="outer")
        if rows.empty:
            pd.DataFrame().to_csv(OUT_DIR / f"{cc}_sed.csv", index=False)
            print(f"  {cc:<3}  EMPTY")
            continue
        rows = rows.reset_index().sort_values("Year")
        n_sectors = sum(1 for c in rows.columns if c.startswith("SED_"))
        if n_sectors >= 4:
            n_full += 1
            status = "FULL"
        else:
            n_partial += 1
            status = f"PARTIAL ({n_sectors}/5 sectors)"
        rows.to_csv(OUT_DIR / f"{cc}_sed.csv", index=False)
        print(f"  {cc:<3}  {status}  years {int(rows['Year'].min())}"
              f"-{int(rows['Year'].max())}")

    print(f"\nWrote CSVs to {OUT_DIR}/")
    print(f"  Full: {n_full}  partial: {n_partial}  "
          f"missing: {len(ALL_COUNTRIES) - n_full - n_partial}")


if __name__ == "__main__":
    main()
