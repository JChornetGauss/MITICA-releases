"""Ensamblador del informe técnico en español.

Salida: docs/MITICA_MACRO_INFORME_TECNICO_ES.pdf
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.resolve()))

from report_common import (DOCS_DIR, load_all_data, make_doc_template,
                           make_styles)
from report_es_part1 import content_part1
from report_es_part2 import content_part2
from report_es_part3 import content_part3


def main() -> None:
    out_path = DOCS_DIR / "MITICA_MACRO_INFORME_TECNICO_ES.pdf"
    data = load_all_data()
    S = make_styles()

    story = []
    story += content_part1(S, data)
    story += content_part2(S, data)
    story += content_part3(S, data)

    doc = make_doc_template(
        out_path,
        title="MITICA - Modulo Macro - Informe Tecnico v2.0",
        author="Gauss",
        header_left="MITICA - Modulo Macro - Informe Tecnico v2.0",
        header_right="Gauss / CMNUCC",
    )
    doc.build(story)
    print(f"Wrote {out_path.resolve()}")


if __name__ == "__main__":
    main()
