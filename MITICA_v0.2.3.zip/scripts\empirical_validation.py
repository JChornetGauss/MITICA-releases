"""Run MITICA macro module on REAL WDI data for 4 countries and print a
diagnostic report on the plausibility of the projections.

Not a unit test — a hand-runnable empirical validation tool. Use:

    python scripts/empirical_validation.py

Fetches live from api.worldbank.org. Compares projection CAGRs against
historical CAGRs, sectoral patterns against Chenery-Syrquin expectation,
and flag counts against the Layer C/D test suite.
"""

from __future__ import annotations

import sys
import time

import numpy as np
import pandas as pd

from mitica_api.wdi import _fetch_one
from mitica_core.modules.macro import run_macro_module_from_dicts

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]

# --------------------------------------------------------------------------
# Country setups: ISO-3, MITICA region, last historical year, horizon.
# We use NY.GDP.MKTP.KD (GDP constant 2015 USD) as the level. Sectoral
# value added at constant 2015 USD: NV.AGR/IND/SRV.TOTL.KD.ZG won't work
# (those are growth rates); use the .KD level series instead.
# --------------------------------------------------------------------------

COUNTRIES = [
    # (label, ISO-3, MITICA region, start, last historical, horizon, profile)
    ("Spain",     "ESP", "HIC",       2000, 2023, 2030, "B"),
    ("Argentina", "ARG", "HIC_TRANS", 2000, 2023, 2030, "B"),
    ("Vietnam",   "VNM", "APAC",      2000, 2023, 2030, "B"),
    ("Kenya",     "KEN", "SSA",       2000, 2023, 2030, "B"),
]

# WDI series we need
SERIES = {
    "gdp":        "NY.GDP.MKTP.KD",        # GDP, constant 2015 USD
    "pop":        "SP.POP.TOTL",
    "agr":        "NV.AGR.TOTL.KD",        # Agriculture value added, constant 2015 USD
    "ind":        "NV.IND.TOTL.KD",        # Industry value added, constant 2015 USD
    "srv":        "NV.SRV.TOTL.KD",        # Services value added, constant 2015 USD
}


def fetch_country(iso3: str, year_min: int, year_max: int) -> dict[str, pd.Series]:
    """Pull all five WDI series for one country."""
    out = {}
    for key, code in SERIES.items():
        out[key] = pd.Series(_fetch_one(iso3, code, year_min, year_max),
                             name=key).sort_index()
    return out


def build_inputs(raw: dict[str, pd.Series], last_hist: int) -> dict[str, pd.DataFrame]:
    """Pivot WDI series into MITICA's HistoricalData dict shape.

    Filters to years where all five series are present (and positive),
    truncates at last_hist.
    """
    years_set = set(raw["gdp"].index)
    for k in ("pop", "agr", "ind", "srv"):
        years_set &= set(raw[k].index)
    years = sorted(y for y in years_set if y <= last_hist)
    if len(years) < 12:
        raise RuntimeError(f"Only {len(years)} years of complete WDI data")

    rows_gdp, rows_pop, rows_sgdp = [], [], []
    for y in years:
        gdp = raw["gdp"].get(y)
        pop = raw["pop"].get(y)
        ag = raw["agr"].get(y)
        ind = raw["ind"].get(y)
        srv = raw["srv"].get(y)
        if any(v is None or v <= 0 for v in (gdp, pop, ag, ind, srv)):
            continue
        # Renormalise sectoral so the three sum to GDP_tot (drop the
        # taxes-on-products wedge so Layer A doesn't fire amber).
        total = ag + ind + srv
        scale = gdp / total
        rows_gdp.append({"Year": y, "GDP_tot": float(gdp)})
        rows_pop.append({"Year": y, "Pop": float(pop)})
        rows_sgdp.append({
            "Year": y,
            "SGDP_primary":   float(ag * scale),
            "SGDP_secondary": float(ind * scale),
            "SGDP_tertiary":  float(srv * scale),
        })
    return {
        "gdp_tot":    pd.DataFrame(rows_gdp),
        "population": pd.DataFrame(rows_pop),
        "sgdp":       pd.DataFrame(rows_sgdp),
    }


def build_projection(hist: dict[str, pd.DataFrame], horizon: int, gdp_target_rate: float
                     ) -> dict[str, pd.DataFrame]:
    """User-supplied projection paths for Profile B.

    We give the model a GDP target consistent with the last 10 years'
    CAGR (so we test what the model does with a 'business-as-usual'
    user input), plus a UN-WPP-like flat population path.
    """
    last_hist = int(hist["gdp_tot"]["Year"].max())
    gdp_lh = float(hist["gdp_tot"].set_index("Year").at[last_hist, "GDP_tot"])
    pop_lh = float(hist["population"].set_index("Year").at[last_hist, "Pop"])
    pop_g = float(
        (hist["population"]["Pop"].iloc[-1] / hist["population"]["Pop"].iloc[-11])
        ** (1 / 10) - 1
    )
    years_proj = list(range(last_hist + 1, horizon + 1))
    rows_gdp = [{"Year": y, "GDP_tot": gdp_lh * (1 + gdp_target_rate) ** (y - last_hist)}
                for y in years_proj]
    rows_pop = [{"Year": y, "Pop": pop_lh * (1 + pop_g) ** (y - last_hist)}
                for y in years_proj]
    return {
        "gdp_tot":    pd.DataFrame(rows_gdp),
        "population": pd.DataFrame(rows_pop),
    }


def cagr(s: pd.Series, n_years: int) -> float:
    if len(s) <= n_years:
        return float("nan")
    return (s.iloc[-1] / s.iloc[-1 - n_years]) ** (1 / n_years) - 1


def proj_cagr(df: pd.DataFrame, col: str, last_hist: int, horizon: int) -> float:
    s = df.set_index("Year")[col]
    n = horizon - last_hist
    return (s.at[horizon] / s.at[last_hist]) ** (1 / n) - 1


def diagnostic(label: str, iso3: str, region: str, profile: str,
               hist: dict[str, pd.DataFrame], last_hist: int, horizon: int,
               target_rate: float) -> dict:
    """Run MITICA + extract numeric diagnostics."""
    proj_dict = build_projection(hist, horizon, target_rate)
    t0 = time.time()
    r = run_macro_module_from_dicts(
        hist, proj_dict, region=region, horizon_year=horizon, profile=profile,
    )
    elapsed = time.time() - t0

    hist_gdp = hist["gdp_tot"].set_index("Year")["GDP_tot"]
    hist_pop = hist["population"].set_index("Year")["Pop"]
    hist_sgdp = hist["sgdp"].set_index("Year")

    pg = pd.DataFrame(r["gdp_tot"])
    pp = pd.DataFrame(r["population"])
    ps = pd.DataFrame(r["sgdp"])

    # Historical 10y CAGRs (last 10 years up to last_hist)
    h_gdp_cagr = cagr(hist_gdp, 10)
    h_pop_cagr = cagr(hist_pop, 10)
    h_p_cagr = cagr(hist_sgdp["SGDP_primary"], 10)
    h_s_cagr = cagr(hist_sgdp["SGDP_secondary"], 10)
    h_t_cagr = cagr(hist_sgdp["SGDP_tertiary"], 10)

    # Projection CAGRs (last_hist → horizon)
    p_gdp_cagr = proj_cagr(pg, "GDP_tot", last_hist, horizon)
    p_pop_cagr = proj_cagr(pp, "Pop", last_hist, horizon)
    p_p_cagr = proj_cagr(ps, "SGDP_primary", last_hist, horizon)
    p_s_cagr = proj_cagr(ps, "SGDP_secondary", last_hist, horizon)
    p_t_cagr = proj_cagr(ps, "SGDP_tertiary", last_hist, horizon)

    # Boundary jump
    boundary_jump = (pg.set_index("Year").at[last_hist + 1, "GDP_tot"]
                     / pg.set_index("Year").at[last_hist, "GDP_tot"]) - 1

    # Sectoral shares at last_hist vs horizon
    hist_total = hist_sgdp.iloc[-1].sum()
    last_shares = (hist_sgdp.iloc[-1] / hist_total).to_dict()
    horizon_row = ps.set_index("Year").loc[horizon]
    horizon_total = horizon_row.sum()
    horizon_shares = (horizon_row / horizon_total).to_dict()

    # Flag breakdown
    flags = r["validation_report"]
    by_sev = {"red": 0, "amber": 0, "info": 0}
    by_test: dict[str, int] = {}
    for f in flags:
        by_sev[f["severity"]] += 1
        by_test[f["test_id"]] = by_test.get(f["test_id"], 0) + 1

    print(f"\n{'='*78}")
    print(f"  {label} ({iso3})  ·  region={region}  ·  profile={profile}  ·  {elapsed*1000:.0f} ms")
    print(f"  History 10y from {last_hist-10} to {last_hist}  →  projection to {horizon}")
    print("=" * 78)

    print(f"\nGDP_tot {last_hist}:  ${hist_gdp.iat[-1]/1e9:>10,.1f} B  (constant 2015 USD)")
    print(f"User target {horizon}: ${pg.set_index('Year').at[horizon,'GDP_tot']/1e9:>10,.1f} B  "
          f"(target CAGR {target_rate*100:+.2f}%/yr)")

    print(f"\n{'':18s}  {'GDP':>9s}  {'Pop':>9s}  {'Primary':>9s}  {'Secondary':>9s}  {'Tertiary':>9s}")
    print(f"  Historical CAGR    {h_gdp_cagr*100:+9.2f}%  {h_pop_cagr*100:+9.2f}%  "
          f"{h_p_cagr*100:+9.2f}%  {h_s_cagr*100:+9.2f}%  {h_t_cagr*100:+9.2f}%")
    print(f"  Projected CAGR     {p_gdp_cagr*100:+9.2f}%  {p_pop_cagr*100:+9.2f}%  "
          f"{p_p_cagr*100:+9.2f}%  {p_s_cagr*100:+9.2f}%  {p_t_cagr*100:+9.2f}%")
    print(f"  Δ (proj − hist)    {(p_gdp_cagr-h_gdp_cagr)*100:+9.2f}pp {(p_pop_cagr-h_pop_cagr)*100:+9.2f}pp "
          f"{(p_p_cagr-h_p_cagr)*100:+9.2f}pp {(p_s_cagr-h_s_cagr)*100:+9.2f}pp "
          f"{(p_t_cagr-h_t_cagr)*100:+9.2f}pp")

    print(f"\n  Boundary jump GDP {last_hist}→{last_hist+1}: {boundary_jump*100:+.2f}%  "
          f"(D1.1 threshold: 10% amber, 20% red)")
    print(f"  Last hist shares:  P {last_shares['SGDP_primary']:5.1%}  "
          f"S {last_shares['SGDP_secondary']:5.1%}  T {last_shares['SGDP_tertiary']:5.1%}")
    print(f"  Horizon shares:    P {horizon_shares['SGDP_primary']:5.1%}  "
          f"S {horizon_shares['SGDP_secondary']:5.1%}  T {horizon_shares['SGDP_tertiary']:5.1%}")

    print(f"\n  Flags: {by_sev['red']} red · {by_sev['amber']} amber · {by_sev['info']} info")
    if by_test:
        items = ", ".join(f"{tid}×{n}" for tid, n in sorted(by_test.items()))
        print(f"  Tests fired: {items}")
    for f in flags:
        msg = f["message"].split("\n\nTechnical:")[0]
        if len(msg) > 200:
            msg = msg[:200] + "…"
        print(f"    [{f['severity']:5s}] {f['test_id']:5s} {f['variable']:24s} {msg}")

    return {
        "label": label,
        "h_gdp_cagr": h_gdp_cagr, "p_gdp_cagr": p_gdp_cagr,
        "h_p_cagr":   h_p_cagr,   "p_p_cagr":   p_p_cagr,
        "h_s_cagr":   h_s_cagr,   "p_s_cagr":   p_s_cagr,
        "h_t_cagr":   h_t_cagr,   "p_t_cagr":   p_t_cagr,
        "boundary_jump": boundary_jump,
        "by_sev": by_sev,
        "by_test": by_test,
    }


def main() -> int:
    """Returns an exit code:
      0 — all countries ran OK and produced zero red flags (baseline
          state at 2026-05-24).
      1 — at least one country fired a red flag (regression: a Layer A
          identity violation or numerical impossibility on a country
          that was clean before).
      2 — at least one country was unreachable (transient WDI / network
          failure; nothing to assert about the engine).
    """
    print("Empirical validation — MITICA macro module on real WDI data\n")
    summary = []
    n_unreachable = 0
    for label, iso, region, start, last_hist, horizon, profile in COUNTRIES:
        try:
            raw = fetch_country(iso, start, last_hist)
        except Exception as e:
            print(f"\n[SKIP] {label} ({iso}): {e}")
            n_unreachable += 1
            continue
        try:
            hist = build_inputs(raw, last_hist)
        except Exception as e:
            print(f"\n[SKIP] {label} ({iso}): {e}")
            n_unreachable += 1
            continue
        # Target rate = country's own last-10y CAGR (BAU run)
        last_hist_y = int(hist["gdp_tot"]["Year"].max())
        target_rate = cagr(hist["gdp_tot"].set_index("Year")["GDP_tot"], 10)
        summary.append(diagnostic(label, iso, region, profile,
                                   hist, last_hist_y, horizon, target_rate))

    # Final summary line
    print(f"\n{'='*78}\nSUMMARY\n{'='*78}")
    print(f"{'Country':12s}  {'Hist g_Y':>9s}  {'Proj g_Y':>9s}  {'Δ':>6s}   "
          f"{'Red':>3s} {'Amb':>3s}   Top flags")
    n_red_total = 0
    for s in summary:
        top = sorted(s["by_test"].items(), key=lambda x: -x[1])[:3]
        top_str = ", ".join(f"{t}×{n}" for t, n in top)
        print(f"{s['label']:12s}  {s['h_gdp_cagr']*100:+8.2f}%  {s['p_gdp_cagr']*100:+8.2f}%  "
              f"{(s['p_gdp_cagr']-s['h_gdp_cagr'])*100:+5.1f}pp   "
              f"{s['by_sev']['red']:>3d} {s['by_sev']['amber']:>3d}   {top_str}")
        n_red_total += s["by_sev"]["red"]

    # CI-friendly verdict.
    print(f"\n{'='*78}")
    if n_unreachable > 0:
        print(f"VERDICT: {n_unreachable} country/ies unreachable — "
              "transient WDI/network failure. Re-run.")
        return 2
    if n_red_total > 0:
        print(f"VERDICT: REGRESSION — {n_red_total} red flag(s) across "
              "the reference countries. The baseline at 2026-05-24 had 0.")
        return 1
    print(f"VERDICT: OK — {len(summary)} countries, 0 red flags. "
          "Baseline preserved.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
