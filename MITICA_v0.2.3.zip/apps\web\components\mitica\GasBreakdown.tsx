"use client";

import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import type { CategoryForecast } from "@/lib/types";

const GAS_COLORS: Record<string, string> = {
  CO2: "#3b82f6",
  CH4: "#ef4444",
  N2O: "#f59e0b",
  HFCs: "#8b5cf6",
  PFCs: "#ec4899",
  SF6: "#10b981",
  NF3: "#0891b2",
};

const GAS_LABEL: Record<string, string> = {
  CO2: "CO₂",
  CH4: "CH₄",
  N2O: "N₂O",
  HFCs: "HFCs",
  PFCs: "PFCs",
  SF6: "SF₆",
  NF3: "NF₃",
};

export function GasBreakdown({ category }: { category: CategoryForecast }) {
  const gases = useMemo(() => Object.keys(category.by_gas ?? {}), [category]);

  // Skip rendering if no per-gas data
  if (gases.length === 0) return null;

  // Check constraint violation on the fly
  const sumByYear = category.years.map((_, i) =>
    gases.reduce((acc, g) => acc + (category.by_gas[g][i] ?? 0), 0)
  );
  const maxAbsDiff = category.years.reduce((m, _, i) => {
    const target = category.forecast[i];
    if (target == null) return m;
    return Math.max(m, Math.abs(sumByYear[i] - target));
  }, 0);
  const hasConstraint = gases.length > 1;
  const constraintOk = maxAbsDiff < 1;

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">Per-gas decomposition</CardTitle>
            <CardDescription>
              Stacked projections in kt CO₂-eq.
              {hasConstraint && (
                <>
                  {" "}
                  Each year, Σ gases is constrained to equal the CO₂-eq total.
                </>
              )}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {gases.length === 1 ? (
              <Badge variant="outline">Single-gas shortcut</Badge>
            ) : (
              <Badge variant={constraintOk ? "success" : "warning"}>
                {constraintOk ? "Σ = CO₂-eq ✓" : `Σ off by ${maxAbsDiff.toFixed(1)} kt`}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <PlotlyChart
          height={320}
          data={gases.map((g) => ({
            x: category.years,
            y: category.by_gas[g],
            type: "scatter",
            mode: "lines",
            stackgroup: gases.length > 1 ? "one" : undefined,
            name: GAS_LABEL[g] ?? g,
            line: { color: GAS_COLORS[g] ?? "#888", width: 1.5 },
            fillcolor: GAS_COLORS[g] ?? "#888",
          }))}
          layout={{
            yaxis: { title: { text: "kt CO₂-eq" } },
            xaxis: { title: { text: "Year" } },
          }}
        />
      </CardContent>
    </Card>
  );
}
