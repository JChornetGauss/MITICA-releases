@echo off
rem MITICA Next — Windows launcher. Opens two child terminals.
rem
rem Important: when start "title" cmd /k "..." has a quoted command that itself
rem contains quoted paths (like the .venv python.exe), cmd.exe chokes on the
rem nested quotes. Workaround: wrap the child command in `call` and use a
rem helper script so no nested double-quotes appear.

setlocal
set ROOT=%~dp0..
pushd "%ROOT%"

rem ---------- Pick Python interpreter ----------
if exist ".venv\Scripts\python.exe" (
    set "PY=%CD%\.venv\Scripts\python.exe"
    echo [MITICA Next] using project venv
) else (
    set "PY=python"
    echo [MITICA Next] WARNING: no .venv found. Using system/conda python.
    echo                Run scripts\setup.cmd first for an isolated install.
)

rem ---------- Sanity check ----------
"%PY%" -c "from mitica_api.main import app" 2>nul
if errorlevel 1 (
    echo.
    echo [MITICA Next] ERROR: mitica_api is not importable from %PY%.
    echo                Run:  scripts\setup.cmd
    echo.
    popd
    endlocal
    exit /b 1
)

rem ---------- Launch ----------
echo [MITICA Next] starting API on http://127.0.0.1:8000
start "MITICA API" cmd /k call "%~dp0_run_api.cmd"

timeout /t 2 /nobreak >nul

echo [MITICA Next] starting Web on http://localhost:3000
start "MITICA Web" cmd /k call "%~dp0_run_web.cmd"

rem Open the browser once the web is up (fire-and-forget background waiter)
start "" /min cmd /c call "%~dp0open_browser.cmd"

echo.
echo [MITICA Next] Both processes launched in separate windows.
echo   - API:  http://127.0.0.1:8000/api/v1/docs
echo   - Web:  http://localhost:3000
echo.
echo Close the two child windows (or run scripts\stop.cmd) to stop.
popd
endlocal
