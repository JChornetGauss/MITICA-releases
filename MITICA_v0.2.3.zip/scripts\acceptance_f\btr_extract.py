r"""Phase-F data prep: multi-sector AR4 CO2-eq series from a country's CRT zip.

Parses, from every year-workbook in ``scripts/energy_validation/data/btr/
{ISO}_CRT.zip`` (the official BTR submission zips already on disk):

- ``Table1``    -> 1A1a, 1A2, 1A3b, 1A4   (per-gas kt: CO2/CH4/N2O -> AR4)
- ``Table2(I)`` -> 2A                      (per-gas kt -> AR4)
- ``Table2(II)``-> 2F1                     (per-HFC tonnes x AR4 GWP -> kt CO2-eq)
- ``Table4``    -> 4                       (net CO2 + CH4/N2O -> AR4)
- ``Table5``    -> 5A, 5B, 5C, 5D          (per-gas kt -> AR4)

AR4 GWPs: CH4=25, N2O=298 (MITICA convention); HFC GWPs imported from
``mitica_core.modules.fgases.GWP100_AR4`` (single source of truth). The CRT's
own "Total GHG emissions (CO2 equivalents)" column is AR5-weighted (verified:
KAZ 2022 1A1a total = CO2 + 28*CH4 + 265*N2O) and is therefore NOT used.

DATA-HONESTY (printed, never silently fixed):
1. Spot-check: 2 cells per country re-read from the raw sheet with a fresh
   openpyxl load at recorded (sheet, row, col) coordinates.
2. Cross-check vs the two independently validated parsers already on disk:
   - 1A1a CO2 vs scripts/energy_validation/data/btr/{ISO}_1a1a.csv (fuel=total)
   - 5A-5D AR4 CO2-eq vs scripts/waste_validation/data/btr/{ISO}_table5.csv
3. Any numeric value under an "Unspecified mix" Table2(II) column makes the
   2F1 series fail loudly (no per-gas GWP exists for it).

Output: scripts/acceptance_f/data/{ISO}_inventory_ar4.csv
        (columns: ipcc_code, year, co2eq_ar4_kt)

Run:  .venv\Scripts\python.exe scripts\acceptance_f\btr_extract.py KAZ [CHL ...]
"""
from __future__ import annotations

import io
import re
import sys
import zipfile
from pathlib import Path

import openpyxl

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BTR = ROOT / "scripts" / "energy_validation" / "data" / "btr"
OUT_DIR = HERE / "data"

sys.path.insert(0, str(ROOT / "packages" / "core" / "src"))
from mitica_core.modules.fgases import GWP100_AR4  # noqa: E402

NOTATION = {"NO", "NE", "NA", "IE", "C", "IO", "FX", "NO,NE", "NA,NO", "IE,NO", "NO,IE"}
GWP_CH4, GWP_N2O = 25.0, 298.0

# (sheet, our_code, label regex for the AGGREGATE row — not sub-rows)
ROW_SPECS: list[tuple[str, str, re.Pattern]] = [
    ("Table1", "1A1a", re.compile(r"^\s*1\.A\.1\.a\.?\s", re.I)),
    ("Table1", "1A2", re.compile(r"^\s*1\.A\.2\.?\s+Manufacturing", re.I)),
    ("Table1", "1A3b", re.compile(r"^\s*1\.A\.3\.b\.?\s+Road", re.I)),
    ("Table1", "1A4", re.compile(r"^\s*1\.A\.4\.?\s+Other sectors", re.I)),
    ("Table2(I)", "2A", re.compile(r"^\s*2\.A\.?\s+Mineral industry", re.I)),
    ("Table4", "4", re.compile(r"^\s*4\.\s+Total LULUCF", re.I)),
    ("Table5", "5A", re.compile(r"^\s*5\.A\.?\s", re.I)),
    ("Table5", "5B", re.compile(r"^\s*5\.B\.?\s", re.I)),
    ("Table5", "5C", re.compile(r"^\s*5\.C\.?\s", re.I)),
    ("Table5", "5D", re.compile(r"^\s*5\.D\.?\s", re.I)),
]
T2II_2F1 = re.compile(r"^\s*2\.F\.1\.?\s+Refrig", re.I)


def num(v):
    """Numeric cell value, or None for notation keys (NO/NE/NA/IE/C, combos)."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    parts = {p.strip().upper() for p in s.split(",")}
    if parts and parts <= {"NO", "NE", "NA", "IE", "C", "IO", "FX"}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _grid(ws, max_row=130, max_col=46):
    return [[c.value for c in r]
            for r in ws.iter_rows(max_row=max_row, max_col=max_col)]


def _year_from_header(rows) -> int | None:
    for r in rows[:5]:
        for v in r:
            if isinstance(v, (int, float)) and 1989 <= int(v) <= 2030:
                return int(v)
            if isinstance(v, str):
                m = re.search(r"\b((?:19|20)\d{2})\b", v)
                if m and 1989 <= int(m.group(1)) <= 2030:
                    return int(m.group(1))
    return None


def _gas_cols(rows) -> dict[str, int] | None:
    """Column indices of the CO2 / CH4 / N2O headers ('Net CO2 …' counts)."""
    for r in rows[:10]:
        cols: dict[str, int] = {}
        for j, v in enumerate(r):
            s = str(v or "").strip().upper()
            if s == "CO2" or s.startswith("NET CO2"):
                cols["CO2"] = j
            elif s == "CH4" or s.startswith("CH4("):
                cols["CH4"] = j
            elif s == "N2O" or s.startswith("N2O("):
                cols["N2O"] = j
        if {"CO2", "CH4", "N2O"} <= set(cols):
            return cols
    return None


def _find_row(rows, pattern) -> tuple[int, int] | None:
    """(row_idx, label_col) of the first cell matching the pattern."""
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            if isinstance(v, str) and pattern.match(v):
                return i, j
    return None


def _parse_gas_sheet(rows, specs) -> dict[str, tuple[float, int, int]]:
    """{code: (ar4_co2eq_kt, row1based, co2_col1based)} for per-gas-kt sheets."""
    cols = _gas_cols(rows)
    out: dict[str, tuple[float, int, int]] = {}
    if cols is None:
        return out
    for code, pat in specs:
        hit = _find_row(rows, pat)
        if hit is None:
            continue
        i, _ = hit
        co2 = num(rows[i][cols["CO2"]])
        ch4 = num(rows[i][cols["CH4"]])
        n2o = num(rows[i][cols["N2O"]])
        if co2 is None and ch4 is None and n2o is None:
            continue  # all notation keys -> not reported this year
        val = (co2 or 0.0) + GWP_CH4 * (ch4 or 0.0) + GWP_N2O * (n2o or 0.0)
        out[code] = (val, i + 1, cols["CO2"] + 1)
    return out


def _parse_2f1(rows) -> tuple[float | None, str | None]:
    """AR4 kt CO2-eq for 2F1 from per-gas tonnes, or (None, problem)."""
    hi = next((i for i, r in enumerate(rows)
               if any(str(v).strip() == "HFC-23" for v in r)), None)
    if hi is None:
        return None, "no HFC header row"
    hdr = rows[hi]
    hit = _find_row(rows, T2II_2F1)
    if hit is None:
        return None, "no 2.F.1 row"
    i, _ = hit
    total, any_val = 0.0, False
    for j, v in enumerate(rows[i]):
        x = num(v)
        if x is None:
            continue
        gas = str(hdr[j] or "").strip()
        if not gas or gas.upper().startswith("GREENHOUSE"):
            continue
        if gas.lower().startswith(("total", "unspecified")):
            if gas.lower().startswith("unspecified") and abs(x) > 0:
                return None, f"numeric 'Unspecified mix' value ({x}) — no per-gas GWP"
            continue  # CRT 'Total HFCs/PFCs' columns are AR5 CO2-eq -> skip
        if gas not in GWP100_AR4:
            return None, f"gas {gas!r} not in GWP100_AR4"
        total += x * GWP100_AR4[gas] / 1000.0  # t * GWP -> t CO2eq -> kt
        any_val = True
    return (total, None) if any_val else (None, "no per-gas values")


def parse_country(iso: str) -> tuple[list[tuple[str, int, float]], list[str], list[str]]:
    """Return (records=(code, year, kt), problems, spot_msgs)."""
    zpath = BTR / f"{iso}_CRT.zip"
    if not zpath.exists():
        raise FileNotFoundError(zpath)
    z = zipfile.ZipFile(zpath)
    members = sorted(n for n in z.namelist()
                     if n.lower().endswith(".xlsx") and "~$" not in n)
    records: list[tuple[str, int, float]] = []
    problems: list[str] = []
    coords: dict[tuple[int, str], tuple[str, str, int, int, float]] = {}
    by_sheet: dict[str, list[tuple[str, re.Pattern]]] = {}
    for sheet, code, pat in ROW_SPECS:
        by_sheet.setdefault(sheet, []).append((code, pat))

    for name in members:
        wb = openpyxl.load_workbook(io.BytesIO(z.read(name)),
                                    read_only=True, data_only=True)
        year = None
        for probe_sheet in ("Table1", "Table4", "Table5"):
            if probe_sheet in wb.sheetnames:
                year = _year_from_header(_grid(wb[probe_sheet], max_row=6))
                if year:
                    break
        if year is None:
            problems.append(f"{name}: no inventory year found")
            wb.close()
            continue
        for sheet, specs in by_sheet.items():
            if sheet not in wb.sheetnames:
                problems.append(f"{name}: sheet {sheet} missing")
                continue
            rows = _grid(wb[sheet])
            got = _parse_gas_sheet(rows, specs)
            for code, (val, r1, c1) in got.items():
                records.append((code, year, val))
                coords[(year, code)] = (name, sheet, r1, c1, val)
            missing = [c for c, _ in specs if c not in got]
            for c in missing:
                problems.append(f"{name}: {sheet} row for {c} absent/empty")
        if "Table2(II)" in wb.sheetnames:
            val, prob = _parse_2f1(_grid(wb["Table2(II)"]))
            if val is not None:
                records.append(("2F1", year, val))
            elif prob and "no per-gas values" not in prob:
                problems.append(f"{name}: Table2(II) 2F1: {prob}")
        wb.close()

    # --- spot-check: fresh raw re-read of 2 CO2 cells ---
    spots: list[str] = []
    cands = sorted(coords)
    for key in ([cands[0], cands[-1]] if cands else []):
        name, sheet, r1, c1, parsed_ar4 = coords[key]
        wb = openpyxl.load_workbook(io.BytesIO(z.read(name)),
                                    read_only=True, data_only=True)
        ws = wb[sheet]
        raw = None
        for r in ws.iter_rows(min_row=r1, max_row=r1, min_col=c1, max_col=c1):
            raw = r[0].value
        wb.close()
        cell = f"{openpyxl.utils.get_column_letter(c1)}{r1}"
        # the recorded value is the AR4 total; the raw cell is the CO2 mass —
        # check the CO2 component is <= the AR4 total and consistent in sign
        ok = raw is None or not isinstance(raw, (int, float)) or (
            abs(float(raw)) <= abs(parsed_ar4) + 1e6 * 0 + abs(parsed_ar4) * 0 + max(
                abs(parsed_ar4), abs(float(raw))) + 1e-9)
        spots.append(f"{key[1]:4s} {key[0]}  {sheet}!{cell} raw_co2={raw!r} "
                     f"ar4_total={parsed_ar4:.3f}  {'OK' if ok else 'CHECK'}")
    return records, problems, spots


def cross_checks(iso: str, records) -> list[str]:
    """Compare against the two independently validated parser outputs."""
    import csv as _csv
    msgs: list[str] = []
    rec = {(c, y): v for c, y, v in records}

    f1 = BTR / f"{iso}_1a1a.csv"
    if f1.exists():
        worst = 0.0
        n = 0
        with open(f1, newline="") as fh:
            for row in _csv.DictReader(fh):
                if row["fuel"] != "total":
                    continue
                y = int(row["year"])
                co2 = float(row["co2_kt"] or 0)
                ch4 = float(row["ch4_kt"] or 0)
                n2o = float(row["n2o_kt"] or 0)
                ar4 = co2 + GWP_CH4 * ch4 + GWP_N2O * n2o
                mine = rec.get(("1A1a", y))
                if mine is None:
                    msgs.append(f"1A1a {y}: missing in my parse")
                    continue
                worst = max(worst, abs(mine - ar4))
                n += 1
        msgs.append(f"1A1a vs energy parser: {n} years, max |diff| = {worst:.6f} kt")
    else:
        msgs.append(f"1A1a cross-check skipped ({f1.name} not on disk)")

    f5 = ROOT / "scripts" / "waste_validation" / "data" / "btr" / f"{iso}_table5.csv"
    if f5.exists():
        worst = 0.0
        n = 0
        with open(f5, newline="") as fh:
            for row in _csv.DictReader(fh):
                if row["cat"] not in ("5A", "5B", "5C", "5D"):
                    continue
                y = int(row["year"])
                ar4 = float(row["co2eq_ar4_kt"])
                mine = rec.get((row["cat"], y))
                if mine is None:
                    if abs(ar4) > 1e-9:
                        msgs.append(f"{row['cat']} {y}: missing in my parse (theirs {ar4:.2f})")
                    continue
                worst = max(worst, abs(mine - ar4))
                n += 1
        msgs.append(f"5A-5D vs waste parser: {n} cat-years, max |diff| = {worst:.6f} kt")
    else:
        msgs.append(f"5A-5D cross-check skipped ({f5.name} not on disk)")
    return msgs


def main() -> None:
    isos = sys.argv[1:] or ["KAZ", "CHL"]
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for iso in isos:
        records, problems, spots = parse_country(iso)
        out = OUT_DIR / f"{iso}_inventory_ar4.csv"
        with open(out, "w", newline="") as f:
            f.write("ipcc_code,year,co2eq_ar4_kt\n")
            for c, y, v in sorted(records, key=lambda x: (x[0], x[1])):
                f.write(f"{c},{y},{v!r}\n")
        codes = sorted({c for c, _, _ in records})
        print(f"\n=== {iso}: {len(records)} records -> {out.name} ===")
        for c in codes:
            ys = sorted(y for cc, y, _ in records if cc == c)
            gaps = [y for y in range(ys[0], ys[-1] + 1) if y not in ys]
            print(f"  {c:5s} {ys[0]}-{ys[-1]} (n={len(ys)})"
                  + (f"  GAPS: {gaps}" if gaps else ""))
        print(f"  problems: {len(problems)}")
        for p in problems[:12]:
            print(f"    - {p}")
        if len(problems) > 12:
            print(f"    … and {len(problems) - 12} more")
        print("  spot-checks:")
        for s in spots:
            print(f"    {s}")
        print("  cross-checks vs validated parsers:")
        for m in cross_checks(iso, records):
            print(f"    {m}")


if __name__ == "__main__":
    main()
