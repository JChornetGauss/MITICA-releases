@echo off
rem MITICA Next — wipe caches that can cause stale-chunk errors.
rem Re-run when you see Next.js "Cannot find module './NNN.js'" or similar.

setlocal
set ROOT=%~dp0..
pushd "%ROOT%"

echo [MITICA clean] removing apps\web\.next ...
if exist "apps\web\.next" rmdir /s /q "apps\web\.next"

echo [MITICA clean] removing Python bytecode caches ...
for /d /r "packages" %%D in (__pycache__) do @if exist "%%D" rmdir /s /q "%%D" 2>nul
if exist ".ruff_cache" rmdir /s /q ".ruff_cache"
if exist ".mypy_cache" rmdir /s /q ".mypy_cache"
if exist ".pytest_cache" rmdir /s /q ".pytest_cache"

echo [MITICA clean] done.
popd
endlocal
