"""
analyze_all_btr.py
==================

Scan every downloaded BTR1 / CRF submission under _btr_crt/<ISO>/, read the
LULUCF Table 4 of each available year, and build:
  (1) a DATA-AVAILABILITY matrix (the casuistry): year coverage, per-category
      vs sector-total-only, which categories, 4H presence, which gases;
  (2) a MODEL run (WoM vs reported) for every country MITICA's refDB can give a
      land area for.

Reads straight from the submission Excel files via crt_lulucf_reader (validated
exact against the reported Total LULUCF). No download here — run dl_btr.sh first.

Output: MITICA_LULUCF_ALL_BTR1_casuistry.xlsx in the MITICA_project root, plus a
cached _btr_series.json of the parsed per-country series.
"""

from __future__ import annotations

import glob
import json
import os
import re
import sys
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

_HERE = Path(__file__).resolve()
_REPO_ROOT = _HERE.parents[2]
_PROJECT_ROOT = _REPO_ROOT.parent
_CORE_SRC = _REPO_ROOT / "packages" / "core" / "src"
_SCRIPTS = _HERE.parent
for p in (str(_CORE_SRC), str(_SCRIPTS)):
    if p not in sys.path:
        sys.path.insert(0, p)

import crt_lulucf_reader as rdr  # noqa: E402
import v1_country_backtest as bt  # noqa: E402
from mitica_core.modules.lulucf import (  # noqa: E402
    HistoricalLULUCF, LULUCFConfig, ProjectedLULUCF, run_lulucf_module,
)

_BTRCRT = _SCRIPTS / "_btr_crt"
CATS_STD = ["4A", "4B", "4C", "4D", "4E", "4F", "4G"]
OUT = _PROJECT_ROOT / "MITICA_LULUCF_ALL_BTR1_casuistry.xlsx"
CACHE = _SCRIPTS / "_btr_series.json"


def _p(s: str = "") -> None:
    sys.stdout.buffer.write((s + "\n").encode("ascii", "replace"))


def _year_from_name(fname: str) -> int | None:
    yrs = [int(y) for y in re.findall(r"(?<!\d)(19[89]\d|20[0-2]\d)(?!\d)", fname)
           if 1989 <= int(y) <= 2023]
    # CRT filenames embed the inventory year; if several, the smallest is usually it
    return min(yrs) if yrs else None


def parse_country(iso_dir: Path) -> dict:
    """Return {year: {cat: co2eq, '_total': reported_total_co2eq, '_gases': set}}."""
    series: dict[int, dict] = {}
    files = sorted(glob.glob(str(iso_dir / "**" / "*.xlsx"), recursive=True))
    for f in files:
        try:
            r = rdr.read_table4(f)
        except Exception:
            continue
        if not r:
            continue
        year = r["year"] or _year_from_name(os.path.basename(f))
        if year is None:
            continue
        cats = {c: rdr.co2eq(g) for c, g in r["categories"].items()}
        gases = set()
        for g in r["categories"].values():
            for gas, v in g.items():
                if abs(v) > 1e-6:
                    gases.add(gas)
        rec = {c: cats.get(c, 0.0) for c in cats}
        rec["_total"] = rdr.co2eq(r["reported_total"]) if r["reported_total"] else None
        rec["_gases"] = sorted(gases)
        # keep the richer record if a year repeats
        if year not in series or len(rec) > len(series[year]):
            series[year] = rec
    return series


def availability(iso: str, series: dict) -> dict:
    years = sorted(series)
    if not years:
        return {"ISO": iso, "note": "no Table4 parsed"}
    last = years[-1]
    cats_present, gases_all, has_4h = set(), set(), False
    for y in years:
        for k, v in series[y].items():
            if k.startswith("_"):
                continue
            if abs(v) > 1:
                cats_present.add(k)
            if k == "4H":
                has_4h = True
        gases_all.update(series[y].get("_gases", []))
    only_total = (len(cats_present) == 0)
    net_last = sum(v for k, v in series[last].items() if not k.startswith("_"))
    rep_last = series[last].get("_total")
    return {
        "ISO": iso,
        "Years": f"{years[0]}-{last}",
        "N yrs": len(years),
        "Contiguous": "Y" if len(years) == last - years[0] + 1 else "N",
        "Per-category?": "TOTAL-ONLY" if only_total else "yes",
        "Cats reported": ",".join(sorted(cats_present)),
        "4H?": "Y" if has_4h else "",
        "Gases": ",".join(sorted(gases_all)),
        "Net last (kt)": round(net_last, 0),
        "Reported total (kt)": round(rep_last, 0) if rep_last is not None else None,
        "in refDB?": "Y" if bt.get_country_profile(bt.load_refdb(), iso) else "",
    }


def run_model(iso: str, series: dict):
    refdb = bt.load_refdb()
    profile = bt.get_country_profile(refdb, iso)
    if profile is None:
        return None
    years = sorted(series)
    rows = []
    for y in years:
        for c in CATS_STD:
            rows.append({"Year": y, "Category": c, "Gas": "CO2eq",
                         "Emissions": series[y].get(c, 0.0)})
    inv = pd.DataFrame(rows)
    if inv["Emissions"].abs().sum() == 0:
        return {"note": "no per-category data (total-only)"}
    land = bt._build_land_areas(iso, profile, years)
    try:
        hist = HistoricalLULUCF(inventory_emissions=inv, land_areas=land, country=iso)
        cfg = LULUCFConfig(country=iso, region=profile["region"], horizon_year=2040,
                           climate_zone=profile["climate_zone"], tier=0, profile="L-A")
        out = run_lulucf_module(hist, ProjectedLULUCF(), cfg)
    except Exception as e:
        return {"note": f"{type(e).__name__}: {str(e)[:60]}"}
    wom = out.net_co2eq_by_year().set_index("Year")["Net_LULUCF_CO2eq_kt"]
    last = years[-1]
    rep = sum(series[last].get(c, 0.0) for c in CATS_STD)
    model = float(wom.get(last, float("nan")))
    err = (model - rep) / abs(rep) * 100 if rep else float("nan")
    flags = [f.test_id for f in out.validation_report if f.severity in ("red", "amber")]
    sign_flip = (rep < 0) != (model < 0)
    return {"reported_4AG": round(rep, 0), "WoM_model": round(model, 0),
            "err_pct": round(err, 0), "sign_flip": "YES" if sign_flip else "",
            "flags": ",".join(flags)}


def main() -> int:
    if not _BTRCRT.exists():
        _p("no _btr_crt dir - run dl_btr.sh first"); return 1
    iso_dirs = sorted([d for d in _BTRCRT.iterdir() if d.is_dir()])
    _p(f"scanning {len(iso_dirs)} country dirs...")
    cache = {}
    avail_rows, model_rows = [], []
    for d in iso_dirs:
        iso = d.name.upper()
        series = parse_country(d)
        if not series:
            _p(f"  {iso}: no data"); continue
        cache[iso] = {str(y): {k: v for k, v in rec.items() if not k.startswith("_") or k == "_total"}
                      for y, rec in series.items()}
        av = availability(iso, series)
        avail_rows.append(av)
        m = run_model(iso, series)
        if m and "note" not in m:
            model_rows.append({"ISO": iso, **m})
        _p(f"  {iso}: {av.get('Years')} {av.get('Per-category?')} cats={av.get('Cats reported')}"
           + (f"  MODEL err={m.get('err_pct')}%" if m and 'err_pct' in m else ""))

    CACHE.write_text(json.dumps(cache, ensure_ascii=False))
    av_df = pd.DataFrame(avail_rows).sort_values("ISO")
    md_df = pd.DataFrame(model_rows).sort_values("err_pct", key=lambda s: s.abs(), ascending=False) \
        if model_rows else pd.DataFrame()

    _p("\n=== DATA AVAILABILITY (all BTR1) ===")
    sys.stdout.buffer.write((av_df.to_string(index=False) + "\n").encode("ascii", "replace"))
    _p("\n=== MODEL vs reported (refDB countries) ===")
    if len(md_df):
        sys.stdout.buffer.write((md_df.to_string(index=False) + "\n").encode("ascii", "replace"))

    with pd.ExcelWriter(OUT, engine="openpyxl") as xl:
        av_df.to_excel(xl, sheet_name="1 Data availability", index=False)
        if len(md_df):
            md_df.to_excel(xl, sheet_name="2 Model vs reported", index=False)
        wb = xl.book
        hf = PatternFill("solid", fgColor="1F4E78"); ff = Font(bold=True, color="FFFFFF")
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.fill = hf; cell.font = ff
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            for col in ws.columns:
                w = max((len(str(c.value)) for c in col if c.value is not None), default=10)
                ws.column_dimensions[get_column_letter(col[0].column)].width = min(w + 2, 32)

    _p(f"\nParsed {len(avail_rows)} countries; modelled {len(model_rows)}. Wrote {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
