"""Seed a 'Guyana' project into the running MITICA app via the API.

Creates a project with a macro run on REAL Guyana data (cached WDI; the oil-boom
structural-break case), so the user can open it and use the
"Export proxies + validation (.xlsx)" button. Idempotent: no-ops if a project
named 'Guyana' already exists.

Run (with the API up on :8000):
    .venv/Scripts/python.exe scripts/seed_guyana.py
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request

import pandas as pd

API = os.environ.get("MITICA_SEED_API", "http://127.0.0.1:8000")
NAME = "Guyana"
W = "scripts/macro_validation/wdi_data"
START, HORIZON = 2000, 2035


def _req(method: str, path: str, body=None):
    h = {"Content-Type": "application/json"} if body is not None else {}
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(f"{API}{path}", data=data, headers=h, method=method)
    with urllib.request.urlopen(req) as r:
        raw = r.read()
    return json.loads(raw) if raw else {}


def _wait(attempts=60, delay=1.0):
    for i in range(attempts):
        try:
            _req("GET", "/api/v1/health")
            print(f"[seed] API reachable after {i+1} attempt(s)")
            return
        except (urllib.error.URLError, ConnectionError):
            time.sleep(delay)
    sys.exit("[seed] API not ready")


def _macro_payload() -> dict:
    def s(f, c):
        d = pd.read_csv(f"{W}/{f}.csv")
        d = d[(d.iso3 == "GUY") & (d.Year >= START)][["Year", "value"]].rename(columns={"value": c})
        return d.sort_values("Year")
    gdp = s("GDP_tot", "GDP_tot")
    pop = s("Pop", "Pop")
    sp, ss, st = s("SGDP_primary", "p"), s("SGDP_secondary", "s"), s("SGDP_tertiary", "t")
    sg = sp.merge(ss, on="Year").merge(st, on="Year").merge(gdp, on="Year")
    tot = sg[["p", "s", "t"]].sum(axis=1)
    years = gdp["Year"].tolist()
    g = dict(zip(gdp.Year, gdp.GDP_tot)); pp = dict(zip(pop.Year, pop.Pop))
    return {
        "region": "LAC", "horizon_year": HORIZON, "shrinkage": 0.5,
        "gdp_tot": [{"year": int(y), "value": float(g[y])} for y in years],
        "population": [{"year": int(y), "value": float(pp[y])} for y in years],
        "sgdp": [
            {"year": int(r.Year),
             "primary": float(r.p / (r.p + r.s + r.t) * r.GDP_tot),
             "secondary": float(r.s / (r.p + r.s + r.t) * r.GDP_tot),
             "tertiary": float(r.t / (r.p + r.s + r.t) * r.GDP_tot)}
            for r in sg.itertuples()
        ],
        # no proj_gdp_tot → flow F3 (the model projects; the validator flags the boom)
    }


def main() -> int:
    print(f"[seed] target API = {API}")
    _wait()
    projects = _req("GET", "/api/v1/projects")
    existing = next((p for p in projects if p.get("name") == NAME), None)
    if existing:
        pid = existing["id"]
        print(f"[seed] '{NAME}' exists (id={pid}) — refreshing the macro run …")
    else:
        proj = _req("POST", "/api/v1/projects", {
            "name": NAME, "country_code": "GUY",
            "description": "Real Guyana macro run (WDI) — oil-boom structural-break "
                           "case. WoM reverts to a sustainable growth rate (robust B0). "
                           "Use 'Export proxies + validation (.xlsx)'.",
        })
        pid = proj["id"]
    print(f"[seed] created project id={pid}; running macro (LAC, F3, horizon {HORIZON}) …")
    try:
        res = _req("POST", f"/api/v1/projects/{pid}/macro/run", _macro_payload())
        nflags = len(res.get("validation_report", []))
        print(f"[seed] macro ok — flow {res.get('flow_detected')}, "
              f"{len(res.get('annalist_proxies_index', []))} proxies, {nflags} validation flags")
        _req("PATCH", f"/api/v1/projects/{pid}", {"use_macro_module": True})
    except urllib.error.HTTPError as e:
        print(f"[seed] macro run failed: {e.read().decode()[:300]}")
        return 1
    print(f"[seed] done. Open http://localhost:3000/projects/{pid} → Macro module")
    return 0


if __name__ == "__main__":
    sys.exit(main())
