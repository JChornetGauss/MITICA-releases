"""Informe técnico español - Parte I: cubierta, resumen ejecutivo, introducción,
marco teórico (secciones 1-3)."""

from __future__ import annotations

from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, Spacer, PageBreak

from report_common import header_table


def P(s, sty):
    return Paragraph(s, sty)


def content_part1(S, data):
    out = []

    # ============================================================
    # CUBIERTA
    # ============================================================
    out.append(Spacer(1, 2.5*cm))
    out.append(P("Módulo Macroeconómico de MITICA", S["TITLE"]))
    out.append(P("Especificación metodológica, calibración y validación "
                  "empírica", S["SUB"]))
    out.append(Spacer(1, 0.5*cm))
    out.append(P("Informe técnico &mdash; Versión 2.0", S["SUB"]))
    out.append(P("Mayo de 2026", S["SUB"]))
    out.append(Spacer(1, 1.5*cm))
    out.append(P("Gauss", S["AUTHOR"]))
    out.append(P("preparado para la Secretaría de la CMNUCC",
                  S["AUTHOR"]))
    out.append(Spacer(1, 0.8*cm))
    out.append(P(
        "<b>Resumen.</b> Este informe presenta la especificación "
        "metodológica, la estrategia de calibración y la validación "
        "empírica del módulo macroeconómico de MITICA (Mitigation-"
        "Inventory Tool for Integrated Climate Action). El módulo "
        "proporciona los drivers macroeconómicos &mdash; PIB, "
        "población, valor añadido sectorial, demanda energética "
        "sectorial &mdash; que alimentan el pipeline sectorial de "
        "proyección de emisiones. La nueva especificación se aparta "
        "de la versión legacy v1.1s en tres aspectos sustantivos. "
        "Primero, sustituye una regresión ridge defectuosa por una "
        "actualización bayesiana gaussiana-gaussiana en forma cerrada "
        "que respeta la estructura de covarianza del prior y produce "
        "intervalos creíbles calibrados. Segundo, prohíbe la síntesis "
        "de covariables ausentes; en su lugar expone una etiqueta de "
        "procedencia transparente sobre cada parámetro estimado. "
        "Tercero, introduce cuatro formas funcionales alternativas "
        "opcionales motivadas por la teoría económica estructural "
        "(Kuznets-Chenery, Bashmakov, Bennett), que el usuario "
        "selecciona por bloque para ajustar el régimen regional. Un "
        "sistema de priors regionales se calibra contra el panel WDI "
        "del Banco Mundial (217 países) y el panel energético "
        "Eurostat nrg_bal_c (29 economías europeas). Reportamos un "
        "estudio Monte Carlo de cobertura con 200 réplicas, un "
        "backtest fuera de muestra de 25 países UE-27 para el PIB "
        "sectorial, y un backtest fuera de muestra de 29 países "
        "UE-29 para la demanda energética sectorial. La configuración "
        "validada por defecto produce un error porcentual absoluto "
        "medio del 5,14% sobre el PIB terciario y del 22,6% sobre la "
        "energía manufacturera en economías maduras de altos ingresos "
        "en una ventana de 19 años fuera de muestra; mejora 4,8 "
        "puntos porcentuales sobre el modelo legacy en el caso de la "
        "energía manufacturera. Tres ejemplos numéricos de sensibilidad "
        "ilustran las implicaciones operativas para los escenarios de "
        "emisiones.", S["ABSTRACT"]))

    out.append(PageBreak())

    # ============================================================
    # ÍNDICE
    # ============================================================
    out.append(P("Índice", S["H1"]))
    toc = [
        ("1.",  "Resumen ejecutivo"),
        ("2.",  "Introducción y alcance"),
        ("3.",  "Marco teórico"),
        ("4.",  "Especificación del modelo"),
        ("5.",  "Estrategia de estimación"),
        ("6.",  "Datos y calibración"),
        ("7.",  "Validación empírica"),
        ("8.",  "Ejemplos numéricos de sensibilidad"),
        ("9.",  "Implicaciones para las proyecciones de emisiones"),
        ("10.", "Limitaciones y advertencias"),
        ("11.", "Discusión y trabajo pendiente"),
        ("A.",  "Derivaciones matemáticas"),
        ("B.",  "Priors regionales estilizados"),
        ("C.",  "Glosario"),
        ("D.",  "Referencias"),
    ]
    out.append(header_table([["", "Sección"]] + toc,
                              col_widths=[1.5*cm, 14*cm]))
    out.append(PageBreak())

    # ============================================================
    # 1. RESUMEN EJECUTIVO
    # ============================================================
    out.append(P("1.&nbsp;&nbsp; Resumen ejecutivo", S["H1"]))

    out.append(P("1.1&nbsp; Motivación", S["H2"]))
    out.append(P(
        "Las proyecciones de gases de efecto invernadero a horizonte "
        "largo descansan sobre trayectorias macroeconómicas: producto "
        "total, dinámica demográfica, composición sectorial del valor "
        "añadido e intensidad energética de cada actividad productiva. "
        "El módulo macro de MITICA produce estos drivers para cada año "
        "del horizonte de proyección y los traspasa a los módulos "
        "sectoriales de emisiones (Energía, LULUCF, F-gases, "
        "Transporte, Residuos). La implementación v1.1s se basaba en "
        "una especificación log-log de elasticidades constantes "
        "estimada mediante mínimos cuadrados penalizados con una "
        "fórmula errónea para la varianza del posterior. Tres "
        "problemas estructurales motivaron la presente revisión: (i) "
        "el estimador v1.1s colapsaba los intervalos creíbles a "
        "shrinkage alto, produciendo valores con confianza espuria; "
        "(ii) cuando el usuario no aportaba datos de inversión "
        "sectorial o capital público, el módulo sintetizaba las "
        "covariables faltantes como fracciones fijas del PIB "
        "sectorial, generando una matriz de diseño linealmente "
        "dependiente del target; (iii) la forma de elasticidades "
        "constantes no captura tres patrones estructurales bien "
        "documentados en datos a horizonte largo: la joroba Kuznets-"
        "Chenery en la cuota secundaria, la disminución de la "
        "intensidad energética con la renta (Bashmakov), y el "
        "desplazamiento dietético hacia la proteína animal con el "
        "ingreso (Bennett). La presente especificación aborda los "
        "tres problemas.", S["BODY"]))

    out.append(P("1.2&nbsp; Hallazgos principales", S["H2"]))
    out.append(P("<b>1.</b> El estimador bayesiano pasa una prueba "
                  "Monte Carlo de recovery con cobertura del 92-100% "
                  "para intervalos creíbles del 95% en todos los "
                  "niveles de shrinkage.", S["BULLET"]))
    out.append(P("<b>2.</b> Sobre un backtest fuera de muestra de 25 "
                  "países UE-27 (entrenamiento 1995-2005, test "
                  "2006-2024) la configuración recomendada alcanza un "
                  "error porcentual absoluto medio de <b>5,14%</b> "
                  "sobre el PIB terciario en el horizonte &mdash; el "
                  "mejor resultado entre todas las combinaciones de "
                  "formas funcionales evaluadas.", S["BULLET"]))
    out.append(P("<b>3.</b> En la parte energética, calibrar la forma "
                  "de convergencia de intensidad contra el panel "
                  "Eurostat nrg_bal_c arroja una elasticidad-renta de "
                  "la intensidad energética manufacturera de "
                  "<b>-1,23</b> en economías OCDE maduras, 2,5 veces "
                  "más fuerte que el prior estilizado derivado de la "
                  "literatura. La forma calibrada reduce el MAPE de "
                  "energía manufacturera en 4,8 puntos porcentuales "
                  "frente al baseline log-log heredado.", S["BULLET"]))
    out.append(P("<b>4.</b> El análisis bootstrap clusterizado por "
                  "país sobre los priors calibrados revela que las "
                  "elasticidades a Pop (&zeta;_s) están identificadas "
                  "con precisión por el panel global, mientras que los "
                  "shifters de renta (&kappa;, &kappa;&sup2;) son en "
                  "su mayoría estadísticamente NO distinguibles de "
                  "cero a nivel regional. La consecuencia "
                  "metodológica: la actualización bayesiana a nivel "
                  "país tiene priors lo suficientemente anchos sobre "
                  "&kappa; para que los datos locales transporten la "
                  "identificación.", S["BULLET"]))
    out.append(P("<b>5.</b> Una nueva prueba de validación (T8, "
                  "detector de cambio estructural) identifica "
                  "correctamente a 10 de 25 países UE-27 donde la "
                  "trayectoria post-2008 diverge de la distribución de "
                  "entrenamiento 1995-2005 &mdash; incluidos todos los "
                  "países con boom-bust documentado (burbuja "
                  "inmobiliaria española, sector financiero chipriota, "
                  "Tigre Celta irlandés, rescate FMI letón).",
                  S["BULLET"]))

    out.append(P("1.3&nbsp; Novedades respecto a v1.1s", S["H2"]))
    out.append(header_table([
        ["Bloque",              "v1.1s",
         "v2.0 (este informe)"],
        ["Estimador",          "Ridge con bug en varianza posterior",
         "Bayesiano en forma cerrada; IC bootstrap"],
        ["Drivers faltantes",    "Sintetizados como fracción fija de SGDP",
         "Excluidos; coeficiente fijado en prior (etiqueta 'calibrated')"],
        ["B2 (PIB sectorial)", "log-log",
         "log-log, Kuznets-Chenery, KC cuadrático"],
        ["B3 (cultivos/ganadería)", "Cuota constante",
         "Constante o Bennett logístico"],
        ["B5 (energía sectorial)", "log-log",
         "log-log o convergencia de intensidad"],
        ["B6 (residencial)", "log-log",
         "log-log o saturación (cuadrático)"],
        ["Priors regionales",    "Estilizados a mano",
         "Calibrados WDI + Eurostat; validados bootstrap"],
        ["Taxonomía regiones",    "6 regiones",
         "7 (HIC dividido en maduro y transicionando)"],
        ["Tests de validación",   "T1-T6",
         "T1-T8 (añadidos T7 plausibilidad, T8 cambio estructural)"],
        ["Tests unitarios",       "0 dedicados",
         "46 tests macro; 138 en toda la librería core"],
    ], col_widths=[3.5*cm, 5.5*cm, 7.5*cm]))
    out.append(Spacer(1, 0.4*cm))

    out.append(P("1.4&nbsp; Estructura del informe", S["H2"]))
    out.append(P(
        "Las secciones 2 y 3 establecen el alcance del módulo y la "
        "teoría económica que motiva cada forma funcional. La "
        "sección 4 especifica el modelo capa por capa, con las "
        "ecuaciones en su forma operativa. La sección 5 deriva el "
        "estimador bayesiano. La sección 6 documenta las fuentes de "
        "datos y el pipeline de calibración. La sección 7 reporta el "
        "Monte Carlo y los backtests UE. La sección 8 presenta tres "
        "ejemplos numéricos de sensibilidad en escenarios operativos. "
        "La sección 9 conecta las salidas macro con la proyección de "
        "emisiones aguas abajo. La sección 10 enumera honestamente "
        "las limitaciones. La sección 11 discute el trabajo pendiente. "
        "Cuatro apéndices contienen las derivaciones formales, los "
        "priors estilizados para regiones sin calibración, un "
        "glosario y las referencias.", S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 2. INTRODUCCIÓN Y ALCANCE
    # ============================================================
    out.append(P("2.&nbsp;&nbsp; Introducción y alcance", S["H1"]))

    out.append(P("2.1&nbsp; Posición en MITICA", S["H2"]))
    out.append(P(
        "MITICA es una aplicación Python desktop / web que apoya a "
        "las Partes del Acuerdo de París en la construcción de "
        "escenarios de emisiones de gases de efecto invernadero "
        "consistentes con su inventario nacional. La herramienta fue "
        "presentada en Martín-Ortega et al. (2024) y distribuida a "
        "través de la Secretaría de la CMNUCC. La aplicación produce "
        "tres escenarios &mdash; Sin Medidas (WoM), Con Medidas "
        "Existentes (WEM) y Con Medidas Adicionales (WAM) &mdash; "
        "para cada categoría IPCC del inventario nacional, anclados "
        "en una proyección baseline de actividad macroeconómica.",
                  S["BODY"]))
    out.append(P(
        "El módulo macroeconómico suministra los drivers de actividad "
        "para el baseline WoM. Concretamente, para cada año de "
        "proyección t &isin; [T+1, H] el módulo produce:", S["BODY"]))
    out.append(P("&bull; PIB total, GDP_tot;", S["BULLET"]))
    out.append(P("&bull; Población total, Pop;", S["BULLET"]))
    out.append(P("&bull; Valor añadido sectorial dividido en primario, "
                  "secundario y terciario, SGDP_s;", S["BULLET"]))
    out.append(P("&bull; Demanda energética final sectorial para seis "
                  "sectores energéticos, SED_k;", S["BULLET"]))
    out.append(P("&bull; Demanda energética residencial, SED_hh;",
                  S["BULLET"]))
    out.append(P("&bull; Cabezas de ganado y composición cultivos / "
                  "ganadería;", S["BULLET"]))
    out.append(P("&bull; Demanda energética total (TED) por identidad.",
                  S["BULLET"]))
    out.append(P(
        "Estos drivers alimentan los módulos sectoriales (Energía, "
        "IPPU, Agricultura, LULUCF, Residuos), que producen "
        "proyecciones de emisiones por categoría IPCC. El módulo "
        "macro NO calcula emisiones directamente; calcula las "
        "variables de actividad a las que se aplican aguas abajo los "
        "factores de emisión. La identidad TED = sum SED_k + SED_hh "
        "es impuesta por la Capa A.", S["BODY"]))

    out.append(P("2.2&nbsp; Restricciones de diseño", S["H2"]))
    out.append(P(
        "El módulo se calibra para las regularidades empíricas del "
        "pronóstico macroeconómico con datos escasos y horizonte "
        "largo. Los inventarios nacionales típicamente contienen "
        "15-25 años de datos históricos; el horizonte de proyección "
        "es 25-30 años. El estimador debe por tanto: (a) extraer "
        "información útil de series cortas sin sobreajustar, (b) "
        "permanecer transparente y auditable para modeladores "
        "nacionales que operan bajo el Marco de Transparencia "
        "Reforzado (ETF) de la CMNUCC, (c) rehusarse a inventar "
        "datos que el usuario no aportó, y (d) señalar situaciones "
        "donde extrapola más allá del régimen capturado por la "
        "ventana de entrenamiento. La shrinkage bayesiana con priors "
        "regionales cumple los tres primeros criterios; la capa de "
        "validación (T7, T8) aborda el cuarto.", S["BODY"]))

    out.append(P("2.3&nbsp; Flujos de usuario", S["H2"]))
    out.append(P("El módulo reconoce tres flujos de input:", S["BODY"]))
    out.append(P("<b>F1 (trayectoria completa).</b> El usuario aporta "
                  "GDP_tot, Pop y SGDP para todo el horizonte. Común "
                  "en sumisiones NDC donde el modelador nacional tiene "
                  "una proyección exógena de PIB del ministerio de "
                  "finanzas. El módulo respeta las trayectorias del "
                  "usuario verbatim y corre la prueba de plausibilidad "
                  "T7 para señalar inconsistencias entre la trayectoria "
                  "del usuario y la predicción data-driven del modelo.",
                  S["BULLET"]))
    out.append(P("<b>F2 (trayectoria parcial).</b> Se aporta al menos "
                  "uno de GDP_tot, Pop, SGDP. El módulo rellena los "
                  "demás desde el estimador. El caso típico es "
                  "GDP_tot aportado (a menudo con un target de "
                  "crecimiento aspiracional) y la composición "
                  "sectorial calculada.", S["BULLET"]))
    out.append(P("<b>F3 (solo priors).</b> No se aporta nada para el "
                  "futuro. El módulo se basa íntegramente en los "
                  "priors regionales y los datos históricos del "
                  "usuario.", S["BULLET"]))

    out.append(P("2.4&nbsp; Etiquetado de origen como interfaz de "
                  "transparencia", S["H2"]))
    out.append(P(
        "Cada parámetro estimado lleva una de tres etiquetas de "
        "origen: <i>estimated</i> (los datos del país dominaron), "
        "<i>adjusted</i> (datos y prior contribuyeron aproximadamente "
        "por igual), e <i>calibrated</i> (el prior regional domina, "
        "típicamente porque el país carecía de la serie histórica "
        "necesaria para identificar el coeficiente). La etiqueta es "
        "parte del contrato de salida del módulo y se muestra al "
        "usuario en el wizard. La interpretación epistémica: cuando "
        "un parámetro es <i>calibrated</i>, el comportamiento de la "
        "proyección en ese eje refleja la literatura regional más "
        "que la experiencia propia del país, y debe reportarse como "
        "tal en cualquier anexo metodológico sometido bajo el ETF.",
                  S["BODY"]))

    out.append(PageBreak())

    # ============================================================
    # 3. MARCO TEÓRICO
    # ============================================================
    out.append(P("3.&nbsp;&nbsp; Marco teórico", S["H1"]))
    out.append(P(
        "Las cuatro formas funcionales alternativas en v2.0 no son "
        "elecciones arbitrarias de especificación: cada una "
        "corresponde a una regularidad empírica bien documentada en "
        "la literatura de transformación estructural. Esta sección "
        "resume la teoría y revisa las referencias más relevantes; "
        "las ecuaciones de estimación están en la sección 4 y se "
        "derivan en el apéndice A.", S["BODY"]))

    out.append(P("3.1&nbsp; El baseline de elasticidades constantes",
                  S["H2"]))
    out.append(P("La especificación log-log:", S["BODY"]))
    out.append(P("log SGDP_s,t = &alpha;_s + &beta;_s log SInv_s,t + "
                  "&gamma;_s log GFCF_pub_s,t + &zeta;_s log Pop_t + "
                  "&delta;_s iRate_t + &epsilon;_s,t", S["EQN"]))
    out.append(P(
        "es el workhorse del pronóstico macroeconométrico con datos "
        "escasos. Tiene fundamento teórico en una función de "
        "producción Cobb-Douglas donde capital, trabajo y "
        "productividad entran multiplicativamente, y es empíricamente "
        "atractiva porque se identifica por mínimos cuadrados "
        "ordinarios sobre series cortas. Su limitación principal es "
        "la imposición de elasticidades <b>constantes</b> en todo el "
        "rango de renta: a renta alta una unidad extra de inversión "
        "se supone con el mismo efecto proporcional sobre el "
        "producto que a renta baja, y la cuota de cada sector se "
        "mantiene implícitamente constante. Ambos supuestos se "
        "violan en los datos sobre el horizonte multidecenal "
        "relevante para los escenarios climáticos.", S["BODY"]))

    out.append(P("3.2&nbsp; Transformación estructural: Kuznets y Chenery",
                  S["H2"]))
    out.append(P(
        "Kuznets (1957, 1971) documentó que conforme aumenta el "
        "ingreso per cápita, la cuota de la agricultura en el "
        "producto total cae monótonamente, la cuota de la industria "
        "sube y luego baja (una U-inversa), y la cuota de los "
        "servicios sube monótonamente. Chenery y Syrquin (1975, "
        "1986) y posteriormente Herrendorf, Rogerson y Valentinyi "
        "(2014) confirmaron el patrón sobre datos panel "
        "internacionales: en la transición de país en desarrollo a "
        "país de renta media, la cuota primaria cae 10-20 puntos "
        "porcentuales por duplicación del PIB per cápita, la cuota "
        "secundaria sube 5-15 puntos porcentuales antes de "
        "alcanzar el pico, y la cuota terciaria sube monótonamente.",
                  S["BODY"]))
    out.append(P(
        "La manera más simple de incorporar este patrón en una "
        "especificación log-log es añadir un shifter de renta:",
                  S["BODY"]))
    out.append(P("log SGDP_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1}",
                  S["EQN"]))
    out.append(P(
        "con &kappa;_primary &lt; 0, &kappa;_tertiary &gt; 0 y "
        "&kappa;_secondary &asymp; 0 en estado estacionario. El "
        "rezago es crítico para la proyección: en t el modelo "
        "conoce GDP/Pop_{t-1}, por lo que el regresor es exógeno en "
        "el loop de proyección y no se requiere iteración de punto "
        "fijo. Nos referimos a esta como la forma Kuznets-Chenery "
        "lineal (KC).", S["BODY"]))
    out.append(P(
        "La U-inversa en secundario es no monótona y por tanto se "
        "captura imperfectamente por el shifter lineal. Añadir un "
        "término cuadrático en log PIB per cápita:", S["BODY"]))
    out.append(P("log SGDP_s,t = ... + &kappa;_s log(GDP/Pop)_{t-1} "
                  "+ &kappa;&sup2;_s [log(GDP/Pop)_{t-1}]&sup2;",
                  S["EQN"]))
    out.append(P(
        "con &kappa;&sup2;_secondary &lt; 0 produce la forma de "
        "joroba con pico en log(GDP/Pop)* = &minus; &kappa; / (2 "
        "&kappa;&sup2;). Nos referimos a esta como la forma "
        "Kuznets-Chenery cuadrática (KCQ).", S["BODY"]))

    out.append(P("3.3&nbsp; Intensidad energética y la ley de Bashmakov",
                  S["H2"]))
    out.append(P(
        "Bashmakov (2007) formuló la regularidad empírica de que la "
        "intensidad energética sectorial (uso de energía por unidad "
        "de producto) disminuye con el ingreso en economías "
        "maduras. El mecanismo es compuesto: mejoras de eficiencia "
        "en el stock de capital, cambios estructurales hacia "
        "actividades menos intensivas en energía, y la difusión de "
        "las mejores tecnologías disponibles. En la fase de "
        "desarrollo de la industrialización, la intensidad a menudo "
        "<b>sube</b> antes de alcanzar el pico. La forma de "
        "convergencia de intensidad codifica esto:", S["BODY"]))
    out.append(P("log(SED_k / scale_k) = &phi;_k + &psi;_k log(GDP/Pop)",
                  S["EQN"]))
    out.append(P(
        "donde scale_k es el driver de actividad natural para el "
        "sector k (e.g. SGDP_secondary para manufactura) y &psi;_k "
        "es la elasticidad-renta de la intensidad. La elección de "
        "<b>intensidad</b> en lugar de <b>nivel</b> como variable "
        "dependiente fija la elasticidad de actividad a la unidad "
        "(respuesta proporcional a la escala) y aísla el "
        "desacoplamiento dirigido por renta en &psi;_k. Recuperamos "
        "&psi;_manufacturing = -1,23 sobre el panel Eurostat, más "
        "fuerte que el consenso de literatura pero consistente con "
        "los drivers adicionales (precios ETS, directivas de "
        "eficiencia energética) en el entorno de política europea.",
                  S["BODY"]))

    out.append(P("3.4&nbsp; Ley de Bennett en el valor añadido primario",
                  S["H2"]))
    out.append(P(
        "Bennett (1941) documentó que la mezcla de consumo se "
        "desplaza de almidones hacia proteína animal conforme "
        "aumenta el ingreso. La implicación para la composición de "
        "valor añadido agrícola: la cuota de ganadería crece con el "
        "ingreso mientras la cuota de cultivos cae. El módulo MITICA "
        "descompone el valor añadido del sector primario en "
        "cultivos, ganadería y otros; la forma Bennett logística "
        "codifica la respuesta-renta sobre la cuota de ganadería:",
                  S["BODY"]))
    out.append(P("logit(share_livestock_t) = a_B + b_B log(GDP/Pop_t)",
                  S["EQN"]))
    out.append(P(
        "donde logit(p) = log(p / (1 &minus; p)) mantiene la cuota "
        "implícita acotada en (0, 1) por construcción. b_B &gt; 0 "
        "es la ley de Bennett. La cuota de cultivos es el residual "
        "1 &minus; share_livestock &minus; share_other.", S["BODY"]))

    out.append(P("3.5&nbsp; Saturación en energía residencial", S["H2"]))
    out.append(P(
        "La demanda energética residencial per cápita sube "
        "rápidamente en la fase de desarrollo de una economía "
        "conforme se difunden los electrodomésticos, y luego se "
        "aplana al aproximarse la saturación. La meseta se alcanza "
        "en distintos umbrales de ingreso en distintos climas, "
        "pero es una característica robusta de los datos IEA. "
        "Capturamos esto con un cuadrático en log PIB per cápita:",
                  S["BODY"]))
    out.append(P("log SED_hh,t = &alpha;_hh + &beta;_hh log(GDP/Pop_t) "
                  "+ &gamma;_hh [log(GDP/Pop_t)]&sup2; "
                  "+ &zeta;_hh log Pop_t", S["EQN"]))
    out.append(P(
        "con &gamma;_hh &lt; 0. La inflexión donde la respuesta "
        "marginal a la renta es cero está en log(GDP/Pop)* = "
        "&minus; &beta;_hh / (2 &gamma;_hh). La forma es matemáticamente "
        "conveniente (lineal en parámetros bajo ridge bayesiano) y "
        "evita la asíntota logística explícita.", S["BODY"]))

    out.append(P("3.6&nbsp; Donde la elección de forma estructural "
                  "importa menos", S["H2"]))
    out.append(P(
        "Dos observaciones matizan el argumento a favor de las "
        "formas alternativas. Primero, cuando el usuario aporta la "
        "trayectoria completa de PIB y SGDP (flujo F1), el módulo "
        "respeta esa trayectoria y la elección de la forma B2 "
        "afecta sólo a la trayectoria de plausibilidad model-only "
        "usada por T7. Segundo, cuando el horizonte de proyección "
        "contiene un cambio de régimen que no está en la ventana de "
        "entrenamiento (la crisis financiera de 2008, COVID-19, una "
        "política de transición energética), ninguna forma de "
        "elasticidades constantes o polinómica en log-PIB puede "
        "predecirlo desde datos previos. El papel de las formas "
        "alternativas es extraer la señal estructural embebida en "
        "la ventana de entrenamiento, no anticipar rupturas "
        "impredecibles. La prueba T8 de la Capa C está diseñada "
        "para señalar estas rupturas cuando se manifiestan en la "
        "proyección.", S["BODY"]))

    out.append(PageBreak())

    return out
