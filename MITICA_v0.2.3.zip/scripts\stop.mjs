#!/usr/bin/env node
// MITICA Next — stop whatever is listening on :8000 and :3000.
// Works on Windows: parses netstat -ano, kills the PIDs with taskkill.
import { execSync } from "node:child_process";

function pidsOn(port) {
  try {
    const out = execSync("netstat -ano", { encoding: "utf-8" });
    const pids = new Set();
    for (const line of out.split("\n")) {
      if (new RegExp(`:${port}\\s+.*LISTENING`).test(line)) {
        const parts = line.trim().split(/\s+/);
        const pid = parts[parts.length - 1];
        if (/^\d+$/.test(pid)) pids.add(pid);
      }
    }
    return [...pids];
  } catch {
    return [];
  }
}

function kill(pid) {
  try {
    execSync(`taskkill /F /PID ${pid}`, { stdio: "pipe" });
    return true;
  } catch {
    return false;
  }
}

const ports = [8000, 3000];
let killed = 0;
for (const port of ports) {
  const pids = pidsOn(port);
  for (const pid of pids) {
    const ok = kill(pid);
    console.log(`  port ${port} — PID ${pid} ${ok ? "killed" : "already gone"}`);
    if (ok) killed++;
  }
}

console.log(killed === 0 ? "\nNothing was running on :8000 or :3000.\n" : `\nStopped ${killed} process(es).\n`);
