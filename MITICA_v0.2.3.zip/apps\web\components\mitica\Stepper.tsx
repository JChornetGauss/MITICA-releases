"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { api } from "@/lib/api";
import { cn } from "@/lib/utils";

interface Step {
  slug: string;
  title: string;
  subtitle: string;
}

const STEPS: Step[] = [
  { slug: "upload", title: "1 · Upload", subtitle: "Inventory + proxies" },
  { slug: "macro", title: "2 · Macro", subtitle: "Driver projection (v4)" },
  { slug: "lulucf", title: "2b · LULUCF", subtitle: "Sector 4 projection (opt-in)" },
  { slug: "fgases", title: "2c · F-gases", subtitle: "CRT 2F cohort engine (opt-in)" },
  { slug: "transport", title: "2d · Transport", subtitle: "Road 1A3b mini-scenarios (opt-in)" },
  { slug: "waste", title: "2e · Waste", subtitle: "CRT 5 FOD model (opt-in)" },
  { slug: "forecast", title: "3 · Forecast", subtitle: "WOM baseline" },
  { slug: "validate", title: "4 · Validate", subtitle: "Per-category review" },
  { slug: "pams", title: "5 · PAMs", subtitle: "Policies & measures" },
  { slug: "scenarios", title: "6 · Scenarios", subtitle: "WEM / WAM" },
  { slug: "targets", title: "6b · Targets", subtitle: "NDC targets (BI-003)" },
  { slug: "dashboard", title: "7 · Dashboard", subtitle: "Charts + CRT export" },
];

interface StepperProps {
  projectId: string;
  status: {
    hasInventory: boolean;
    hasForecast: boolean;
    pamCount: number;
    validatedCount: number;
    categoryCount: number;
    hasMacroResult: boolean;
    hasLulucfResult: boolean;
    hasFgasesResult: boolean;
  };
}

function stepDone(slug: string, status: StepperProps["status"]): boolean {
  const allValidated =
    status.categoryCount > 0 && status.validatedCount === status.categoryCount;
  switch (slug) {
    case "upload":
      return status.hasInventory;
    case "macro":
      // Optional module — marked done once a macro result is persisted
      // (project flag `has_macro_result`).
      return status.hasMacroResult;
    case "lulucf":
      // Opt-in sectoral module. Marked done once at least one scenario
      // result is persisted (project flag `has_lulucf_result`).
      return status.hasLulucfResult;
    case "fgases":
      // Opt-in F-gases module (SI-005). Marked done once a cohort-engine
      // result is persisted (project flag `has_fgases_result`).
      return status.hasFgasesResult;
    case "forecast":
      return status.hasForecast;
    case "validate":
      return allValidated;
    case "pams":
      return status.pamCount > 0;
    case "scenarios":
    case "dashboard":
      return allValidated && status.pamCount > 0;
    default:
      return false;
  }
}

export function Stepper({ projectId, status }: StepperProps) {
  const pathname = usePathname();

  // Same query key as the project layout → served from the TanStack cache,
  // no extra network round-trip. Used only for the transport/waste gate below.
  const { data: project } = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => api.getProject(projectId),
  });

  // Opt-in sectoral modules (SI-006 transport, SI-007 waste): each step only
  // appears when the project has the module activated (or already holds a
  // persisted result, so the done-mark survives a later toggle-off).
  const transportVisible = Boolean(
    project?.use_transport_module || project?.has_transport_result,
  );
  const wasteVisible = Boolean(
    project?.use_waste_module || project?.has_waste_result,
  );
  const steps = STEPS.filter(
    (s) =>
      (s.slug !== "transport" || transportVisible) &&
      (s.slug !== "waste" || wasteVisible),
  );

  return (
    <nav aria-label="Workflow steps" className="mb-6 overflow-x-auto">
      <ol className="flex min-w-max items-center gap-1">
        {steps.map((s, i) => {
          const active = pathname?.endsWith(`/${s.slug}`);
          const done =
            s.slug === "transport"
              ? Boolean(project?.has_transport_result)
              : s.slug === "waste"
              ? Boolean(project?.has_waste_result)
              : stepDone(s.slug, status);
          return (
            <li key={s.slug} className="flex items-center">
              <Link
                href={`/projects/${projectId}/${s.slug}`}
                className={cn(
                  "flex items-center gap-3 rounded-md border px-3 py-2 text-sm transition-colors",
                  active
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border bg-background text-muted-foreground hover:text-foreground"
                )}
              >
                <span
                  className={cn(
                    "flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
                    done
                      ? "bg-primary text-primary-foreground"
                      : active
                      ? "bg-primary/20 text-primary"
                      : "bg-muted text-muted-foreground"
                  )}
                >
                  {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
                </span>
                <div className="hidden text-left sm:block">
                  <p className="font-medium leading-tight">{s.title}</p>
                  <p className="text-[10px] leading-tight text-muted-foreground">{s.subtitle}</p>
                </div>
              </Link>
              {i < steps.length - 1 && (
                <span aria-hidden className="mx-1 h-px w-4 bg-border sm:w-6" />
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
