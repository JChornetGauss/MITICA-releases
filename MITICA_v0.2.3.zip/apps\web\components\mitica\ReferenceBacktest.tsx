"use client";

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";

interface ReferenceBacktestProps {
  projectId: string;
  referenceYear: number | null;
}

/**
 * Reference-year backtest — v1.1s "CheckWamWem" equivalent.
 *
 * For each IPCC category we show:
 *  - Historical (actual inventory values, blue)
 *  - Forecast (WOM, projected from the last inventory year, green)
 *  - Reference forecast (what the model WOULD have projected if it had only seen
 *    data up to `reference_year`, orange dashed)
 *
 * The distance between Historical and Reference-forecast in the years AFTER
 * `reference_year` is the model's backtest error for that category — a QA check.
 */
export function ReferenceBacktest({ projectId, referenceYear }: ReferenceBacktestProps) {
  const { data: forecast, isLoading } = useQuery({
    queryKey: ["forecast", projectId],
    queryFn: () => api.getForecast(projectId),
    retry: false,
  });

  // Only categories that actually carry reference data
  const withRef = useMemo(() => {
    if (!forecast) return [];
    return forecast.categories.filter(
      (c) => c.reference && c.reference_forecast && c.reference.some((v) => v !== null)
    );
  }, [forecast]);

  const [selected, setSelected] = useState<string>("");
  // Pick the first category with ref data by default
  const pickedCode = selected || withRef[0]?.ipcc_code || "";
  const picked = withRef.find((c) => c.ipcc_code === pickedCode);

  // Compute backtest error: sum absolute delta between Historical and Reference_Forecasted
  // for years strictly after reference_year where BOTH values exist
  const backtestStats = useMemo(() => {
    if (!picked || referenceYear == null) return null;
    let sumAbsErr = 0;
    let sumHist = 0;
    let n = 0;
    picked.years.forEach((y, i) => {
      if (y <= referenceYear) return;
      const hist = picked.historical[i];
      const refFc = picked.reference_forecast?.[i] ?? null;
      if (hist == null || refFc == null) return;
      sumAbsErr += Math.abs(refFc - hist);
      sumHist += Math.abs(hist);
      n += 1;
    });
    if (n === 0) return null;
    return {
      n,
      mape: sumHist > 0 ? (sumAbsErr / sumHist) * 100 : 0,
    };
  }, [picked, referenceYear]);

  if (isLoading)
    return (
      <Card>
        <CardContent className="pt-6">
          <Skeleton className="h-64" />
        </CardContent>
      </Card>
    );

  if (!forecast) return null;

  if (referenceYear == null) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Reference-year backtest</CardTitle>
          <CardDescription>
            Not available — this project was forecast without a reference year.
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-6 text-sm text-muted-foreground">
          To enable: re-run the forecast setting a reference year earlier than the last
          inventory year. The model will then fit using only the data up to that year, and
          you can compare its projection against what actually happened.
        </CardContent>
      </Card>
    );
  }

  if (withRef.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-sm text-muted-foreground">
          Reference year is set but no category has comparable reference values. Re-run the
          forecast to regenerate.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">Reference-year backtest</CardTitle>
            <CardDescription>
              Fit the model as if we only knew data up to <strong>{referenceYear}</strong>, then
              compare against what actually happened — a model-accuracy QA check.
            </CardDescription>
          </div>
          <select
            className="h-9 rounded-md border border-input bg-background px-3 text-sm"
            value={pickedCode}
            onChange={(e) => setSelected(e.target.value)}
          >
            {withRef.map((c) => (
              <option key={c.ipcc_code} value={c.ipcc_code}>
                {c.ipcc_code}
              </option>
            ))}
          </select>
        </div>
      </CardHeader>
      <CardContent>
        {picked && (
          <>
            <PlotlyChart
              height={340}
              data={[
                {
                  x: picked.years,
                  y: picked.historical,
                  type: "scatter",
                  mode: "lines+markers",
                  name: "Historical",
                  line: { color: "#0ea5e9", width: 2 },
                },
                {
                  x: picked.years,
                  y: picked.forecast,
                  type: "scatter",
                  mode: "lines",
                  name: "Forecast (WOM)",
                  line: { color: "#0f766e", width: 2, dash: "dot" },
                },
                {
                  x: picked.years,
                  y: picked.reference_forecast,
                  type: "scatter",
                  mode: "lines",
                  name: `Reference forecast (from ${referenceYear})`,
                  line: { color: "#f59e0b", width: 2, dash: "dash" },
                },
                {
                  x: [referenceYear],
                  y: [0],
                  type: "scatter",
                  mode: "markers+text",
                  name: "Reference year",
                  marker: { color: "#ef4444", size: 10, symbol: "diamond" },
                  text: [`← anchor ${referenceYear}`],
                  textposition: "top center",
                  showlegend: false,
                },
              ]}
              layout={{
                yaxis: { title: { text: "kt CO₂ eq" } },
                xaxis: { title: { text: "Year" } },
                shapes: [
                  {
                    type: "line",
                    x0: referenceYear,
                    x1: referenceYear,
                    yref: "paper",
                    y0: 0,
                    y1: 1,
                    line: { color: "rgba(239, 68, 68, 0.3)", width: 1, dash: "dot" },
                  },
                ],
              }}
            />
            {backtestStats && (
              <div className="mt-3 flex flex-wrap items-center gap-3 rounded-md border bg-muted/30 p-3 text-sm">
                <span className="font-medium">Backtest error:</span>
                <Badge
                  variant={backtestStats.mape < 15 ? "success" : "warning"}
                  className="gap-1"
                >
                  {backtestStats.mape < 15 ? (
                    <CheckCircle2 className="h-3 w-3" />
                  ) : (
                    <AlertTriangle className="h-3 w-3" />
                  )}
                  MAPE {backtestStats.mape.toFixed(1)} %
                </Badge>
                <span className="text-xs text-muted-foreground">
                  over {backtestStats.n} overlap years ({referenceYear + 1} – last inventory year)
                </span>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
