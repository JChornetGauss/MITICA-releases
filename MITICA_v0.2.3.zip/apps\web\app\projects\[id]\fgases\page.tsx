"use client";

import { use, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Info,
  Play,
  Snowflake,
} from "lucide-react";

import {
  api,
  type FGasesFormsCatalog,
  type FGasesKigaliGroup,
  type FGasesResult,
  type FGasesRunRequest,
  type FGasesScenario,
  type FGasesSystem,
  type FGasesUploadResponse,
  type FGasesValidationFlag,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlotlyChart } from "@/components/mitica/PlotlyChart";
import { UploadBox } from "@/components/mitica/UploadBox";
import { cn } from "@/lib/utils";

const SCENARIO_COLORS: Record<FGasesScenario, string> = {
  BaU: "#1A2438",
  WEM: "#147A6E",
  WAM: "#8a7d5a",
};

const CRT_LABELS: Record<string, string> = {
  "2F1a": "Domestic refrigeration",
  "2F1b": "Commercial refrigeration",
  "2F1c": "Transport refrigeration",
  "2F1d": "Industrial refrigeration / chillers",
  "2F1e": "Stationary air-conditioning",
  "2F1f": "Mobile air-conditioning",
};

const KIGALI_GROUP_LABEL: Record<FGasesKigaliGroup, string> = {
  non_article_5: "Non-Article 5 (Annex I / developed)",
  article_5_group_1: "Article 5 group 1 (most developing)",
  article_5_group_2: "Article 5 group 2 (high-ambient / oil)",
};


export default function FGasesPage({
  params,
}: { params: Promise<{ id: string }> }) {
  const { id } = use(params);

  // ---- Server state ----
  const catalog = useQuery<FGasesFormsCatalog>({
    queryKey: ["fgases-catalog"],
    queryFn: () => api.getFGasesFormsCatalog(),
  });
  const system = useQuery<FGasesSystem>({
    queryKey: ["fgases-system", id],
    queryFn: () => api.getFGasesSystem(id),
    retry: false,
  });
  const stored = useQuery<FGasesResult>({
    queryKey: ["fgases-result", id],
    queryFn: () => api.getFGasesResult(id),
    retry: false,
  });

  // ---- Run-form state ----
  const [horizon, setHorizon] = useState<string>("2050");
  const [countryCode, setCountryCode] = useState<string>("UNK");
  const [applyKigali, setApplyKigali] = useState<boolean>(true);
  const [kigaliGroup, setKigaliGroup] = useState<FGasesKigaliGroup | "">("");
  const [scenarios, setScenarios] = useState<FGasesScenario[]>([
    "BaU", "WEM", "WAM",
  ]);

  // Auto-infer Kigali group from the uploaded system's country, if any
  const sys = system.data;
  const inferredKigali = useMemo<FGasesKigaliGroup | undefined>(() => {
    if (!catalog.data || !sys?.country_code) return undefined;
    return catalog.data.country_kigali_group[sys.country_code] as
      | FGasesKigaliGroup
      | undefined;
  }, [catalog.data, sys?.country_code]);

  // ---- Mutations ----
  const upload = useMutation({
    mutationFn: (file: File) =>
      api.uploadFGasesTemplate(id, file, countryCode, 2023),
    onSuccess: (resp: FGasesUploadResponse) => {
      // Cascade refresh
      void system.refetch();
      if (resp.country_code && resp.country_code !== "UNK") {
        setCountryCode(resp.country_code);
      }
    },
  });

  const run = useMutation({
    mutationFn: (): Promise<FGasesResult> => {
      const body: FGasesRunRequest = {
        horizon_year: Number(horizon) || 2050,
        scenarios,
        apply_kigali_default: applyKigali,
        kigali_group: kigaliGroup || null,
      };
      return api.runFGases(id, body);
    },
    onSuccess: () => stored.refetch(),
  });

  const result: FGasesResult | undefined = run.data ?? stored.data;
  const hasSystem = Boolean(sys);

  return (
    <div className="space-y-8">
      {/* ---- Header ---- */}
      <div>
        <div className="mb-2 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-border bg-card text-sky-700">
            <Snowflake className="h-5 w-5" />
          </div>
          <div>
            <div className="eyebrow">Module · SI-005 · IPCC / CRT 2F</div>
            <h2 className="font-serif text-2xl font-[460]">F-gases module</h2>
          </div>
        </div>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Cohort-accurate IPCC 2006 Vol 3 Ch 7 <em>Tier 2</em> mass balance for
          refrigeration + air conditioning (CRT <code className="font-mono">2F1a–2F1f</code>).
          Tracks per-(sub-application × gas × cohort) inventory of new charges,
          annual stock leakage, end-of-life decommissioning, and applies the
          Kigali Amendment phase-down to the WAM scenario. Activating the
          module on a project overrides ANNALIST for ONLY the 2F1 lines. Every
          other category in the inventory still projects with ANNALIST using your
          proxies.
        </p>
      </div>

      {/* ---- 1. Upload ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">1. Upload the F-gases template (optional)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label>Country ISO3</Label>
              <Input
                value={countryCode}
                onChange={(e) =>
                  setCountryCode(e.target.value.toUpperCase().slice(0, 3))
                }
                placeholder="ESP"
              />
              <p className="mt-1 text-[11px] text-muted-foreground">
                Used to infer the Kigali group automatically (default Article 5 group 1).
              </p>
            </div>
            <div className="sm:col-span-2">
              <Label>Legacy 2F Excel</Label>
              <UploadBox
                label={
                  sys
                    ? `System loaded for ${sys.country_code} — ${sys.subsectors.length} sub-applications`
                    : "Choose 2F_Estimate_final.xlsx"
                }
                description="Reverse-engineered from the original Excel prototype: parses sales / stock / IC / lifetime / EFs from BaU + Ref Distribution sheets, splits ϕ at last_hist_year=2023."
                accept=".xlsx,.xlsm,.xls"
                onUpload={async (file) => {
                  await upload.mutateAsync(file);
                }}
                uploaded={Boolean(sys)}
              />
              {upload.error && (
                <p className="mt-2 text-sm text-destructive">
                  {(upload.error as Error).message}
                </p>
              )}
              {upload.data && (
                <p className="mt-2 inline-flex items-center gap-1.5 text-xs text-primary">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {upload.data.n_subsectors} sub-applications · last hist{" "}
                  {upload.data.last_historical_year} · Kigali group{" "}
                  <code className="font-mono">
                    {upload.data.kigali_group_inferred}
                  </code>
                </p>
              )}
            </div>
          </div>
          {!hasSystem && (
            <p className="text-xs text-muted-foreground">
              You can also skip the upload and pass an inline system payload
              programmatically via <code>POST /fgases/run</code>.
            </p>
          )}
        </CardContent>
      </Card>

      {/* ---- 2. Run config ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">2. Run the cohort engine</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <Label>Horizon year</Label>
              <Input
                type="number"
                min={2020}
                max={2100}
                value={horizon}
                onChange={(e) => setHorizon(e.target.value)}
              />
            </div>
            <div>
              <Label>Kigali group (override)</Label>
              <select
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={kigaliGroup}
                onChange={(e) =>
                  setKigaliGroup(e.target.value as FGasesKigaliGroup | "")
                }
              >
                <option value="">
                  Auto from country
                  {inferredKigali ? ` · ${inferredKigali}` : ""}
                </option>
                {catalog.data &&
                  Object.entries(catalog.data.kigali_groups).map(([k]) => (
                    <option key={k} value={k}>
                      {KIGALI_GROUP_LABEL[k as FGasesKigaliGroup] ?? k}
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <Label>Scenarios</Label>
              <div className="flex gap-1.5">
                {(["BaU", "WEM", "WAM"] as FGasesScenario[]).map((s) => {
                  const on = scenarios.includes(s);
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() =>
                        setScenarios(
                          on
                            ? scenarios.filter((x) => x !== s)
                            : [...scenarios, s].sort(),
                        )
                      }
                      className={cn(
                        "h-10 flex-1 rounded-md border text-xs font-medium transition-colors",
                        on
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-border bg-card text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="self-end">
              <Button
                onClick={() => run.mutate()}
                disabled={run.isPending || scenarios.length === 0}
                className="w-full"
              >
                <Play className="mr-2 h-4 w-4" />
                {run.isPending ? "Running…" : "Run"}
              </Button>
            </div>
          </div>

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={applyKigali}
              onChange={(e) => setApplyKigali(e.target.checked)}
              className="mt-0.5"
            />
            <span>
              <strong>Apply Kigali default to WAM</strong>{" "}
              <span className="text-muted-foreground">
                — engine builds an industry-typical low-GWP substitution path
                per sub-application (HFC-32 / HFO-1234yf / HC-600a / R-744)
                paced by the country group. BaU and WEM stay on the historical
                refrigerant mix.
              </span>
            </span>
          </label>

          {run.error && (
            <p className="text-sm text-destructive">
              {(run.error as Error).message}
            </p>
          )}
          {run.isSuccess && (
            <p className="inline-flex items-center gap-1.5 text-sm text-primary">
              <CheckCircle2 className="h-4 w-4" /> Engine ran — horizon{" "}
              {run.data.horizon_year}
              {run.data.kigali_group_used
                ? ` · Kigali ${run.data.kigali_group_used}`
                : ""}
            </p>
          )}
        </CardContent>
      </Card>

      {/* ---- 3. Results ---- */}
      {result && (
        <FGasesResults result={result} catalog={catalog.data} />
      )}
    </div>
  );
}


// ============================================================================
// Results — narrative summary, validation panel, scenario chart,
// CRT 2F breakdown, per-(sub, gas) detail.
// ============================================================================


function FGasesResults({
  result,
  catalog,
}: {
  result: FGasesResult;
  catalog?: FGasesFormsCatalog;
}) {
  const years = result.years;

  // Scenario totals — top chart
  const totalTraces = result.scenarios.map((scen) => {
    const m = result.scenario_totals[scen] ?? {};
    return {
      x: years,
      y: years.map((y) => m[String(y)] ?? null),
      type: "scatter" as const,
      mode: "lines+markers" as const,
      name: scen,
      line: { color: SCENARIO_COLORS[scen], width: 2 },
    };
  });

  return (
    <div className="space-y-6">
      <NarrativeSummary result={result} />
      <ValidationPanel report={result.validation_report} />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Scenario comparison — total CRT 2F1 emissions (kt CO₂-eq)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PlotlyChart
            height={340}
            data={totalTraces}
            layout={{
              yaxis: { title: "kt CO₂-eq" },
              xaxis: { title: "Year" },
              legend: { orientation: "h" },
            }}
          />
        </CardContent>
      </Card>

      <CRT2FBreakdown result={result} />
      <AdvancedOutputs result={result} catalog={catalog} />
    </div>
  );
}


// ----- Narrative summary -----------------------------------------------------


function NarrativeSummary({ result }: { result: FGasesResult }) {
  const years = result.years;
  if (years.length === 0) return null;
  const last = years[years.length - 1];

  const totalAt = (scen: FGasesScenario, y: number): number => {
    return result.scenario_totals[scen]?.[String(y)] ?? 0;
  };
  const bauHorizon = totalAt("BaU", last);
  const wamHorizon = totalAt("WAM", last);
  const abatePct =
    bauHorizon > 0 ? ((bauHorizon - wamHorizon) / bauHorizon) * 100 : 0;

  // Highest-impact sub-app at horizon (BaU)
  const subTotals: Record<string, number> = {};
  for (const row of result.emissions) {
    if (row.scenario !== "BaU" || row.year !== last) continue;
    for (const [key, v] of Object.entries(row.kt_co2eq)) {
      const [sub] = key.split("|");
      subTotals[sub] = (subTotals[sub] ?? 0) + v;
    }
  }
  const topSub = Object.entries(subTotals).sort((a, b) => b[1] - a[1])[0];

  return (
    <div className="rounded-md border border-border bg-muted/30 p-4">
      <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        <Info className="h-3.5 w-3.5" /> Summary
      </div>
      <p className="text-sm leading-relaxed">
        At the {last} horizon, BaU CRT 2F1 emissions reach{" "}
        <strong>{bauHorizon.toFixed(1)} kt CO₂-eq</strong>.
        {result.scenarios.includes("WAM") && bauHorizon > 0 && (
          <>
            {" "}WAM (with{" "}
            {result.apply_kigali_default ? "Kigali" : "user-supplied"}{" "}
            substitution) reaches{" "}
            <strong>{wamHorizon.toFixed(1)} kt CO₂-eq</strong>,
            an abatement of{" "}
            <strong
              className={abatePct > 0 ? "text-emerald-700" : "text-destructive"}
            >
              {abatePct >= 0 ? "" : "+"}
              {(-abatePct).toFixed(1).replace("-", "")}
              {abatePct >= 0 ? "% reduction" : "% increase"}
            </strong>
            .
          </>
        )}
        {topSub && (
          <>
            {" "}Largest 2F1 source at horizon:{" "}
            <code className="font-mono text-xs">{topSub[0]}</code>{" "}
            ({topSub[1].toFixed(1)} kt CO₂-eq).
          </>
        )}
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        Cohort engine tracks {result.subsector_names?.length ?? 0} sub-applications
        across {years.length} years. AR4 GWP-100 throughout (MITICA convention).
      </p>
    </div>
  );
}


// ----- Validation panel ------------------------------------------------------


function ValidationPanel({ report }: { report: FGasesValidationFlag[] }) {
  if (report.length === 0) {
    return (
      <div className="rounded-md border border-emerald-500/30 bg-emerald-50 p-3">
        <p className="inline-flex items-center gap-1.5 text-sm text-emerald-700">
          <CheckCircle2 className="h-4 w-4" />
          All F-series plausibility checks pass (F1 IC, F2 leakage, F4 WAM
          direction, F5 ϕ normalisation).
        </p>
      </div>
    );
  }
  const byTest: Record<string, FGasesValidationFlag[]> = {};
  for (const f of report) (byTest[f.test_id] ??= []).push(f);
  const ids = Object.keys(byTest).sort();
  return (
    <div className="rounded-md border border-amber-500/30 bg-amber-50/50 p-4">
      <div className="mb-2 inline-flex items-center gap-1.5 text-sm font-semibold text-amber-800">
        <AlertCircle className="h-4 w-4" /> {report.length} plausibility flag
        {report.length === 1 ? "" : "s"} raised
      </div>
      <ul className="space-y-3">
        {ids.flatMap((tid) =>
          byTest[tid].map((f, i) => (
            <li
              key={`${tid}-${i}`}
              className="border-l-2 border-amber-500/50 pl-3 text-sm"
            >
              <div className="flex items-center gap-2 text-xs text-amber-900">
                <code className="rounded bg-amber-100 px-1.5 py-0.5 font-mono font-semibold">
                  {f.test_id}
                </code>
                <span className="text-muted-foreground">{f.variable}</span>
              </div>
              <p className="mt-0.5">{f.message}</p>
              {f.proposed_action && (
                <p className="mt-1 text-xs text-muted-foreground">
                  <strong className="text-foreground">What to do:</strong>{" "}
                  {f.proposed_action}
                </p>
              )}
            </li>
          )),
        )}
      </ul>
    </div>
  );
}


// ----- CRT 2F breakdown ------------------------------------------------------


function CRT2FBreakdown({ result }: { result: FGasesResult }) {
  const [scen, setScen] = useState<FGasesScenario>(result.scenarios[0] ?? "BaU");
  const crt = result.crt_totals[scen] ?? {};
  const codes = Object.keys(crt).sort();
  const years = result.years;

  const stacked = codes.map((code) => ({
    x: years,
    y: years.map((y) => crt[code][String(y)] ?? 0),
    name: `${code} · ${CRT_LABELS[code] ?? code}`,
    type: "bar" as const,
  }));

  // Last-year table
  const last = years[years.length - 1];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">CRT 2F1 breakdown — {scen}</CardTitle>
        <div className="flex overflow-hidden rounded-sm border border-border text-xs">
          {result.scenarios.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setScen(s)}
              className={cn(
                "px-3 py-1",
                s === scen
                  ? "bg-primary font-medium text-primary-foreground"
                  : "bg-card text-muted-foreground hover:bg-muted",
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <PlotlyChart
          height={300}
          data={stacked}
          layout={{
            barmode: "stack",
            yaxis: { title: "kt CO₂-eq" },
            xaxis: { title: "Year" },
            legend: { orientation: "h" },
          }}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr>
                <th className="px-2 py-1.5 text-left">CRT code</th>
                <th className="px-2 py-1.5 text-left">Category</th>
                <th className="px-2 py-1.5 text-right">{last} (kt CO₂-eq)</th>
              </tr>
            </thead>
            <tbody>
              {codes.map((code) => (
                <tr key={code} className="border-t border-border">
                  <td className="px-2 py-1.5 font-mono text-xs">{code}</td>
                  <td className="px-2 py-1.5">
                    {CRT_LABELS[code] ?? "—"}
                  </td>
                  <td className="px-2 py-1.5 text-right font-mono text-xs">
                    {(crt[code][String(last)] ?? 0).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}


// ----- Advanced outputs ------------------------------------------------------


function AdvancedOutputs({
  result,
  catalog,
}: {
  result: FGasesResult;
  catalog?: FGasesFormsCatalog;
}) {
  const [open, setOpen] = useState(false);
  const [scen, setScen] = useState<FGasesScenario>(result.scenarios[0] ?? "BaU");
  const last = result.years[result.years.length - 1];

  // Per-(sub, gas) emissions at horizon, scenario-scoped
  const rowsAtHorizon = result.emissions
    .filter((e) => e.scenario === scen && e.year === last)
    .flatMap((e) =>
      Object.entries(e.kt_co2eq).map(([key, v]) => {
        const [sub, gas] = key.split("|");
        return { sub, gas, kt: v };
      }),
    )
    .sort((a, b) => b.kt - a.kt);

  // Per-stream activity at horizon
  const horizonRow = result.emissions.find(
    (e) => e.scenario === scen && e.year === last,
  );
  const streamTotals: Record<string, number> = {};
  for (const [key, kg] of Object.entries(horizonRow?.activity_kg ?? {})) {
    const [stream] = key.split("|");
    streamTotals[stream] = (streamTotals[stream] ?? 0) + kg;
  }

  return (
    <Card>
      <CardHeader>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center justify-between text-left"
        >
          <CardTitle className="text-base">Advanced outputs</CardTitle>
          {open ? (
            <ChevronDown className="h-4 w-4" />
          ) : (
            <ChevronRight className="h-4 w-4" />
          )}
        </button>
      </CardHeader>
      {open && (
        <CardContent className="space-y-6">
          <div className="flex items-center gap-3 text-xs">
            <span className="text-muted-foreground">Scenario</span>
            <div className="flex overflow-hidden rounded-sm border border-border">
              {result.scenarios.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setScen(s)}
                  className={cn(
                    "px-3 py-1",
                    s === scen
                      ? "bg-primary font-medium text-primary-foreground"
                      : "bg-card text-muted-foreground hover:bg-muted",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Per-(sub-app × gas) emissions at {last}
            </p>
            <div className="max-h-80 overflow-y-auto rounded-md border border-border">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted text-xs text-muted-foreground">
                  <tr>
                    <th className="px-2 py-1.5 text-left">Sub-application</th>
                    <th className="px-2 py-1.5 text-left">Gas</th>
                    <th className="px-2 py-1.5 text-right">kt CO₂-eq</th>
                    <th className="px-2 py-1.5 text-right">GWP</th>
                  </tr>
                </thead>
                <tbody>
                  {rowsAtHorizon.map((r, i) => (
                    <tr key={i} className="border-t border-border">
                      <td className="px-2 py-1.5 font-mono text-xs">{r.sub}</td>
                      <td className="px-2 py-1.5 font-mono text-xs">{r.gas}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-xs">
                        {r.kt.toFixed(3)}
                      </td>
                      <td className="px-2 py-1.5 text-right font-mono text-xs text-muted-foreground">
                        {result.gwp_used[r.gas] ?? "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {Object.keys(streamTotals).length > 0 && (
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                IPCC activity streams at {last} (kg of refrigerant)
              </p>
              <div className="grid gap-3 sm:grid-cols-3">
                {(["manufacturing", "in_service", "decommissioning"] as const).map(
                  (s) => (
                    <div
                      key={s}
                      className="rounded-md border border-border bg-card p-3"
                    >
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        {s.replace("_", " ")}
                      </div>
                      <div className="mt-1 font-mono text-lg">
                        {(streamTotals[s] ?? 0).toFixed(1)}
                      </div>
                      <div className="text-[11px] text-muted-foreground">kg</div>
                    </div>
                  ),
                )}
              </div>
            </div>
          )}

          {catalog && (
            <div className="text-[11px] text-muted-foreground">
              Engine version: cohort-accurate Tier 2 · 13 sub-applications ·{" "}
              {catalog.gases.length} gases · AR4 GWP-100 · Kigali phase-down
              applied to WAM (industry-typical replacement strategy per
              sub-app, paced by country group).
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
}
