"""
Estimate the v3 compositional B2 priors from the WDI panel.

Specification
-------------
For each MITICA region r and each non-reference sector j ∈ {primary, secondary}
(tertiary is the reference, denominator of the log-ratio):

    η_{j,c,t} ≡ log(σ_{j,c,t} / σ_{T,c,t})
              = α_{c,j}                            (country FE)
                + β_{j,r}  log(y_{c,t})
                + γ_{j,r}  (log y_{c,t})^2
                + μ_{j,r}  log(P_{c,t})
                + ν_{j,r}  (t - t_anchor_panel)
                + ε_{j,c,t}

This is the *exact* equation that the macro module's compositional B2
projects with, so the recovered (β, γ, μ, ν) are usable verbatim as
regional priors. Country FE α_{c,j} is absorbed via within-country
demeaning; it is then re-estimated per-country at run time by the engine.

Identification & robustness
---------------------------
* Within-country demean → one-way FE estimator.
* Require ≥ 5 years per country.
* HC1 standard errors.
* Country-clustered bootstrap (200 resamples) for the reported SE.
* Contemporaneous log y (matches the engine; see §2.2.2 of the design doc).

What is calibrated
------------------
Two passes over the panel:

  **Within-country FE pass** identifies β (log y) and ν (time trend).
  Within a country, log y, (log y)^2, log P and t are near-linear in
  time so FE alone cannot disentangle the quadratic γ and the
  demographic μ from β. These two coefficients come from FE.

  **Pooled-OLS pass with country dummies** exploits cross-country
  variation to identify γ (quadratic income effect — the Kuznets hump
  on secondary share) and μ (population scale effect). Specifically we
  pool observations across countries and regress the log-ratio η_j on
  [1, log y, (log y)^2, log P], with country-clustered standard
  errors. The β coefficient from this pooled pass is biased (it
  conflates within and between variation); we report it only as a
  diagnostic. The γ and μ from the pooled pass are what we keep for the
  prior.

The JSON output carries β and ν from the FE pass, and γ and μ from
the pooled pass. The engine loader applies each field independently.

Output
------
``scripts/macro_validation/wdi_data/calibrated_b2_compositional_priors.json``
with the estimated (β, ν) per region per non-reference sector and
explicit nulls for γ / μ. The ``g_Macro_Priors.py`` loader picks up the
non-null entries; absent values keep the stylised defaults.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path("scripts/macro_validation/wdi_data")
OUT_PATH = DATA_DIR / "calibrated_b2_compositional_priors.json"

REGIONS = ("LAC", "SSA", "MENA", "APAC", "EEU", "HIC", "HIC_TRANS")
NON_REF_SECTORS = ("primary", "secondary")
REFERENCE_SECTOR = "tertiary"

# Stylised defaults — kept for the side-by-side comparison.
STYLISED = {
    "beta": {
        "LAC":       {"primary": -0.80, "secondary": +0.20},
        "SSA":       {"primary": -0.85, "secondary": +0.25},
        "MENA":      {"primary": -0.75, "secondary": +0.15},
        "APAC":      {"primary": -0.90, "secondary": +0.30},
        "EEU":       {"primary": -0.70, "secondary": +0.15},
        "HIC":       {"primary": -0.40, "secondary": +0.05},
        "HIC_TRANS": {"primary": -0.60, "secondary": +0.12},
    },
    "gamma": {
        r: {"primary": 0.00, "secondary": -0.011}
        for r in REGIONS
    },
}


# ---------------------------------------------------------------------------
# Panel assembly
# ---------------------------------------------------------------------------


def load_panel() -> pd.DataFrame:
    """Assemble the compositional panel: iso3, Year, region, log_y, log_P,
    eta_primary, eta_secondary, year_norm."""
    countries = pd.read_csv(DATA_DIR / "countries.csv")
    countries = countries.dropna(subset=["mitica_region"])

    indicators = ("GDP_pc", "GDP_tot", "Pop",
                  "SGDP_primary", "SGDP_secondary", "SGDP_tertiary")
    frames = []
    for short in indicators:
        df = pd.read_csv(DATA_DIR / f"{short}.csv")
        df = df.rename(columns={"value": short})
        frames.append(df.set_index(["iso3", "Year"]))
    panel = frames[0]
    for f in frames[1:]:
        panel = panel.join(f, how="outer")
    panel = panel.reset_index().merge(
        countries[["iso3", "mitica_region"]], on="iso3", how="inner"
    )

    # Drop rows where any of the three sectoral GDPs are missing or non-positive.
    for s in ("primary", "secondary", "tertiary"):
        col = f"SGDP_{s}"
        panel = panel[(panel[col].notna()) & (panel[col] > 0)]
    panel = panel[(panel["GDP_pc"].notna()) & (panel["GDP_pc"] > 0)]
    panel = panel[(panel["Pop"].notna())     & (panel["Pop"] > 0)]
    panel = panel[(panel["GDP_tot"].notna()) & (panel["GDP_tot"] > 0)]

    # Shares and log-ratios. Tertiary is the reference.
    panel["sigma_primary"]   = panel["SGDP_primary"]   / panel["GDP_tot"]
    panel["sigma_secondary"] = panel["SGDP_secondary"] / panel["GDP_tot"]
    panel["sigma_tertiary"]  = panel["SGDP_tertiary"]  / panel["GDP_tot"]

    # Defensive: drop years where any share is < 1e-3 or > 0.999 (log-ratio blow-up).
    valid = (
        (panel["sigma_primary"]   >= 1e-3) & (panel["sigma_primary"]   <= 0.999)
        & (panel["sigma_secondary"] >= 1e-3) & (panel["sigma_secondary"] <= 0.999)
        & (panel["sigma_tertiary"]  >= 1e-3) & (panel["sigma_tertiary"]  <= 0.999)
    )
    panel = panel[valid].copy()

    panel["eta_primary"]   = np.log(panel["sigma_primary"]   / panel["sigma_tertiary"])
    panel["eta_secondary"] = np.log(panel["sigma_secondary"] / panel["sigma_tertiary"])
    panel["log_y"]   = np.log(panel["GDP_pc"])
    panel["log_y_sq"] = panel["log_y"] ** 2
    panel["log_P"]   = np.log(panel["Pop"])

    # Time normalisation: subtract the panel-mean year so the ν coefficient
    # stays in interpretable units. Within FE absorbs the country-specific
    # offset; only the slope identifies ν.
    panel["year_norm"] = panel["Year"].astype(float) - panel["Year"].astype(float).mean()

    return panel


# ---------------------------------------------------------------------------
# Estimation (lifted from calibrate_priors.py)
# ---------------------------------------------------------------------------


def _fit_within_fe(
    df: pd.DataFrame,
    y_col: str,
    X_cols: list[str],
) -> tuple[np.ndarray, np.ndarray, int]:
    """One-way FE via within-country demeaning + OLS. Returns
    (coefs, hc1_se, n_obs)."""
    use = df.dropna(subset=[y_col] + X_cols).copy()
    if len(use) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0
    counts = use.groupby("iso3").size()
    keep = counts[counts >= 5].index
    use = use[use["iso3"].isin(keep)]
    if len(use) < 10:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0

    cols = [y_col] + X_cols
    means = use.groupby("iso3")[cols].transform("mean")
    dm = use[cols] - means
    y = dm[y_col].values
    X = dm[X_cols].values
    try:
        XtX_inv = np.linalg.inv(X.T @ X)
        beta = XtX_inv @ (X.T @ y)
        resid = y - X @ beta
        n = len(y)
        k = X.shape[1]
        S = (X * resid[:, None]).T @ (X * resid[:, None])
        var_hc1 = (n / (n - k)) * XtX_inv @ S @ XtX_inv
        se = np.sqrt(np.diag(var_hc1))
        return beta, se, n
    except np.linalg.LinAlgError:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0


def _cluster_bootstrap_fe(
    df: pd.DataFrame,
    y_col: str,
    X_cols: list[str],
    n_boot: int = 200,
    seed: int = 42,
) -> np.ndarray:
    """Country-clustered bootstrap; returns per-coefficient SE."""
    use = df.dropna(subset=[y_col] + X_cols).copy()
    if len(use) < 30:
        return np.full(len(X_cols), np.nan)
    countries = use["iso3"].unique()
    if len(countries) < 5:
        return np.full(len(X_cols), np.nan)
    rng = np.random.default_rng(seed)
    coefs = []
    for _ in range(n_boot):
        sampled = rng.choice(countries, size=len(countries), replace=True)
        parts = []
        for k, cc in enumerate(sampled):
            chunk = use[use["iso3"] == cc].copy()
            chunk["iso3"] = f"{cc}_{k}"
            parts.append(chunk)
        boot_df = pd.concat(parts, ignore_index=True)
        beta, _, _ = _fit_within_fe(boot_df, y_col, X_cols)
        if not np.isnan(beta).any():
            coefs.append(beta)
    if len(coefs) < n_boot // 2:
        return np.full(len(X_cols), np.nan)
    return np.asarray(coefs).std(axis=0, ddof=1)


# ---------------------------------------------------------------------------
# Regional calibration
# ---------------------------------------------------------------------------


# FE pass identifies β (log income) and ν (time trend).
X_COLS_FE = ["log_y", "year_norm"]
FE_PARAMS = ("beta", "nu")
# Pooled-OLS pass identifies γ (quadratic income) and μ (population scale).
# Includes log y as a regressor so γ is the *net* quadratic effect after
# controlling for the linear income effect.
X_COLS_POOLED = ["log_y", "log_y_sq", "log_P"]
POOLED_PARAMS_KEEP = ("gamma", "mu")        # we keep these two
POOLED_PARAMS_DISCARD = ("beta_pooled",)    # for diagnostic only


def _fit_pooled_ols_clustered(
    df: pd.DataFrame,
    y_col: str,
    X_cols: list[str],
) -> tuple[np.ndarray, np.ndarray, int]:
    """Pooled-OLS with intercept, country-clustered SE.

    Returns ([beta, gamma, mu], cluster_se, n_obs) — the same order as
    X_cols, NO intercept term reported (it's a nuisance parameter).
    """
    use = df.dropna(subset=[y_col] + X_cols + ["iso3"]).copy()
    if len(use) < 30 or use["iso3"].nunique() < 5:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0
    y = use[y_col].values
    X = np.column_stack([np.ones(len(use))] + [use[c].values for c in X_cols])
    try:
        XtX_inv = np.linalg.inv(X.T @ X)
        beta_full = XtX_inv @ (X.T @ y)
        resid = y - X @ beta_full
    except np.linalg.LinAlgError:
        return np.full(len(X_cols), np.nan), np.full(len(X_cols), np.nan), 0
    # Cluster-robust SE (Cameron-Gelbach-Miller). One score per cluster.
    G = use["iso3"].nunique()
    n = len(use)
    k = X.shape[1]
    score_sums = []
    for _, grp in use.groupby("iso3"):
        idx = grp.index.to_numpy() - use.index.min()
        idx = grp.index - use.index.min()
        # build positional mask via reset
    # Simpler: re-index and group on positions
    use_r = use.reset_index(drop=True)
    score_per_cluster = np.zeros((G, k))
    for gi, (_, grp) in enumerate(use_r.groupby("iso3")):
        idx = grp.index.values
        Xg = X[idx]
        rg = resid[idx]
        score_per_cluster[gi] = (Xg * rg[:, None]).sum(axis=0)
    meat = score_per_cluster.T @ score_per_cluster
    dof_adj = (G / (G - 1)) * ((n - 1) / (n - k))
    V = dof_adj * (XtX_inv @ meat @ XtX_inv)
    se_full = np.sqrt(np.maximum(np.diag(V), 0.0))
    return beta_full[1:], se_full[1:], n


def calibrate(panel: pd.DataFrame) -> dict:
    """Per region and per non-reference sector j, calibrate β, ν via
    within-FE; γ, μ via pooled-OLS with country-clustered SE."""
    all_params = FE_PARAMS + POOLED_PARAMS_KEEP
    point: dict = {p: {r: {} for r in REGIONS} for p in all_params}
    se: dict = {p: {r: {} for r in REGIONS} for p in all_params}
    n_obs: dict = {r: {} for r in REGIONS}

    for r in REGIONS:
        sub = panel[panel["mitica_region"] == r].copy()
        for j in NON_REF_SECTORS:
            y_col = f"eta_{j}"
            # ---- FE pass: β and ν ----
            coefs, _, n = _fit_within_fe(sub, y_col, X_COLS_FE)
            n_obs[r][j] = int(n)
            if np.isnan(coefs).any() or n < 100:
                for p in FE_PARAMS:
                    point[p][r][j] = None
                    se[p][r][j] = None
            else:
                for i, p in enumerate(FE_PARAMS):
                    point[p][r][j] = float(coefs[i])
                boot = _cluster_bootstrap_fe(sub, y_col, X_COLS_FE)
                for i, p in enumerate(FE_PARAMS):
                    v = boot[i]
                    se[p][r][j] = float(v) if not np.isnan(v) else None
            # ---- Pooled-OLS pass: γ and μ ----
            coefs_p, se_p, n_p = _fit_pooled_ols_clustered(
                sub, y_col, X_COLS_POOLED,
            )
            # coefs_p ordered as X_COLS_POOLED: [log_y, log_y_sq, log_P]
            if np.isnan(coefs_p).any() or n_p < 100:
                point["gamma"][r][j] = None
                point["mu"][r][j] = None
                se["gamma"][r][j] = None
                se["mu"][r][j] = None
            else:
                point["gamma"][r][j] = float(coefs_p[1])   # log_y_sq
                point["mu"][r][j]    = float(coefs_p[2])   # log_P
                se["gamma"][r][j]    = float(se_p[1])
                se["mu"][r][j]       = float(se_p[2])
    return {"point": point, "boot_se": se, "n_obs": n_obs}


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def print_comparison(calib: dict) -> None:
    point = calib["point"]
    se = calib["boot_se"]

    def _fmt(v: float | None, ss: float | None) -> str:
        if v is None:
            return "n/a"
        if ss is None:
            return f"{v:+.3f}"
        marker = "*" if abs(v / ss) > 2.0 else " "
        return f"{v:+.3f}({ss:.3f}){marker}"

    print("\n" + "=" * 95)
    print("Compositional B2 panel calibration -- WDI shares (tertiary = reference)")
    print("Specification: eta_j = alpha_c + beta_j log(y) + gamma_j (log y)^2 "
          "+ mu_j log(P) + nu_j (t - mean)")
    print("Within-country FE; bootstrap SE in (parentheses); * = |t|>2")
    print("=" * 95)

    for j in NON_REF_SECTORS:
        print(f"\n-- Sector {j} --")
        print(f"{'region':<10}  {'beta(FE)':>14}  {'nu(FE)':>14}  "
              f"{'gamma(pool)':>14}  {'mu(pool)':>14}  {'n':>5}")
        for r in REGIONS:
            n = calib["n_obs"][r].get(j, 0)
            beta = _fmt(point["beta"][r][j],  se["beta"][r][j])
            nu   = _fmt(point["nu"][r][j],    se["nu"][r][j])
            gamma = _fmt(point["gamma"][r][j], se["gamma"][r][j])
            mu   = _fmt(point["mu"][r][j],    se["mu"][r][j])
            print(f"{r:<10}  {beta:>14}  {nu:>14}  {gamma:>14}  "
                  f"{mu:>14}  {n:>5}")

    print("\n-- Comparison vs stylised priors (beta only) --")
    print(f"{'region':<10}  {'sector':<10}  {'stylised':>10}  {'calibrated':>12}  "
          f"{'delta':>8}")
    for r in REGIONS:
        for j in NON_REF_SECTORS:
            st = STYLISED["beta"][r][j]
            cal = point["beta"][r].get(j)
            if cal is None:
                line = f"{r:<10}  {j:<10}  {st:+10.3f}  {'n/a':>12}  {'n/a':>8}"
            else:
                line = (f"{r:<10}  {j:<10}  {st:+10.3f}  "
                        f"{cal:+12.3f}  {cal - st:+8.3f}")
            print(line)


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------


def write_json(calib: dict, path: Path) -> None:
    payload = {
        "_meta": {
            "source": ("World Bank WDI panel (cached); one-way country fixed "
                       "effects; HC1 SE; country-clustered bootstrap (200)"),
            "indicators": [
                "NY.GDP.PCAP.KD", "SP.POP.TOTL", "NY.GDP.MKTP.KD",
                "NV.AGR.TOTL.KD", "NV.IND.TOTL.KD", "NV.SRV.TOTL.KD",
            ],
            "year_range": [1960, 2024],
            "specification": (
                "η_j = α_c + β_j log(y) + γ_j (log y)^2 + μ_j log(P) "
                "+ ν_j (t - t_anchor_panel),  j ∈ {primary, secondary}, "
                "tertiary = reference. Matches the v3 compositional B2 "
                "equation in MACRO_v3_DESIGN.md §2.2.2."
            ),
            "min_obs_per_country": 5,
            "min_obs_per_region":  100,
        },
        "beta":  calib["point"]["beta"],
        "gamma": calib["point"]["gamma"],
        "mu":    calib["point"]["mu"],
        "nu":    calib["point"]["nu"],
        "boot_se": calib["boot_se"],
        "n_obs":   calib["n_obs"],
    }
    path.write_text(json.dumps(payload, indent=2))
    print(f"\nWrote compositional B2 priors to {path.resolve()}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    print("=== MITICA macro compositional B2 priors — WDI calibration ===\n")
    print("Loading panel ...")
    panel = load_panel()
    print(f"Panel size: {len(panel):,} country-year rows after share filtering")
    print(f"Countries:  {panel['iso3'].nunique()}")
    print(f"Years:      {int(panel['Year'].min())}-{int(panel['Year'].max())}")

    print("\nPer-region observation counts:")
    print(panel["mitica_region"].value_counts().to_string())

    print("\nRunning panel regressions (FE + bootstrap) ...")
    calib = calibrate(panel)

    print_comparison(calib)
    write_json(calib, OUT_PATH)


if __name__ == "__main__":
    main()
