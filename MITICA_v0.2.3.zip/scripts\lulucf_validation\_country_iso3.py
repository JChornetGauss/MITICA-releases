"""Country name -> ISO3 map for the BTR1 Parties (manual; no pycountry)."""

NAME2ISO3 = {
    "Albania": "ALB", "Algeria": "DZA", "Argentina": "ARG", "Armenia": "ARM",
    "Australia": "AUS", "Austria": "AUT", "Azerbaijan": "AZE", "Bahrain": "BHR",
    "Belarus": "BLR", "Belgium": "BEL", "Belize": "BLZ", "Bhutan": "BTN",
    "Brazil": "BRA", "Brunei Darussalam": "BRN", "Bulgaria": "BGR",
    "Burkina Faso": "BFA", "Burundi": "BDI", "Canada": "CAN", "Chile": "CHL",
    "China": "CHN", "Colombia": "COL", "Costa Rica": "CRI",
    "Côte d'Ivoire": "CIV", "Cote d'Ivoire": "CIV", "Croatia": "HRV",
    "Cuba": "CUB", "Cyprus": "CYP", "Czechia": "CZE", "Denmark": "DNK",
    "Ecuador": "ECU", "Egypt": "EGY", "Estonia": "EST", "Eswatini": "SWZ",
    "European Union": "EUU", "Finland": "FIN", "France": "FRA", "Gabon": "GAB",
    "Georgia": "GEO", "Germany": "DEU", "Ghana": "GHA", "Greece": "GRC",
    "Guatemala": "GTM", "Guinea-Bissau": "GNB", "Guyana": "GUY",
    "Holy See": "VAT", "Honduras": "HND", "Hungary": "HUN", "Iceland": "ISL",
    "India": "IND", "Indonesia": "IDN", "Iraq": "IRQ", "Ireland": "IRL",
    "Israel": "ISR", "Italy": "ITA", "Japan": "JPN", "Jordan": "JOR",
    "Kazakhstan": "KAZ", "Kenya": "KEN",
    "Lao People's Democratic Republic": "LAO", "Latvia": "LVA",
    "Lebanon": "LBN", "Liechtenstein": "LIE", "Lithuania": "LTU",
    "Luxembourg": "LUX", "Madagascar": "MDG", "Malaysia": "MYS",
    "Maldives": "MDV", "Malta": "MLT", "Mauritius": "MUS", "Mexico": "MEX",
    "Mongolia": "MNG", "Morocco": "MAR", "Namibia": "NAM", "Nepal": "NPL",
    "Netherlands": "NLD", "New Zealand": "NZL", "Nigeria": "NGA",
    "Norway": "NOR", "Oman": "OMN", "Pakistan": "PAK", "Panama": "PAN",
    "Paraguay": "PRY", "Peru": "PER", "Poland": "POL", "Portugal": "PRT",
    "Republic of Korea": "KOR", "Republic of Moldova": "MDA",
    "Russian Federation": "RUS", "Rwanda": "RWA", "Saudi Arabia": "SAU",
    "Serbia": "SRB", "Singapore": "SGP", "Slovakia": "SVK", "Slovenia": "SVN",
    "Solomon Islands": "SLB", "South Africa": "ZAF", "Spain": "ESP",
    "Sri Lanka": "LKA", "Sweden": "SWE", "Switzerland": "CHE",
    "Tajikistan": "TJK", "Thailand": "THA", "Tunisia": "TUN", "Türkiye": "TUR",
    "Turkiye": "TUR", "Tuvalu": "TUV", "Ukraine": "UKR",
    "United Arab Emirates": "ARE", "United Kingdom": "GBR",
    "United States of America": "USA", "Uruguay": "URY", "Uzbekistan": "UZB",
    "Venezuela": "VEN", "Zimbabwe": "ZWE",
}


def iso3(country: str) -> str | None:
    return NAME2ISO3.get(country.strip())
