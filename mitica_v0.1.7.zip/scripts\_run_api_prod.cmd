@echo off
rem Helper invoked by start.cmd -- runs the API in PRODUCTION mode (no --reload).
rem
rem Works both in dev mode (.venv in app\) and in installed mode (portable python).
rem All paths are relative to this script -- no hardcoded paths.
rem
rem Folder structure:
rem   <INSTDIR>\
rem     app\
rem       scripts\        <- this script (%~dp0)
rem       .venv\          <- Python virtual environment
rem     tools\
rem       python\         <- portable Python (installed mode)

setlocal EnableDelayedExpansion

rem Resolve paths relative to this script
for %%i in ("%~dp0..") do set "APP_DIR=%%~fi"
for %%i in ("%~dp0..\..") do set "INSTDIR=%%~fi"

cd /d "!APP_DIR!"
title MITICA API (production)

if "%MITICA_WORKERS%"=="" set MITICA_WORKERS=1

echo.
echo [MITICA API] starting uvicorn on http://127.0.0.1:8000  (workers=%MITICA_WORKERS%)
echo.

rem Priority order for Python:
rem   1. .venv inside app\ (both dev and installed mode)
rem   2. Portable Python in tools\python\ (fallback)
rem   3. System Python (dev mode fallback)
if exist "!APP_DIR!\.venv\Scripts\python.exe" (
    "!APP_DIR!\.venv\Scripts\python.exe" -m uvicorn mitica_api.main:app ^
        --host 127.0.0.1 --port 8000 ^
        --workers %MITICA_WORKERS% ^
        --proxy-headers
) else if exist "!INSTDIR!\tools\python\python.exe" (
    "!INSTDIR!\tools\python\python.exe" -m uvicorn mitica_api.main:app ^
        --host 127.0.0.1 --port 8000 ^
        --workers %MITICA_WORKERS% ^
        --proxy-headers
) else (
    python -m uvicorn mitica_api.main:app ^
        --host 127.0.0.1 --port 8000 ^
        --workers %MITICA_WORKERS% ^
        --proxy-headers
)

echo.
echo [MITICA API] server exited. Press any key to close this window.
pause >nul

endlocal
