"use client";

import { use, useMemo, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  ChevronDown, ChevronRight, Save, TrendingUp,
  BarChart2, CheckSquare, Square,
} from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import type { ActivityDataset, ActivityCategory, ProjectionResponse } from "@/lib/types";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const SECTOR_LABELS: Record<string, string> = {
  "1": "Energy", "2": "IPPU", "3": "Agriculture",
  "4": "LULUCF", "5": "Waste", "6": "Other",
};

const METHODS = [
  { value: "OLS",        label: "OLS — Linear trend",     desc: "Straight-line extrapolation.", hasParam: false },
  { value: "PCT_AUTO",   label: "Auto growth rate",        desc: "Geometric mean of last N years.", hasParam: false },
  { value: "PCT_MANUAL", label: "Manual growth rate (%)",  desc: "Fixed annual % you specify.", hasParam: true },
  { value: "ARIMA",      label: "ARIMA (1,1,1)",           desc: "Statistical time-series model.", hasParam: false },
  { value: "HOLT",       label: "Holt smoothing",          desc: "Adapts to recent trend shifts.", hasParam: false },
  { value: "FLAT",       label: "Flat (constant)",         desc: "Holds the last value constant.", hasParam: false },
];

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface SectorGroup {
  sectorKey: string;
  label: string;
  categories: ActivityCategory[];
}

// ---------------------------------------------------------------------------
// Build sector groups from ActivityDataset
// ---------------------------------------------------------------------------

function getSectorKey(code: string): string {
  return code.split(".")[0] ?? "other";
}

/** Replace individual values that are non-zero integer multiples of 1024 with null.
 *  These are CRT unit-conversion artefacts stored as data points.
 *  Replacing (not just filtering) preserves series that have real values
 *  for some years and artefact values for others. */
function sanitize1024(values: (number | null)[]): (number | null)[] {
  return values.map((v) => {
    if (v === null || !isFinite(v) || v === 0) return v;
    return Math.abs(v % 1024) < 1e-6 ? null : v;
  });
}

/** Returns true when the column is gas-specific (not a pure physical "no gas" variable).
 *  Old format: "HFC-125 | Filled into new manufactured products"
 *  New format: "HFC-125 · Filled into new manufactured products (t)"
 *  We keep only columns where the prefix before the separator is "no gas" or absent. */
function isGasSpecific(name: string): boolean {
  const pipeIdx = name.indexOf(" | ");
  const dotIdx  = name.indexOf(" · ");
  const sepIdx  = pipeIdx >= 0 ? pipeIdx : dotIdx;
  if (sepIdx < 0) return false;
  const prefix = name.slice(0, sepIdx).trim().toLowerCase();
  return prefix !== "no gas" && prefix !== "";
}

function buildSectorGroups(activity: ActivityDataset): SectorGroup[] {
  const map = new Map<string, ActivityCategory[]>();
  for (const cat of activity.categories) {
    const cleanColumns = cat.columns
      // 1. Drop gas-specific variables
      .filter((col) => !isGasSpecific(col.name))
      // 2. Replace individual 1024-multiple values with null
      .map((col) => ({ ...col, values: sanitize1024(col.values) }))
      // 3. Drop columns with no remaining real values
      .filter((col) => col.values.some((v) => v !== null && isFinite(v as number)));
    if (cleanColumns.length === 0) continue;
    const cleanCat = { ...cat, columns: cleanColumns };
    const key = getSectorKey(cat.ipcc_code);
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(cleanCat);
  }
  return Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b, undefined, { numeric: true }))
    .map(([key, cats]) => ({
      sectorKey: key,
      label: SECTOR_LABELS[key] ?? `Sector ${key}`,
      categories: cats.sort((a, b) =>
        a.ipcc_code.localeCompare(b.ipcc_code, undefined, { numeric: true })
      ),
    }));
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function ActivityPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);

  const { data: project } = useQuery({
    queryKey: ["project", id],
    queryFn: () => api.getProject(id),
  });

  const { data: activity, isLoading, error } = useQuery<ActivityDataset>({
    queryKey: ["activity", id],
    queryFn: () => api.getActivity(id),
    retry: false,
  });

  const sectorGroups = useMemo(
    () => (activity ? buildSectorGroups(activity) : []),
    [activity]
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground text-sm">
        Loading activity data…
      </div>
    );
  }

  if (error || !activity) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Activity Data</CardTitle>
          <CardDescription>
            Physical drivers extracted from your CRT JSON inventory.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
            <BarChart2 className="mx-auto mb-3 h-8 w-8 opacity-40" />
            <p className="font-medium text-foreground">No activity data yet</p>
            <p className="mt-1">
              Upload a <strong>CRT JSON</strong> in the Inventory tab to extract
              activity data automatically.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalCats = sectorGroups.reduce((s, g) => s + g.categories.length, 0);
  const totalVars = sectorGroups.reduce(
    (s, g) => s + g.categories.reduce((ss, c) => ss + c.columns.length, 0), 0
  );

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle>Activity Data</CardTitle>
              <CardDescription className="mt-1 max-w-xl">
                For each inventory category, choose which activity variables to use as
                forecast proxy, configure the projection model, preview and save.
              </CardDescription>
            </div>
            <Badge variant="success" className="ml-4 shrink-0">
              {totalCats} categories · {totalVars} variables
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {sectorGroups.map((group) => (
            <SectorPanel
              key={group.sectorKey}
              group={group}
              projectId={id}
              horizonYear={project?.horizon_year ?? new Date().getFullYear() + 10}
            />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// SectorPanel — collapsible sector accordion
// ---------------------------------------------------------------------------

function SectorPanel({
  group, projectId, horizonYear,
}: {
  group: SectorGroup;
  projectId: string;
  horizonYear: number;
}) {
  const [open, setOpen] = useState(true);
  const totalVars = group.categories.reduce((s, c) => s + c.columns.length, 0);

  return (
    <div className="rounded-md border overflow-hidden">
      <div
        className="flex items-center gap-2 px-4 py-2.5 bg-muted/40 cursor-pointer select-none hover:bg-muted/60 transition-colors"
        onClick={() => setOpen((o) => !o)}
      >
        {open
          ? <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
          : <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
        }
        <span className="font-semibold text-sm">{group.label}</span>
        <span className="text-xs text-muted-foreground">
          {group.categories.length} categories · {totalVars} variables
        </span>
      </div>
      {open && (
        <div className="divide-y">
          {group.categories.map((cat) => (
            <CategoryRow
              key={cat.ipcc_code}
              cat={cat}
              projectId={projectId}
              horizonYear={horizonYear}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// CategoryRow — one row per IPCC category
// ---------------------------------------------------------------------------

function CategoryRow({
  cat, projectId, horizonYear,
}: {
  cat: ActivityCategory;
  projectId: string;
  horizonYear: number;
}) {
  const [expanded, setExpanded]           = useState(false);
  const [method, setMethod]               = useState("OLS");
  const [ratePct, setRatePct]             = useState("2");
  const [selectedVars, setSelectedVars]   = useState<Set<string>>(
    () => new Set(cat.columns.map((c) => c.name))
  );
  const [previewVar, setPreviewVar]       = useState(cat.columns[0]?.name ?? "");
  const [preview, setPreview]             = useState<ProjectionResponse | null>(null);
  const [savedVars, setSavedVars]         = useState<Set<string>>(new Set());

  const methodMeta = METHODS.find((m) => m.value === method)!;
  const selectedList = Array.from(selectedVars);
  const allSaved = selectedList.length > 0 && selectedList.every((v) => savedVars.has(v));

  const fmt = (v: number | null) =>
    v === null ? "—" : v.toLocaleString("es-ES", { maximumFractionDigits: 2 });

  const { mutate: runPreview, isPending: previewing } = useMutation({
    mutationFn: () =>
      api.projectActivity(projectId, {
        ipcc_code: cat.ipcc_code,
        column: previewVar,
        method,
        horizon_year: horizonYear,
        rate_pct: method === "PCT_MANUAL" ? parseFloat(ratePct) : undefined,
      }),
    onSuccess: setPreview,
  });

  const { mutate: saveProxies, isPending: saving } = useMutation({
    mutationFn: () =>
      Promise.all(
        selectedList.map((varName) => {
          const safe = varName.toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 30);
          const code = cat.ipcc_code.replace(/\./g, "_");
          return api.saveActivityAsProxy(projectId, {
            ipcc_code: cat.ipcc_code,
            column: varName,
            method,
            horizon_year: horizonYear,
            rate_pct: method === "PCT_MANUAL" ? parseFloat(ratePct) : undefined,
            proxy_name: `act_${code}_${safe}`.slice(0, 50),
          });
        })
      ),
    onSuccess: () => setSavedVars(new Set(selectedList)),
  });

  function toggleVar(name: string) {
    const next = new Set(selectedVars);
    next.has(name) ? next.delete(name) : next.add(name);
    setSelectedVars(next);
    setPreview(null);
  }

  return (
    <div>
      {/* Row header */}
      <div className="flex items-center gap-3 px-4 py-2.5">
        <span className="font-mono text-sm font-semibold w-24 shrink-0">
          {cat.ipcc_code}
        </span>

        {/* Variable chips — inline preview of available variables */}
        <div className="flex-1 flex flex-wrap gap-1.5">
          {cat.columns.map((col) => (
            <span
              key={col.name}
              className="inline-flex items-center rounded-full border px-2 py-0.5 text-xs text-muted-foreground"
            >
              {col.name}
            </span>
          ))}
        </div>

        {allSaved && (
          <Badge variant="success" className="text-xs shrink-0">Saved ✓</Badge>
        )}
        <button
          onClick={() => setExpanded((e) => !e)}
          className="text-xs text-primary hover:underline shrink-0 inline-flex items-center gap-1"
        >
          {expanded
            ? <><ChevronDown className="h-3.5 w-3.5" /> Close</>
            : <><ChevronRight className="h-3.5 w-3.5" /> Configure</>
          }
        </button>
      </div>

      {/* Configure panel */}
      {expanded && (
        <div className="mx-4 mb-4 rounded-lg border bg-muted/20 p-4 space-y-4">

          {/* Variable selector — which to use as proxy */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-medium">
                Use as proxy ({selectedVars.size} / {cat.columns.length} selected)
              </Label>
              <button
                className="text-xs text-primary hover:underline"
                onClick={() => {
                  const all = cat.columns.map((c) => c.name);
                  setSelectedVars(
                    selectedVars.size === all.length ? new Set() : new Set(all)
                  );
                }}
              >
                {selectedVars.size === cat.columns.length ? "Deselect all" : "Select all"}
              </button>
            </div>
            <div className="rounded-md border bg-background overflow-hidden">
              {cat.columns.map((col) => {
                const isSel = selectedVars.has(col.name);
                const isSaved = savedVars.has(col.name);
                const validVals = col.values.filter(
                  (v): v is number => v !== null && isFinite(v)
                );
                return (
                  <div
                    key={col.name}
                    onClick={() => toggleVar(col.name)}
                    className={`flex items-center gap-2.5 px-3 py-2 cursor-pointer transition-colors border-b last:border-0 ${
                      isSel ? "bg-primary/5 hover:bg-primary/10" : "hover:bg-muted/40"
                    }`}
                  >
                    {isSel
                      ? <CheckSquare className="h-3.5 w-3.5 text-primary shrink-0" />
                      : <Square className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    }
                    <span className="text-sm flex-1">{col.name}</span>
                    <span className="text-xs text-muted-foreground shrink-0">
                      {col.years[0]}–{col.years[col.years.length - 1]}
                      {" · "}{validVals.length} values
                    </span>
                    {isSaved && (
                      <span className="text-xs text-emerald-600 shrink-0">✓ saved</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Projection model */}
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label className="text-xs">Projection method</Label>
              <Select value={method} onValueChange={(v) => { setMethod(v); setPreview(null); }}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {METHODS.map((m) => (
                    <SelectItem key={m.value} value={m.value} className="text-xs">
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">{methodMeta.desc}</p>
            </div>

            {methodMeta.hasParam && (
              <div className="space-y-1">
                <Label className="text-xs">Growth rate (%/yr)</Label>
                <Input
                  type="number" step="0.1" value={ratePct}
                  onChange={(e) => { setRatePct(e.target.value); setPreview(null); }}
                  className="h-8 text-xs"
                />
              </div>
            )}

            {/* Preview variable selector when category has multiple variables */}
            {cat.columns.length > 1 && (
              <div className="space-y-1">
                <Label className="text-xs">Preview variable</Label>
                <Select
                  value={previewVar}
                  onValueChange={(v) => { setPreviewVar(v); setPreview(null); }}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-48">
                    {cat.columns.map((c) => (
                      <SelectItem key={c.name} value={c.name} className="text-xs">
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              variant="outline" size="sm" className="h-8 text-xs"
              disabled={previewing || !previewVar}
              onClick={() => runPreview()}
            >
              <TrendingUp className="mr-1.5 h-3.5 w-3.5" />
              {previewing ? "Projecting…" : "Preview"}
            </Button>
            <Button
              size="sm" className="h-8 text-xs"
              disabled={saving || selectedVars.size === 0}
              onClick={() => saveProxies()}
            >
              <Save className="mr-1.5 h-3.5 w-3.5" />
              {saving
                ? "Saving…"
                : `Save ${selectedVars.size} ${selectedVars.size === 1 ? "proxy" : "proxies"}`
              }
            </Button>
          </div>

          {/* Preview table */}
          {preview && (
            <div className="rounded border overflow-hidden text-xs">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-muted/40 border-b font-medium">
                {preview.method}
                {Object.entries(preview.params_used)
                  .filter(([k]) => !k.includes("fallback"))
                  .slice(0, 3)
                  .map(([k, v]) => (
                    <span key={k} className="text-muted-foreground font-normal">
                      {k}: <strong>
                        {typeof v === "number" ? v.toFixed(3) : String(v)}
                      </strong>
                    </span>
                  ))}
                <span className="ml-auto text-muted-foreground font-normal">
                  {previewVar}
                </span>
              </div>
              <div className="max-h-52 overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-background border-b">
                    <tr>
                      <th className="text-left px-3 py-1.5 font-medium">Year</th>
                      <th className="text-right px-3 py-1.5 font-medium">Historical</th>
                      <th className="text-right px-3 py-1.5 font-medium">Projected</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {preview.series
                      .filter((s) => s.historical !== null)
                      .slice(-5)
                      .map((row) => (
                        <tr key={row.year} className="text-muted-foreground">
                          <td className="px-3 py-1">{row.year}</td>
                          <td className="px-3 py-1 text-right">{fmt(row.historical)}</td>
                          <td className="px-3 py-1 text-right opacity-40">—</td>
                        </tr>
                      ))}
                    <tr className="bg-primary/5">
                      <td colSpan={3} className="px-3 py-1 text-primary font-medium">
                        ↓ projected to {horizonYear}
                      </td>
                    </tr>
                    {preview.series
                      .filter((s) => s.projected !== null)
                      .map((row) => (
                        <tr key={row.year}>
                          <td className="px-3 py-1">{row.year}</td>
                          <td className="px-3 py-1 text-right opacity-40">—</td>
                          <td className="px-3 py-1 text-right font-medium">
                            {fmt(row.projected)}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
