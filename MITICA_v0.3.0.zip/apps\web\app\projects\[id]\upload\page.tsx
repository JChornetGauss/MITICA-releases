// This route is handled by the parent [id]/page.tsx
// Keeping this file to avoid broken links from older bookmarks.
export { default } from "../page";
