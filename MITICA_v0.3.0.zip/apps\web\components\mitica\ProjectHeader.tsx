"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import { ArrowLeft, Pencil, Check, X } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";

import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Project } from "@/lib/types";

export function ProjectHeader({ project }: { project: Project }) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<string>("");
  const inputRef = useRef<HTMLInputElement>(null);

  const { mutate: saveHorizon, isPending } = useMutation({
    mutationFn: (year: number) =>
      api.patchProject(project.id, { horizon_year: year }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["project", project.id] });
      qc.invalidateQueries({ queryKey: ["projects"] });
      setEditing(false);
    },
  });

  function startEdit() {
    setDraft(String(project.horizon_year ?? new Date().getFullYear() + 10));
    setEditing(true);
    // Focus after render
    setTimeout(() => inputRef.current?.select(), 0);
  }

  function commit() {
    const year = parseInt(draft, 10);
    if (!isNaN(year) && year >= 2020 && year <= 2100) {
      saveHorizon(year);
    } else {
      cancel();
    }
  }

  function cancel() {
    setEditing(false);
  }

  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
      <div>
        <Link
          href="/"
          className="mb-2 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" /> All projects
        </Link>
        <h1 className="text-2xl font-bold tracking-tight">{project.name}</h1>
        <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
          <Badge variant="outline">{project.country_code}</Badge>

          {/* Editable horizon year */}
          {editing ? (
            <span className="inline-flex items-center gap-1">
              <span className="text-xs">horizon</span>
              <input
                ref={inputRef}
                type="number"
                value={draft}
                min={2020}
                max={2100}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") commit();
                  if (e.key === "Escape") cancel();
                }}
                onBlur={commit}
                disabled={isPending}
                className="w-20 rounded border border-input bg-background px-2 py-0.5 text-xs font-medium text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <button
                onMouseDown={(e) => { e.preventDefault(); commit(); }}
                className="text-emerald-600 hover:text-emerald-700"
              >
                <Check className="h-3.5 w-3.5" />
              </button>
              <button
                onMouseDown={(e) => { e.preventDefault(); cancel(); }}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </span>
          ) : (
            <button
              onClick={startEdit}
              className="inline-flex items-center gap-1 hover:text-foreground transition-colors group"
              title="Click to edit horizon year"
            >
              <span>
                {project.horizon_year
                  ? `horizon ${project.horizon_year}`
                  : "set horizon year"}
              </span>
              <Pencil className="h-3 w-3 opacity-0 group-hover:opacity-60 transition-opacity" />
            </button>
          )}

          {project.reference_year && (
            <span>· ref {project.reference_year}</span>
          )}
        </div>
        {project.description && (
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            {project.description}
          </p>
        )}
      </div>

      <div className="flex gap-2">
        <Button asChild variant="outline" size="sm">
          <a
            href={`/api/v1/projects/${project.id}/forecast`}
            target="_blank"
            rel="noreferrer"
          >
            Forecast JSON
          </a>
        </Button>
      </div>
    </div>
  );
}
