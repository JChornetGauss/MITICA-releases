"use client";

import { use, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { ArrowRight, BarChart2, AlertTriangle, X, CheckCircle2 } from "lucide-react";

import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadBox } from "@/components/mitica/UploadBox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

// ---------------------------------------------------------------------------
// Confirmation dialog
// ---------------------------------------------------------------------------

function ConfirmSwitchDialog({
  fromSource,
  toLabel,
  hasActivity,
  onConfirm,
  onCancel,
}: {
  fromSource: string;
  toLabel: string;
  hasActivity: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-xl border bg-background shadow-xl p-6 space-y-4">
        <button onClick={onCancel} className="absolute right-4 top-4 text-muted-foreground hover:text-foreground">
          <X className="h-4 w-4" />
        </button>
        <div className="flex items-start gap-3">
          <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-600">
            <AlertTriangle className="h-4 w-4" />
          </div>
          <div className="space-y-1">
            <p className="font-semibold">Switch inventory format?</p>
            <p className="text-sm text-muted-foreground">
              Current inventory: <strong>{fromSource}</strong>. Switching to{" "}
              <strong>{toLabel}</strong> will replace all inventory rows.
            </p>
            {hasActivity && (
              <p className="text-sm text-amber-700 bg-amber-50 rounded-md px-3 py-2 mt-2">
                ⚠️ Activity Data extracted from the CRT JSON will also be removed,
                including any proxies derived from it.
              </p>
            )}
          </div>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" size="sm" onClick={onCancel}>Keep current</Button>
          <Button size="sm" onClick={onConfirm}>Switch format</Button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// ActiveFormatBadge — shown inside the box that is the current active format
// ---------------------------------------------------------------------------

function ActiveBadge({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
      <CheckCircle2 className="h-3.5 w-3.5" />
      Active — {label}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------

export default function UploadPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();

  const { data: project } = useQuery({
    queryKey: ["project", id],
    queryFn: () => api.getProject(id),
  });

  // Derived from server state — which format is stored
  const activeSource = project?.inventory_source ?? null;   // "Excel" | "JSON" | null
  const hasActivity  = project?.has_activity ?? false;
  const invYears     = project?.inventory_years ?? null;

  async function invalidate() {
    await qc.invalidateQueries({ queryKey: ["project", id] });
    await qc.invalidateQueries({ queryKey: ["projects"] });
    await qc.invalidateQueries({ queryKey: ["activity", id] });
  }

  // Shared confirmation dialog state — lifted here so only one dialog exists
  const [confirmPending, setConfirmPending] = useState<{
    toLabel: string;
    upload: () => Promise<void>;
  } | null>(null);

  function requestUpload(
    thisSource: string,
    toLabel: string,
    upload: () => Promise<void>,
  ) {
    const needsConfirm = !!activeSource && activeSource !== thisSource;
    if (needsConfirm) {
      setConfirmPending({ toLabel, upload });
    } else {
      upload();
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">

      {/* Confirmation dialog (single, at page level) */}
      {confirmPending && (
        <ConfirmSwitchDialog
          fromSource={activeSource!}
          toLabel={confirmPending.toLabel}
          hasActivity={hasActivity}
          onConfirm={async () => {
            const fn = confirmPending.upload;
            setConfirmPending(null);
            await fn();
          }}
          onCancel={() => setConfirmPending(null)}
        />
      )}

      {/* ── Inventory ─────────────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle>Inventory</CardTitle>
              <CardDescription>
                Three ways to feed MITICA the historical inventory. Pick one — the
                per-gas option is <strong>recommended</strong> because it unlocks
                gas-level projections (BI-001).
              </CardDescription>
            </div>
            {invYears && (
              <Badge variant="outline" className="shrink-0 text-xs">{invYears}</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">

          {/* CO2eq */}
          <div className="space-y-1.5">
            {activeSource === "Excel" && <ActiveBadge label="Excel inventory" />}
            <UploadBox
              label="Single file — CO₂-eq aggregate"
              description={
                activeSource && activeSource !== "Excel"
                  ? "One .xlsx, single sheet. Switching will replace the current inventory."
                  : "One .xlsx with a single sheet: either MITICA template or simple shape (ipcc_code | years). No gas decomposition."
              }
              accept=".xlsx,.xls,.xlsm"
              uploaded={activeSource === "Excel"}
              onUpload={(f) => {
                requestUpload("Excel", "Excel (CO₂-eq)", async () => {
                  await api.uploadInventoryExcel(id, f);
                  await invalidate();
                });
                return Promise.resolve();
              }}
            />
          </div>

          {/* Multi-gas */}
          <div className="space-y-1.5">
            <UploadBox
              label="Single file — multi-gas (MITICA template)"
              description={
                activeSource && activeSource !== "Excel"
                  ? "One .xlsx with one sheet per gas. Switching will replace the current inventory."
                  : "One .xlsx with one sheet per gas (CO2, CH4, N2O, SF6, NF3, HFC, PFC). Values in kt CO2-eq."
              }
              accept=".xlsx,.xls,.xlsm"
              uploaded={activeSource === "Excel"}
              onUpload={(f) => {
                requestUpload("Excel", "Excel (multi-gas)", async () => {
                  await api.uploadInventoryExcel(id, f);
                  await invalidate();
                });
                return Promise.resolve();
              }}
            />
          </div>

          {/* Per-gas */}
          <PerGasUpload
            projectId={id}
            activeSource={activeSource}
            hasActivity={hasActivity}
            onRequestUpload={requestUpload}
            onDone={invalidate}
          />

          {/* CRT JSON */}
          <div className="space-y-1.5">
            {activeSource === "JSON" && <ActiveBadge label="IPCC CRT JSON" />}
            <UploadBox
              label="IPCC CRT JSON"
              description={
                activeSource && activeSource !== "JSON"
                  ? "IPCC Inventory Software export. Switching will replace the current inventory."
                  : "IPCC Inventory Software export (IPCC-CRT-v1.0 schema). Activity Data is extracted automatically."
              }
              accept=".json"
              uploaded={activeSource === "JSON"}
              onUpload={(f) => {
                requestUpload("JSON", "IPCC CRT JSON", async () => {
                  await api.uploadInventoryCRT(id, f);
                  await invalidate();
                });
                return Promise.resolve();
              }}
            />
            {/* Activity Data link */}
            {(activeSource === "JSON" || hasActivity) && (
              <div className="flex items-center justify-end px-1 pt-0.5">
                <Link
                  href={`/projects/${id}/activity`}
                  className="inline-flex items-center gap-1.5 text-xs text-primary hover:underline"
                >
                  <BarChart2 className="h-3.5 w-3.5" />
                  View Activity Data
                  <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            )}
          </div>

        </CardContent>
      </Card>

      {/* ── Proxies ───────────────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle>Proxies</CardTitle>
          <CardDescription>
            Two-column file with <code>Year | value</code> (Excel or CSV).{" "}
            <strong>GDP</strong> and <strong>population</strong> are mandatory;
            sectoral proxies are optional and matched automatically to each IPCC
            category.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <UploadBox
            label="GDP (mandatory)"
            description="Year | GDP  (.xlsx or .csv)"
            accept=".xlsx,.xls,.xlsm,.csv"
            onUpload={async (f) => {
              await api.uploadProxy(id, f, { name: "gdp", mandatory: true, unit: "USD" });
              await invalidate();
            }}
          />
          <UploadBox
            label="Population (mandatory)"
            description="Year | Population  (.xlsx or .csv)"
            accept=".xlsx,.xls,.xlsm,.csv"
            onUpload={async (f) => {
              await api.uploadProxy(id, f, { name: "pop", mandatory: true, unit: "people" });
              await invalidate();
            }}
          />
          <SectoralProxyUpload projectId={id} onDone={invalidate} />

          {/* Activity Data proxies — only when CRT JSON was used */}
          {hasActivity && (
            <div className="rounded-md border border-primary/20 bg-primary/5 p-3 space-y-2">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold">Activity Data proxies</p>
                  <p className="text-xs text-muted-foreground">
                    Project any activity variable to{" "}
                    {project?.horizon_year ?? "horizon year"} and use it as a
                    forecast driver.
                  </p>
                </div>
                <Button asChild size="sm" variant="outline" className="shrink-0">
                  <Link href={`/projects/${id}/activity`}>
                    <BarChart2 className="mr-1.5 h-3.5 w-3.5" />
                    Manage
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Footer ────────────────────────────────────────────────────── */}
      <div className="md:col-span-2 flex items-center justify-between rounded-lg border bg-card p-4">
        <div className="flex items-center gap-3 text-sm">
          <Badge variant={project?.has_inventory ? "success" : "outline"}>
            {project?.has_inventory ? "Inventory ✓" : "Inventory missing"}
          </Badge>
          <span className="text-muted-foreground">
            At least GDP + Population are required before forecasting.
          </span>
        </div>
        <Button asChild disabled={!project?.has_inventory}>
          <Link href={`/projects/${id}/forecast`}>
            Next: Forecast <ArrowRight className="ml-2 h-3 w-3" />
          </Link>
        </Button>
      </div>

    </div>
  );
}

// ---------------------------------------------------------------------------
// PerGasUpload
// ---------------------------------------------------------------------------

const GAS_CHOICES = [
  { value: "CO2",  label: "CO₂ — Carbon dioxide" },
  { value: "CH4",  label: "CH₄ — Methane" },
  { value: "N2O",  label: "N₂O — Nitrous oxide" },
  { value: "HFCs", label: "HFCs — Hydrofluorocarbons (agg.)" },
  { value: "PFCs", label: "PFCs — Perfluorocarbons (agg.)" },
  { value: "SF6",  label: "SF₆ — Sulfur hexafluoride" },
  { value: "NF3",  label: "NF₃ — Nitrogen trifluoride" },
];

function PerGasUpload({
  projectId,
  activeSource,
  hasActivity,
  onRequestUpload,
  onDone,
}: {
  projectId: string;
  activeSource: string | null;
  hasActivity: boolean;
  onRequestUpload: (source: string, label: string, upload: () => Promise<void>) => void;
  onDone: () => void;
}) {
  const [selectedGas, setSelectedGas] = useState("CO2");

  return (
    <div className="rounded-md border p-3 space-y-2">
      {activeSource === "PerGas" && (
        <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
          <CheckCircle2 className="h-3.5 w-3.5" />
          Active — per-gas files
        </div>
      )}
      <p className="text-sm font-medium">Per-gas files (recommended for BI-001)</p>
      <p className="text-xs text-muted-foreground">
        Upload one Excel per gas. Values in <strong>kt CO₂-eq</strong> (mass × GWP).
        Each gas is merged; re-uploading overwrites it.
        {activeSource && activeSource !== "PerGas" && (
          <span className="ml-1 text-amber-600">
            Uploading will replace the current {activeSource} inventory.
          </span>
        )}
      </p>
      <select
        className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
        value={selectedGas}
        onChange={(e) => setSelectedGas(e.target.value)}
      >
        {GAS_CHOICES.map((g) => (
          <option key={g.value} value={g.value}>{g.label}</option>
        ))}
      </select>
      <UploadBox
        label={`Upload ${selectedGas} sheet`}
        description="col B = IPCC code, cols G+ = years in kt CO2-eq"
        accept=".xlsx,.xls,.xlsm"
        uploaded={activeSource === "PerGas"}
        onUpload={(f) => {
          onRequestUpload("PerGas", "Per-gas files", async () => {
            await api.uploadInventoryGasSheet(projectId, selectedGas, f);
            onDone();
          });
          return Promise.resolve();
        }}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// SectoralProxyUpload
// ---------------------------------------------------------------------------

function SectoralProxyUpload({ projectId, onDone }: { projectId: string; onDone: () => void }) {
  const { data: proxyCatalog } = useQuery({
    queryKey: ["proxy-catalog"],
    queryFn: () => api.proxyCatalog(),
    staleTime: Infinity,
  });

  const [sector, setSector] = useState("Energy");
  const [preset, setPreset] = useState("");
  const [customName, setCustomName] = useState("");

  const presets = proxyCatalog?.[sector] ?? [];
  const activeName = preset === "__custom__" ? customName.trim() : preset;
  const activePreset = presets.find((p) => p.name === preset);
  const activeUnit = activePreset?.unit ?? null;

  useEffect(() => {
    setPreset(proxyCatalog?.[sector]?.[0]?.name ?? "__custom__");
  }, [sector, proxyCatalog]);

  return (
    <div className="rounded-md border p-3 space-y-2">
      <p className="text-sm font-medium">Sectoral proxy (optional)</p>
      <div className="grid grid-cols-2 gap-2">
        <select
          className="h-10 rounded-md border border-input bg-background px-3 text-sm"
          value={sector}
          onChange={(e) => setSector(e.target.value)}
        >
          <option value="Energy">Energy</option>
          <option value="IPPU">IPPU</option>
          <option value="LULUCF">LULUCF</option>
          <option value="Agri">Agriculture</option>
          <option value="Waste">Waste</option>
        </select>
        <select
          className="h-10 rounded-md border border-input bg-background px-3 text-sm"
          value={preset}
          onChange={(e) => setPreset(e.target.value)}
        >
          {presets.map((p) => (
            <option key={p.name} value={p.name}>{p.label} ({p.unit})</option>
          ))}
          <option value="__custom__">— Other —</option>
        </select>
      </div>
      {preset === "__custom__" && (
        <input
          className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          value={customName}
          onChange={(e) => setCustomName(e.target.value)}
          placeholder="custom proxy name"
        />
      )}
      <UploadBox
        label={activeName ? `Upload "${activeName}"` : "Sectoral proxy"}
        description={
          activeName
            ? `Year | ${activeName}${activeUnit ? ` (${activeUnit})` : ""}  —  .xlsx or .csv`
            : "Pick a preset or type a name first"
        }
        accept=".xlsx,.xls,.xlsm,.csv"
        onUpload={async (f) => {
          if (!activeName) throw new Error("Proxy name required");
          await api.uploadProxy(projectId, f, {
            name: activeName, sector, mandatory: false, unit: activeUnit,
          });
          onDone();
        }}
      />
    </div>
  );
}
